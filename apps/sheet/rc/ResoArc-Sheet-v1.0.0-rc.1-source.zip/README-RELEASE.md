# ResoArc Sheet v1.0.0-rc.1 (release candidate)

This is an unsigned release candidate, not a stable release.
It exposes four explicit save formats: preserved XLSX, simplified XLSX, CSV, JSON. Advanced features are not fully editable; simplified XLSX may discard them after explicit approval.
ResoArc Sheet is not Microsoft Excel, and it does not guarantee full compatibility with Excel workbooks. Test important files and keep originals.
Earlier releases and original samples remain intact. This RC must pass all required acceptance gates before stable release.

How to use:
- Double-click ResoArc-Sheet.html in recent Edge, Chrome, or Firefox.
- Use the file picker to load XLSX or CSV; original files are not overwritten.
- The editor runs locally without sending spreadsheet data to a server.
- Save an edited copy. For critical spreadsheets, open the copy in Excel
  and verify formulas, formatting, charts, and advanced features.

Compatibility boundaries:
- Not an implementation of all Excel workbook features.
- Protected sheets reject edits and sorting. Filtered sheets reject insertion.
- XLSX dimension updates must complete or report failure before restructuring.
- Sorting rejects formulas, merges, existing filters, and some advanced
  metadata; row 1 is treated as the header.
- The search/name-box target is shown, but the grid selection outline is not
  synchronized to that target.
- Pasted/copied formula-looking text may require additional verification in
  Microsoft Excel. Clipboard APIs vary across browsers.
- Macro-capable and legacy formats are unsupported.

Attribution:
- Direct dependency ExcelJS 4.4.0 was added; the package was already a transitive dependency;
  the project/root version changed to 1.0.0-rc.1.
- The prior third-party license texts and review ledger are retained.
- The previous 68 embedded vendor attributions include nine entries whose
  exact original-source editions were not established byte-for-byte.
- The old license inventory is inherited, not independently re-certified
  for every newly generated minified bundle.

See THIRD_PARTY_NOTICES.md and VENDOR_ORIGIN_REVIEW.json, and retain all
files under licenses/ when redistributing the release.
