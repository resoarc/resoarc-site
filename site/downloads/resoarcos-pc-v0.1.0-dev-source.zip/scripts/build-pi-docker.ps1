# Build a Pi 4 or Pi 5 ARM64 IMG from Windows using a disposable Debian Docker container.
# Only the final IMG and checksum are exported to out/pi-images.
param([ValidateSet('4','5')][string]$Model = '5')
$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Reference = Join-Path $Repo 'out\rpi-image-gen-reference'
if (-not (Test-Path (Join-Path $Reference 'rpi-image-gen'))) {
    throw 'Clone the official raspberrypi/rpi-image-gen repo into out\rpi-image-gen-reference first.'
}
$Name = 'resoarc-pi' + $Model + '-builder'
$Existing = docker ps -a --filter ('name=^/' + $Name + '$') --format '{{.ID}}'
if ($Existing) { throw ('A previous builder exists: ' + $Name + '. Inspect its logs first.') }
$DockerArgs = @(
    'run', '--name', $Name, '--pull=never',
    '--privileged', '--cpus=2', '--memory=6g',
    '-v', ($Repo + ':/repo'),
    '-v', ($Reference + ':/reference:ro'),
    '-e', ('RESOARC_MODEL=' + $Model),
    'debian:trixie-slim', 'bash', '/repo/scripts/build-pi-inside-container.sh'
)
& docker @DockerArgs
if ($LASTEXITCODE -ne 0) {
    throw ('IMG build failed. Inspect with: docker logs ' + $Name)
}
Write-Output ('Final image: ' + (Join-Path $Repo ('out\pi-images\resoarcos-pi' + $Model + '-arm64.img')))
