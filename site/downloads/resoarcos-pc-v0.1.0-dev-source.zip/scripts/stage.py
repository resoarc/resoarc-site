#!/usr/bin/env python3
"""Stage portable ResoArcOS files into a target root filesystem directory."""
from __future__ import annotations
import argparse
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def stage(destination: Path) -> None:
    destination = destination.resolve()
    if destination == Path(destination.anchor):
        raise ValueError("Refusing to stage into a filesystem root")
    source = ROOT / "src" / "resoarcos"
    library = destination / "usr/local/lib/resoarcos"
    library.mkdir(parents=True, exist_ok=True)
    for file in source.rglob("*"):
        if file.is_file() and "__pycache__" not in file.parts:
            target = library / file.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file, target)
            # Normalize permissions: Windows bind mounts can report 0777.
            # Root-managed CLI code and profile data must not be writable by users.
            target.chmod(0o644)

    bin_dir = destination / "usr/local/bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    launchers = {
        "resoarc": "#!/bin/sh\nexec /usr/bin/python3 -I -c 'import sys; sys.path.insert(0, \"/usr/local/lib\"); from resoarcos.cli import main; raise SystemExit(main())' \"$@\"\n",
        "resogui": '''#!/bin/sh
set -eu
if [ -n "${SSH_CONNECTION:-}" ] || [ -n "${SSH_TTY:-}" ]; then
    echo "resogui requires a physical terminal, not SSH" >&2
    exit 2
fi
if [ ! -t 0 ] || [ -n "${DISPLAY:-}" ]; then
    echo "Run resogui from a Linux virtual console (TTY)" >&2
    exit 2
fi
if ! command -v startx >/dev/null 2>&1; then
    echo "GUI packages missing: install xinit xserver-xorg openbox pcmanfm xterm" >&2
    exit 2
fi
exec startx /usr/local/bin/resoarc-desktop -- -nolisten tcp
''',
        "resoarc-desktop": '''#!/bin/sh
set -eu
pcmanfm --desktop >/dev/null 2>&1 &
xterm >/dev/null 2>&1 &
exec openbox-session
''',
    }
    for name, data in launchers.items():
        target = bin_dir / name
        target.write_text(data, encoding="utf-8", newline="\n")
        target.chmod(0o755)
    settings = destination / "etc/resoarc"
    settings.mkdir(parents=True, exist_ok=True)
    (settings / "release").write_text("RESOARC_VERSION=0.1.0-dev\nRESOARC_BASE=Debian-13\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    stage(args.destination)
    print("Staged ResoArcOS into " + str(args.destination))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())