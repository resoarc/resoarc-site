#!/usr/bin/env bash
# Invoked INSIDE the resource-limited Docker build container.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
echo "[ResoArc] Installing build prerequisites"
apt-get update -qq
apt-get install -y -qq --no-install-recommends ca-certificates git arch-test qemu-user-static binfmt-support debian-archive-keyring bash python3 python3-yaml python3-debian dpkg-dev mmdebstrap podman uidmap dbus-user-session zip dosfstools e2fsprogs grep rsync curl xz-utils mtools pv btrfs-progs dctrl-tools uuid-runtime fdisk python3-jsonschema cryptsetup python3-pip make build-essential autoconf automake libtool autopoint flex gettext pkgconf
mountpoint -q /proc/sys/fs/binfmt_misc || mount -t binfmt_misc binfmt_misc /proc/sys/fs/binfmt_misc
if [ ! -f /proc/sys/fs/binfmt_misc/aarch64 ]; then
    echo '[ResoArc] Missing active aarch64 binfmt; refusing broken cross-build' >&2
    exit 8
fi
arch-test arm64 || { echo '[ResoArc] arm64 emulation test failed' >&2; exit 9; }
# Some slim Docker bases clear APT lists after package installation.
apt-get update -qq
mkdir -p /builder
cp -a /reference/. /builder/
# Git for Windows can turn upstream text files into CRLF, including shebangs.
# Normalize text only in the private Linux build copy, not the source clone.
python3 - <<'PY'
from pathlib import Path
for f in Path('/builder').rglob('*'):
    if not f.is_file() or '.git' in f.parts:
        continue
    if f.suffix.lower() in {'.png','.jpg','.jpeg','.ico','.gif','.pdf','.zip','.img','.deb','.so','.a','.gz','.xz','.dtb','.elf','.bin'}:
        continue
    data = f.read_bytes()
    if b'\0' not in data and b'\r\n' in data:
        f.write_bytes(data.replace(b'\r\n', b'\n'))
PY
chmod +x /builder/rpi-image-gen /builder/install_deps.sh
cd /builder
./install_deps.sh
export RPI_IMAGE_GEN=/builder/rpi-image-gen
export RESOARC_BUILD_ROOT=/builder/resoarc-sources-v4
cd /builder
bash /repo/images/pi/build.sh "$RESOARC_MODEL"
mkdir -p /repo/out/pi-images
image="$(find /builder/work -type f -name 'resoarcos-pi*-arm64.img' -print -quit)"
test -n "$image" || { echo "No image produced under /builder/work" >&2; exit 5; }
cp "$image" "/repo/out/pi-images/resoarcos-pi$RESOARC_MODEL-arm64.img"
sha256sum "/repo/out/pi-images/resoarcos-pi$RESOARC_MODEL-arm64.img" > "/repo/out/pi-images/resoarcos-pi$RESOARC_MODEL-arm64.img.sha256"
echo "[ResoArc] Image complete."
