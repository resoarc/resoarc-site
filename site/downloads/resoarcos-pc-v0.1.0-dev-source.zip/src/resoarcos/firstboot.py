"""ResoArcOS first boot console wizard. Never embeds a factory password."""
from __future__ import annotations

import argparse
import configparser
import getpass
import json
import os
try:
    import pwd  # POSIX-only; used only when installing a key on the device.
except ImportError:
    pwd = None
import re
import subprocess
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

STATE = Path("/var/lib/resoarc/setup-complete.json")
ADMIN = "resoarc"
HOST_RE = re.compile(r"^[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?$")
KEY_RE = re.compile(r"^(ssh-ed25519|ssh-rsa|ecdsa-sha2-nistp256) [A-Za-z0-9+/=]+(?: [^\r\n]*)?$")


def validate_hostname(value: str) -> str:
    value = value.strip().lower()
    if not HOST_RE.fullmatch(value):
        raise ValueError("Use 1-63 lowercase letters, numbers or hyphens; start with a letter.")
    return value


def validate_timezone(value: str, zone_root: Path = Path("/usr/share/zoneinfo")) -> str:
    if not value or value.startswith("/") or not re.fullmatch(r"[A-Za-z0-9_+\-/]{1,80}", value):
        raise ValueError("Invalid timezone name")
    location = (zone_root / value).resolve()
    if not location.is_relative_to(zone_root.resolve()) or not location.is_file():
        raise ValueError("Unknown timezone, for example Asia/Tokyo")
    return value


def validate_password(value: str) -> str:
    if len(value) < 12 or len(value) > 256 or any(ch in value for ch in "\x00\r\n"):
        raise ValueError("Administrator password must be 12-256 characters without line breaks.")
    return value


def validate_wifi(ssid: str, secret: str) -> tuple[str, str]:
    if not ssid:
        return "", ""
    if len(ssid.encode("utf-8")) > 32 or any(ch in ssid for ch in "\x00\r\n"):
        raise ValueError("Wi-Fi SSID must be 1-32 UTF-8 bytes without line breaks.")
    if not (8 <= len(secret) <= 63 or len(secret) == 64 and re.fullmatch(r"[0-9a-fA-F]{64}", secret)):
        raise ValueError("Wi-Fi password must be 8-63 characters or a 64-character hexadecimal key.")
    if any(ch in secret for ch in "\x00\r\n"):
        raise ValueError("Invalid Wi-Fi password character.")
    return ssid, secret


def validate_public_key(value: str) -> str:
    value = value.strip()
    if value and (len(value) > 4096 or not KEY_RE.fullmatch(value)):
        raise ValueError("Paste one valid OpenSSH public key.")
    return value


def run(*args: str, stdin: str | None = None) -> None:
    subprocess.run(list(args), input=stdin, text=True, check=True,
                   stdout=subprocess.DEVNULL, timeout=45)


def save_wifi(ssid: str, secret: str) -> None:
    """NetworkManager keyfile avoids exposing the password via process arguments."""
    if not ssid:
        return
    validate_wifi(ssid, secret)
    directory = Path("/etc/NetworkManager/system-connections")
    directory.mkdir(parents=True, exist_ok=True)
    connection = configparser.ConfigParser(interpolation=None)
    connection["connection"] = {"id": "resoarc-wifi", "uuid": str(uuid.uuid4()),
                                "type": "wifi", "autoconnect": "true", "interface-name": "wlan0"}
    connection["wifi"] = {"mode": "infrastructure", "ssid": ssid}
    connection["wifi-security"] = {"key-mgmt": "wpa-psk", "psk": secret}
    connection["ipv4"] = {"method": "auto"}
    connection["ipv6"] = {"method": "auto"}
    fd, temporary = tempfile.mkstemp(prefix=".resoarc-", dir=directory)
    destination = directory / "resoarc-wifi.nmconnection"
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            connection.write(out, space_around_delimiters=False)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, destination)
        run("nmcli", "connection", "load", str(destination))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def configure(*, hostname: str, tz: str, password: str, ssid: str = "",
              wifi_password: str = "", pubkey: str = "", ssh_password: bool = False,
              state_file: Path = STATE) -> None:
    hostname = validate_hostname(hostname)
    tz = validate_timezone(tz)
    validate_password(password)
    ssid, wifi_password = validate_wifi(ssid, wifi_password)
    pubkey = validate_public_key(pubkey)
    if not pubkey and not ssh_password:
        raise ValueError("SSH requires a public key or explicit password authentication.")
    if state_file.exists():
        raise RuntimeError("Already configured")
    if os.geteuid() != 0:
        raise PermissionError("Root privileges required for initial setup")
    run("hostnamectl", "set-hostname", hostname)
    run("timedatectl", "set-timezone", tz)
    run("chpasswd", stdin=f"{ADMIN}:{password}\n")
    if pubkey:
        user = pwd.getpwnam(ADMIN)
        ssh_dir = Path(user.pw_dir) / ".ssh"
        ssh_dir.mkdir(mode=0o700, exist_ok=True)
        os.chmod(ssh_dir, 0o700)
        os.chown(ssh_dir, user.pw_uid, user.pw_gid)
        target = ssh_dir / "authorized_keys"
        target.write_text(pubkey + "\n", encoding="utf-8")
        os.chmod(target, 0o600)
        os.chown(target, user.pw_uid, user.pw_gid)
    ssh_conf = Path("/etc/ssh/sshd_config.d/60-resoarc.conf")
    ssh_conf.parent.mkdir(parents=True, exist_ok=True)
    ssh_conf.write_text("PermitRootLogin no\nKbdInteractiveAuthentication no\n"
                        "PubkeyAuthentication yes\nPasswordAuthentication "
                        + ("yes\n" if ssh_password else "no\n"), encoding="utf-8")
    # The image deliberately contains no reusable SSH host keys.
    # Generate a unique host identity even if the upstream boot unit has not run yet.
    run("/usr/bin/ssh-keygen", "-A")
    Path("/run/sshd").mkdir(mode=0o755, exist_ok=True)
    run("/usr/sbin/sshd", "-t")
    save_wifi(ssid, wifi_password)
    run("systemctl", "enable", "--now", "ssh")
    state_file.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(prefix=".setup-", dir=state_file.parent)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            json.dump({"schema": 1, "configured_at": datetime.now(timezone.utc).isoformat(),
                       "hostname": hostname, "timezone": tz, "admin": ADMIN,
                       "ssh_password_enabled": ssh_password, "wifi_configured": bool(ssid)}, out)
            out.write("\n")
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, state_file)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def prompt(question: str, default: str = "") -> str:
    answer = input(f"{question}" + (f" [{default}]" if default else "") + ": ").strip()
    return answer or default


def console() -> int:
    if STATE.exists():
        return 0
    print("\n" + "=" * 55)
    print("  ResoArcOS | Raspberry Pi first boot")
    print("  Secure setup: no factory login password")
    print("=" * 55 + "\n")
    try:
        while True:
            try:
                hostname = validate_hostname(prompt("Device name", "resoarcos"))
                tz = validate_timezone(prompt("Timezone", "Asia/Tokyo"))
                break
            except ValueError as error:
                print("Error:", error)
        while True:
            password = getpass.getpass("New administrator password (12+ chars): ")
            again = getpass.getpass("Repeat administrator password: ")
            try:
                validate_password(password)
                if password != again:
                    raise ValueError("Passwords did not match")
                break
            except ValueError as error:
                print("Error:", error)
        ssid = prompt("Wi-Fi SSID (leave blank for Ethernet)")
        wifi_password = getpass.getpass("Wi-Fi password: ") if ssid else ""
        validate_wifi(ssid, wifi_password)
        pubkey = validate_public_key(prompt("SSH public key (optional)"))
        mode = prompt("Allow SSH password login? yes/no", "no" if pubkey else "yes").lower()
        if mode not in {"yes", "no"}:
            raise ValueError("Answer yes or no")
        print("\nApplying settings...")
        configure(hostname=hostname, tz=tz, password=password, ssid=ssid,
                  wifi_password=wifi_password, pubkey=pubkey, ssh_password=mode == "yes")
        print("Setup complete. Log in as 'resoarc'.")
        print("Optional GUI: enter 'resogui' from the physical console.")
        return 0
    except (EOFError, KeyboardInterrupt):
        print("\nSetup cancelled; reboot to start again.")
        return 130
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        print("Setup failed:", error, "Reboot to retry.")
        return 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--console", action="store_true")
    args = parser.parse_args()
    if not args.console:
        parser.error("Use --console on the Raspberry Pi's physical console")
    return console()


if __name__ == "__main__":
    raise SystemExit(main())
