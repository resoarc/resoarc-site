# ResoArcOS Raspberry Pi 4 / 5 image (ARM64, experimental)

Write the IMG to microSD, plug in HDMI display and USB keyboard, and power on.
On the first boot the device automatically launches a one-time text setup
wizard on tty1. On later boots the normal login prompt appears.

Wizard prompts: hostname (default resoarcos), timezone (default Asia/Tokyo),
new administrator password of 12+ characters, optional Wi-Fi name/password,
optional SSH public key, and whether SSH password logins are allowed. Before
configuration the resoarc account is locked, and SSH is disabled. No factory
password is embedded. After setup log in as resoarc. Use the command resogui
at a physical console to start the optional desktop.

This version REQUIRES an HDMI monitor and keyboard for first-boot setup.
The browser setup / captive portal is not implemented yet. For headless use,
configure once with display and keyboard, then remove them and connect by SSH.

## Build on a Linux machine

Obtain the official builder from https://github.com/raspberrypi/rpi-image-gen
and run its install_deps.sh as instructed upstream. Native Debian arm64
is preferred; Docker/amd64 cross-builds are not an officially supported host.

    export RPI_IMAGE_GEN=/path/to/rpi-image-gen/rpi-image-gen
    bash images/pi/build.sh 5

Choose 4 for Raspberry Pi 4. The temporary custom layer lives in
out/pi5-firstboot; the IMG is in the upstream image generator's work/image-*
output directory. See upstream documentation for details.

## Flash

Use https://www.raspberrypi.com/software/ (Raspberry Pi Imager).
Choose Use custom, choose the generated IMG, select the SD card carefully,
and write. THIS DESTROYS THE CARD'S EXISTING DATA. Raspberry Pi Imager 2.x
does not automatically apply OS customisation to local custom IMG files.
ResoArcOS has its own first-boot setup.

No real-hardware boot validation yet. No signed image, automatic rollback,
disk encryption or public Web admin interface.
