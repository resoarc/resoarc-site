"""Unit checks are host-safe; no real root commands."""
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from resoarcos import firstboot

class FirstBootTests(unittest.TestCase):
    def test_hostname(self):
        self.assertEqual(firstboot.validate_hostname("ResoArcOS"), "resoarcos")
        for value in ("-host", "host-", "host.name", "a" * 64, ""):
            with self.assertRaises(ValueError):
                firstboot.validate_hostname(value)

    def test_timezone_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            (base / "Asia").mkdir()
            (base / "Asia" / "Tokyo").write_text("tz")
            self.assertEqual(firstboot.validate_timezone("Asia/Tokyo", base), "Asia/Tokyo")
            for value in ("../etc/passwd", "/etc/passwd", "No/Zone"):
                with self.assertRaises(ValueError):
                    firstboot.validate_timezone(value, base)

    def test_password(self):
        for value in ("short", "passabcdefghijkl\n", "a" * 257):
            with self.assertRaises(ValueError):
                firstboot.validate_password(value)
        self.assertEqual(firstboot.validate_password("abcdefghijkl"), "abcdefghijkl")

    def test_wifi(self):
        self.assertEqual(firstboot.validate_wifi("", ""), ("", ""))
        for ssid, password in (("a" * 33, "12345678"), ("wifi", "short"), ("wifi\n", "12345678")):
            with self.assertRaises(ValueError):
                firstboot.validate_wifi(ssid, password)

    def test_ssh_key(self):
        self.assertTrue(firstboot.validate_public_key("ssh-ed25519 AAAA comment"))
        with self.assertRaises(ValueError):
            firstboot.validate_public_key("ssh-ed25519 AAAA\nbad")

    def test_requires_ssh_auth(self):
        with tempfile.TemporaryDirectory() as d:
            with mock.patch.object(firstboot, "validate_timezone", return_value="Asia/Tokyo"):
                with self.assertRaisesRegex(ValueError, "SSH requires"):
                    firstboot.configure(hostname="resoarcos", tz="Asia/Tokyo",
                                        password="abcdefghijkl", state_file=Path(d) / "done")

    def test_completion_marker_prevents_repeat(self):
        with tempfile.TemporaryDirectory() as d:
            marker = Path(d) / "done"
            marker.write_text("{}")
            with mock.patch.object(firstboot, "validate_timezone", return_value="Asia/Tokyo"):
                with self.assertRaisesRegex(RuntimeError, "Already configured"):
                    firstboot.configure(hostname="resoarcos", tz="Asia/Tokyo",
                                        password="abcdefghijkl", ssh_password=True,
                                        state_file=marker)

if __name__ == "__main__":
    unittest.main()
