# ResoArcOS

**ResoArcOS 0.1.0-dev** is an experimental, headless-first Linux distribution built on Debian 13 for PCs, with a common-core Raspberry Pi ARM64 project.

## Design principles

- Terminal-first, no mandatory display manager; invoke `resogui` from a physical TTY to start a minimal Openbox desktop.
- Four trusted service profiles (`web`, `files`, `iot`, `ai`), explicit preview and confirmation before changes.
- Audit profile changes locally and expose readable machine-format plans.
- Prioritize security, repairability and transparent source over adding many background services.

## Current test coverage

The PC edition has been built as an amd64 live ISO inside Docker Desktop and has booted under QEMU to a Linux serial login prompt. The separate virtual CD-ROM boot menus have also been observed under BIOS and UEFI firmware. A stricter ISO verification routine checks code-file permissions and the isolated Python launcher. See [verification matrix](docs/STATUS.md) for exactly which version passed each test.

The ResoArcOS desktop itself has **not yet been tested interactively**. There is no disk installer, automatic OS rollback, signed OTA updater, or production-grade firewall setup. All downloaded or generated images are experimental.

## Latest tested PC image

The headless-first experimental image is `out/resoarcos-cli-default-v4-amd64.iso` (SHA-256 `34adbe3b9d73997647d81313dd92e0be17af5518a7f8624039e90fc5dbe76918`). Debian Live's automatic `xinit` startup is disabled in its normal BIOS/UEFI boot entries.

From the local console the user can type `resogui` to start an Openbox desktop, xterm shell, and PCManFM. QEMU direct-kernel testing verified both the CLI-only starting state and the visible on-demand GUI. It remains a test-only Live ISO: console autologin is enabled, there is no installer, and hardware driver compatibility is not guaranteed. See [GUI investigation and evidence](docs/PC_GUI_20261016.md).

## Build and verify on Windows Docker Desktop

Use Docker Desktop in Linux containers mode. In a PowerShell terminal opened at the repository root:

```powershell
docker build --pull=false -t resoarcos-live-builder:local -f images/pc/Dockerfile.build .
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/test-pc-docker.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build-pc-docker.ps1 -BuildId trial1
docker logs --tail 30 resoarcos-iso-trial1
docker inspect resoarcos-iso-trial1 --format '{{.State.ExitCode}}'
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/finish-pc-docker.ps1 -BuildId trial1
```

The final command refuses to copy an ISO unless the build exited successfully and its content/security checks pass. It emits a SHA-256 checksum file next to the ISO.

The build writes its Linux root filesystem to a new Docker-native named volume (not a Windows bind mount), uses 4 CPUs / 6 GiB of memory, and requires a privileged container for filesystem mounting. **Do not put secrets into the build source**. None of the scripts partition, format, replace or boot the Windows host operating system.

For advanced QEMU smoke tests see `scripts/qemu-iso-smoke.sh` and `scripts/qemu-media-smoke.sh`. Use a disposable VM or spare USB media; live-system changes are not persistent by default.

## CLI commands

```sh
resoarc status
resoarc profile list
resoarc profile plan web
sudo resoarc profile apply web --confirm --acknowledge-network
resoarc audit
resogui
```

The `apply` command changes packages and services. Port acknowledgement is **not** firewall setup, authentication provisioning or exposure control. The profiles are demonstrations and must be hardened before public network deployment.

## Raspberry Pi 3B / 4 / 5

The ARM64 builds contain a one-time local-console first-boot wizard with a locked default account, unique password setup, hostname, timezone, Wi-Fi and explicit SSH provisioning. SD root partition auto-expansion and an optional localhost-only read-only web dashboard are included in the newer `grow-v1` candidates. The Pi 4 and Pi 5 candidates were built on Linux Docker/amd64 with QEMU and passed SHA-256, FAT32/ext4, first-boot, and compressed archive checks. Physical board startup has **not** been tested.

**Pi 3B native ARM64 SD image** is built and statically verified in `out/pi-images-pi3-first` using official `rpi3`; see [Pi 3B guide](docs/PI3B-SD-QUICKSTART-ja.md). **Zero 2 W native ARM64 IMG** is also built and statically verified in `out/pi-images-zero2-first` using official `rpizero2w`. It passed compressed archive integrity and a disposable 8 GiB SD expansion test; see [Zero 2 W guide](docs/ZERO2W-SD-QUICKSTART-ja.md). **Original Pi Zero / Zero W ARMv6 trial IMG** was built by staging ResoArcOS into a verified official Raspberry Pi OS Lite **32-bit** base in `out/pi-images-zero-armv6-first`. It passed separate FAT32/ext4, locked-login, cloud-init, machine-id, and disposable SD expansion checks; see [original Zero guide](docs/PI-ZERO-SD-QUICKSTART-ja.md) and [original Zero QA](docs/PI-ZERO-ARMV6-QA.md). **None of these Raspberry Pi images has been boot-tested on physical boards.** Their upstream licenses also need review before external redistribution.

## License

ResoArcOS-owned source is MIT. Linux, Debian packages, Raspberry Pi firmware and all upstream programs retain their original licenses. No personal-account GitHub deployment is required to build locally.