"""ResoArcOS local CLI. Profiles must be trusted files bundled with the OS."""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
import platform
import re
import subprocess
import sys
import tempfile
import tomllib
from importlib.resources import files
from pathlib import Path
from . import __version__

DEFAULT_STATE = Path("/var/lib/resoarc")
NAME = re.compile(r"^[a-z][a-z0-9-]{0,31}$")


def profiles() -> dict:
    result = {}
    for f in sorted(files("resoarcos").joinpath("profiles").iterdir(), key=lambda x: x.name):
        if not f.name.endswith(".toml"):
            continue
        p = tomllib.loads(f.read_text(encoding="utf-8"))
        name = p.get("id")
        if not isinstance(name, str) or not NAME.fullmatch(name) or f.name != name + ".toml":
            raise ValueError("Invalid profile identity: " + f.name)
        if name in result:
            raise ValueError("Duplicate profile: " + name)
        for key in ("packages", "services", "ports"):
            if not isinstance(p.get(key), list) or not all(isinstance(item, str) for item in p[key]):
                raise ValueError("Invalid " + key + " in " + name)
        if any(not re.fullmatch(r"[a-z0-9][a-z0-9+.-]*", v) for v in p["packages"]):
            raise ValueError("Invalid package in profile " + name)
        if any(not re.fullmatch(r"[a-zA-Z0-9_.@-]+", v) for v in p["services"]):
            raise ValueError("Invalid service in profile " + name)
        result[name] = p
    return result


def load_state(directory: Path) -> dict:
    try:
        data = json.loads((directory / "profiles.json").read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("enabled"), dict):
            return data
        raise ValueError("Invalid ResoArcOS state file")
    except FileNotFoundError:
        return {"schema": 1, "enabled": {}}


def save_state(directory: Path, data: dict) -> None:
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, name = tempfile.mkstemp(prefix=".profiles-", dir=str(directory))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            if hasattr(os, "fchmod"):
                os.fchmod(stream.fileno(), 0o600)
            json.dump(data, stream, indent=2, ensure_ascii=False, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, directory / "profiles.json")
    finally:
        if os.path.exists(name):
            os.unlink(name)


def audit(directory: Path, event: dict) -> None:
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    event = {"timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(), **event}
    fd = os.open(str(directory / "audit.jsonl"), os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")


def run(command: list[str]) -> None:
    subprocess.run(command, check=True, timeout=900)


def apply_profile(name: str, directory: Path, confirm: bool, acknowledge_network: bool) -> int:
    entries = profiles()
    if name not in entries:
        raise ValueError("Unknown profile: " + name)
    entry = entries[name]
    if not confirm:
        raise ValueError("First run: resoarc profile plan " + name + "; then add --confirm")
    if entry["ports"] and not acknowledge_network:
        raise ValueError("Network services require --acknowledge-network after reviewing exposure")
    if platform.system() != "Linux" or not hasattr(os, "geteuid") or os.geteuid() != 0:
        raise PermissionError("Profile application is restricted to Linux root")
    data = load_state(directory)
    if name in data["enabled"]:
        print(name + ": already recorded as enabled")
        return 0
    try:
        if entry["packages"]:
            run(["apt-get", "install", "--yes", "--no-install-recommends", *entry["packages"]])
        for service in entry["services"]:
            run(["systemctl", "enable", "--now", service])
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as err:
        audit(directory, {"action": "profile.apply", "profile": name, "result": "failed", "reason": str(err)})
        print("Partial changes possible; inspect apt and systemd manually.", file=sys.stderr)
        return 1
    data["enabled"][name] = dt.datetime.now(dt.timezone.utc).isoformat()
    save_state(directory, data)
    audit(directory, {"action": "profile.apply", "profile": name, "result": "success"})
    print("Enabled " + name + "; review firewall and authentication settings before exposure")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="resoarc", description="ResoArcOS local administration")
    parser.add_argument("--state-dir", type=Path, default=DEFAULT_STATE, help=argparse.SUPPRESS)
    parser.add_argument("--version", action="version", version=__version__)
    subs = parser.add_subparsers(dest="command", required=True)
    status = subs.add_parser("status")
    status.add_argument("--json", action="store_true")
    profile = subs.add_parser("profile")
    actions = profile.add_subparsers(dest="action", required=True)
    actions.add_parser("list")
    plan = actions.add_parser("plan")
    plan.add_argument("name")
    plan.add_argument("--json", action="store_true")
    apply_cmd = actions.add_parser("apply")
    apply_cmd.add_argument("name")
    apply_cmd.add_argument("--confirm", action="store_true")
    apply_cmd.add_argument("--acknowledge-network", action="store_true")
    installer = subs.add_parser("install", help="Read-only PC disk inspection; installation is not implemented")
    install_cmds = installer.add_subparsers(dest="action", required=True)
    install_list = install_cmds.add_parser("list", help="List disks without writing to them")
    install_list.add_argument("--json", action="store_true")
    install_plan = install_cmds.add_parser("plan", help="Safety-preview an existing whole disk")
    install_plan.add_argument("--target", required=True)
    install_plan.add_argument("--json", action="store_true")
    audit_cmd = subs.add_parser("audit")
    audit_cmd.add_argument("--limit", type=int, default=20)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        entries = profiles()
        if args.command == "status":
            info = {
                "name": "ResoArcOS", "version": __version__,
                "host": platform.node(), "system": platform.system(),
                "architecture": platform.machine(), "kernel": platform.release(),
                "profiles_enabled": sorted(load_state(args.state_dir)["enabled"]),
            }
            if args.json:
                print(json.dumps(info, ensure_ascii=False, indent=2))
            else:
                for k, v in info.items():
                    print(f"{k}: {v}")
            return 0
        if args.command == "profile":
            if args.action == "list":
                for name, item in entries.items():
                    print(f"{name:<12} {item['description']}")
                return 0
            if args.name not in entries:
                raise ValueError("Unknown profile: " + args.name)
            if args.action == "plan":
                item = entries[args.name]
                plan = {
                    "profile": args.name,
                    "description": item["description"],
                    "packages": item["packages"],
                    "services_to_enable": item["services"],
                    "potential_network_ports": item["ports"],
                    "already_enabled": args.name in load_state(args.state_dir)["enabled"],
                    "automatic_rollback_available": False,
                }
                if args.json:
                    print(json.dumps(plan, ensure_ascii=False, indent=2))
                else:
                    for k, v in plan.items():
                        print(f"{k}: {v}")
                return 0
            return apply_profile(args.name, args.state_dir, args.confirm, args.acknowledge_network)
        if args.command == "install":
            from .install import inspect
            plan = inspect(args.target if args.action == "plan" else None)
            if args.json:
                print(json.dumps(plan, ensure_ascii=False, indent=2))
            elif args.action == "plan":
                for k, v in plan.items():
                    print(f"{k}: {v}")
            else:
                print("Read-only disk inventory (no installer or disk writes):")
                for disk in plan["disks"]:
                    print(f"  {disk['target']}: {disk['bytes']} bytes / {disk['status']}")
                    for reason in disk["blocking_reasons"]:
                        print(f"    BLOCKED: {reason}")
            return 0
        if args.command == "audit":
            logfile = args.state_dir / "audit.jsonl"
            if not logfile.exists():
                print("No audit entries yet")
                return 0
            with logfile.open(encoding="utf-8") as stream:
                lines = stream.readlines()
            for line in lines[-max(0, min(args.limit, 1000)):]:
                print(line.rstrip())
            return 0
    except (ValueError, PermissionError, OSError, RuntimeError, subprocess.CalledProcessError, subprocess.TimeoutExpired, json.JSONDecodeError, tomllib.TOMLDecodeError) as error:
        print("resoarc: " + str(error), file=sys.stderr)
        return 2
    return 2
