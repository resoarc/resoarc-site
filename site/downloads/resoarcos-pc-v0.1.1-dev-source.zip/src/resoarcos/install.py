"""Non-destructive disk inspection for a future ResoArcOS PC installer.

The current developer-preview Live ISO has NO install/apply command.
Every operation in this module is read-only. It intentionally rejects
mounted/system/internal disks rather than providing a dangerous override.
"""
from __future__ import annotations

import json
import platform
import re
import subprocess

MIN_DISK_BYTES = 8 * 1024**3
SAFE_PATH = re.compile(r"^/dev/[A-Za-z0-9][A-Za-z0-9_.+-]{0,89}$")
COLUMNS = "NAME,PATH,SIZE,TYPE,RM,RO,TRAN,FSTYPE,MOUNTPOINTS"


def inventory() -> list[dict]:
    """Request read-only Linux block-device metadata without invoking blkid writes."""
    if platform.system() != "Linux":
        raise RuntimeError("Disk inspection requires Linux; nothing was modified.")
    process = subprocess.run(
        ["lsblk", "--bytes", "--json", "--tree", "--output", COLUMNS],
        text=True, capture_output=True, timeout=12, check=True,
    )
    data = json.loads(process.stdout)
    if not isinstance(data, dict) or not isinstance(data.get("blockdevices"), list):
        raise ValueError("Invalid lsblk inventory")
    return data["blockdevices"]


def descendants(node: dict):
    yield node
    children = node.get("children") or []
    if not isinstance(children, list):
        raise ValueError("Malformed lsblk child list")
    for child in children:
        if not isinstance(child, dict):
            raise ValueError("Malformed lsblk device")
        yield from descendants(child)


def mounted_locations(node: dict) -> list[str]:
    paths = []
    for part in descendants(node):
        entries = part.get("mountpoints")
        if entries is None:
            entries = [part.get("mountpoint")]
        if isinstance(entries, str):
            entries = [entries]
        if not isinstance(entries, list):
            raise ValueError("Invalid lsblk mountpoints")
        for entry in entries:
            if entry:
                paths.append(str(entry))
    return sorted(set(paths))


def has_existing_data(node: dict) -> bool:
    return any(bool(dev.get("fstype")) for dev in descendants(node))


def disk_plan(node: dict) -> dict:
    """Return conservative, informational-only suitability for a disk."""
    if node.get("type") != "disk":
        raise ValueError("Only whole disks can be candidates")
    path = node.get("path")
    if not isinstance(path, str) or not SAFE_PATH.fullmatch(path):
        raise ValueError("Unexpected disk device path from lsblk")
    try:
        size = int(node.get("size"))
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Unknown disk size") from exc
    if size < 0:
        raise ValueError("Negative disk size")
    mounted = mounted_locations(node)
    rm = node.get("rm") in (True, 1, "1")
    ro = node.get("ro") in (True, 1, "1")
    transport = str(node.get("tran") or "").lower()
    usb = rm or transport == "usb"
    blocked = []
    if not usb:
        blocked.append("Not identified as removable/USB; internal disks are always blocked")
    if ro:
        blocked.append("Read-only disk")
    if size < MIN_DISK_BYTES:
        blocked.append("Disk smaller than the 8 GiB planning minimum")
    if mounted:
        blocked.append("Device or a partition is mounted; cannot be an installation target")
    data_present = has_existing_data(node)
    return {
        "target": path,
        "bytes": size,
        "transport": transport or "unknown",
        "removable_or_usb": usb,
        "read_only": ro,
        "mounted": mounted,
        "existing_filesystems": data_present,
        "status": "candidate_for_future_planning_only" if not blocked else "blocked",
        "blocking_reasons": blocked,
        "warning": ("READ-ONLY PREVIEW. No installer is available. "
                    "Any future installation could ERASE ALL DATA on this disk. "
                    "Never select a disk without independently verifying its identity."),
        "installation_implemented": False,
        "disk_changes_performed": False,
    }


def inspect(target: str | None = None) -> dict:
    devices = inventory()
    disks = [node for node in devices if isinstance(node, dict) and node.get("type") == "disk"]
    if target is not None:
        if not SAFE_PATH.fullmatch(target):
            raise ValueError("Target must be an exact /dev device path returned by lsblk")
        matching = [dev for dev in disks if dev.get("path") == target]
        if len(matching) != 1:
            raise ValueError("Requested target is not an existing whole disk")
        return disk_plan(matching[0])
    return {
        "disks": [disk_plan(d) for d in disks],
        "installation_implemented": False,
        "disk_changes_performed": False,
        "note": "Read-only inventory. No disk installer is included in this release.",
    }
