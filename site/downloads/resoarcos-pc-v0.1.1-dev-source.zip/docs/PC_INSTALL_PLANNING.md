# ResoArcOS PC: read-only installation planning (2026-10-16)

Status: **experimental / inspection only**. No disk installer is implemented or shipped.

## Goal

The existing PC Live ISO boots into a disposable Debian 13 session, with temporary console autologin. Installing to internal disks, persisting settings or upgrading as a production OS is **not supported**.

The next step is to gather an accurate disk inventory without risking the Windows host, other OS installations, or removable drives containing user data.

## Commands

```sh
resoarc install list
resoarc install list --json
resoarc install plan --target /dev/sdb
resoarc install plan --target /dev/sdb --json
```

The paths must be device names actually reported by Linux `lsblk`. The tool only invokes:

```sh
lsblk --bytes --json --tree --output NAME,PATH,SIZE,TYPE,RM,RO,TRAN,FSTYPE,MOUNTPOINTS
```

It performs no mounting, formatting, partitioning, probing writes, bootloader changes or installer invocation.

## Conservative selection policy

- Only whole disks with an exact valid `/dev/...` path are considered.
- Internal devices, including the running system's likely NVMe/SATA drives, are blocked even when apparently empty.
- Mounted drives or drives with mounted descendants are blocked.
- Read-only devices and devices smaller than 8 GiB are blocked.
- A device identified as USB/removable, unmounted and writable may be marked *candidate for future planning only*. This **does not** certify that it is safe to erase. The preview always declares that installation is unavailable.
- Existing filesystem signatures are displayed. A candidate may still contain important user data.

The future installer must independently re-identify the device immediately before any write, demand typed confirmation, verify a robust rollback/back-up plan, require explicit selection of encryption and account handling, and undergo virtual-disk destructive-path tests. Neither an `apply` subcommand nor destructive operations are present today.

## Evidence and next gates

- Unit tests mock Linux `lsblk` responses, validate root/partition mount protection, size/read-only/internal disk checks, path validation and the absence of `apply`.
- CI/container execution does not require any real disk access. PC QEMU tests use a virtual CD-ROM and have no guest network.
- To advance to a release candidate, additionally implement reliable persistence, secure first-user setup, signed updates, recovery support, disk-installation test fixtures and real-PC hardware/USB boot testing.

Do **not** describe this command as an installer or use it to select a disk for manual formatting.
