# PC firmware boot QA, 2026-10-16

This report concerns the **existing local v4 Live ISO**, not yet the future ISO containing the read-only `install plan` commands.

## Image and isolation

- ISO path on developer's Windows PC: `out/resoarcos-cli-default-v4-amd64.iso`
- ISO length: 611,319,808 bytes
- SHA-256: `34adbe3b9d73997647d81313dd92e0be17af5518a7f8624039e90fc5dbe76918`
- Test execution: Docker Linux container `resoarcos-pc-uefi-20261016-qa`; QEMU system x86_64, `q35,accel=tcg`, OVMF 4 MiB code and disposable firmware variables, 1.5 GiB guest memory, 2 vCPUs.
- Guest medium: read-only virtual CD-ROM. No guest NIC, host disk pass-through, partition operations, or firmware changes on the physical Windows host.
- Test script: `scripts/qemu-media-smoke.sh` with `RESOARC_QEMU_FIRMWARE=uefi`.
- QEMU process exited 0. This exit alone only establishes that screenshots were captured, not that the guest reached a usable shell.

## Visual evidence (reviewed)

| Frame | File in `out/` | Observation |
|---|---|---|
| Before boot | `resoarcos-pc-uefi-20261016-1.png` | Debian GNU/Linux 13 (trixie) amd64 **UEFI boot menu**, Live system selected |
| After boot | `resoarcos-pc-uefi-20261016-2.png` | `Debian GNU/Linux 13 resoarcos tty1`, `resoarcos login: resoarc (automatic login)` and `resoarc@resoarcos:~$` command prompt |

**Result: UEFI virtual-CD-ROM boot to a working CLI prompt was visually confirmed.** This is stronger than merely parsing UEFI GRUB boot entries or testing the kernel directly. Previous BIOS QEMU virtual-CD-ROM boot and on-demand GUI test results are documented in `docs/PC_GUI_20261016.md`.

## Boundaries

- OVMF QEMU boot verification is not a claim of compatibility with all physical UEFI devices or secure boot.
- The Live ISO autologin is intentional for an isolated developer preview and **is not suitable for production use**.
- This run verified the local v4 ISO digest above, **not** the separately built GitHub Release ISO digest `7706b665ef250be764cda9de43826edf9ad7c85baccbf7655f5ae43f0b5d61dd`. The released image passed independent internal, direct-kernel and GUI tests but not this specific full UEFI run.
- The screenshot test currently requires visual inspection. The script's exit status must not be used as a fully automatic "booted" certification.
- Persistence, safe installation, encrypted storage, signed updates, hardware drivers, and rollback remain outstanding.

## Further gates

Next: run the same test against the freshly built ISO with read-only disk planning, check cold-boot behavior and preserve screenshots; add a CI firmware-path test that can programmatically verify the guest's CLI prompt instead of merely collecting captures.
