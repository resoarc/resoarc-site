#!/usr/bin/env bash
# Stages a synthetic (disposable) 32-bit-style Linux rootfs; no IMG or SD media.
set -euo pipefail
repo="${1:-/repo}"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
root="$tmp/root"
install -d "$root/etc" "$root/bin" "$root/usr/bin" "$root/usr/sbin" "$root/usr/share/zoneinfo" "$root/etc/systemd"
touch "$root/bin/bash"
for f in passwd shadow group gshadow login.defs; do
    cp "/etc/$f" "$root/etc/$f"
done
grep -q '^sudo:' "$root/etc/group" || echo 'sudo:x:27:' >> "$root/etc/group"
grep -q '^sudo:' "$root/etc/gshadow" || echo 'sudo:!::' >> "$root/etc/gshadow"
grep -q '^users:' "$root/etc/group" || echo 'users:x:100:' >> "$root/etc/group"
grep -q '^users:' "$root/etc/gshadow" || echo 'users:!::' >> "$root/etc/gshadow"
for path in usr/bin/python3 usr/bin/nmcli usr/bin/sudo usr/sbin/sshd usr/bin/ssh-keygen usr/sbin/resize2fs usr/bin/growpart; do
    touch "$root/$path"
done
bash "$repo/scripts/stage-original-zero-rootfs.sh" "$root" "$repo"
grep -q '^resoarc:!' "$root/etc/shadow"
grep -q '^resoarc:' "$root/etc/passwd"
test -e "$root/usr/local/lib/resoarcos/firstboot.py"
test -e "$root/usr/local/bin/resoarc-web"
test -L "$root/etc/systemd/system/multi-user.target.wants/resoarc-grow-root.service"
test -e "$root/etc/systemd/system/getty@tty1.service.d/resoarc.conf"
test -e "$root/usr/local/sbin/resoarc-grow-root"
test -e "$root/etc/ssh/sshd_config.d/60-resoarc.conf"
grep -q 'PasswordAuthentication no' "$root/etc/ssh/sshd_config.d/60-resoarc.conf"
grep -q 'RESOARC_BASE=RaspberryPiOS-Trixie-armhf' "$root/etc/resoarc/release"
echo "PASS original Pi Zero offline 32-bit rootfs staging and locked firstboot"
