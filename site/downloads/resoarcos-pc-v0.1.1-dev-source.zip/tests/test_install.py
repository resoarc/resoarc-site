"""Safety regression tests for the read-only PC installer preflight."""
from __future__ import annotations

import contextlib
import io
import json
import unittest
from unittest.mock import patch

from resoarcos import install
from resoarcos.cli import main


def sample(*, path="/dev/sdb", usb="usb", rm=0, size=16*1024**3, ro=0,
           mounts=None, fstype="ext4"):
    return {
        "name": path.removeprefix("/dev/"), "path": path, "type": "disk",
        "size": size, "ro": ro, "rm": rm, "tran": usb, "mountpoints": [None],
        "children": [{
            "path": path+"1", "type": "part", "size": size-1_000_000,
            "mountpoints": mounts if mounts is not None else [None],
            "fstype": fstype,
        }],
    }


class DiskInspectionTests(unittest.TestCase):
    def test_usb_candidate_is_informational_only(self):
        d = install.disk_plan(sample())
        self.assertEqual(d["status"], "candidate_for_future_planning_only")
        self.assertTrue(d["existing_filesystems"])
        self.assertFalse(d["installation_implemented"])
        self.assertFalse(d["disk_changes_performed"])
        self.assertIn("ERASE ALL DATA", d["warning"])

    def test_internal_disk_is_blocked_even_if_empty(self):
        plan = install.disk_plan(sample(path="/dev/nvme0n1", usb="nvme", fstype=""))
        self.assertEqual(plan["status"], "blocked")
        self.assertTrue(any("internal disks" in r for r in plan["blocking_reasons"]))

    def test_mounted_partition_is_blocked(self):
        plan = install.disk_plan(sample(mounts=["/home", "/"]))
        self.assertEqual(plan["mounted"], ["/", "/home"])
        self.assertEqual(plan["status"], "blocked")

    def test_readonly_or_undersized_is_blocked(self):
        d = install.disk_plan(sample(ro=1, size=4*1024**3))
        self.assertEqual(len(d["blocking_reasons"]), 2)

    def test_non_disk_or_bad_paths_refused(self):
        for bad in ("/dev/../sda", "/tmp/external", "/dev/sdb;touch /tmp/x"):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    install.disk_plan(sample(path=bad))
        with self.assertRaises(ValueError):
            install.disk_plan({**sample(), "type": "part"})

    def test_invalid_block_device_inventory_refused(self):
        with patch.object(install, "inventory", return_value=[sample()]):
            with self.assertRaises(ValueError):
                install.inspect("/dev/sda")
            with self.assertRaises(ValueError):
                install.inspect("/dev/sdb1")

    def test_inventory_is_one_nonmutating_lsblk_invocation(self):
        dummy = type("Result", (), {
            "stdout": json.dumps({"blockdevices": [sample()]})
        })()
        with patch.object(install.platform, "system", return_value="Linux"), \
             patch.object(install.subprocess, "run", return_value=dummy) as shell:
            self.assertEqual(install.inspect("/dev/sdb")["target"], "/dev/sdb")
            self.assertEqual(shell.call_count, 1)
            command = shell.call_args.args[0]
            self.assertEqual(command[0], "lsblk")
            self.assertIn("--json", command)
            self.assertNotIn("wipefs", command)

    def test_windows_rejected_without_running_lsblk(self):
        with patch.object(install.platform, "system", return_value="Windows"), \
             patch.object(install.subprocess, "run") as shell:
            with self.assertRaises(RuntimeError):
                install.inventory()
            shell.assert_not_called()

    def test_cli_json_exposes_no_apply(self):
        with patch.object(install, "inventory", return_value=[sample()]):
            with contextlib.redirect_stdout(io.StringIO()) as capture:
                self.assertEqual(main(["install", "plan", "--target", "/dev/sdb", "--json"]), 0)
            result = json.loads(capture.getvalue())
            self.assertFalse(result["installation_implemented"])
            self.assertEqual(result["target"], "/dev/sdb")

    def test_no_install_apply_subcommand(self):
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as exc:
                main(["install", "apply", "--target", "/dev/sdb"])
        self.assertEqual(exc.exception.code, 2)


if __name__ == "__main__":
    unittest.main()
