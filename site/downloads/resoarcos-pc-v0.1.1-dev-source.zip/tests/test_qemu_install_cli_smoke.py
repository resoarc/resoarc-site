"""Fast local tests for the offline QEMU install-planning smoke harness."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch


MODULE_PATH = Path(__file__).resolve().parents[1] / "scripts" / "qemu-install-cli-smoke.py"
spec = importlib.util.spec_from_file_location("qemu_install_cli_smoke", MODULE_PATH)
qemu = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(qemu)


class QemuCLIInputTests(unittest.TestCase):
    def test_safe_help_command_key_names(self):
        commands = []
        with patch.object(qemu, "hmp", side_effect=lambda port, cmd: commands.append(cmd) or ""), \
             patch.object(qemu.time, "sleep"):
            qemu.send_text(4556, "resoarc install --help")
        self.assertEqual(commands[-1], "sendkey ret")
        self.assertEqual(commands.count("sendkey minus"), 2)
        self.assertEqual(commands.count("sendkey spc"), 2)
        self.assertEqual(commands[:7], [f"sendkey {ch}" for ch in "resoarc"])

    def test_json_list_command_is_typable(self):
        commands = []
        with patch.object(qemu, "hmp", side_effect=lambda port, cmd: commands.append(cmd) or ""), \
             patch.object(qemu.time, "sleep"):
            qemu.send_text(4556, "resoarc install list --json")
        self.assertIn("sendkey minus", commands)
        self.assertEqual(commands[-1], "sendkey ret")

    def test_rejects_unsafe_key_encoding_before_enter(self):
        commands = []
        with patch.object(qemu, "hmp", side_effect=lambda port, cmd: commands.append(cmd) or ""), \
             patch.object(qemu.time, "sleep"):
            with self.assertRaises(ValueError):
                qemu.send_text(4556, "echo > /dev/sdb")
        self.assertNotIn("sendkey ret", commands)

    def test_errors_from_monitor_are_reported(self):
        with patch.object(qemu, "hmp", return_value="Error: device not ready"), \
             patch.object(qemu.time, "sleep"):
            with self.assertRaises(RuntimeError):
                qemu.send_text(4556, "a")


if __name__ == "__main__":
    unittest.main()
