#!/usr/bin/env bash
set -euo pipefail
stage="$(mktemp -d)"
trap 'rm -rf "$stage"' EXIT
python3 scripts/stage.py "$stage" >/dev/null
test "$(stat -c %a "$stage/usr/local/lib/resoarcos/install.py")" = 644
test "$(stat -c %a "$stage/usr/local/bin/resoarc")" = 755
export PYTHONPATH="$stage/usr/local/lib"
python3 -m resoarcos install --help >"$stage/help.txt"
grep -q 'List disks without writing to them' "$stage/help.txt"
grep -q 'Safety-preview an existing whole disk' "$stage/help.txt"
if python3 -m resoarcos install apply --target /dev/sdb >"$stage/apply.txt" 2>&1; then
  echo 'Unsafe install apply unexpectedly succeeded' >&2
  exit 1
fi
if grep -qE '(parted|sfdisk|mkfs|wipefs|dd if=)' "$stage/usr/local/lib/resoarcos/install.py"; then
  echo 'Unexpected destructive disk-operation reference in install.py' >&2
  exit 1
fi
echo 'RESOARC_READONLY_INSTALL_STAGE_PASS'
