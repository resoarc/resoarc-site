#!/usr/bin/env bash
# ResoArcOS Raspberry Pi 3B/4/5/Zero2W ARM64 with local first-boot wizard.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
MODEL="$(printf '%s' "$*" | awk '{print $1}')"
case "$MODEL" in 3|4|5|zero2w) ;; *) echo "Usage: bash images/pi/build.sh 3|4|5|zero2w" >&2; exit 2;; esac
RPI_IMAGE_GEN="$(printenv RPI_IMAGE_GEN || echo rpi-image-gen)"
if ! command -v "$RPI_IMAGE_GEN" >/dev/null 2>&1 && [[ ! -x "$RPI_IMAGE_GEN" ]]; then
    echo "Missing rpi-image-gen. Set RPI_IMAGE_GEN to its executable." >&2
    exit 2
fi
BUILD_BASE="$(printenv RESOARC_BUILD_ROOT || echo "$ROOT/out")"
WORK="$BUILD_BASE/pi$MODEL-firstboot"
if [[ -e "$WORK" ]]; then
    echo "Build directory exists. Use a new RESOARC_BUILD_ROOT: $WORK" >&2
    exit 2
fi
umask 077
OVERLAY="$WORK/layer/resoarc-firstboot.d/customize.overlay"
mkdir -p "$OVERLAY/etc/systemd/system/getty@tty1.service.d" "$OVERLAY/etc/systemd/system/multi-user.target.wants" "$OVERLAY/usr/local/bin" "$OVERLAY/usr/local/sbin"
if python3 --version >/dev/null 2>&1; then PYTHON=python3; else PYTHON=python; fi
"$PYTHON" "$ROOT/scripts/stage.py" "$OVERLAY"
printf "RESOARC_PI_FEATURES=firstboot,root-grow,local-web\n" >> "$OVERLAY/etc/resoarc/release"
cp "$ROOT/images/pi/getty-firstboot.sh" "$OVERLAY/usr/local/bin/resoarc-getty-firstboot"
cp "$ROOT/images/pi/setup-launcher.sh" "$OVERLAY/usr/local/bin/resoarc-setup"
cp "$ROOT/images/pi/getty-override.conf" "$OVERLAY/etc/systemd/system/getty@tty1.service.d/resoarc.conf"
cp "$ROOT/images/pi/grow-root.sh" "$OVERLAY/usr/local/sbin/resoarc-grow-root"
cp "$ROOT/images/pi/grow-root.service" "$OVERLAY/etc/systemd/system/resoarc-grow-root.service"
ln -s ../resoarc-grow-root.service "$OVERLAY/etc/systemd/system/multi-user.target.wants/resoarc-grow-root.service"
cp "$ROOT/images/pi/resoarc-firstboot.yaml" "$WORK/layer/resoarc-firstboot.yaml"
# Official rpi-image-gen calls the Zero 2 W layer "rpizero2w".
DEVICE_LAYER="rpi$MODEL"
if [[ "$MODEL" = zero2w ]]; then DEVICE_LAYER=rpizero2w; fi
# No passwords or static secrets are placed into the IMG or build configuration.
cat > "$WORK/resoarc.yaml" <<EOF
device:
  layer: $DEVICE_LAYER
  hostname: resoarcos
  user1: resoarc
  user1sudo: passwd
image:
  layer: image-rpios
  name: resoarcos-pi$MODEL-arm64
  boot_part_size: 512M
  root_part_size: 4G
layer:
  - debian-trixie-arm64-multi
  - rpi-debian-trixie
  - rpi-misc-utils
  - rpi-essential-base
  - rpi-misc-skel
  - systemd-timesyncd
  - network-manager
  - wireless-regulatory
  - openssh-server
  - resoarc-firstboot
ssh:
  pubkey_only: n
EOF
"$RPI_IMAGE_GEN" build -S "$WORK" -c "$WORK/resoarc.yaml"
echo "Builder output: inspect rpi-image-gen work/image-*/ for the resulting IMG."
