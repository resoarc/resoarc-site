# ResoArcOS Raspberry Pi 4 / 5 image (ARM64, experimental)

Write the IMG to microSD, plug in HDMI display and USB keyboard, and power on.
On the first boot the device automatically launches a one-time text setup
wizard on tty1. On later boots the normal login prompt appears.

Wizard prompts: hostname (default resoarcos), timezone (default Asia/Tokyo),
new administrator password of 12+ characters, optional Wi-Fi name/password,
optional SSH public key, and whether SSH password logins are allowed. Before
configuration the resoarc account is locked, and SSH is disabled. No factory
password is embedded. After setup log in as resoarc. Use the command resogui
at a physical console to start the optional desktop.

This version REQUIRES an HDMI monitor and keyboard for first-boot setup.
The browser setup / captive portal is not implemented yet. For headless use,
configure once with display and keyboard, then remove them and connect by SSH.

## Build on a Linux machine

Obtain the official builder from https://github.com/raspberrypi/rpi-image-gen
and run its install_deps.sh as instructed upstream. Native Debian arm64
is preferred; Docker/amd64 cross-builds are not an officially supported host.

    export RPI_IMAGE_GEN=/path/to/rpi-image-gen/rpi-image-gen
    bash images/pi/build.sh 5

Choose 4 for Raspberry Pi 4. The temporary custom layer lives in
out/pi5-firstboot; the IMG is in the upstream image generator's work/image-*
output directory. See upstream documentation for details.

## Windows Docker build of the next candidate

The previously verified raw IMG remains in `out/pi-images`. A fresh build is
written to a **separate** `out/pi-images-grow-v1` folder, so an unsuccessful
rebuild cannot overwrite the existing tested artifact.

```powershell
.\scripts\build-pi-docker.ps1 -Model 5 -BuildTag grow-v1
.\scripts\verify-pi-release.ps1 -Model 5 -BuildTag grow-v1
```

To run both models sequentially, first start the Pi 5 build, then run
`scripts/build-pi-grow-v1-batch.ps1` in another PowerShell session. The batch
waits for Pi 5, verifies it, builds Pi 4, verifies it, and writes an
`ACCEPTANCE.txt` manifest. Do not run two ARM64 builders concurrently on a
resource-constrained PC.

The standard release gate also supports an optional complete **disposable 8 GiB SD expansion test**, integrated with checksum, FAT32, ext4 and boot configuration verification:

```powershell
.\scripts\verify-pi-release.ps1 -Model 3 -BuildTag pi3-first -OfflineGrowthTest
```

The temporary Docker volume is removed even if the expansion test fails. This is not a physical Pi boot test.

The standalone **disposable 8 GiB SD simulation** is also available after building
`images/pi/Dockerfile.verify`:

```powershell
docker volume create resoarcos-grow-smoke
docker run --rm --privileged --cpus=2 --memory=4g --pull=never -v "${PWD}/out/pi-images:/images:ro" -v "${PWD}:/repo:ro" -v "resoarcos-grow-smoke:/scratch" --entrypoint bash resoarcos-pi-verifier:local /repo/scripts/smoke-pi-root-grow.sh
```

It works on a temporary copy and never modifies the source IMG or a physical
SD card. Passing this offline test does not prove online first-boot expansion.

The builder snapshots ResoArcOS source scripts inside the Linux container
before starting the long ARM64 build. This avoids a Windows bind-mount script
read failure if the working tree changes during image creation. The snapshot
is build-local and does not publish or modify the Git repository.

To verify a compressed candidate on Windows with Python's optional
`zstandard` package installed:

```powershell
python scripts/verify_pi_archive.py out/pi-images-grow-v1/resoarcos-pi5-arm64.img
```

This streams the compressed archive and checks its decompressed SHA-256 against
the raw IMG checksum without writing another multi-gigabyte temporary file.

The release gate for tagged candidates additionally requires the grow-root
systemd unit, `growpart`, `resize2fs` and the local-only web dashboard to be
present in the **built ext4 filesystem**. It does not prove actual root
expansion or board boot until a physical microSD test succeeds.

## Flash

Use https://www.raspberrypi.com/software/ (Raspberry Pi Imager).
Choose Use custom, choose the generated IMG, select the SD card carefully,
and write. THIS DESTROYS THE CARD'S EXISTING DATA. Raspberry Pi Imager 2.x
does not automatically apply OS customisation to local custom IMG files.
ResoArcOS has its own first-boot setup. The console wizard validates the actual OpenSSH public-key binary structure (Ed25519, RSA 2048+ or ECDSA nistp256) before allowing key-only SSH login. Incorrect Wi-Fi credentials, malformed public keys and invalid SSH login-mode answers are re-prompted without discarding the preceding setup inputs. This validation reduces setup lockouts but does not replace a real login test on a spare Raspberry Pi.

A Raspberry Pi 5 raw IMG has now been generated and its Windows SHA-256
verified. MBR, boot FAT signature, root ext4 signature and first-boot setup
files were independently inspected from the finished IMG. It is a hardware
**test candidate**, not a board-booted release. Source build commit d3d1539
and subsequent PC-side commits are in the local repository.

Pi 5 raw IMG: out/pi-images/resoarcos-pi5-arm64.img
(4,840,226,816 bytes; SHA-256 d6fcc71ae97f486520dfa35ea2267ed24af87762f3021212960021d51e20abb4).
The raw .img is the most reliable choice for Raspberry Pi Imager's **Use custom**
option. A 336 MB .img.zstd copy is also provided for faster distribution on
Imager versions supporting Zstandard archives; the upstream .img.zst is kept
as the exact builder output.

On Windows with Python and Docker Desktop in Linux-container mode, run the
reproducible release gate from PowerShell at the repository root:

    powershell -NoProfile -ExecutionPolicy Bypass -File scripts/verify-pi-release.ps1 -Model 5

The release gate checks SHA-256, MBR, FAT boot files, root ext4 and first-boot
security settings directly inside the IMG. Its verification container is
buildable from the included `images/pi/Dockerfile.verify`.

The existing Pi 4 and Pi 5 images allocate 4 GiB for rootfs. The next image
revision includes a first-boot growpart/resize2fs systemd unit to expand the
root partition to the SD card capacity. This addition has only passed source
and mock composition checks so far: **the current generated images do not
include it**, and no real-device expansion has been verified. Root data and signatures must be validated on a spare
card with a local HDMI display and keyboard. Do not expose unconfigured
services to public networks. No signed image, automatic rollback, disk encryption or public Web admin interface.

### Optional local browser dashboard (new image revision)

After first-boot setup, log in as the non-root `resoarc` user and run:

    resoarc-web

It prints a one-time random password and serves a **read-only** system status
page on `127.0.0.1:8765` only. From another computer, open an SSH tunnel:

    ssh -L 8765:127.0.0.1:8765 resoarc@<PI_IP>

Then browse `http://127.0.0.1:8765/`, enter username `resoarc` and the
one-time password printed by `resoarc-web`. No LAN listener, automatic
startup, configuration changes or remote unauthenticated setup are enabled.
The dashboard is still untested on real Pi hardware.
