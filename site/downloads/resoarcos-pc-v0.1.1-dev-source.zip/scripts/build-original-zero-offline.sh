#!/usr/bin/env bash
# Customize a COPY of a VERIFIED stock Raspberry Pi OS Lite ARMHF raw IMG.
# This script runs inside a privileged throwaway Docker container.
# It never accesses /dev/sd*, /dev/mmc*, physical drives, or the source file.
set -euo pipefail
source_image="${1:-/images/2026-10-06-raspios-trixie-armhf-lite.img}"
target="${2:-/output/resoarcos-pizero-armhf.img}"
repo="${3:-/repo}"
case "$target" in /output/*.img) ;; *) echo 'Output must be under /output/*.img' >&2; exit 2;; esac
test -f "$source_image" || { echo "Missing verified stock 32-bit raw IMG" >&2; exit 2; }
test -f "$repo/scripts/stage-original-zero-rootfs.sh" || exit 3
test -d /scratch || { echo "Missing disposable scratch Docker volume" >&2; exit 3; }
test ! -e "$target" && test ! -e "$target.sha256" || {
  echo 'Existing ResoArcOS image found; refusing overwrite' >&2
  exit 4
}
work="$(mktemp -d /scratch/resoarc-zero-XXXXXXXX)"
loop=""
mounted=0
cleanup() {
  if [[ "$mounted" = 1 ]]; then umount "$work/root" || true; fi
  if [[ -n "$loop" ]]; then losetup -d "$loop" || true; fi
  rm -f "$target.part"
  # Do not delete work when cleanup failed to unmount.
  if ! mountpoint -q "$work/root"; then rm -rf "$work"; fi
}
trap cleanup EXIT
cp --sparse=always "$source_image" "$work/zero.img"
read -r offset length < <(python3 - "$work/zero.img" <<'PY'
from pathlib import Path
import struct,sys
p=Path(sys.argv[1])
with p.open("rb") as f:
    sector=f.read(512)
    if len(sector)!=512 or sector[-2:]!=b'\x55\xaa':
        raise SystemExit("Missing MBR boot signature")
    entry=sector[462:478]
    start,sectors=struct.unpack_from("<II",entry,8)
    if entry[4]!=0x83 or (start+sectors)*512>p.stat().st_size:
        raise SystemExit("Invalid rootfs partition")
    print(start*512,sectors*512)
PY
)
# Docker's /dev exposes only loop0-7 by default even when extra loop minors exist.
for i in $(seq 8 31); do
  if [[ ! -b "/dev/loop$i" ]]; then mknod "/dev/loop$i" b 7 "$i"; fi
done
loop="$(losetup -f --show -o "$offset" --sizelimit "$length" "$work/zero.img")"
mkdir -p "$work/root"
mount -t ext4 "$loop" "$work/root"
mounted=1
bash "$repo/scripts/stage-original-zero-rootfs.sh" "$work/root" "$repo"
sync
umount "$work/root"
mounted=0
losetup -d "$loop"
loop=""
cp --sparse=always "$work/zero.img" "$target.part"
mv "$target.part" "$target"
sha256sum "$target" | awk -v filename="$(basename "$target")" '{print $1 "  " filename}' > "$target.sha256"
echo "PASS original Zero ARMv6 candidate IMG produced: $target"
echo 'Hardware boot and 32-bit runtime provisioning NOT TESTED'
