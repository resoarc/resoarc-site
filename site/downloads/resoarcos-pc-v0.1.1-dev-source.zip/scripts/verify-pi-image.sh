#!/usr/bin/env bash
# Read-only inspection of the generated ARM64 SD image.
set -euo pipefail
MODEL="${1:-5}"
if [ "$MODEL" = zero ]; then
  IMG="/images/resoarcos-pizero-armhf.img"
else
  IMG="/images/resoarcos-pi${MODEL}-arm64.img"
fi
[ -f "$IMG" ] || { echo "IMG not found: $IMG" >&2; exit 2; }
for command in losetup debugfs grep; do command -v "$command" >/dev/null; done
loop=""
cleanup() { if [ -n "$loop" ]; then losetup -d "$loop" || true; fi; }
trap cleanup EXIT
# MBR partition 2 is located at LBA 1064960. Verify it independently before use.
if command -v python3 >/dev/null; then
  eval "$(python3 - "$IMG" <<'PY'
import sys, struct
with open(sys.argv[1], 'rb') as f:
    sector = f.read(512)
assert sector[510:] == b'\x55\xaa', 'Invalid MBR signature'
p1, p2 = sector[446:462], sector[462:478]
assert p1[4] in (0x0b,0x0c), 'Boot partition is not FAT'
assert p2[4] == 0x83, 'Root partition is not Linux'
lba, length = struct.unpack_from('<II', p2, 8)
print('OFFSET=' + str(lba * 512))
print('LENGTH=' + str(length * 512))
PY
)"
else
  OFFSET=545259520
  LENGTH=4294967296
fi
loop="$(losetup -r -f --show -o "$OFFSET" --sizelimit "$LENGTH" "$IMG")"
echo "Read-only ext4 loop: $loop"
inspect() { debugfs -R "stat $1" "$loop" 2>/dev/null; }
has() { inspect "$1" | grep -q 'Inode:'; }
for name in /usr/local/bin/resoarc /usr/local/bin/resoarc-setup /usr/local/bin/resoarc-getty-firstboot /usr/local/lib/resoarcos/firstboot.py /etc/systemd/system/getty@tty1.service.d/resoarc.conf /etc/systemd/system/getty.target.wants/getty@tty1.service /etc/resoarc/release /usr/bin/python3 /usr/sbin/sshd; do
  if ! has "$name"; then echo "FAIL missing $name" >&2; exit 3; fi
  echo "PASS $name"
done
if debugfs -R 'cat /etc/systemd/system/getty@tty1.service.d/resoarc.conf' "$loop" 2>/dev/null | grep -q 'resoarc-getty-firstboot'; then
  echo "PASS getty first-boot override"
else
  echo 'FAIL first-boot getty override' >&2; exit 4
fi
if debugfs -R 'cat /etc/shadow' "$loop" 2>/dev/null | grep -Eq '^resoarc:[!*]'; then
  echo 'PASS administrator password initially locked'
else
  echo 'FAIL initial account credential lock' >&2; exit 5
fi
if has /var/lib/resoarc/setup-complete.json; then
  echo 'FAIL image already marked configured' >&2; exit 6
fi
if has /etc/systemd/system/multi-user.target.wants/ssh.service || has /etc/systemd/system/sockets.target.wants/ssh.socket; then
  echo 'FAIL image enables SSH before provisioning' >&2; exit 7
fi
for name in /etc/ssh/ssh_host_rsa_key /etc/ssh/ssh_host_ecdsa_key /etc/ssh/ssh_host_ed25519_key; do
  if has "$name"; then echo "FAIL image contains reusable SSH host identity: $name" >&2; exit 10; fi
done
echo 'PASS first boot not completed, SSH disabled, no reusable SSH host keys'
if [ "${2:-}" = '--require-grow' ]; then
  for name in /usr/local/bin/resoarc-web /usr/local/lib/resoarcos/web.py /usr/local/sbin/resoarc-grow-root /etc/systemd/system/resoarc-grow-root.service /etc/systemd/system/multi-user.target.wants/resoarc-grow-root.service /usr/bin/growpart /usr/sbin/resize2fs; do
    if ! has "$name"; then echo "FAIL missing grow-root dependency: $name" >&2; exit 8; fi
    echo "PASS $name"
  done
  if ! debugfs -R 'cat /etc/systemd/system/resoarc-grow-root.service' "$loop" 2>/dev/null | grep -q 'ExecStart=/usr/local/sbin/resoarc-grow-root'; then
    echo 'FAIL grow-root service configuration' >&2; exit 9
  fi
  if ! debugfs -R 'cat /etc/resoarc/release' "$loop" 2>/dev/null | grep -q 'RESOARC_PI_FEATURES=firstboot,root-grow,local-web'; then
    echo 'FAIL missing Pi feature revision marker' >&2; exit 12
  fi
  echo 'PASS root expansion and local dashboard provisioned (hardware behavior untested)'
fi
if [ "$MODEL" = zero ]; then
  if ! has /etc/cloud/cloud-init.disabled; then
    echo 'FAIL: upstream cloud-init is not disabled for ResoArcOS provisioning' >&2; exit 14
  fi
  if ! debugfs -R 'stat /etc/machine-id' "$loop" 2>/dev/null | grep -Eq 'Size:[[:space:]]*0([^0-9]|$)'; then
    echo 'FAIL: image contains a reusable machine-id' >&2; exit 15
  fi
  if ! debugfs -R 'cat /etc/shadow' "$loop" 2>/dev/null | grep -Eq '^root:[!*]'; then
    echo 'FAIL: root account was not locked' >&2; exit 16
  fi
  echo 'PASS ARMv6 Zero stock cloud-init disabled, machine-id cleared, root login locked'
fi
echo 'PASS generated IMG rootfs validation (boot test still pending)'
