# Safely prepare a verified ResoArcOS image for manual flashing.
# Never writes, formats, selects or modifies a storage device.
param(
    [ValidateSet('3','4','5','zero2w','zero')][string]$Model = '5',
    [ValidatePattern('^[A-Za-z0-9_-]{1,32}$')][string]$BuildTag = 'grow-v1',
    [switch]$NoOpen
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Folder = Join-Path $Root ('out\pi-images-' + $BuildTag)
$Name = if ($Model -eq 'zero') { 'resoarcos-pizero-armhf.img' } else { 'resoarcos-pi' + $Model + '-arm64.img' }
$Image = Join-Path $Folder $Name
$Manifest = $Image + '.sha256'
if (-not (Test-Path $Image) -or -not (Test-Path $Manifest)) {
    throw ('IMG or SHA-256 manifest not found: ' + $Image + '. Build and verify this model first.')
}
$Expected = ((Get-Content $Manifest -Raw).Trim() -split '\s+')[0].ToLowerInvariant()
$Actual = (Get-FileHash -Path $Image -Algorithm SHA256).Hash.ToLowerInvariant()
if ($Actual -ne $Expected) {
    throw ('Image checksum mismatch. Do not flash this image: ' + $Image)
}
& python (Join-Path $Root 'scripts\verify_pi_image_layout.py') $Image | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Image partition/boot verification failed' }
Write-Output ('VERIFIED IMG: ' + $Image)
Write-Output ('SHA-256: ' + $Actual)
Write-Output 'IMPORTANT: Flashing a microSD card erases all data on that card.'
Write-Output 'In Raspberry Pi Imager: choose your Pi model, Use custom image, select this .img, then carefully choose the SD card and write.'

if ($NoOpen) { return }
$Paths = @(
    (Join-Path $env:ProgramFiles 'Raspberry Pi Imager\rpi-imager.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Raspberry Pi Imager\rpi-imager.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\Raspberry Pi Imager\rpi-imager.exe')
)
$Executable = $Paths | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $Executable) {
    $Found = Get-Command rpi-imager.exe -ErrorAction SilentlyContinue
    if ($Found) { $Executable = $Found.Source }
}
Start-Process -FilePath explorer.exe -ArgumentList ('/select,"' + $Image + '"')
if ($Executable) {
    Start-Process -FilePath $Executable
    Write-Output 'Raspberry Pi Imager opened. Choose the verified image shown in Explorer.'
} else {
    Write-Output 'Raspberry Pi Imager is not installed. Get it from https://www.raspberrypi.com/software/'
    Write-Output 'The image folder is open. No disk has been modified.'
}
