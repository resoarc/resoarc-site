#!/usr/bin/env python3
"""Resume and verify the official Raspberry Pi OS Lite ARMHF source archive.

This only fetches a known upstream source archive to out/upstream. It does not
install, modify a disk image, or write to any physical SD card.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.request import Request, urlopen
import argparse
import hashlib
import math
import os
import re
import shutil
import sys
import time

FILE = "2026-10-06-raspios-trixie-armhf-lite.img.xz"
URL = ("https://ftp.jaist.ac.jp/pub/raspberrypi/raspios_lite_armhf/"
       "images/raspios_lite_armhf-2026-10-06/" + FILE)
EXPECTED_BYTES = 569_747_828
EXPECTED_SHA = "2c302771f34c67a0b7ae7aa2e0dcdd3eac660504be59193c011ba79d412e1632"


def fetch_chunk(index: int, directory: Path, streams: int) -> Path:
    span = math.ceil(EXPECTED_BYTES / streams)
    start = index * span
    end = min(EXPECTED_BYTES - 1, start + span - 1)
    need = end - start + 1
    part = directory / f"part-{index:02d}-of-{streams:02d}.chunk"
    failures = 0
    while True:
        done = part.stat().st_size if part.exists() else 0
        if done == need:
            print(f"Verified chunk length {index+1}/{streams}: {done}", flush=True)
            return part
        if done > need:
            raise ValueError(f"Chunk {index} is longer than its reserved byte range")
        begin = start + done
        req = Request(URL, headers={
            "Range": f"bytes={begin}-{end}",
            "Accept-Encoding": "identity",
            "User-Agent": "ResoArcOS-source-acquisition/0.1",
        })
        try:
            with urlopen(req, timeout=35) as response:
                if response.status != 206:
                    raise ValueError(f"Missing HTTP 206 for chunk {index}: {response.status}")
                cr = response.headers.get("Content-Range", "")
                match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", cr)
                if not match or int(match[1]) != begin or int(match[3]) != EXPECTED_BYTES:
                    raise ValueError(f"Unexpected Content-Range: {cr}")
                with part.open("ab") as dest:
                    while True:
                        piece = response.read(256 * 1024)
                        if not piece:
                            break
                        dest.write(piece)
            failures = 0
        except (OSError, TimeoutError) as exc:
            failures += 1
            if failures > 30:
                raise RuntimeError(f"Chunk {index} failed too often: {exc}") from exc
            time.sleep(min(10, failures * 2))
            continue
        if part.stat().st_size == done:
            failures += 1
            if failures > 30:
                raise RuntimeError(f"Chunk {index} had no progress")
            time.sleep(min(10, failures * 2))


def verify_existing(archive: Path) -> bool:
    if not archive.exists():
        return False
    if archive.stat().st_size != EXPECTED_BYTES:
        raise ValueError("Existing archive has unexpected size; refusing to overwrite")
    with archive.open("rb") as source:
        digest = hashlib.file_digest(source, "sha256").hexdigest()
    if digest != EXPECTED_SHA:
        raise ValueError("Existing archive does not match official SHA-256")
    return True


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--streams", type=int, default=8)
    args = parser.parse_args(argv)
    if not 1 <= args.streams <= 16:
        parser.error("streams must be between 1 and 16")
    folder = args.directory.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    archive = folder / FILE
    if verify_existing(archive):
        print("PASS previously verified official 32-bit source", flush=True)
        return 0
    parts = [None] * args.streams
    with ThreadPoolExecutor(max_workers=args.streams) as pool:
        futures = {pool.submit(fetch_chunk, i, folder, args.streams): i
                   for i in range(args.streams)}
        for future in as_completed(futures):
            idx = futures[future]
            parts[idx] = future.result()
    staging = folder / (FILE + ".assembling")
    digest = hashlib.sha256()
    with staging.open("wb") as result:
        for part in parts:
            with part.open("rb") as source:
                while piece := source.read(4 * 1024 * 1024):
                    result.write(piece)
                    digest.update(piece)
    if staging.stat().st_size != EXPECTED_BYTES or digest.hexdigest() != EXPECTED_SHA:
        staging.unlink(missing_ok=True)
        raise ValueError("Official 32-bit base source SHA-256 mismatch")
    staging.replace(archive)
    (folder / (FILE + ".sha256")).write_text(f"{EXPECTED_SHA}  {FILE}\n", encoding="ascii")
    for part in parts:
        part.unlink()
    print(f"PASS official Raspberry Pi OS Lite 32-bit source SHA256={EXPECTED_SHA}", flush=True)
    print(f"Source archive: {archive}", flush=True)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("FAIL:", exc, file=sys.stderr)
        sys.exit(1)
