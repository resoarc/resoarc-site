# Resume verification when the already-started Pi 3B build completes.
# This script never writes to physical SD cards or modifies the previous images.
$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Name = 'resoarc-pi3-pi3-first-builder'
$Folder = Join-Path $Repo 'out\pi-images-pi3-first'
$Image = Join-Path $Folder 'resoarcos-pi3-arm64.img'
$Deadline = (Get-Date).AddHours(2)
New-Item -ItemType Directory -Force -Path $Folder | Out-Null
Write-Output 'Monitoring the Pi 3B builder; no changes to user storage media.'
while ((Get-Date) -lt $Deadline) {
    $Current = docker inspect $Name --format '{{.State.Status}}:{{.State.ExitCode}}' 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Pi 3B builder not found' }
    if ($Current -match '^exited:(\d+)$') { break }
    if ($Current -match '^(dead|removing):') { throw ('Pi 3B builder failure: ' + $Current) }
    Start-Sleep -Seconds 20
}
if ((Get-Date) -ge $Deadline) { throw 'Pi 3B builder exceeded acceptance deadline' }
Write-Output ('Pi 3B builder terminal state: ' + $Current)

if (-not (Test-Path $Image)) {
    $Source = $Name + ':/builder/work/image-resoarcos-pi3-arm64/resoarcos-pi3-arm64.img'
    $Part = $Image + '.part'
    & docker cp $Source $Part
    if ($LASTEXITCODE -ne 0) { throw 'Pi 3B raw IMG was not generated; inspect build logs' }
    Move-Item -Force $Part $Image
    Write-Output 'Recovered generated Pi 3B IMG from the build container'
}
# Rewrite the checksum only for an image successfully recovered from our own
# original builder, never accept an unrelated pre-existing candidate silently.
$Manifest = $Image + '.sha256'
if (-not (Test-Path $Manifest)) {
    $Hash = (Get-FileHash -Path $Image -Algorithm SHA256).Hash.ToLowerInvariant()
    ('{0}  resoarcos-pi3-arm64.img' -f $Hash) | Set-Content -Encoding ascii $Manifest
}
Write-Output 'Running strict Pi 3B image acceptance checks'
& (Join-Path $PSScriptRoot 'verify-pi-release.ps1') -Model 3 -BuildTag pi3-first
if ($LASTEXITCODE -ne 0) { throw 'Pi 3B image verification failed' }
$Hash = (Get-FileHash -Path $Image -Algorithm SHA256).Hash.ToLowerInvariant()
@(
    'ResoArcOS Raspberry Pi 3B ARM64 candidate'
    ('Verified UTC: {0}' -f (Get-Date).ToUniversalTime().ToString('o'))
    ('Raw IMG: {0}' -f $Image)
    ('Bytes: {0}' -f (Get-Item $Image).Length)
    ('SHA256: {0}' -f $Hash)
    'PASS: Raspberry Pi 3 boot files, FAT32/ext4, initial account and first-boot components'
    'PENDING: Real Raspberry Pi 3B boot, Wi-Fi and first-boot setup'
) | Set-Content -Path (Join-Path $Folder 'PI3-ACCEPTANCE.txt') -Encoding UTF8
Write-Output 'Pi 3B image acceptance file written'
