# One-shot, guarded PC vNext QA orchestration. No publishing, no disk writes.
param([string]$BuildId='pc-plan-v1', [int]$MaxWaitMinutes=75)
$ErrorActionPreference='Stop'
if ($BuildId -notmatch '^[a-z0-9][a-z0-9-]{0,24}$') { throw 'Unsafe build identifier' }
$root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$container="resoarcos-iso-$BuildId"
$iso=Join-Path $root "out/resoarcos-$BuildId-amd64.iso"
$evidence=Join-Path $root "out/qa-$BuildId"
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
$lock=Join-Path $evidence 'pipeline.lock'
$lockHandle=$null
try {
    $lockHandle=[IO.File]::Open($lock,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    $lockHandle.WriteByte(1)
    $lockHandle.Flush()
} catch { throw 'Another QA run may have already started. Inspect the lock and logs.' }
function Log([string]$message) { Write-Output ("$(Get-Date -Format o) $message") }
try {
    Log "Waiting for $container; no host partition or boot setting will be modified"
    $deadline=(Get-Date).AddMinutes($MaxWaitMinutes)
    while ((Get-Date) -lt $deadline) {
        $status=(& docker inspect $container --format '{{.State.Status}}|{{.State.ExitCode}}' 2>$null | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) { throw "Missing build container $container" }
        if ($status -eq 'exited|0') { break }
        if ($status -like 'exited|*' -or $status -like 'dead|*') { throw "ISO build failed: $status" }
        Start-Sleep -Seconds 20
    }
    if ($status -ne 'exited|0') { throw "Timed out waiting for build; last state $status" }
    Log "Build exited cleanly; verifying and copying"
    if (Test-Path $iso) { throw "ISO already exists; refusing to overwrite: $iso" }
    & (Join-Path $root 'scripts/finish-pc-docker.ps1') -BuildId $BuildId
    if (!(Test-Path $iso)) { throw 'Validated ISO not copied to host' }
    $sha=(Get-FileHash $iso -Algorithm SHA256).Hash.ToLowerInvariant()
    $bytes=(Get-Item $iso).Length
    Log "ISO_READY bytes=$bytes sha256=$sha"
    $safeId=$BuildId.Replace('-','_')
    foreach ($firmware in @('bios','uefi')) {
        $vm="resoarcos-qa-$BuildId-$firmware"
        if (@(& docker ps -a --format '{{.Names}}') -contains $vm) { throw "Container exists: $vm" }
        $prefix="resoarcos-$safeId-$firmware"
        Log "Starting $firmware QEMU virtual-CD-ROM test with networking disabled"
        $args=@('run','--name',$vm,'--cpus=2','--memory=2g','--memory-swap=2g',
                '--network=none','--read-only','--pids-limit=256','--tmpfs','/tmp:rw,exec,size=96m',
                '--mount',"type=bind,src=$root,dst=/src,readonly",
                '--mount',"type=bind,src=$root\out,dst=/results",
                '-w','/src','-e',"RESOARC_QEMU_FIRMWARE=$firmware",
                'resoarcos-qemu-smoke:local',
                'bash','scripts/qemu-media-smoke.sh',"/src/out/$(Split-Path $iso -Leaf)",$prefix)
        & docker @args
        if ($LASTEXITCODE -ne 0) { throw "$firmware QEMU screenshot/boot process failed" }
        foreach ($frame in @(1,2)) {
            $ppm=Join-Path $root "out/$prefix-$frame.ppm"
            if (!(Test-Path $ppm)) { throw "Missing $firmware screenshot $frame" }
            $png=[IO.Path]::ChangeExtension($ppm,'.png')
            & py -3.13 -c "from PIL import Image; Image.open(r'$ppm').save(r'$png')"
            if ($LASTEXITCODE -ne 0) { throw "Unable to export screenshot $ppm" }
        }
        Log "$firmware virtual-CD-ROM screenshots saved; visual guest-prompt review still required"
    }
    $report=@{
      schema=1; iso=$iso; bytes=$bytes; sha256=$sha
      local_tests='PASSED_PREVIOUSLY'
      internal_iso='PASS'
      bios='SCREENSHOTS_SAVED_NEEDS_VISUAL_REVIEW'
      uefi='SCREENSHOTS_SAVED_NEEDS_VISUAL_REVIEW'
      published=$false
      generated_utc=[DateTimeOffset]::UtcNow.ToString('o')
    } | ConvertTo-Json -Depth 5
    $reportPath=Join-Path $evidence 'qa-status.json'
    [IO.File]::WriteAllText($reportPath,$report,(New-Object Text.UTF8Encoding($false)))
    Log "QA_MEDIA_CAPTURE_DONE $reportPath"
} finally {
    if ($lockHandle) { $lockHandle.Dispose() }
}
