# Build ARMv6 Raspberry Pi Zero/Zero W candidate from a SHA-256-verified
# Raspberry Pi OS Lite 32-bit base, in isolated Docker storage.
# Does not flash or modify any physical disk.
param([ValidatePattern('^[A-Za-z0-9_-]{1,32}$')][string]$BuildTag = 'zero-armv6-first')
$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Upstream = Join-Path $Repo 'out\upstream\raspios-32bit-20261006'
$Source = Join-Path $Upstream 'extracted'
$Output = Join-Path $Repo ('out\pi-images-' + $BuildTag)
$Image = Join-Path $Output 'resoarcos-pizero-armhf.img'
$Manifest = Join-Path $Source 'ORIGINAL-ZERO-BASE.json'
$Original = Join-Path $Source '2026-10-06-raspios-trixie-armhf-lite.img'
if (Test-Path $Image) { throw 'Candidate IMG already exists. Refusing overwrite.' }
& python -B (Join-Path $PSScriptRoot 'prepare-original-zero-base.py') --source $Upstream --out $Source
if ($LASTEXITCODE -ne 0) { throw 'Official 32-bit source integrity validation failed' }
$Metadata = Get-Content $Manifest -Raw | ConvertFrom-Json
$Digest = (Get-FileHash $Original -Algorithm SHA256).Hash.ToLowerInvariant()
if ($Digest -ne $Metadata.raw_img_sha256) { throw 'Original 32-bit raw IMG SHA-256 mismatch' }
New-Item -ItemType Directory -Force -Path $Output | Out-Null
$Volume = 'resoarc-zero-stage-' + [Guid]::NewGuid().ToString('N')
& docker volume create $Volume | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Could not create isolated Linux scratch volume' }
try {
    Write-Output 'Staging ResoArcOS into a copied verified original-Zero ARMHF IMG'
    $Args = @('run','--rm','--privileged','--pull=never','--entrypoint','bash',
        '-v',($Source+':/images:ro'),'-v',($Repo+':/repo:ro'),
        '-v',($Output+':/output'),'-v',($Volume+':/scratch'),
        'resoarcos-pi-verifier:local','/repo/scripts/build-original-zero-offline.sh',
        '/images/2026-10-06-raspios-trixie-armhf-lite.img',
        '/output/resoarcos-pizero-armhf.img','/repo')
    & docker @Args
    if ($LASTEXITCODE -ne 0) { throw 'Original Zero staging failed; no IMG accepted.' }
} finally {
    & docker volume rm $Volume | Out-Null
}
if (-not (Test-Path $Image)) { throw 'Builder returned success but IMG is missing' }
Write-Output ('IMG: ' + $Image)
Write-Output ('SHA-256: ' + (Get-Content ($Image+'.sha256') -Raw).Trim())
Write-Output 'PENDING separate structural release verification and physical Zero boot test'
