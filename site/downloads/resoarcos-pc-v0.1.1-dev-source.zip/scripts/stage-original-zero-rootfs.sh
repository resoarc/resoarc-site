#!/usr/bin/env bash
# Offline ResoArcOS first-boot staging for a verified stock Raspberry Pi OS
# Lite (32-bit) *root filesystem directory*.
# Never executes ARM target binaries; never touches disks or partitions.
set -euo pipefail
root="${1:-}"
repo="${2:-/repo}"
if [[ -z "$root" || ! -d "$root" || "$root" = "/" ]]; then
    echo "Refusing unsafe or nonexistent rootfs target" >&2
    exit 2
fi
root="$(realpath "$root")"
if [[ "$root" = "/" || "$root" = /repo || "$root" = /images* ]]; then
    echo "Refusing source or host root directory" >&2
    exit 2
fi
for path in etc/passwd etc/shadow etc/group etc/gshadow; do
    test -f "$root/$path" || { echo "Missing required Raspberry Pi OS rootfs: $path" >&2; exit 3; }
done
for path in usr/bin/python3 usr/bin/nmcli usr/bin/sudo usr/sbin/sshd usr/bin/ssh-keygen usr/sbin/resize2fs usr/bin/growpart; do
    test -e "$root/$path" || { echo "Original Zero image prerequisite missing: $path" >&2; exit 4; }
done
test ! -e "$root/var/lib/resoarc/setup-complete.json" || {
    echo "Refusing image containing an existing setup identity" >&2
    exit 5
}
test -f "$repo/scripts/stage.py" || { echo "Missing staging script" >&2; exit 6; }
if grep -q '^resoarc:' "$root/etc/passwd"; then
    echo "Refusing to change an existing 'resoarc' account" >&2
    exit 7
fi
if ! grep -q '^sudo:' "$root/etc/group"; then
    echo "No sudo group available for administrator" >&2
    exit 8
fi

# First generate the portable Python/CLI code and read-only web dashboard.
python3 "$repo/scripts/stage.py" "$root"
install -d -m 0755 "$root/usr/local/bin" "$root/usr/local/sbin"
install -m 0755 "$repo/images/pi/getty-firstboot.sh" "$root/usr/local/bin/resoarc-getty-firstboot"
install -m 0755 "$repo/images/pi/setup-launcher.sh" "$root/usr/local/bin/resoarc-setup"
install -m 0755 "$repo/images/pi/grow-root.sh" "$root/usr/local/sbin/resoarc-grow-root"
install -d -m 0755 "$root/etc/systemd/system/getty@tty1.service.d" "$root/etc/systemd/system/getty.target.wants" "$root/etc/systemd/system/multi-user.target.wants"
# Official 32-bit Lite currently has no static tty1 wants symlink: enable it.
ln -sfn /usr/lib/systemd/system/getty@.service "$root/etc/systemd/system/getty.target.wants/getty@tty1.service"
install -m 0644 "$repo/images/pi/getty-override.conf" "$root/etc/systemd/system/getty@tty1.service.d/resoarc.conf"
install -m 0644 "$repo/images/pi/grow-root.service" "$root/etc/systemd/system/resoarc-grow-root.service"
ln -sfn ../resoarc-grow-root.service "$root/etc/systemd/system/multi-user.target.wants/resoarc-grow-root.service"

# Account creation is done via host useradd --root against OFFLINE text files.
# Password ! is locked, no factory credentials or SSH keys are supplied.
useradd --root "$root" --create-home --shell /bin/bash --gid users --groups sudo --password '!' resoarc
usermod --root "$root" --lock root
if ! grep '^resoarc:!' "$root/etc/shadow" >/dev/null; then
    echo "Administrator password is not locked" >&2
    exit 9
fi
install -d -m 0755 "$root/etc/ssh/sshd_config.d"
printf '%s\n' 'PermitRootLogin no' 'PasswordAuthentication no' 'KbdInteractiveAuthentication no' \
   > "$root/etc/ssh/sshd_config.d/60-resoarc.conf"
# No baked SSH identity; firstboot generates it after the user chooses auth.
rm -f "$root"/etc/ssh/ssh_host_*_key "$root"/etc/ssh/ssh_host_*_key.pub
# Disable automatic SSH, retain a usable unmasked service for secure setup.
for dir in "$root/etc/systemd/system/multi-user.target.wants" "$root/etc/systemd/system/sockets.target.wants"; do
    rm -f "$dir/ssh.service" "$dir/ssh.socket"
done
install -d -m 0755 "$root/etc/cloud" "$root/etc/resoarc"
# Stock Raspberry Pi OS Lite ships cloud-init. Avoid competing first-boot
# provisioning: the ResoArcOS tty1 wizard replaces cloud-init for this image.
touch "$root/etc/cloud/cloud-init.disabled"
# Force unique machine identity on first boot, never ship a reused machine-id.
: > "$root/etc/machine-id"
rm -f "$root/var/lib/dbus/machine-id"
printf '%s\n' 'RESOARC_VERSION=0.1.0-dev' 'RESOARC_BASE=RaspberryPiOS-Trixie-armhf' \
    'RESOARC_PI_FEATURES=firstboot,root-grow,local-web' > "$root/etc/resoarc/release"
echo "PASS staged original Pi Zero ARMv6 rootfs. Offline image boot remains untested."
