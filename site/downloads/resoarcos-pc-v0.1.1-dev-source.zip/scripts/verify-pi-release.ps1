# Verify a generated ResoArcOS Pi SD image before using Raspberry Pi Imager.
param([ValidateSet('3','4','5','zero2w','zero')][string]$Model = '5', [ValidatePattern('^[A-Za-z0-9_-]{1,32}$')][string]$BuildTag = '', [switch]$OfflineGrowthTest)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Images = Join-Path $Root ('out\pi-images' + $(if ($BuildTag) { '-' + $BuildTag } else { '' }))
$Name = if ($Model -eq 'zero') { 'resoarcos-pizero-armhf.img' } else { 'resoarcos-pi' + $Model + '-arm64.img' }
$Image = Join-Path $Images $Name
$Manifest = $Image + '.sha256'
if (-not (Test-Path $Image)) { throw ('Image not generated: ' + $Image) }
if (-not (Test-Path $Manifest)) { throw ('Checksum manifest missing: ' + $Manifest) }
$Expected = ((Get-Content $Manifest -Raw).Trim() -split '\s+')[0].ToLowerInvariant()
$Actual = (Get-FileHash -Path $Image -Algorithm SHA256).Hash.ToLowerInvariant()
if ($Expected -ne $Actual) { throw ('SHA256 MISMATCH. Expected ' + $Expected + ' actual ' + $Actual) }
Write-Output ('PASS SHA256: ' + $Actual)
& python (Join-Path $Root 'scripts\verify_pi_image_layout.py') $Image
if ($LASTEXITCODE -ne 0) { throw 'Pi image partition/FAT/EXT4 layout verification failed' }
$Verifier = 'resoarcos-pi-verifier:local'
& docker image inspect $Verifier --format '{{.Id}}' 2>$null | Out-Null
$NeedsVerifierBuild = ($LASTEXITCODE -ne 0)
if (-not $NeedsVerifierBuild) {
    & docker run --rm --pull=never --entrypoint sh $Verifier -c 'command -v mtype >/dev/null'
    $NeedsVerifierBuild = ($LASTEXITCODE -ne 0)
}
if ($NeedsVerifierBuild) {
    & docker build --pull=false -t $Verifier -f (Join-Path $Root 'images\pi\Dockerfile.verify') $Root
    if ($LASTEXITCODE -ne 0) { throw 'Could not build the open-source Pi image verification container' }
}
$Args = @(
 'run','--rm','--privileged','--pull=never','--entrypoint','bash',
 '-v',($Images + ':/images:ro'),'-v',($Root + ':/repo:ro'),
 $Verifier,'/repo/scripts/verify-pi-image.sh',$Model
)
if ($BuildTag) { $Args += '--require-grow' }
& docker @Args
if ($LASTEXITCODE -ne 0) { throw 'Pi ext4 rootfs verification failed' }
& docker run --rm --pull=never --entrypoint bash -v ($Images + ':/images:ro') -v ($Root + ':/repo:ro') $Verifier '/repo/scripts/verify-pi-boot-config.sh' ('/images/' + $Name) $Model
if ($LASTEXITCODE -ne 0) { throw 'Pi FAT boot configuration verification failed' }
if (Test-Path ($Image + '.zst')) {
    & python (Join-Path $Root 'scripts\verify_pi_archive.py') $Image
    if ($LASTEXITCODE -ne 0) {
        throw 'Compressed IMG archive failed integrity verification. Install Python zstandard if missing.'
    }
}
if ($OfflineGrowthTest) {
    # Uses only a disposable 8 GiB file in a Docker volume.
    $Scratch = 'resoarc-grow-qa-' + [Guid]::NewGuid().ToString('N')
    & docker volume create $Scratch | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not create disposable expansion-test volume' }
    try {
        $RunArgs = @('run','--rm','--privileged','--cpus=2','--memory=4g','--pull=never','--entrypoint','bash',
            '-v',($Images + ':/images:ro'),'-v',($Root + ':/repo:ro'),
            '-v',($Scratch + ':/scratch'),$Verifier,
            '/repo/scripts/smoke-pi-root-grow.sh',('/images/' + $Name))
        & docker @RunArgs
        if ($LASTEXITCODE -ne 0) { throw 'Offline 8 GiB SD growth simulation failed' }
    }
    finally {
        & docker volume rm $Scratch | Out-Null
    }
}
Write-Output ('PASS: ' + $Name + ' is a structurally verified SD test image.')
Write-Output ('WARNING: Raspberry Pi ' + $Model + ' hardware boot and first-login still require physical verification.')
