#!/usr/bin/env bash
# Read real FAT32 boot content from the raw SD IMG, not just root filenames.
set -euo pipefail
image="${1:-}"
model="${2:-}"
case "$model" in 3|4|5|zero2w|zero) ;; *) echo 'Expected model 3,4,5,zero2w,zero' >&2; exit 2 ;; esac
test -f "$image" || { echo "IMG missing: $image" >&2; exit 2; }
offset="$(python3 - "$image" <<'PY'
import struct,sys
with open(sys.argv[1], "rb") as f:
    mbr=f.read(512)
assert mbr[510:]==b'\x55\xaa'
entry=mbr[446:462]
assert entry[4] in (0x0B, 0x0C, 0x0E)
print(struct.unpack_from("<I",entry,8)[0]*512)
PY
)"
config="$(mtype -i "$image@@$offset" ::config.txt)"
cmdline="$(mtype -i "$image@@$offset" ::cmdline.txt)"
printf '%s\n' "$config" | grep -Eq '^auto_initramfs=1\r?$' || { echo "Missing automatic initramfs config" >&2; exit 3; }
printf '%s\n' "$cmdline" | grep -q 'console=tty1' || { echo "Missing HDMI console" >&2; exit 4; }
printf '%s\n' "$cmdline" | grep -Eq 'root=[^ ]+' || { echo "Missing root device directive" >&2; exit 5; }
# Ensure the Pi 3's mandatory 64-bit boot assets are actually readable
# through the FAT driver, rather than trusting only directory entry names.
if [ "$model" = 3 ]; then
    mtype -i "$image@@$offset" ::kernel8.img >/dev/null
    mtype -i "$image@@$offset" ::bcm2710-rpi-3-b.dtb >/dev/null
    echo 'PASS Pi 3B FAT32 kernel8.img and bcm2710-rpi-3-b.dtb readable'
elif [ "$model" = zero2w ]; then
    mtype -i "$image@@$offset" ::kernel8.img >/dev/null
    mtype -i "$image@@$offset" ::bcm2710-rpi-zero-2-w.dtb >/dev/null
    echo 'PASS Zero 2 W FAT32 kernel8.img and bcm2710-rpi-zero-2-w.dtb readable'
elif [ "$model" = zero ]; then
    mtype -i "$image@@$offset" ::kernel.img >/dev/null
    mtype -i "$image@@$offset" ::bcm2708-rpi-zero.dtb >/dev/null
    mtype -i "$image@@$offset" ::bcm2708-rpi-zero-w.dtb >/dev/null
    echo 'PASS original Pi Zero ARMv6 FAT32 kernel.img and device trees readable'
fi
echo "PASS Pi $model FAT boot config auto_initramfs and tty1 console"
