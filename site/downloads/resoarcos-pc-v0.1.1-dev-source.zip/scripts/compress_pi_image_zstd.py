#!/usr/bin/env python3
"""Compress a verified ResoArcOS raw IMG to a checked .zst archive.

No temporary uncompressed image is produced; source IMG is read-only.
"""
import argparse
import hashlib
from pathlib import Path
import sys

import zstandard as zstd


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        while block := source.read(8 * 1024 * 1024):
            h.update(block)
    return h.hexdigest()


def compress(image: Path) -> Path:
    manifest = Path(str(image) + ".sha256")
    if not image.is_file() or not manifest.is_file():
        raise ValueError("IMG and verified SHA-256 manifest are required")
    expected = manifest.read_text(encoding="ascii").split()[0].lower()
    if len(expected) != 64 or file_sha256(image) != expected:
        raise ValueError("Raw IMG does not match SHA-256 manifest")
    archive = Path(str(image) + ".zst")
    if archive.exists():
        raise ValueError("Compressed archive exists; refusing overwrite")
    temporary = Path(str(archive) + ".part")
    try:
        with image.open("rb") as raw, temporary.open("wb") as target:
            with zstd.ZstdCompressor(level=3).stream_writer(target, closefd=False) as out:
                while data := raw.read(8 * 1024 * 1024):
                    out.write(data)
        temporary.replace(archive)
        digest = file_sha256(archive)
        Path(str(archive) + ".sha256").write_text(
            f"{digest}  {archive.name}\n", encoding="ascii"
        )
        print(f"PASS {archive}, SHA-256 {digest}", flush=True)
        return archive
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path)
    args = parser.parse_args()
    try:
        compress(args.image)
    except (OSError, ValueError, zstd.ZstdError) as error:
        print(f"FAIL {error}", file=sys.stderr)
        sys.exit(1)
