#!/usr/bin/env python3
"""Create a privacy-audited source ZIP for an anonymous ResoArcOS PC preview.

Only committed files from HEAD are considered. A strict path allowlist excludes
internal planning documents and personal-machine quickstarts. Never include
untracked, working-directory, firmware, ROM or generated ISO files.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import pathlib
import re
import subprocess
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ALLOWED_FILES = {
    ".gitattributes", ".gitignore", "LICENSE", "README.md", "pyproject.toml",
    ".github/workflows/build-pc.yml", ".github/workflows/test.yml",
}
ALLOWED_PREFIXES = ("images/pc/", "images/pi/", "src/resoarcos/", "scripts/", "tests/")
ALLOWED_DOCS = {"docs/PC_DOCKER_QA_20261016.md", "docs/PC_GUI_20261016.md",
                "docs/PC_FIRMWARE_QEMU_20261016.md", "docs/PC_INSTALL_PLANNING.md",
                "docs/PC_PLAN_V1_QA_20261016.md"}
IDENTITY_PATTERNS = (
    re.compile("zin" + "1985", re.IGNORECASE),
    re.compile(r"[A-Za-z]:\\Users\\[A-Za-z0-9_.-]+", re.IGNORECASE),
    re.compile("resoarc" + "0001" + r"@gmail\.com", re.IGNORECASE),
    re.compile("/home/" + "zin" + r"(?:/|\b)", re.IGNORECASE),
)


def allowed(name: str) -> bool:
    return (name in ALLOWED_FILES or name in ALLOWED_DOCS or
            any(name.startswith(prefix) for prefix in ALLOWED_PREFIXES))


def create_snapshot(destination: pathlib.Path) -> tuple[int, str]:
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite {destination}")
    archive = subprocess.run(
        ["git", "-C", str(ROOT), "archive", "--format=zip", "HEAD"],
        capture_output=True, check=True, timeout=60,
    ).stdout
    source = zipfile.ZipFile(io.BytesIO(archive), "r")
    entries = []
    for member in source.infolist():
        name = member.filename
        if member.is_dir() or not allowed(name):
            continue
        if name.startswith("/") or ".." in pathlib.PurePosixPath(name).parts:
            raise ValueError("Unsafe archive path")
        if member.file_size > 3_000_000:
            raise ValueError(f"Unexpectedly large source file: {name}")
        body = source.read(member)
        if b"\0" in body:
            raise ValueError(f"Unexpected binary content in source ZIP: {name}")
        text = body.decode("utf-8")
        for rule in IDENTITY_PATTERNS:
            if rule.search(text):
                raise ValueError(f"Identity/local path audit failed for {name}")
        entries.append((name, body))
    required = {"LICENSE", "README.md", "pyproject.toml",
                "images/pc/build.sh", "images/pc/Dockerfile.build",
                "scripts/stage.py", "scripts/verify-iso.sh",
                "src/resoarcos/install.py", "src/resoarcos/cli.py",
                "tests/test_install.py"}
    present = {name for name, _ in entries}
    if not required.issubset(present):
        raise ValueError(f"Required source missing: {required - present}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=7) as out:
            for name, body in sorted(entries):
                out.writestr(name, body)
        digest = hashlib.sha256(destination.read_bytes()).hexdigest()
        destination.with_suffix(destination.suffix + ".sha256").write_text(
            f"{digest}  {destination.name}\n", encoding="ascii",
        )
        return len(entries), digest
    except BaseException:
        destination.unlink(missing_ok=True)
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=pathlib.Path)
    args = parser.parse_args()
    count, sha = create_snapshot(args.output.resolve())
    print(f"RESOARC_PC_SOURCE_AUDIT_PASS files={count} sha256={sha}")
