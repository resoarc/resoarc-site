#!/usr/bin/env bash
# Disposable offline expansion test: never writes to the source IMG or host disk.
set -euo pipefail
image="${1:-/images/resoarcos-pi5-arm64.img}"
test -f "$image" || { echo "Image missing" >&2; exit 2; }
test -d /scratch || { echo "Missing disposable scratch directory" >&2; exit 2; }
scratch="$(mktemp /scratch/resoarc-grow-XXXXXX)"
disk_loop=""
root_loop=""
cleanup() {
    if [ -n "$root_loop" ]; then losetup -d "$root_loop" || true; fi
    if [ -n "$disk_loop" ]; then losetup -d "$disk_loop" || true; fi
    rm -f "$scratch"
}
trap cleanup EXIT
# Docker Desktop exposes a small subset of /dev/loop minors by default.
# Add container-local nodes so a concurrently running verifier cannot
# exhaust loop0..loop7. Never detach other jobs' loop devices.
for i in $(seq 8 31); do
    if [ ! -b "/dev/loop$i" ]; then mknod "/dev/loop$i" b 7 "$i"; fi
done

# A sparse file emulates an 8 GiB SD card; existing IMG bytes are copied exactly.
truncate -s 8G "$scratch"
dd if="$image" of="$scratch" bs=16M conv=notrunc,sparse status=none
disk_loop="$(losetup -f --show "$scratch")"
case "$disk_loop" in /dev/loop[0-9]*) ;; *) echo "Unexpected loop device" >&2; exit 3;; esac

partition_geometry() {
    python3 - "$scratch" <<'PY'
import struct, sys
with open(sys.argv[1], 'rb') as f:
    sector = f.read(512)
assert sector[510:] == b'\x55\xaa'
entry = sector[462:478]
assert entry[4] == 0x83
start, sectors = struct.unpack_from('<II', entry, 8)
assert start > 0 and sectors > 0
print(f'{start * 512} {sectors * 512}')
PY
}
read -r offset length <<< "$(partition_geometry)"
root_loop="$(losetup -f --show -o "$offset" --sizelimit "$length" "$scratch")"
before="$(dumpe2fs -h "$root_loop" 2>/dev/null | awk '/Block count:/ {print $3; exit}')"
test -n "$before" || { echo "Missing original ext4 block count" >&2; exit 5; }
losetup -d "$root_loop"
root_loop=""

# Modify only the simulated SD file's MBR. Docker Desktop need not expose
# /dev/loopXp2 partition nodes because the ext4 region uses an offset loop.
growpart "$disk_loop" 2
losetup -c "$disk_loop"
read -r offset length <<< "$(partition_geometry)"
root_loop="$(losetup -f --show -o "$offset" --sizelimit "$length" "$scratch")"
# Stock Raspberry Pi OS Lite ARMHF snapshots may be flagged for first-boot
# journal replay. Unlike the real booted/mounted root, this offline test
# needs an ext4 filesystem check before resizing the disposable image.
fsck_rc=0
e2fsck -pf "$root_loop" || fsck_rc=$?
if [ "$fsck_rc" -gt 1 ]; then
    echo "Disposable IMG failed e2fsck ($fsck_rc)" >&2
    exit 6
fi
resize2fs "$root_loop"
after="$(dumpe2fs -h "$root_loop" 2>/dev/null | awk '/Block count:/ {print $3; exit}')"
echo "Before ext4 blocks: $before"
echo "After ext4 blocks: $after"
test "$after" -gt "$before" || { echo "Root filesystem did not expand" >&2; exit 6; }
echo 'PASS disposable 8 GiB SD root expansion'
