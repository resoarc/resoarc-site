#!/usr/bin/env bash
# Read-only inspection of the verified Raspberry Pi OS 32-bit Lite base image.
set -euo pipefail
img="${1:-/images/2026-10-06-raspios-trixie-armhf-lite.img}"
test -f "$img"
read -r offset length <<< "$(python3 - "$img" <<'PY'
from pathlib import Path
import struct,sys
p=Path(sys.argv[1])
with p.open("rb") as f:
    mbr=f.read(512)
    entry=mbr[462:478]
    lba,sectors=struct.unpack_from("<II",entry,8)
    if mbr[-2:]!=b'\x55\xaa' or entry[4]!=0x83 or (lba+sectors)*512>p.stat().st_size:
        raise SystemExit("Invalid MBR/root")
    print(lba*512,sectors*512)
PY
)"
# Docker's /dev exposes only loop0-7 by default even when extra loop minors exist.
for i in $(seq 8 31); do
  if [[ ! -b "/dev/loop$i" ]]; then mknod "/dev/loop$i" b 7 "$i"; fi
done
loop="$(losetup -r -f --show -o "$offset" --sizelimit "$length" "$img")"
trap 'losetup -d "$loop"' EXIT
echo '=== ARMHF USERSPACE PREREQUISITES ==='
for f in /usr/bin/python3 /usr/bin/nmcli /usr/bin/sudo /usr/sbin/sshd /usr/bin/ssh-keygen /usr/sbin/resize2fs /usr/bin/growpart /usr/bin/raspi-config /etc/systemd/system/getty.target.wants/getty@tty1.service /etc/shadow /etc/passwd /etc/group; do
 if debugfs -R "stat $f" "$loop" 2>/dev/null | grep -q 'Inode:'; then echo "PRESENT $f"; else echo "MISSING $f"; fi
done
echo '=== OS VERSION ==='
debugfs -R 'cat /etc/os-release' "$loop" 2>/dev/null | head -n 12
echo '=== CLOUD INIT SERVICES ==='
for f in /usr/bin/cloud-init /etc/systemd/system/multi-user.target.wants/cloud-init.service /etc/systemd/system/multi-user.target.wants/ssh.service; do
 if debugfs -R "stat $f" "$loop" 2>/dev/null | grep -q 'Inode:'; then echo "PRESENT $f"; else echo "MISSING $f"; fi
done
echo '=== ORIGINAL ZERO BOOT FILES ==='
mtype -i "$img@@8388608" ::kernel.img > /dev/null
mtype -i "$img@@8388608" ::bcm2708-rpi-zero.dtb > /dev/null
mtype -i "$img@@8388608" ::bcm2708-rpi-zero-w.dtb > /dev/null
echo 'PASS original Zero kernel.img and device trees readable'
