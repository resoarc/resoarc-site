# Download the official ARMv6-compatible Raspberry Pi OS Lite 32-bit base.
# Python byte-range resume is robust to interrupted HTTPS sessions.
# Source SHA-256 is checked against the upstream published hash.
param([ValidateRange(1,16)][int]$Streams = 16)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
& python -B (Join-Path $PSScriptRoot 'fetch_original_zero_base.py') --directory (Join-Path $Root 'out\upstream\raspios-32bit-20261006') --streams $Streams
if ($LASTEXITCODE -ne 0) {
    throw 'Original Zero 32-bit source download or SHA-256 verification failed'
}
