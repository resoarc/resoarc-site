#!/usr/bin/env python3
"""Verify and extract the official Raspberry Pi OS 32-bit Lite base IMG.

Output is a LOCAL FILE only. No partition tools or physical disks are touched.
Never accept bytes unless the official upstream compressed SHA-256 matches.
"""
import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import struct
import sys

FILENAME = "2026-10-06-raspios-trixie-armhf-lite.img.xz"
EXPECTED_XZ_SIZE = 569_747_828
EXPECTED_SHA256 = "2c302771f34c67a0b7ae7aa2e0dcdd3eac660504be59193c011ba79d412e1632"


def mbr_layout(image: Path) -> dict:
    with image.open("rb") as source:
        sector = source.read(512)
        if len(sector) != 512 or sector[-2:] != b"\x55\xaa":
            raise ValueError("Missing MBR signature")
        partitions = []
        for i in (0, 1):
            part = sector[446 + i * 16:462 + i * 16]
            type_id = part[4]
            start, length = struct.unpack_from("<II", part, 8)
            if not start or not length or (start + length) * 512 > image.stat().st_size:
                raise ValueError("Image partition extent out of bounds")
            partitions.append({"type":type_id,"lba":start,"sectors":length})
        if partitions[0]["type"] not in (0x0B,0x0C,0x0E):
            raise ValueError("Missing FAT boot partition")
        if partitions[1]["type"] != 0x83:
            raise ValueError("Missing Linux root partition")
        source.seek(partitions[1]["lba"] * 512 + 1024 + 56)
        if source.read(2) != b"\x53\xef":
            raise ValueError("Missing ext2/3/4 filesystem signature")
    return {"size_bytes":image.stat().st_size,"partitions":partitions}


def extract(source_folder: Path, output_folder: Path) -> Path:
    archive = source_folder / FILENAME
    if not archive.exists() or archive.stat().st_size != EXPECTED_XZ_SIZE:
        raise ValueError("Official 32-bit compressed source is absent or incomplete")
    digest = hashlib.sha256()
    with archive.open("rb") as source:
        while data := source.read(4 * 1024 * 1024):
            digest.update(data)
    if digest.hexdigest() != EXPECTED_SHA256:
        raise ValueError("Official source archive SHA-256 mismatch")
    output_folder.mkdir(parents=True,exist_ok=True)
    target = output_folder / FILENAME.removesuffix(".xz")
    manifest = output_folder / "ORIGINAL-ZERO-BASE.json"
    if target.exists():
        if not manifest.exists():
            raise ValueError("Existing extracted IMG lacks its verification manifest")
        prior = json.loads(manifest.read_text(encoding="utf-8"))
        raw_hash = hashlib.sha256()
        with target.open("rb") as old:
            while data := old.read(4 * 1024 * 1024):
                raw_hash.update(data)
        if (prior.get("official_compressed_sha256") != EXPECTED_SHA256 or
                prior.get("raw_img_sha256") != raw_hash.hexdigest()):
            raise ValueError("Extracted IMG integrity mismatch; refusing to reuse")
        layout = mbr_layout(target)
        print("PASS previously verified extracted IMG:", layout)
        return target
    partial = target.with_suffix(".img.part")
    try:
        with lzma.open(archive,"rb") as compressed, partial.open("wb") as out:
            while data := compressed.read(8 * 1024 * 1024):
                out.write(data)
        layout = mbr_layout(partial)
        raw_hash = hashlib.sha256()
        with partial.open("rb") as extracted:
            while data := extracted.read(4 * 1024 * 1024):
                raw_hash.update(data)
        os.replace(partial,target)
        (output_folder / "ORIGINAL-ZERO-BASE.json").write_text(
            json.dumps({"official_compressed_sha256":EXPECTED_SHA256,
                        "raw_img_sha256":raw_hash.hexdigest(),
                        "base_img":target.name,"layout":layout,
                        "status":"verified upstream source, not ResoArcOS"},indent=2) + "\n",
            encoding="utf-8")
        print("PASS verified official 32-bit base IMG:",target)
        print(layout)
        return target
    finally:
        partial.unlink(missing_ok=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--source",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    try:
        extract(args.source,args.out)
    except (OSError, ValueError, EOFError, lzma.LZMAError) as exc:
        print("FAIL:",exc,file=sys.stderr)
        sys.exit(1)
