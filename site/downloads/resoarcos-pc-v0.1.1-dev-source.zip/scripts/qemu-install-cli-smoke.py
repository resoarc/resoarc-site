#!/usr/bin/env python3
"""Offline QEMU guest CLI exercise for ResoArcOS install preflight.

The guest boots from ISO only; no disk passthrough and no NIC. Screenshots are
evidence for subsequent visual review, not a claim that guest output was
programmatically understood. No real disk writes or installer actions occur.
"""
from __future__ import annotations

import argparse
import json
import pathlib
import socket
import subprocess
import tempfile
import time


def hmp(port: int, command: str) -> str:
    with socket.create_connection(("127.0.0.1", port), timeout=8) as sock:
        sock.settimeout(6)
        sock.recv(4096)
        sock.sendall((command + "\n").encode("ascii"))
        time.sleep(0.35)
        try:
            return sock.recv(32768).decode("utf8", "replace")
        except socket.timeout:
            return ""


def send_text(port: int, command: str) -> None:
    # HMP key names are intentionally limited to the literal read-only tests.
    for ch in command:
        if "a" <= ch <= "z" or "0" <= ch <= "9":
            key = ch
        elif ch == " ":
            key = "spc"
        elif ch == "-":
            key = "minus"
        elif ch == "/":
            key = "slash"
        else:
            raise ValueError(f"Unsupported key {ch!r}")
        response = hmp(port, f"sendkey {key}")
        if "Error" in response:
            raise RuntimeError(response)
        time.sleep(.06)
    response = hmp(port, "sendkey ret")
    if "Error" in response:
        raise RuntimeError(response)


def screen(port: int, destination: pathlib.Path) -> None:
    destination.unlink(missing_ok=True)
    response = hmp(port, f"screendump {destination}")
    if "Error" in response:
        raise RuntimeError(response)
    for _ in range(36):
        if destination.is_file() and destination.stat().st_size > 50000:
            return
        time.sleep(.25)
    raise TimeoutError(f"Could not save screenshot {destination}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("iso", type=pathlib.Path)
    parser.add_argument("--out-dir", type=pathlib.Path, required=True)
    parser.add_argument("--boot-wait", type=int, default=170)
    parser.add_argument("--port", type=int, default=4556)
    args = parser.parse_args()
    if args.boot_wait < 80:
        parser.error("Boot wait is too short")
    if not args.iso.is_file():
        parser.error("ISO missing")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="resoarc-install-qemu-") as d:
        tmp = pathlib.Path(d)
        subprocess.run(["xorriso", "-osirrox", "on", "-indev", str(args.iso),
                        "-extract", "/live/vmlinuz", str(tmp / "vmlinuz"),
                        "-extract", "/live/initrd.img", str(tmp / "initrd.img")],
                       check=True, timeout=90, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        command = [
            "qemu-system-x86_64", "-machine", "pc,accel=tcg",
            "-smp", "2", "-m", "1536", "-display", "none", "-vga", "std",
            "-monitor", f"tcp:127.0.0.1:{args.port},server,nowait",
            "-serial", f"file:{tmp/'serial.log'}",
            "-kernel", str(tmp/"vmlinuz"), "-initrd", str(tmp/"initrd.img"),
            "-append", "boot=live components hostname=resoarcos username=resoarc live-config.nocomponents=xinit console=tty0",
            "-cdrom", str(args.iso), "-nic", "none", "-no-reboot", "-no-shutdown",
        ]
        with (tmp/"qemu.log").open("wb") as log:
            proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
            try:
                deadline = time.monotonic() + 25
                while time.monotonic() < deadline:
                    try:
                        hmp(args.port, "info status")
                        break
                    except (OSError, TimeoutError):
                        time.sleep(1)
                else:
                    raise TimeoutError("QEMU monitor failed to start")
                time.sleep(args.boot_wait)
                if proc.poll() is not None:
                    raise RuntimeError("QEMU exited before CLI tests")
                before = args.out_dir / "install-cli-before.ppm"
                after_help = args.out_dir / "install-cli-help.ppm"
                after_list = args.out_dir / "install-cli-list.ppm"
                screen(args.port, before)
                send_text(args.port, "resoarc install --help")
                time.sleep(18)
                screen(args.port, after_help)
                send_text(args.port, "resoarc install list --json")
                time.sleep(20)
                screen(args.port, after_list)
                report = {
                    "image": str(args.iso), "guest_network": False,
                    "disk_passthrough": False,
                    "commands": ["resoarc install --help", "resoarc install list --json"],
                    "screenshots": [str(before), str(after_help), str(after_list)],
                    "execution": "sent_commands_and_captured_frames",
                    "output_verified": False,
                    "note": "Must visually review CLI output in screenshots before claiming success",
                }
                path = args.out_dir / "install-cli-qa.json"
                path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf8")
                print("RESOARC_INSTALL_CLI_FRAMES_CAPTURED")
                return 0
            finally:
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=10)


if __name__ == "__main__":
    raise SystemExit(main())
