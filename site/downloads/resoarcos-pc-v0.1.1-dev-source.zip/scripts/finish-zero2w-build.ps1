# Verify the long-running Zero 2 W native SD candidate after Docker finishes.
# Never flashes or modifies a physical removable disk.
$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Name = 'resoarc-pizero2w-zero2-first-builder'
$Out = Join-Path $Repo 'out\pi-images-zero2-first'
$Image = Join-Path $Out 'resoarcos-pizero2w-arm64.img'
$Deadline = (Get-Date).AddHours(2)
New-Item -ItemType Directory -Path $Out -Force | Out-Null
Write-Output 'Monitoring native Zero 2 W Docker builder'
$Current = ''
while ((Get-Date) -lt $Deadline) {
    $Current = docker inspect $Name --format '{{.State.Status}}:{{.State.ExitCode}}' 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Zero 2 W builder container unavailable' }
    if ($Current -match '^exited:(\d+)$') { break }
    if ($Current -match '^dead:') { throw ('Zero 2 W builder dead: ' + $Current) }
    Start-Sleep -Seconds 20
}
if ($Current -notmatch '^exited:(\d+)$') { throw 'Zero 2 W image build not complete before deadline' }
if ([int]$Matches[1] -ne 0) { throw ('Zero 2 W build exit code: ' + $Matches[1]) }
if (-not (Test-Path $Image)) { throw 'Zero 2 W builder completed but output IMG is absent' }
Write-Output 'Running strict Zero 2 W IMG release verification'
& (Join-Path $PSScriptRoot 'verify-pi-release.ps1') -Model zero2w -BuildTag zero2-first -OfflineGrowthTest
if ($LASTEXITCODE -ne 0) { throw 'Zero 2 W image release verification failed' }
$Hash = (Get-FileHash $Image -Algorithm SHA256).Hash.ToLowerInvariant()
@(
    'ResoArcOS Raspberry Pi Zero 2 W ARM64 image candidate'
    ('Verified UTC: {0}' -f (Get-Date).ToUniversalTime().ToString('o'))
    ('IMG: {0}' -f $Image)
    ('Bytes: {0}' -f (Get-Item $Image).Length)
    ('SHA256: {0}' -f $Hash)
    'PASS: Pi Zero 2 W FAT32 kernel, DTB, ARM64 root and locked firstboot'
    'PASS: root-grow and read-only localhost dashboard provisioned'
    'PENDING: Physical Zero 2 W boot and RAM usage check'
) | Set-Content -Path (Join-Path $Out 'ZERO2W-ACCEPTANCE.txt') -Encoding UTF8
Write-Output 'PASS Zero 2 W structural acceptance manifest created'
