# Run the complete disposable SD expansion release gate after the native
# Zero 2 W builder and static acceptance job complete. No physical disks touched.
$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Dir = Join-Path $Repo 'out\pi-images-zero2-first'
$StaticAcceptance = Join-Path $Dir 'ZERO2W-ACCEPTANCE.txt'
$Report = Join-Path $Dir 'ZERO2W-GROW-QA.txt'
$Builder = 'resoarc-pizero2w-zero2-first-builder'
$Deadline = (Get-Date).AddHours(2)
Write-Output 'Checking native Zero 2 W acceptance before disposable SD growth test'
while (-not (Test-Path $StaticAcceptance)) {
    if ((Get-Date) -ge $Deadline) { throw 'Zero 2 W acceptance was not completed before the deadline' }
    $State = docker inspect $Builder --format '{{.State.Status}}:{{.State.ExitCode}}' 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Native Zero 2 W Docker builder unavailable' }
    if ($State -match '^exited:(\d+)$' -and [int]$Matches[1] -ne 0) {
        throw ('Native Zero 2 W builder failed: ' + $State)
    }
    Start-Sleep -Seconds 30
}
& (Join-Path $PSScriptRoot 'verify-pi-release.ps1') -Model zero2w -BuildTag zero2-first -OfflineGrowthTest
if ($LASTEXITCODE -ne 0) { throw 'Zero 2 W disposable SD growth acceptance failed' }
@(
    'ResoArcOS Zero 2 W native IMG disposable SD QA'
    ('UTC: {0}' -f (Get-Date).ToUniversalTime().ToString('o'))
    'PASS: SHA256, FAT32 boot files, root ext4, first-boot security, compressed IMG'
    'PASS: 8 GiB simulated microSD partition 2 and ext4 root expansion'
    'PENDING: Actual Zero 2 W hardware boot and setup'
) | Set-Content -Path $Report -Encoding UTF8
Write-Output ('PASS Zero2 W native SD acceptance: ' + $Report)
