#!/usr/bin/env bash
# Validate the generated live ISO and security-critical ResoArcOS payload modes.
set -euo pipefail
ISO="${1:?Usage: verify-iso.sh /path/to/resoarcos.iso}"
test -s "$ISO" || { echo "Missing ISO: $ISO" >&2; exit 2; }
for cmd in xorriso unsquashfs sha256sum stat; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Missing required command: $cmd" >&2; exit 2; }
done
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
xorriso -osirrox on -indev "$ISO" \
  -extract /live/filesystem.squashfs "$TMP/filesystem.squashfs" \
  -extract /live/vmlinuz "$TMP/vmlinuz" \
  -extract /live/initrd.img "$TMP/initrd.img" >"$TMP/xorriso.log" 2>&1
# Headless-first invariant: both BIOS and UEFI normal boot entries must disable
# Debian live-config's automatic xinit/startx component.
xorriso -osirrox on -indev "$ISO" \
  -extract /isolinux/live.cfg "$TMP/isolinux-live.cfg" \
  -extract /boot/grub/grub.cfg "$TMP/grub.cfg" >"$TMP/bootcfg.log" 2>&1
for config in "$TMP/isolinux-live.cfg" "$TMP/grub.cfg"; do
  if ! grep -E '^[[:space:]]*(append|linux)[[:space:]]' "$config" |
      grep -q 'live-config.nocomponents=xinit'; then
    echo "Missing headless-first boot parameter in: $config" >&2
    exit 1
  fi
done
test "$(stat -c %s "$TMP/filesystem.squashfs")" -gt 100000000
test "$(stat -c %s "$TMP/vmlinuz")" -gt 1000000
test "$(stat -c %s "$TMP/initrd.img")" -gt 1000000
unsquashfs -no-progress -d "$TMP/root" "$TMP/filesystem.squashfs" \
  usr/local/bin/resoarc usr/local/bin/resogui usr/local/bin/resoarc-desktop \
  usr/local/lib/resoarcos etc/resoarc/release >/dev/null
for executable in resoarc resogui resoarc-desktop; do
  f="$TMP/root/usr/local/bin/$executable"
  test -f "$f"
  test "$(stat -c %a "$f")" = 755 || { echo "Invalid mode for $executable" >&2; exit 1; }
  sh -n "$f"
done
grep -q 'python3 -I -c' "$TMP/root/usr/local/bin/resoarc" || { echo "Management launcher lacks isolated Python mode" >&2; exit 1; }
if grep -q 'PYTHONPATH' "$TMP/root/usr/local/bin/resoarc"; then
  echo "Management launcher inherits untrusted Python paths" >&2
  exit 1
fi
while IFS= read -r -d '' file; do
  mode="$(stat -c %a "$file")"
  test "$mode" = 644 || { echo "Unsafe managed code mode ($mode): $file" >&2; exit 1; }
done < <(find "$TMP/root/usr/local/lib/resoarcos" -type f -print0)
PYTHONPATH="$TMP/root/usr/local/lib" python3 -m resoarcos profile plan web --json >"$TMP/profile.json"
grep -q '"automatic_rollback_available": false' "$TMP/profile.json"
# Optional (next development candidate): check safe disk-planning commands if staged.
# Older v0.1.0-dev images do not yet have this module, and remain verifiable.
if [[ -f "$TMP/root/usr/local/lib/resoarcos/install.py" ]]; then
  PYTHONPATH="$TMP/root/usr/local/lib" python3 -m resoarcos install --help >"$TMP/install-help.txt"
  grep -q 'List disks without writing to them' "$TMP/install-help.txt" ||
    { echo 'Missing read-only install planning CLI' >&2; exit 1; }
  grep -q 'list,plan' "$TMP/install-help.txt" ||
    { echo 'Unexpected install CLI subcommands' >&2; exit 1; }
  if PYTHONPATH="$TMP/root/usr/local/lib" python3 -m resoarcos install apply --target /dev/sdb >"$TMP/unsafe-install.txt" 2>&1; then
    echo 'Destructive install apply must not be available in a developer-preview ISO' >&2
    exit 1
  fi
  echo 'ResoArcOS safe installer planning: read-only commands only.'
elif [[ "${RESOARC_REQUIRE_INSTALL_PLAN:-0}" == "1" ]]; then
  echo 'Expected safe install planning module is absent' >&2
  exit 1
fi
echo "Verified kernel, initrd, SquashFS, executables, trusted code mode and profile plan."
sha256sum "$ISO"
echo "RESOARC_ISO_CHECK_PASS"