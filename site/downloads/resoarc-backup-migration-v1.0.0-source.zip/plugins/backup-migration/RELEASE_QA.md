> **履歴文書（2026-10-20時点の開発QA）**：この資料の「59件」「NO-GO」「α」は当時の検証状態です。
> **v1.0.0配布判定に使用しないでください。** 最新の独立した再ビルド・116件試験・隔離実kintone 3,001件・B/C審査は
> [RELEASE_ACCEPTANCE_v1.0.0.md](RELEASE_ACCEPTANCE_v1.0.0.md)を参照してください。

# ResoArc Backup & Migration v0.3 Release Quality Gate

Status: **Release candidate under validation; NOT approved for production deployment**
Updated: 2026-10-16 (JST)

## Automated evidence

- [x] All 59 Node test cases passed on the Windows development computer.
- [x] A simulated kintone API round-trip transferred **501 source records**, including a nested table and a shared attachment.
- [x] Real headless Edge/browser UI mock now includes a real byte-for-byte **attachment round-trip in an ordinary field and nested subtable**, deduplicating the source download and uploading to both destination references. It also rejects a source cursor permission/error condition without creating an incomplete management backup. It created only a new *preview* app, simulated a lost response after 50 committed rows, resumed the remaining 451 rows, and confirmed that a third run added zero duplicates.
- [x] **Actual Edge headless browser smoke test with mocked kintone APIs**: dedicated BrowserCDP Edge loaded the production JavaScript bundle, rendered the management-app controls, created and read a 501-record ZIP, previewed and restored 501 records in 26 batches, and confirmed a second preview offered zero new records. The same real-browser script rejects a tampered ZIP, a destination without a unique restore marker, and an incorrect manual confirmation phrase **before any destination record write**. It also creates a **new app preview draft** via browser UI, verifies the unique restore marker exists, and asserts that **no deploy endpoint or existing-record modification** was used. The browser test exited successfully. No tenant login, cookies, or real API writes were used. Reproduce with `npm run test:browser` on Windows Edge or Linux Chrome; the runner uses a disposable browser profile.
- [x] Fixed ZIP entry timestamps when the archive creation time is explicit. Repeating the same QA input now creates byte-identical ZIPs and stable restore keys; cross-time repeatability and out-of-range timestamp tests pass.
- [x] The new QA API runner's mocked provisioning and end-to-end use of the production ZIP/restore code passes two consecutive runs without duplicate management or destination records. Additional tests enforce confirmation, tenant allowlist, and rejection of manipulated destination app IDs.
- [x] ZIP archive hardening rejects duplicate entry names and enforces a non-disableable 50,000-entry ceiling, in addition to the existing 25MiB byte limit. Three regression tests cover duplicate entries and entry-count limits. Two more tests confirm that the tenant probe rejects unsafe origins and invalid app IDs.
- [x] Browser UI regression simulates a first batch committed but its HTTP response lost: the UI stops, an explicit re-preview reports 20 completed and 481 pending, and a confirmed resume finishes all 501 with no duplicates.
- [x] Cursor tests cover multi-page reads, invalid pages, stalls, excessive row counts, cleanup on failure, and stopping before destination writes.
- [x] Archive tests cover SHA-256, corrupted contents, attachments, a large compressed payload, ZIP traversal names, and dangerous field-code rejection. **Five additional tests** alter JSONL data and recompute internal digests, verifying that malformed scalar, number, multiple-choice, user, subtable and file-reference structures are still rejected before restoration.
- [x] Field-planning tests cover compatible mappings, incompatible types, required/choice checks, and rejection of unsupported kintone field codes.
- [x] Patched `fflate` to `0.8.3` after detecting CVE-2026-45820 in `0.8.2`; the npm production dependency audit reports **0 known vulnerabilities**. The redistributed MIT license matches the installed upstream file.
- [x] A malformed ZIP64 sentinel parsing case runs in a child process with a hard timeout, so a decompression regression cannot hang the entire test suite.
- [x] Browser build reproduces the committed distribution in CI.
- [x] A standalone browser-smoke launcher has passed with an isolated **fresh Edge profile** on Windows. This is now also a required step in the dedicated GitHub Actions workflow, subject to its first CI run.
- [x] GitHub Actions: **both the Backup Migration and public-source workflows passed** for commit `6bb7f3a140d18430fb94c59b59a4d839765106d6`. Current record-shape validation and the expanded attachment browser test must pass again on the upcoming commit before public release decisions.
- [x] No desktop files created. Work is under the project's Documents/GitHub folder.
- [x] A safe, read-only CDP tenant readiness script is available at `scripts/tenant-api-probe.mjs`. On the development tenant, it returned **HTTP 401** for both GET app details and GET form fields. It never accesses response bodies or authentication secrets; malformed origins and IDs are rejected before browser access.
- [x] The read-only QA status command detects a dedicated Edge login page using tab metadata without issuing API calls or waiting on an unauthenticated renderer; API checks after login have bounded HTTP/CDP timeouts.
- [x] A separate visible QA Edge profile is running in the Windows interactive session. A localhost-only CDP adapter, strict developer-tenant allowlist held in a local-only Documents config, QA source/destination/management app provisioner, synthetic record/attachment seed, real-API backup/archive/restore round-trip runner, and read-only QA plan/status commands are implemented. **Offline mock of the full provisioning and repeatable API round-trip passes; credentials have not been extracted.**
- [ ] **Authenticated, real kintone tenant API round-trip** (not completed). The visible QA Edge has been opened for manual login; until the user signs in there, API requests return HTTP 401. Creating/deploying the three isolated QA apps requires an explicit confirmation.
- [ ] **User permission variation and inaccessible records** on a real tenant (not completed).
- [ ] **Actual preview app creation/deployment and restore** in an isolated real tenant (not completed).
- [ ] **Actual browser cancellation/session expiration and recovery** (not completed).

## Required isolated tenant procedure

Prepare **three new test applications**, not an existing business application:
1. A source app with a single-line text, number, selection, attachment, and table containing text/attachment. Add at least 3 non-sensitive dummy records, including an empty file field and a duplicate attachment.
2. A dedicated `ResoArc Backup` management app matching the six field codes in README.md. Restrict app and record access to the test operator.
3. An empty destination app with compatible fields and an editable, `unique=true` single-line `ResoArcRestoreKey` field. This must be an otherwise unused test app.

Run the following checks in the authenticated browser. **Never copy session cookies or passwords into logs.**
- [ ] In the source tenant, inspect `/k/v1/app.json` and `/k/v1/app/form/fields.json` with the read-only `scripts/diagnose-kintone-session.js` diagnostic. Confirm both read permissions.
- [ ] Install the built browser JS **on the management app only**, refresh its record index, verify a single operation panel appears, and check the console for initialization errors.
- [ ] Back up the source, confirm the management record's `Archive`, `SourceAppId`, `ArchiveHash` and count, download the ZIP, and independently confirm its SHA-256.
- [ ] Restore preview to the empty test destination, verify exact source/target field counts, skipped field names, and planned writes **before** confirmation.
- [ ] Restore once, compare all supported fields, table rows and attachment bytes, and verify unique `ResoArcRestoreKey` markers. The original IDs and audit trail are intentionally not cloned.
- [ ] Preview and restore the same archive again. Confirm `0 new records`, no duplicates, and unchanged original data.
- [ ] Test an incompatible target type and a missing unique marker. Confirm both stop **before** any record write.
- [ ] Test app creation preview; create a fresh preview app only; verify it remains pre-live and no existing app is modified. Manually deploy only after reviewing field settings.
- [ ] Test an interrupted restore on *test data only*. Verify confirmed already-written rows are skipped after explicit preview and retry; no blind automatic retry.
- [ ] Sign in as a user without required view/add permissions. Confirm safe failure and that an incomplete backup is not mistaken for full tenant data.
- [ ] If cross-tenant migration is advertised, test import of a ZIP through the approved offline channel, confirm mapping and actual restored bytes in another isolated tenant.

## Security and operational boundaries

- This is **append-only migration**, not a full disaster-recovery backup: it omits historical metadata, app permissions, process history, views, some field types, and inaccessible records.
- It is **not a transaction** across all batches. Failed restores can leave some newly inserted records.
- Record visibility is defined by current kintone permissions. A backup cannot assert that all tenant records were readable.
- An external ZIP has internal SHA-256 integrity checks, not a cryptographic signature proving origin. Only import from a trusted source.
- The 25 MiB uncompressed and ZIP size limit, the 50,000-entry ZIP limit, and the 20,000-record limit are explicit abort conditions, not silent truncation.
- Store a separate encrypted/off-tenant copy if continuity after tenant loss is required.
- No API tokens, session cookies, passwords, customer data or personally identifying evidence should be committed to the public repository.
- Releasing a stable public build must not be confused with deploying into a user's kintone account.

## Release decisions

- **Automated code quality gate:** PASS, subject to latest CI after all documentation updates.
- **Real-world integration gate:** BLOCKED pending isolated tenant tests and browser access.
- **Public production release:** **NO-GO** until the real-world integration gate passes.
- **Developer preview:** May remain available for review on a Draft PR with conspicuous alpha limitations, not promoted as production-ready.

For reproducibility run `npm ci && npm run check` inside `plugins/backup-migration`, then inspect `git diff --exit-code -- dist/resoarc-backup.js`.
