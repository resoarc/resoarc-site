# Third-party licenses for Backup & Migration

Runtime ZIP compression/decompression: **fflate 0.8.3**, Copyright © 2026 Arjun Barrett, MIT License.
The complete upstream license text is included at `licenses/fflate-MIT.txt` and inside the generated distributed JavaScript file.

Build tool only (not bundled at runtime): **esbuild 0.25.12**, MIT License.
See https://github.com/evanw/esbuild/blob/master/LICENSE.md.

ResoArc's own source code is licensed under the repository's MIT LICENSE. The package lockfile pins the exact dependency versions used for the v1.0.0 release build.
