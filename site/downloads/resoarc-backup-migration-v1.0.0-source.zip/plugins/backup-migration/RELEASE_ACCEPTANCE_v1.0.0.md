# ResoArc Backup & Migration v1.0.0 | Release Acceptance

検証日：2026-10-23

## 提供形態
本製品はkintoneアプリのPC用JavaScript/CSSカスタマイズのJavaScriptファイルと、オフライン閲覧用HTML/JS/CSSです。
**kintoneの署名済みプラグインZIPではありません。** PC用とモバイル用は別設定で、モバイル動作は対象外です。
kintoneライトコースではJavaScript/CSSカスタマイズを利用できません。提供対象はカスタマイズ機能が有効な契約と必要なアプリ管理権限のある環境です。
参照：https://jp.kintone.help/k/ja/app/customize/js_customize

## ビルドの正本
- npmパッケージ：resoarc-kintone-backup v1.0.0
- 実行時依存：fflate 0.8.3（MIT / licenses/fflate-MIT.txt）
- ビルド依存：esbuild 0.25.12（MIT / ランタイム非同梱）
- 利用者向け配布物はdist/resoarc-archive-kintone.js、archive-viewer/index.html、viewer.js、viewer.css。
- README、THIRD_PARTY_NOTICES、LOCAL_ARCHIVEは本版の説明。旧RELEASE_QAおよびLOCAL_FIRST_INTEGRATION_NOTESは開発履歴資料であり、現行の合否判定を示さない。

## 受入結果と適用範囲
- ソースZIPから隔離フォルダーにnpm ci、npm run build:local / buildを実施し、固定候補と4実行/ビューアファイルのSHA-256一致を確認。
- 116/116 Node試験。隔離Edge合成501件と通信障害復旧を確認。
- QA66隔離実kintone上で合成3,001件の書込み・レスポンス遮断・再開・二重登録なし、添付原本SHA一致を確認。
- 別ブラウザーのオフライン閲覧は配布ZIPから実際に取り出したビューアを使用し、22/22試験PASS。
- 公開サイトへの個別C承認は別途必要。B配布PASSのみで一般公開しない。
- 本書に記載された試験結果は環境を限定する。事業継続や完全復旧を保証しない。

## 運用上の制約
- 1単一ZIP25MiB／20,000件／50,000エントリ、分割最大256パート／総256MiB。
- 復元は同じデータを上書きしない追記式。移行先に重複禁止のResoArcRestoreKeyを必ず作り、読み込み・対応表のプレビュー後に明示確認して実行する。
- 全kintone設定、コメント、監査履歴、元レコードID、権限の復元は行えない。
- 未暗号化のZIPは機密情報を含む平文。暗号化しても分割索引はメタデータが平文で残る場合がある。
- ZIP SHA-256は破損改変の検出であり作者証明の署名ではない。

## 追加の公開前条件
- 公開した2ZIPをHTTPSで再取得してSHA-256照合、正式公開済み12署名プラグインZIPのハッシュが変化していないことを確認。
- ターゲットkintone契約・PC用スクリプトのみ・既存カスタマイズとの読込順を導入ガイドに記載する。
