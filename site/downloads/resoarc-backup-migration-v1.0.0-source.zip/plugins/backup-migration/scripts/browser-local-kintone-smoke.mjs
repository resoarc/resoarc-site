import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {inspectArchive} from '../src/core.js';
import {decryptLocalArchive,isEncryptedArchive} from '../src/encryption.js';
const require=createRequire(import.meta.url);
const {chromium}=require(process.env.RESOARC_PLAYWRIGHT_CORE || 'playwright-core');
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
try{
  const page=await browser.newPage({acceptDownloads:true});
  await page.addInitScript(()=>{
    window.mock={writes:[],reads:[],cursor:0,records:[{Title:{type:'SINGLE_LINE_TEXT',value:'Mock tenant customer'}}]};
    window.confirm=()=>true;
    window.prompt=(message)=>{
      if(message.startsWith('復元先へ追記'))return 'RESTORE 77 1';
      if(window.mock.secure && message.includes('パスフレーズ'))return 'Browser QA secure archive passphrase';
      return '';
    };
    const url=path=>path;
    const rest=async(path,method,body)=>{
      window.mock.reads.push([path,method]);
      if(path==='/k/v1/app/form/fields.json')return {properties:{
        Title:{type:'SINGLE_LINE_TEXT',label:'案件名'},
        ResoArcRestoreKey:{type:'SINGLE_LINE_TEXT',label:'復元識別子',unique:true}
      }};
      if(path==='/k/v1/app/form/layout.json')return {layout:[{type:'ROW',fields:[{code:'Title'}]}]};
      if(path==='/k/v1/records/cursor.json'){
        if(method==='POST'){window.mock.cursor++;return {id:'cursor'+window.mock.cursor};}
        if(method==='GET')return {records:window.mock.cursor===1?window.mock.records:[],next:false};
        return {};
      }
      if(path==='/k/v1/records.json'&&method==='POST'){
        window.mock.writes.push(body);return {ids:body.records.map((_,i)=>String(500+i))};
      }
      if(path==='/k/v1/app.json')return {name:'Mock tenant'};
      return {};
    };
    window.kintone={app:{getId:()=>77,getHeaderMenuSpaceElement:()=>document.body},
      getRequestToken:()=> 'dummy-only-for-mock',
      api:Object.assign(rest,{url})};
    window.kintone.events={on:(_event,fn)=>{window.trigger=()=>fn({});}};
  });
  await page.goto(pathToFileURL(path.resolve('scripts/mock-kintone-host.html')).href);
  await page.addScriptTag({path:path.resolve('dist/resoarc-archive-kintone.js')});
  await page.evaluate(()=>window.trigger());
  const buttons=page.locator('[data-ra-archive] button');
  assert.equal(await buttons.count(),5);
  const [download]=await Promise.all([page.waitForEvent('download'),buttons.nth(0).click()]);
  const localArchive=await readFile(await download.path());
  const archive=await inspectArchive(localArchive);
  assert.equal(archive.manifest.version,3);
  assert.equal(archive.records[0].Title.value,'Mock tenant customer');
  assert.equal(await page.evaluate(()=>window.mock.writes.length),0);
  const fileChooser=page.waitForEvent('filechooser');
  await buttons.nth(1).click({noWaitAfter:true});
  const chooser=await fileChooser;
  await chooser.setFiles({name:'test.ra-kintone',mimeType:'application/zip',buffer:localArchive});
  await page.waitForFunction(()=>document.querySelector('[data-ra-archive] pre')?.textContent.includes('追加予定'));
  assert.equal(await page.evaluate(()=>window.mock.writes.length),0);
  await buttons.nth(2).click();
  await page.waitForFunction(()=>document.querySelector('[data-ra-archive] pre')?.textContent.includes('追記復元完了'));
  assert.equal(await page.evaluate(()=>window.mock.writes.length),1);
  assert.equal(await page.evaluate(()=>window.mock.writes[0].records[0].Title.value),'Mock tenant customer');
  console.log('PASS: kintone mock export v3, local save, preview read-only, confirmed append restore, no writes before approval');
  await page.evaluate(()=>{
    window.mock.cursor=0;
    window.mock.localFiles={};
    window.showDirectoryPicker=async()=>({getDirectoryHandle:async()=>({
      getFileHandle:async name=>({createWritable:async()=>({
        write:async bytes=>{window.mock.localFiles[name]=Array.from(bytes);},
        close:async()=>{},abort:async()=>{}
      })})
    })});
  });
  await buttons.nth(4).click();
  await page.waitForFunction(()=>document.querySelector('[data-ra-archive] pre')?.textContent.includes('分割保存完了'));
  const filenames=await page.evaluate(()=>Object.keys(window.mock.localFiles));
  assert.equal(filenames.includes('resoarc-collection.ra-collection.json'),true);
  assert.equal(filenames.filter(n=>n.startsWith('part-')).length,1);
  assert.equal(await page.evaluate(()=>window.mock.writes.length),1);
  console.log('PASS: browser directory multipart export, index written after parts, no new kintone writes');
  await page.evaluate(()=>{window.mock.secure=true;window.mock.cursor=0;});
  const [encryptedDownload]=await Promise.all([page.waitForEvent('download'),buttons.nth(0).click()]);
  assert.match(encryptedDownload.suggestedFilename(),/\.ra-kintone\.enc$/);
  const encryptedBytes=await readFile(await encryptedDownload.path());
  assert.equal(isEncryptedArchive(encryptedBytes),true);
  const restored=await decryptLocalArchive(encryptedBytes,'Browser QA secure archive passphrase');
  const checked=await inspectArchive(restored);
  assert.equal(checked.records[0].Title.value,'Mock tenant customer');
  assert.equal(await page.evaluate(()=>window.mock.writes.length),1);
  console.log('PASS: kintone encrypted local export and offline ZIP roundtrip');
}finally{await browser.close();}
