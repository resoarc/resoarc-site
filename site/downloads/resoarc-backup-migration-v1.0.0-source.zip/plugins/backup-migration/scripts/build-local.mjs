import {build} from 'esbuild';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
const license=await readFile('node_modules/fflate/LICENSE','utf8');
const notice='/* ResoArc kintone Archive v1.0.0 (local-first distribution) MIT\n'+
  'Bundled fflate 0.8.3 under MIT license:\n'+license+'\n*/\n';
for(const [entry,outfile] of [
  ['src/local-app.js','dist/resoarc-archive-kintone.js'],
  ['src/local-viewer.js','archive-viewer/viewer.js']
]){
  const result=await build({entryPoints:[entry],bundle:true,format:'iife',platform:'browser',
    target:'es2022',write:false,legalComments:'none',logLevel:'warning',minify:false});
  await mkdir(outfile.split('/')[0],{recursive:true});
  await writeFile(outfile,notice+new TextDecoder().decode(result.outputFiles[0].contents));
  console.log('Built: '+outfile);
}
