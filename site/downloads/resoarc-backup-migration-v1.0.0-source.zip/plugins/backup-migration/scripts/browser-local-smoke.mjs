import {makeArchive} from '../src/core.js';
import {encryptLocalArchive} from '../src/encryption.js';
import {buildCollection} from '../src/collection.js';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {strToU8} from 'fflate';
const require=createRequire(import.meta.url);
const {chromium}=require(process.env.RESOARC_PLAYWRIGHT_CORE || 'playwright-core');
const file=path.resolve('archive-viewer/index.html');
const payload='Injected <img src=x onerror="window.hacked=true">';
const built=await makeArchive({
  appId:77,fields:{properties:{Title:{type:'SINGLE_LINE_TEXT',label:'案件名',code:'Title'},Attach:{type:'FILE',label:'ファイル',code:'Attach'}}},
  layout:{layout:[{type:'ROW',fields:[{code:'Title'}]}]},
  records:[{Title:{value:payload},Attach:{value:[{fileKey:'x',name:'evidence.txt',size:4,contentType:'text/plain'}]}}],
  download:async()=>strToU8('safe'),now:'2026-10-20T00:00:00Z',
  settings:{app:{name:'Viewer QA'}},coverage:{sections:{views:{status:'captured'}}},sourceMeta:[{'$id':'15'}]
});
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  args:['--no-first-run','--disable-extensions']});
try{
  const context=await browser.newContext({acceptDownloads:true});
  let network=0;
  context.on('request',req=>{if(/^https?:/.test(req.url()))network++;});
  const page=await context.newPage();
  await page.goto(pathToFileURL(file).href);
  await page.locator('#file').setInputFiles({name:'fixture.ra-kintone',mimeType:'application/zip',buffer:Buffer.from(built.zip)});
  await page.waitForFunction(()=>document.getElementById('loaded').hidden===false);
  assert.match(await page.locator('#title').innerText(),/Viewer QA/);
  assert.match(await page.locator('#detail').innerText(),/Injected/);
  assert.equal(await page.evaluate(()=>Boolean(window.hacked)),false);
  assert.equal(network,0);
  await page.locator('#search').fill('Injected');
  assert.match(await page.locator('#page').innerText(),/1件/);
  const [download]=await Promise.all([page.waitForEvent('download'),page.locator('.file button').click()]);
  assert.equal(download.suggestedFilename(),'evidence.txt');
  await page.locator('#clear').click();
  assert.equal(await page.locator('#loaded').isHidden(),true);
  console.log('PASS: local viewer file:// rendering, record search, file download, XSS escaping, no HTTP network, clear state');
  const protectedZip=await encryptLocalArchive(built.zip,'local encrypted browser passphrase!');
  await page.evaluate(()=>{window.prompt=()=> 'local encrypted browser passphrase!';});
  await page.locator('#file').setInputFiles({name:'fixture.ra-kintone.enc',mimeType:'application/octet-stream',buffer:Buffer.from(protectedZip)});
  await page.waitForFunction(()=>document.getElementById('loaded').hidden===false);
  assert.match(await page.locator('#detail').innerText(),/Injected/);
  assert.equal(network,0);
  await page.locator('#clear').click();
  await page.evaluate(()=>{window.prompt=()=> 'wrong local test passphrase';});
  await page.locator('#file').setInputFiles({name:'fixture.ra-kintone.enc',mimeType:'application/octet-stream',buffer:Buffer.from(protectedZip)});
  await page.waitForFunction(()=>document.getElementById('status').textContent.includes('読み込みを拒否しました'));
  assert.equal(await page.locator('#loaded').isHidden(),true);
  console.log('PASS: encrypted archive offline decryption, password rejection, zero HTTP requests');
  const store=new Map();
  const collection=await buildCollection({appId:77,
    fields:{properties:{Title:{type:'SINGLE_LINE_TEXT',label:'案件名',code:'Title'}}},
    layout:{layout:[]},
    records:Array.from({length:12},(_,i)=>({Title:{value:'Sample row '+i}})),
    sourceMeta:Array.from({length:12},(_,i)=>({'$id':String(i+1)})),
    settings:{app:{name:'Collection UI QA'}},coverage:{sections:{fields:{status:'captured'}}},
    download:async()=>strToU8(''),partRecordLimit:5,
    createdAt:'2026-10-20T00:00:00Z',
    onPart:async(name,bytes)=>{store.set(name,bytes);}
  });
  const inputs=[{name:collection.filename,mimeType:'application/json',buffer:Buffer.from(collection.bytes)},
    ...[...store.entries()].map(([name,bytes])=>({name,mimeType:'application/zip',buffer:Buffer.from(bytes)}))];
  await page.locator('#file').setInputFiles(inputs);
  await page.waitForFunction(()=>document.getElementById('loaded').hidden===false);
  assert.match(await page.locator('#summary').innerText(),/分割 3ファイル/);
  assert.match(await page.locator('#page').innerText(),/12件/);
  await page.locator('#clear').click();
  await page.locator('#file').setInputFiles(inputs.slice(0,-1));
  await page.waitForFunction(()=>document.getElementById('status').textContent.includes('読み込みを拒否しました'));
  assert.equal(await page.locator('#loaded').isHidden(),true);
  assert.equal(network,0);
  console.log('PASS: offline multipart viewer assembly, search counts and missing part detection');
}finally{await browser.close();}
