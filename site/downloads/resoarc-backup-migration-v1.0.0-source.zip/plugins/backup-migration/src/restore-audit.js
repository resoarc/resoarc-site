// Independent read-only verification of restored content and attachment bytes.
import {sha256} from './core.js';
import {restoreKeyBase,keyForIndex,MARKER_CODE} from './restore.js';
import {compareRestoreRecord} from './restore-compare.js';

const bad=message=>{throw Error(message);};
export async function auditRestoredContent({
  archive,plan,api,download,maxRecords=200000,signal,onProgress=()=>{}
}){
  if(typeof api!=='function'||!Array.isArray(plan?.rows)||!plan?.mapped||
     !Number.isSafeInteger(Number(plan.targetAppId))||Number(plan.targetAppId)<1)
    bad('復元の監査プランが不正です');
  if(!Number.isSafeInteger(maxRecords)||maxRecords<1||maxRecords>200000)
    bad('監査件数上限が不正です');
  if(signal?.aborted)bad('監査が中止されました');
  const {base}=await restoreKeyBase(archive,plan);
  const expected=new Map();
  for(let i=0;i<plan.rows.length;i++)expected.set(keyForIndex(base,i),plan.rows[i]);
  const fields=[MARKER_CODE,...Object.keys(plan.mapped)];
  const cursor=await api('/k/v1/records/cursor.json','POST',{app:plan.targetAppId,fields,size:500});
  if(typeof cursor?.id!=='string'||!cursor.id)bad('監査Cursorを作成できませんでした');
  let finished=false,scanned=0,matched=0,attachmentCount=0;
  const seen=new Set(),differences=[];
  try{
    do{
      if(signal?.aborted)bad('監査が中止されました');
      const data=await api('/k/v1/records/cursor.json','GET',{id:cursor.id});
      if(!Array.isArray(data?.records)||typeof data.next!=='boolean'||
         data.records.length>500||(data.next&&data.records.length===0))
        bad('監査Cursorの応答が不正です');
      scanned+=data.records.length;
      if(scanned>maxRecords)bad('監査レコードの件数上限を超えました');
      for(const row of data.records){
        const key=row?.[MARKER_CODE]?.value;
        if(typeof key!=='string')bad('復元識別子を閲覧できません');
        if(!expected.has(key))continue;
        if(seen.has(key))bad('復元識別子が重複しています');
        seen.add(key);
        const index=parseInt(key.slice(base.length),36);
        const result=compareRestoreRecord(expected.get(key),row,plan.mapped);
        for(const task of result.attachments){
          if(signal?.aborted)bad('監査が中止されました');
          if(typeof download!=='function')bad('添付ファイルの監査にはダウンロード処理が必要です');
          const bytes=await download(task.fileKey);
          if(!(bytes instanceof Uint8Array)&&!(bytes instanceof ArrayBuffer))
            bad('添付の取得結果が不正です');
          if(await sha256(bytes)!==task.sha256)result.differences.push(task.path);
          attachmentCount++;
        }
        if(result.differences.length){
          for(const field of result.differences){
            if(differences.length<30)differences.push('record['+index+'].'+field);
          }
        }else{
          matched++;
        }
      }
      onProgress({scanned,matched,expected:expected.size,attachmentCount});
      finished=!data.next;
    }while(!finished);
  }finally{
    if(!finished)try{await api('/k/v1/records/cursor.json','DELETE',{id:cursor.id});}
    catch{/* Kintone expires abandoned cursors */}
  }
  const missing=expected.size-seen.size;
  return {
    passed:missing===0&&differences.length===0,expected:expected.size,
    matched,missing,mismatchedPaths:differences,attachmentsVerified:attachmentCount,
    scanned
  };
}
