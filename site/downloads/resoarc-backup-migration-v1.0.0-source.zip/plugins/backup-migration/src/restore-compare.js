// Read-only structural comparison for previously exported kintone records.
// Return field paths, never source or destination values.
const isObject=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const lists=new Set(['CHECK_BOX','MULTI_SELECT']);
const actors=new Set(['USER_SELECT','ORGANIZATION_SELECT','GROUP_SELECT']);
function canonical(value,type){
  if(lists.has(type))return (Array.isArray(value)?value:[]).map(String).sort();
  if(actors.has(type))return (Array.isArray(value)?value:[]).map(x=>String(x?.code||'')).sort();
  if(type==='NUMBER'){
    const s=String(value??'');
    if(!/^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)$/.test(s))return s;
    const neg=s.startsWith('-');
    const [whole,fraction='']=s.replace(/^[+-]/,'').split('.');
    const a=whole.replace(/^0+(?=[0-9])/,'')||'0',b=fraction.replace(/0+$/,'');
    const result=a+(b?'.'+b:'');
    return neg&&result!=='0'?'-'+result:result;
  }
  return value;
}
export function compareRestoreRecord(expected,actual,schema){
  const differences=[],attachments=[];
  function visit(src,dst,definitions,path){
    if(!isObject(src)||!isObject(dst)){differences.push(path||'record');return;}
    for(const [field,definition] of Object.entries(definitions)){
      if(!Object.hasOwn(src,field))continue;
      const at=path?path+'.'+field:field;
      if(!isObject(dst[field])||!Object.hasOwn(dst[field],'value')){
        differences.push(at);continue;
      }
      const a=src[field].value,b=dst[field].value;
      if(definition.type==='SUBTABLE'){
        if(!Array.isArray(a)||!Array.isArray(b)||a.length!==b.length){
          differences.push(at);continue;
        }
        a.forEach((row,i)=>visit(row.value,b[i]?.value,definition.fields,at+'['+i+']'));
      }else if(definition.type==='FILE'){
        if(!Array.isArray(a)||!Array.isArray(b)||a.length!==b.length){
          differences.push(at);continue;
        }
        a.forEach((f,i)=>{
          const g=b[i],where=at+'['+i+']';
          if(!isObject(f)||!isObject(g)||!g.fileKey||f.name!==g.name||
             Number(f.size)!==Number(g.size)){
            differences.push(where);return;
          }
          attachments.push({path:where,sha256:f.ref,fileKey:g.fileKey});
        });
      }else if(JSON.stringify(canonical(a,definition.type))!==JSON.stringify(canonical(b,definition.type))){
        differences.push(at);
      }
    }
  }
  visit(expected,actual,schema,'');
  return {passed:differences.length===0,differences,attachments};
}
