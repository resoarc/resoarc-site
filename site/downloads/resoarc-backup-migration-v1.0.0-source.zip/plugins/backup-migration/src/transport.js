// Bounded, cleanup-safe kintone cursor reader for backups.
export async function fetchAllRecords(app, api, {maxRecords=20000}={}) {
  if (typeof api !== 'function') throw Error('kintone API関数が必要です');
  if (!Number.isSafeInteger(maxRecords) || maxRecords < 1) throw Error('取得件数の上限が不正です');
  const created = await api('/k/v1/records/cursor.json', 'POST', {app, size:500});
  if (typeof created?.id !== 'string' || !created.id) throw Error('バックアップ用Cursorの作成に失敗しました');
  const records = [];
  let finished = false;
  try {
    while (!finished) {
      const page = await api('/k/v1/records/cursor.json', 'GET', {id:created.id});
      if (!Array.isArray(page?.records) || typeof page.next !== 'boolean' || page.records.length > 500)
        throw Error('バックアップ用Cursorの取得結果が不正です');
      if (page.next && page.records.length === 0)
        throw Error('バックアップ用Cursorが進行しません。処理を中止します');
      if (records.length + page.records.length > maxRecords)
        throw Error('一度に処理できるレコードは' + maxRecords.toLocaleString('en-US') + '件までです');
      records.push(...page.records);
      finished = !page.next;
    }
  } finally {
    if (!finished) {
      try { await api('/k/v1/records/cursor.json', 'DELETE', {id:created.id}); }
      catch (error) { console.warn('Backup cursor cleanup failed', error); }
    }
  }
  return records;
}


/**
 * Streaming iterator for a single kintone Cursor.
 * Only one cursor page is retained by the transport layer at a time.
 * Cleanup is guaranteed on early return, exception, or explicit abort.
 */
export async function* streamRecordPages(app, api, {pageSize=500,maxRecords=250000,signal}={}){
  if(typeof api!=='function')throw Error('kintone API関数が必要です');
  if(!Number.isSafeInteger(Number(app))||Number(app)<1)throw Error('取得対象アプリIDが不正です');
  if(!Number.isSafeInteger(pageSize)||pageSize<1||pageSize>500)throw Error('取得ページサイズが不正です');
  if(!Number.isSafeInteger(maxRecords)||maxRecords<1||maxRecords>250000)throw Error('ストリームの取得件数上限が不正です');
  if(signal?.aborted)throw Error('処理が中止されました');
  const created=await api('/k/v1/records/cursor.json','POST',{app,size:pageSize});
  if(typeof created?.id!=='string'||!created.id)throw Error('Cursorの作成に失敗しました');
  let finished=false,received=0;
  try{
    do{
      if(signal?.aborted)throw Error('処理が中止されました');
      const response=await api('/k/v1/records/cursor.json','GET',{id:created.id});
      if(!Array.isArray(response?.records)||typeof response.next!=='boolean'||
         response.records.length>pageSize||(response.next&&response.records.length===0))
        throw Error('Cursorの応答が不正または停止しています');
      received+=response.records.length;
      if(received>maxRecords)throw Error('ストリームのレコード件数上限を超えました');
      // Cursor returns the exact page from its own iteration state.
      finished=!response.next;
      yield response.records;
    }while(!finished);
  }finally{
    if(!finished){
      try{await api('/k/v1/records/cursor.json','DELETE',{id:created.id});}
      catch(e){console.warn('Stream cursor cleanup failed',e);}
    }
  }
}
