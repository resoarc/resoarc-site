// ResoArc local archive collection (development format).
// Each part stays within the individually validated 25MiB v3 format.
// The collection index is saved LAST, only after every part was persisted.
// Missing, altered, duplicated or reordered parts are rejected before restore.
import {makeArchive,inspectArchive,sha256,MAX_BYTES,MAX_RECORDS} from './core.js';
import {encryptLocalArchive,decryptLocalArchive} from './encryption.js';

export const COLLECTION_FORMAT='resoarc.kintone.archive.collection';
export const COLLECTION_VERSION=1;
export const MAX_PARTS=256;
export const MAX_COLLECTION_RECORDS=250000;
export const MAX_COLLECTION_BYTES=256*1024*1024;
const encoder=new TextEncoder();
const decoder=new TextDecoder();
const fail=reason=>{throw Error(reason);};
const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const NAME=/^part-[0-9]{5}\.ra-kintone(?:\.enc)?$/;
const sha=/^[0-9a-f]{64}$/;
function pathName(i,encrypted){
  return 'part-'+String(i).padStart(5,'0')+'.ra-kintone'+(encrypted?'.enc':'');
}
export async function buildCollection({
  appId,fields,layout,records,sourceMeta,settings,coverage,download,onPart,
  passphrase='',partRecordLimit=500,maxPartBytes=MAX_BYTES,
  createdAt=new Date().toISOString()
}){
  if(!Array.isArray(records)||records.length>MAX_RECORDS)fail('コレクションのレコード数上限を超えています');
  if(!Array.isArray(sourceMeta)||sourceMeta.length!==records.length)fail('メタデータの件数が一致しません');
  if(typeof download!=='function'||typeof onPart!=='function')fail('読み出し・保存コールバックが必要です');
  if(!Number.isInteger(partRecordLimit)||partRecordLimit<1||partRecordLimit>1000)fail('分割件数が不正です');
  if(!Number.isInteger(maxPartBytes)||maxPartBytes<1024||maxPartBytes>MAX_BYTES)fail('分割ZIP上限が不正です');
  if(passphrase&&(typeof passphrase!=='string'||passphrase.length<12))fail('暗号化パスフレーズは12文字以上です');
  const saved=[],seenNames=new Set();
  let totalBytes=0,offset=0;
  // If a segment is too large, bisect only that segment, preserving record order.
  async function emit(batch,meta){
    let result;
    try{
      result=await makeArchive({appId,fields,layout,records:batch,sourceMeta:meta,
        settings,coverage,download,now:createdAt,maxBytes:maxPartBytes});
    }catch(e){
      if(!/容量上限/.test(String(e.message)))throw e;
      if(batch.length===1)fail('単一レコードがZIPサイズ上限を超えるため、完全な分割保存ができません。レコード開始位置: '+offset);
      const mid=Math.floor(batch.length/2);
      await emit(batch.slice(0,mid),meta.slice(0,mid));
      await emit(batch.slice(mid),meta.slice(mid));
      return;
    }
    if(saved.length>=MAX_PARTS)fail('分割ファイルの上限を超えています');
    const filename=pathName(saved.length+1,!!passphrase);
    if(seenNames.has(filename))fail('分割ファイル名が重複しています');
    let bytes=result.zip;
    if(passphrase)bytes=await encryptLocalArchive(bytes,passphrase);
    totalBytes+=bytes.byteLength;
    if(totalBytes>MAX_COLLECTION_BYTES)fail('分割保存の合計容量上限256MiBを超えています');
    const entry={file:filename,start:offset,count:batch.length,bytes:bytes.byteLength,
      sha256:await sha256(bytes),zipSha256:result.hash};
    // Fail closed: don't mark successful until consumer confirms filesystem write.
    await onPart(filename,bytes,entry);
    saved.push(entry);seenNames.add(filename);offset+=batch.length;
  }
  for(let i=0;i<records.length;i+=partRecordLimit)
    await emit(records.slice(i,i+partRecordLimit),sourceMeta.slice(i,i+partRecordLimit));
  if(records.length===0)await emit([],[]);
  if(offset!==records.length)fail('分割処理の件数が一致しません');
  const index={format:COLLECTION_FORMAT,version:COLLECTION_VERSION,sourceAppId:Number(appId),
    createdAt,recordCount:records.length,encrypted:!!passphrase,
    totalBytes,parts:saved,limitations:['単一時点の完全スナップショットではありません','全パートの復元確認前に個別パートの使用を避けてください']};
  const bytes=encoder.encode(JSON.stringify(index,null,2)+'\n');
  return {index,bytes,filename:'resoarc-collection.ra-collection.json'};
}
function validateIndex(index){
  if(!object(index)||index.format!==COLLECTION_FORMAT||index.version!==COLLECTION_VERSION)
    fail('未対応のコレクション形式です');
  if(!Number.isSafeInteger(index.sourceAppId)||index.sourceAppId<1||
     !Number.isSafeInteger(index.recordCount)||index.recordCount<0||index.recordCount>MAX_COLLECTION_RECORDS||
     !Array.isArray(index.parts)||index.parts.length<1||index.parts.length>MAX_PARTS||
     typeof index.encrypted!=='boolean')fail('コレクション索引が不正です');
  let expected=0,total=0;
  for(const [i,p] of index.parts.entries()){
    if(!object(p)||!NAME.test(p.file)||p.file!==pathName(i+1,index.encrypted)||
       p.start!==expected||!Number.isSafeInteger(p.count)||p.count<0||p.count>1000||
       !Number.isSafeInteger(p.bytes)||p.bytes<1||p.bytes>MAX_BYTES+56||
       !sha.test(p.sha256)||!sha.test(p.zipSha256))fail('分割ファイル索引が不正です');
    expected+=p.count;total+=p.bytes;
  }
  if(expected!==index.recordCount||total!==index.totalBytes||total>MAX_COLLECTION_BYTES)
    fail('分割ファイル索引の件数または容量が一致しません');
}
export async function openCollection(indexBytes,readPart,{passphrase=''}={}){
  if(typeof readPart!=='function')fail('ローカルファイル読み込み関数が必要です');
  const indexRaw=indexBytes instanceof Uint8Array?indexBytes:new Uint8Array(indexBytes);
  if(indexRaw.length<1||indexRaw.length>1024*1024)fail('コレクション索引のサイズが不正です');
  let index;
  try{index=JSON.parse(decoder.decode(indexRaw));}catch{fail('コレクション索引を解釈できません');}
  validateIndex(index);
  if(index.encrypted&&(!passphrase||passphrase.length<12))fail('暗号化コレクションのパスフレーズが必要です');
  const allRecords=[],allMeta=[],mergedFiles=Object.create(null),uniqueFiles=new Map();
  let first=null;
  for(const part of index.parts){
    const raw=await readPart(part.file);
    if(!(raw instanceof Uint8Array)||raw.length!==part.bytes||
       await sha256(raw)!==part.sha256)fail('分割ファイルが欠落・破損しています: '+part.file);
    let zip=raw;
    if(index.encrypted)zip=await decryptLocalArchive(raw,passphrase);
    let archive;
    try{archive=await inspectArchive(zip,{expectedHash:part.zipSha256});}
    finally{if(zip!==raw)zip.fill(0);}
    if(archive.manifest.sourceAppId!==index.sourceAppId||
       archive.manifest.recordCount!==part.count||archive.manifest.createdAt!==index.createdAt||
       archive.manifest.version!==3)fail('分割ファイルの内容・アプリIDが一致しません');
    if(!first)first=archive;
    else if(JSON.stringify(archive.schema)!==JSON.stringify(first.schema)||
      JSON.stringify(archive.sourceFields)!==JSON.stringify(first.sourceFields)||
      JSON.stringify(archive.layout)!==JSON.stringify(first.layout)||
      JSON.stringify(archive.settings)!==JSON.stringify(first.settings)||
      JSON.stringify(archive.coverage)!==JSON.stringify(first.coverage))
        fail('分割ファイル間でフォーム・設定が変化しています');
    allRecords.push(...archive.records);
    allMeta.push(...archive.sourceMeta);
    for(const file of archive.manifest.files){
      const prior=uniqueFiles.get(file.path);
      if(prior&&JSON.stringify(prior)!==JSON.stringify(file))fail('分割間で添付ファイルのハッシュが矛盾しています');
      uniqueFiles.set(file.path,file);
      mergedFiles[file.path]=archive.files[file.path];
    }
  }
  if(allRecords.length!==index.recordCount||allMeta.length!==index.recordCount)fail('コレクションの総件数が一致しません');
  const indexHash=await sha256(indexRaw);
  return {...first,records:allRecords,sourceMeta:allMeta,files:mergedFiles,
    manifest:{...first.manifest,files:[...uniqueFiles.values()],recordCount:index.recordCount,collection:true},
    archiveHash:indexHash,collectionIndex:index};
}


/**
 * Bounded exporter driven by an AsyncIterable of kintone pages.
 * Holds at most partRecordLimit pending records plus the active ZIP in memory.
 * Caller is responsible for writing the index LAST after all onPart callbacks.
 * Never silently drops a page, retries a failed write, or generates a success index.
 */
export async function buildCollectionStream({
  appId,fields,layout,pages,metadataOf,settings,coverage,download,onPart,
  passphrase='',partRecordLimit=500,maxPartBytes=MAX_BYTES,
  maxRecords=MAX_COLLECTION_RECORDS,createdAt=new Date().toISOString(),
  onProgress=()=>{}
}){
  if(!Number.isSafeInteger(Number(appId))||Number(appId)<1)fail('アプリIDが不正です');
  if(!pages||typeof pages[Symbol.asyncIterator]!=='function')fail('ページの非同期イテレーターが必要です');
  if(typeof metadataOf!=='function'||typeof download!=='function'||typeof onPart!=='function')
    fail('メタデータ・読み出し・保存コールバックが必要です');
  if(!Number.isSafeInteger(partRecordLimit)||partRecordLimit<1||partRecordLimit>1000)
    fail('分割レコード数が不正です');
  if(!Number.isSafeInteger(maxPartBytes)||maxPartBytes<1024||maxPartBytes>MAX_BYTES)
    fail('分割ZIP上限が不正です');
  if(!Number.isSafeInteger(maxRecords)||maxRecords<1||maxRecords>MAX_COLLECTION_RECORDS)
    fail('総レコード上限が不正です');
  if(passphrase&&(typeof passphrase!=='string'||passphrase.length<12))
    fail('暗号化パスフレーズは12文字以上です');
  const parts=[];
  let offset=0,readCount=0,totalBytes=0;
  let batch=[],meta=[];
  async function emit(rows,metas){
    let archive;
    try{
      archive=await makeArchive({appId,fields,layout,records:rows,sourceMeta:metas,settings,
        coverage,download,now:createdAt,maxBytes:maxPartBytes});
    }catch(error){
      if(!/容量上限/.test(String(error.message)))throw error;
      if(rows.length===1)fail('1レコードが分割サイズ上限を超えています。開始レコード: '+offset);
      const mid=Math.floor(rows.length/2);
      await emit(rows.slice(0,mid),metas.slice(0,mid));
      await emit(rows.slice(mid),metas.slice(mid));
      return;
    }
    if(parts.length>=MAX_PARTS)fail('最大分割数 '+MAX_PARTS+' を超えました。索引ファイルは生成されません');
    let bytes=archive.zip;
    if(passphrase)bytes=await encryptLocalArchive(bytes,passphrase);
    if(totalBytes+bytes.length>MAX_COLLECTION_BYTES)fail('総保存容量上限を超えました。索引ファイルは生成されません');
    const file=pathName(parts.length+1,!!passphrase);
    const entry={file,start:offset,count:rows.length,bytes:bytes.length,
      sha256:await sha256(bytes),zipSha256:archive.hash};
    await onPart(file,bytes,entry);
    parts.push(entry);
    totalBytes+=bytes.length;
    offset+=rows.length;
    onProgress({read:readCount,written:offset,parts:parts.length,bytes:totalBytes});
  }
  for await(const page of pages){
    if(!Array.isArray(page)||page.length>500)fail('ストリームのレコードページが不正です');
    if(readCount+page.length>maxRecords)fail('レコード数が上限を超えました');
    for(const record of page){
      if(!object(record))fail('レコードの形式が不正です');
      batch.push(record);
      const m=metadataOf(record);
      if(!object(m))fail('メタデータの形式が不正です');
      meta.push(m);
      readCount++;
      if(batch.length>=partRecordLimit){
        await emit(batch,meta);
        batch=[];meta=[];
      }
    }
  }
  if(batch.length||readCount===0)await emit(batch,meta);
  if(offset!==readCount)fail('保存件数と取得件数が一致しません');
  const index={format:COLLECTION_FORMAT,version:COLLECTION_VERSION,sourceAppId:Number(appId),
    createdAt,recordCount:readCount,encrypted:!!passphrase,totalBytes,
    parts,limitations:['Cursor走査中の同時更新について厳密なスナップショット整合性は保証しません',
      'すべてのパートを検証するまでバックアップ成功として扱わないでください']};
  // Validate final index before caller is allowed to persist a success marker.
  validateIndex(index);
  return {index,bytes:encoder.encode(JSON.stringify(index,null,2)+'\n'),
    filename:'resoarc-collection.ra-collection.json'};
}
