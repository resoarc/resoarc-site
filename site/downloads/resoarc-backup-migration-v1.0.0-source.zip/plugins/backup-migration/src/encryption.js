// Versioned self-contained encrypted envelope for user-owned archives.
// Uses authenticated AES-256-GCM (PBKDF2-SHA256, 310000 iterations).
// No passphrase, raw key, or backup content is sent to or saved by ResoArc.
import {MAX_BYTES} from './core.js';
const MAGIC=new TextEncoder().encode('RAKENC01');
const HEADER_SIZE=40; // magic(8), salt(16), iv(12), PBKDF2 iterations uint32(4)
const SALT_LEN=16;
const IV_LEN=12;
const MIN_ITERATIONS=310000;
const MAX_ITERATIONS=2000000;
const TAG_LEN=16;
const error=reason=>{throw new Error(reason);};
const toBytes=value=>value instanceof Uint8Array?value:new Uint8Array(value);
const digest=()=>globalThis.crypto?.subtle||error('この環境ではWeb Cryptoを利用できません');
function checkPassphrase(value){
  if(typeof value!=='string'||value.length<12||value.length>1024)error('パスフレーズは12〜1024文字で指定してください');
  return new TextEncoder().encode(value);
}
export function isEncryptedArchive(value){
  const bytes=toBytes(value);
  return bytes.length>=MAGIC.length&&MAGIC.every((b,i)=>bytes[i]===b);
}
export function isPotentialEncryptedArchive(value){
  const bytes=toBytes(value);
  return bytes.length>=4 && bytes[0]===82&&bytes[1]===65&&bytes[2]===75&&bytes[3]===69;
}
async function derive(passphrase,salt,iterations,usage){
  const subtle=digest();
  const raw=checkPassphrase(passphrase);
  const key=await subtle.importKey('raw',raw,'PBKDF2',false,['deriveKey']);
  // Drop the raw TextEncoder buffer reference after import.
  raw.fill(0);
  return subtle.deriveKey({name:'PBKDF2',salt,iterations,hash:'SHA-256'},key,
    {name:'AES-GCM',length:256},false,[usage]);
}
export async function encryptLocalArchive(archive,passphrase,{iterations=MIN_ITERATIONS,salt,iv}={}){
  const plaintext=toBytes(archive);
  if(plaintext.byteLength<1||plaintext.byteLength>MAX_BYTES)error('暗号化対象は25MiB以内のアーカイブにしてください');
  if(!Number.isSafeInteger(iterations)||iterations<MIN_ITERATIONS||iterations>MAX_ITERATIONS)
    error('鍵導出の反復回数が許容範囲外です');
  const randomSalt=salt?toBytes(salt):crypto.getRandomValues(new Uint8Array(SALT_LEN));
  const randomIv=iv?toBytes(iv):crypto.getRandomValues(new Uint8Array(IV_LEN));
  if(randomSalt.length!==SALT_LEN||randomIv.length!==IV_LEN)error('SaltまたはIVのサイズが不正です');
  const header=new Uint8Array(HEADER_SIZE);
  header.set(MAGIC);header.set(randomSalt,8);header.set(randomIv,24);
  new DataView(header.buffer).setUint32(36,iterations,false);
  const key=await derive(passphrase,randomSalt,iterations,'encrypt');
  const ciphertext=new Uint8Array(await digest().encrypt({
    name:'AES-GCM',iv:randomIv,additionalData:header,tagLength:128},key,plaintext));
  const encrypted=new Uint8Array(HEADER_SIZE+ciphertext.length);
  encrypted.set(header);encrypted.set(ciphertext,HEADER_SIZE);
  return encrypted;
}
export async function decryptLocalArchive(envelope,passphrase){
  const bytes=toBytes(envelope);
  if(bytes.length<HEADER_SIZE+TAG_LEN+1||bytes.length>HEADER_SIZE+TAG_LEN+MAX_BYTES)
    error('暗号化アーカイブのサイズが不正です');
  if(!isEncryptedArchive(bytes))error('非対応の暗号化アーカイブ形式です');
  const header=bytes.slice(0,HEADER_SIZE);
  const iterations=new DataView(header.buffer).getUint32(36,false);
  if(iterations<MIN_ITERATIONS||iterations>MAX_ITERATIONS)error('鍵導出の反復回数が不正です');
  const key=await derive(passphrase,header.slice(8,24),iterations,'decrypt');
  try{
    const plaintext=new Uint8Array(await digest().decrypt({
      name:'AES-GCM',iv:header.slice(24,36),additionalData:header,tagLength:128},
      key,bytes.subarray(HEADER_SIZE)));
    if(plaintext.length>MAX_BYTES){plaintext.fill(0);error('復号データが容量上限を超えています');}
    return plaintext;
  }catch{
    error('復号できません。パスフレーズかファイルの完全性を確認してください');
  }
}
