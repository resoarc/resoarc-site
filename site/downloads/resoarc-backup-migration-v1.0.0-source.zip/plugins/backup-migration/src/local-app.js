// ResoArc kintone Archive: explicitly local-first, same-origin browser customization.
import {makeArchive,inspectArchive,MAX_BYTES} from './core.js';
import {encryptLocalArchive,decryptLocalArchive,isEncryptedArchive,isPotentialEncryptedArchive} from './encryption.js';
import {buildCollectionStream,openCollection,MAX_COLLECTION_RECORDS} from './collection.js';
import {fetchAllRecords,streamRecordPages} from './transport.js';
import {createMappedRestorePlan,previewRestoreProgress,runResumableRestore,MARKER_CODE} from './restore.js';
import {auditRestoredContent} from './restore-audit.js';
import {planNewApp,createDraftApp} from './migration.js';
const K=window.kintone;
const api=(path,method,body)=>K.api(K.api.url(path,true),method,body);
const getFields=id=>api('/k/v1/app/form/fields.json','GET',{app:id});
const getLayout=id=>api('/k/v1/app/form/layout.json','GET',{app:id});
const requiredApp=()=>{const id=Number(K.app.getId());if(!Number.isSafeInteger(id)||id<1)throw Error('アプリのレコード一覧を開いてください');return id;};
const sections={
  app:'/k/v1/app.json',views:'/k/v1/app/views.json',reports:'/k/v1/app/reports.json',
  process:'/k/v1/app/status.json',actions:'/k/v1/app/actions.json',
  appAcl:'/k/v1/app/acl.json',recordAcl:'/k/v1/record/acl.json',fieldAcl:'/k/v1/field/acl.json',
  notificationGeneral:'/k/v1/app/notifications/general.json',
  notificationPerRecord:'/k/v1/app/notifications/perRecord.json',
  notificationReminder:'/k/v1/app/notifications/reminder.json',
  customize:'/k/v1/app/customize.json'
};
const metaFields=['$id','$revision','作成者','更新者','作成日時','更新日時','ステータス','作業者','カテゴリー'];
const errorText=e=>String(e?.message||e).slice(0,350);
async function collectSettings(id,onProgress){
  const settings={},coverage={sections:{},limitations:[
    'API権限の範囲のみ取得','コメント・変更履歴・スペース・監査履歴は対象外',
    'カスタマイズJS/CSSの参照情報は保持しても実行・完全再現しない',
    '取得中の同時更新について同一時点スナップショットを保証しない'
  ]};
  for(const [name,path] of Object.entries(sections)){
    onProgress('設定取得: '+name);
    try {
      const response=await api(path,'GET',name==='app'?{id}:{app:id});
      settings[name]=response;
      coverage.sections[name]={status:'captured'};
    }catch(e){
      coverage.sections[name]={status:'unavailable',reason:errorText(e)};
    }
  }
  return {settings,coverage};
}
async function downloadAttachment(fileKey){
  const response=await fetch('/k/v1/file.json?fileKey='+encodeURIComponent(fileKey),{
    method:'GET',credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});
  if(!response.ok)throw Error('添付ファイル取得失敗 HTTP '+response.status);
  const blob=await response.blob();
  if(blob.size>MAX_BYTES)throw Error('単一添付ファイルが25MiB上限を超えています');
  return new Uint8Array(await blob.arrayBuffer());
}
async function uploadAttachment(bytes,name,contentType){
  if(bytes.length>MAX_BYTES)throw Error('添付ファイル容量上限超過');
  const body=new FormData();
  body.append('__REQUEST_TOKEN__',K.getRequestToken());
  body.append('file',new Blob([bytes],{type:contentType||'application/octet-stream'}),name||'attachment.bin');
  const response=await fetch('/k/v1/file.json',{method:'POST',credentials:'same-origin',
    headers:{'X-Requested-With':'XMLHttpRequest'},body});
  if(!response.ok)throw Error('添付ファイルの登録に失敗 HTTP '+response.status);
  const data=await response.json();
  if(!data.fileKey)throw Error('移行先の添付ファイルキーがありません');
  return data.fileKey;
}
function saveBytes(bytes,name){
  const url=URL.createObjectURL(new Blob([bytes],{type:'application/octet-stream'}));
  const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),60000);
}
function chooseFile(){
  return new Promise(resolve=>{
    const input=document.createElement('input');input.type='file';input.accept='.ra-kintone,.enc,.zip,.json,application/zip,application/octet-stream';input.multiple=true;
    input.onchange=()=>resolve([...input.files||[]]);
    input.oncancel=()=>resolve(null);input.click();
  });
}
async function loadFile(){
  const files=await chooseFile();
  if(!files?.length)return null;
  const collection=files.find(f=>f.name==='resoarc-collection.ra-collection.json');
  if(collection){
    const indexBytes=new Uint8Array(await collection.arrayBuffer());
    let index;
    try{index=JSON.parse(new TextDecoder().decode(indexBytes));}catch{throw Error('索引JSONを読み取れません');}
    const passphrase=index.encrypted?window.prompt('分割アーカイブのパスフレーズを入力してください',''):'';
    if(passphrase===null)return null;
    const map=new Map();
    for(const f of files){if(map.has(f.name))throw Error('重複したファイル名があります: '+f.name);map.set(f.name,f);}
    return openCollection(indexBytes,async name=>{
      const f=map.get(name);
      if(!f)throw Error('索引に記載された分割ファイルがありません: '+name);
      if(f.size>MAX_BYTES+56)throw Error('分割ファイルの上限を超えています');
      return new Uint8Array(await f.arrayBuffer());
    },{passphrase});
  }
  if(files.length!==1)throw Error('分割アーカイブは索引JSONと全パートをまとめて選択してください');
  const file=files[0];
  if(file.size>MAX_BYTES+56)throw Error('ファイルの容量上限を超えています');
  const raw=new Uint8Array(await file.arrayBuffer());
  if(isPotentialEncryptedArchive(raw)&&!isEncryptedArchive(raw))throw Error('破損または非対応の暗号化ヘッダーです');
  if(isEncryptedArchive(raw)){
    const passphrase=window.prompt('このファイルのパスフレーズを入力してください。画面やサーバーには保存しません。','');
    if(passphrase===null)return null;
    const plaintext=await decryptLocalArchive(raw,passphrase);
    try{return await inspectArchive(plaintext);}finally{plaintext.fill(0);}
  }
  return inspectArchive(raw);
}
function text(tag,content){const node=document.createElement(tag);node.textContent=content;return node;}
function button(host,label,callback){const b=text('button',label);b.type='button';b.className='ra-button';b.onclick=callback;host.append(b);return b;}
function boot(){
  // Prefer the full-width header space. The menu slot can overlap the list
  // header and make the export button impossible to click in live kintone.
  const holder=K.app.getHeaderSpaceElement?.()||K.app.getHeaderMenuSpaceElement?.();
  if(!holder||holder.querySelector('[data-ra-archive]'))return;
  const panel=document.createElement('section');panel.dataset.raArchive='1';
  panel.style.cssText='margin:10px 0;padding:14px;border-radius:10px;background:#f4f9fc;color:#163449;border:1px solid #aecbd9;max-width:1060px;font:14px sans-serif';
  const heading=text('strong','ResoArc kintone Archive | v1.0.0');
  const info=text('div','このPCに保存します。ResoArcのサーバーにもバックアップ管理アプリにも送信しません。復元は追記のみ。');
  info.style.margin='9px 0';const actions=document.createElement('div');
  const status=text('pre','準備完了');status.style.cssText='white-space:pre-wrap;font:12px/1.7 sans-serif;margin-top:12px';
  panel.append(heading,info,actions,status);holder.append(panel);
  const css=document.createElement('style');css.textContent='.ra-button{margin:3px;padding:9px 12px;border:1px solid #93b0c3;border-radius:6px;background:white;color:#123c54;cursor:pointer}.ra-button:disabled{opacity:.5;cursor:wait}';panel.append(css);
  let loaded=null,prepared=null;
  async function run(task){
    const buttons=[...actions.querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);
    try{await task();}catch(e){status.textContent='エラー: '+errorText(e);console.error(e);}
    finally{buttons.forEach(b=>b.disabled=false);}
  }
  button(actions,'このアプリをローカル保存',()=>run(async()=>{
    const id=requiredApp();
    if(!window.confirm('アプリ #'+id+' をローカル保存します。現在の上限は25MiBです。続行しますか？'))return;
    const passphrase=window.prompt('推奨：パスフレーズ12文字以上で暗号化します。空欄なら暗号化せず保存します（機密情報の漏洩に注意）。','');
    if(passphrase===null)return;
    if(passphrase && passphrase!==window.prompt('確認のためパスフレーズを再入力してください。',''))throw Error('パスフレーズが一致しません');
    if(passphrase && passphrase.length<12)throw Error('暗号化には12文字以上のパスフレーズが必要です');
    if(!passphrase && !window.confirm('暗号化なしの平文アーカイブです。保存先の保護を確認しましたか？'))return;
    status.textContent='フィールド・レコードを取得中（データを別サーバーに送信しません）';
    const fields=await getFields(id);
    const layout=await getLayout(id);
    const records=await fetchAllRecords(id,api);
    const {settings,coverage}=await collectSettings(id,info=>{status.textContent=info;});
    coverage.sections.fields={status:'captured'};coverage.sections.layout={status:'captured'};
    coverage.sections.records={status:'captured',count:records.length};
    const sourceMeta=records.map(record=>{
      const values={};
      for(const code of metaFields)if(record[code]&&Object.hasOwn(record[code],'value'))values[code]=record[code].value;
      return values;
    });
    status.textContent='添付ファイルとZIPの検証情報を生成しています';
    const result=await makeArchive({appId:id,fields,layout,records,download:downloadAttachment,settings,coverage,sourceMeta});
    const valid=await inspectArchive(result.zip,{expectedHash:result.hash});
    const failed=Object.entries(coverage.sections).filter(([,x])=>x.status!=='captured').map(([name])=>name);
    const protectedArchive=passphrase?await encryptLocalArchive(result.zip,passphrase):result.zip;
    saveBytes(protectedArchive,'resoarc-app-'+id+'-'+new Date().toISOString().slice(0,10)+(passphrase?'.ra-kintone.enc':'.ra-kintone'));
    status.textContent='PCに'+(passphrase?'暗号化して':'暗号化せず')+'保存しました：'+valid.manifest.recordCount+'件 / '+protectedArchive.byteLength+' bytes\nZIP SHA-256: '+result.hash+
      '\n取得できなかった設定: '+(failed.join(', ')||'なし')+'\n※過去履歴・実行時カスタマイズは再現しません。';
  }));
  button(actions,'ローカルファイルを読み込み・復元プレビュー',()=>run(async()=>{
    prepared=null;loaded=await loadFile();if(!loaded)return;
    const app=requiredApp();const fields=await getFields(app);
    const mappingInput=window.prompt('フィールド対応表（JSON。コードが同一なら空欄）','');
    if(mappingInput===null)return;
    let mapping={};if(mappingInput.trim())mapping=JSON.parse(mappingInput);
    const plan=createMappedRestorePlan(loaded,fields,app,0,mapping);
    const progress=await previewRestoreProgress({archive:loaded,plan,api});
    prepared={plan,archive:loaded,otherArchiveKeyCount:progress.otherArchiveKeyCount,
      unmarkedRecordCount:progress.unmarkedRecordCount};

    status.textContent='検証済みのアーカイブです\n元アプリ: '+plan.sourceAppId+'　復元先: '+app+
      '\n全'+plan.recordCount+'件 / 既存'+progress.already+'件 / 追加予定'+progress.remaining+'件\n除外項目: '+(plan.skipped.join(', ')||'なし')+
      '\n復元先に重複不可の文字列フィールド '+MARKER_CODE+' が必要です。元ID・履歴・権限設定は再現しません。'+
      ((progress.otherArchiveKeyCount>0||progress.unmarkedRecordCount>0)&&progress.remaining>0?
       '\n警告: 別アーカイブ由来 '+progress.otherArchiveKeyCount+' 件、復元識別子がない既存レコード '+progress.unmarkedRecordCount+' 件があります。重複追加の危険があるため実行時に別途確認が必要です。':'');
  }));
  button(actions,'プレビュー後に追記復元',()=>run(async()=>{
    if(!prepared)throw Error('先にローカルファイルを選び、プレビューしてください');
    const {plan,archive,otherArchiveKeyCount,unmarkedRecordCount}=prepared;
    let allowCrossArchiveAppend=false;
    if(otherArchiveKeyCount>0||unmarkedRecordCount>0){
      const crossText='ALLOW CROSS ARCHIVE '+plan.targetAppId+' '+plan.recordCount;
      const entered=window.prompt('警告: 復元先に別アーカイブ由来の履歴が '+otherArchiveKeyCount+
        ' 件、復元識別子がない既存レコードが '+unmarkedRecordCount+' 件あります。通常は新規の空アプリに復元してください。'+
        '\n追加を明示的に許可する場合だけ、以下を入力してください:\n'+crossText,'');
      if(entered!==crossText)return;
      allowCrossArchiveAppend=true;
    }
    const phrase='RESTORE '+plan.targetAppId+' '+plan.recordCount;
    const typed=window.prompt('復元先へ追記します。既存レコードは上書きしません。\n確認文字列: '+phrase,'');
    if(typed!==phrase)return;
    if(!window.confirm('最終確認：追加済みのレコードは自動削除されません。実行しますか？'))return;
    const latest=await getFields(plan.targetAppId);
    const checked=createMappedRestorePlan(archive,latest,plan.targetAppId,0,plan.mapping);
    if(JSON.stringify(checked.mapped)!==JSON.stringify(plan.mapped))throw Error('プレビュー時からフォームが変更されています。再確認してください');
    const done=await runResumableRestore({archive,plan,api,upload:uploadAttachment,
      allowCrossArchiveAppend,
      onProgress:p=>{status.textContent='追加済み '+p.added+' / 残 '+p.remaining;}});
    status.textContent='追記復元完了：'+done.added+'件追加 / '+done.already+'件は重複防止でスキップ\n再読込検証：'+done.verifiedRows+'件の復元識別子を確認';
    prepared=null;
  }));
  button(actions,'復元済みデータの整合性監査（読取のみ）',()=>run(async()=>{
    if(!prepared)throw Error('先にローカルファイルを選び、復元プレビューしてください');
    const {archive,plan}=prepared;
    status.textContent='復元済みの値・サブテーブル・添付ファイルを照合中';
    const result=await auditRestoredContent({archive,plan,api,download:downloadAttachment,
      onProgress:p=>{status.textContent='監査 '+p.scanned+'件走査 / '+p.matched+'件一致';}});
    status.textContent='復元後の読み取り専用監査: '+(result.passed?'合格':'不一致')+
      '\n一致 '+result.matched+' / '+result.expected+' 件、欠落 '+result.missing+
      ' 件、添付SHA-256検証 '+result.attachmentsVerified+' 件'+
      (result.mismatchedPaths.length?'\n差異項目: '+result.mismatchedPaths.join(', '):'')+
      '\n※復元先は変更していません。';
  }));
  button(actions,'ローカルファイルから新規アプリの下書き',()=>run(async()=>{
    const archive=loaded||await loadFile();if(!archive)return;
    const proposed=window.prompt('新規アプリ名を入力','ResoArc Archive '+archive.manifest.sourceAppId);
    if(!proposed)return;
    const plan=planNewApp(archive,proposed);
    status.textContent='下書き予定: '+plan.name+' / '+plan.fieldCount+'項目\n除外: '+plan.skipped.join(', ')+
      '\nフォームの定義のみ。プロセス・権限・データは自動移行しません。';
    const phrase='CREATE '+plan.name;
    if(window.prompt('新規アプリの下書きを作成します。確認文字列: '+phrase,'')!==phrase)return;
    if(!window.confirm('既存アプリは変更しません。新規アプリの下書きを作成しますか？'))return;
    const created=await createDraftApp(plan,api,s=>{status.textContent=s;});
    status.textContent='新規アプリ #'+created.appId+' の下書きを作成しました。手動でフォームを確認して「アプリを更新」してください。';
  }));
  button(actions,'大容量: フォルダーに分割保存',()=>run(async()=>{
    if(typeof window.showDirectoryPicker!=='function')
      throw Error('分割保存にはEdge/Chromeのフォルダー書き込み対応が必要です。HTTPSのkintoneから実行してください');
    // Directory selection MUST happen in the direct click path for user activation.
    const parent=await window.showDirectoryPicker({mode:'readwrite'});
    const id=requiredApp();
    const password=window.prompt('推奨: 分割ファイルを暗号化するパスフレーズ（12文字以上）。空欄なら平文です。','');
    if(password===null)return;
    if(password&&password!==window.prompt('パスフレーズをもう一度入力してください',''))throw Error('パスフレーズが一致しません');
    if(password&&password.length<12)throw Error('パスフレーズは12文字以上にしてください');
    if(!password&&!window.confirm('暗号化しない分割バックアップを保存します。保存先は保護されていますか？'))return;
    const dirname='resoarc-app-'+id+'-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomUUID().slice(0,8);
    const target=await parent.getDirectoryHandle(dirname,{create:true});
    if(!window.confirm('アプリ #'+id+' の分割バックアップを選択フォルダー内の '+dirname+' に作成します。途中失敗時には索引ファイルは作成されません。続行しますか？'))return;
    status.textContent='アプリ構造を取得しています';
    const [fields,layout]=await Promise.all([getFields(id),getLayout(id)]);
    const {settings,coverage}=await collectSettings(id,message=>{status.textContent=message;});
    coverage.sections.fields={status:'captured'};
    coverage.sections.layout={status:'captured'};
    coverage.sections.records={status:'captured',mode:'cursor-stream',count:'索引作成後に確定'};
    const metadataOf=record=>{
      const values={};
      for(const code of metaFields)if(record[code]&&Object.hasOwn(record[code],'value'))values[code]=record[code].value;
      return values;
    };
    async function writeLocal(name,bytes){
      const fileHandle=await target.getFileHandle(name,{create:true});
      const writer=await fileHandle.createWritable();
      try{await writer.write(bytes);await writer.close();}
      catch(e){try{await writer.abort();}catch{}throw e;}
    }
    const {index,bytes,filename}=await buildCollectionStream({
      appId:id,fields,layout,
      pages:streamRecordPages(id,api,{maxRecords:MAX_COLLECTION_RECORDS}),metadataOf,
      settings,coverage,download:downloadAttachment,passphrase:password,
      onProgress:p=>{status.textContent='取得 '+p.read+'件 / 保存 '+p.written+'件 / 分割 '+p.parts+'ファイル';},
      onPart:async(name,bytes,entry)=>{
        status.textContent='分割ZIP '+name+' / '+entry.count+'件 / '+entry.bytes+' bytes を保存中';
        await writeLocal(name,bytes);
      }
    });
    await writeLocal(filename,bytes); // Index written last only after all parts succeed.
    status.textContent='分割保存完了: '+index.parts.length+'ファイル / '+index.recordCount+
      '件 / '+index.totalBytes+' bytes\n保存先: '+dirname+
      '\n暗号化: '+(index.encrypted?'AES-256-GCM':'なし')+
      '\n復元/閲覧には索引JSONと全パートを選択してください。';
  }));
}
if(K?.events)K.events.on('app.record.index.show',event=>{try{boot();}catch(e){console.error(e);}return event;});
