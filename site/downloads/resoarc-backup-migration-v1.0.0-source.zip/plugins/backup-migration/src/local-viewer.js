// Standalone file://-compatible read-only viewer. Never fetches or executes archived content.
import {inspectArchive,MAX_BYTES} from './core.js';
import {isEncryptedArchive,isPotentialEncryptedArchive,decryptLocalArchive} from './encryption.js';
import {openCollection} from './collection.js';
const $=id=>document.getElementById(id);
const create=(tag,content,cls)=>{
  const el=document.createElement(tag);
  if(content!==undefined)el.textContent=content;
  if(cls)el.className=cls;
  return el;
};
let current=null,chosen=0,page=0,filter='';
const PAGE=50;
const getMeta=archive=>{
  if(!archive.files['data/source-meta.jsonl'])return [];
  const source=new TextDecoder().decode(archive.files['data/source-meta.jsonl']);
  return source.trim()?source.trimEnd().split('\n').map(JSON.parse):[];
};
const getCoverage=archive=>{
  if(!archive.files['schema/coverage.json'])return null;
  return JSON.parse(new TextDecoder().decode(archive.files['schema/coverage.json']));
};
const getSettings=archive=>{
  if(!archive.files['schema/settings.json'])return null;
  return JSON.parse(new TextDecoder().decode(archive.files['schema/settings.json']));
};
function clear(node){node.replaceChildren();}
function fmt(val){
  if(val===null||val===undefined)return '';
  if(Array.isArray(val))return val.map(fmt).join(', ');
  if(typeof val==='object')return JSON.stringify(val);
  return String(val);
}
function fieldLabel(code){
  return current?.archive?.sourceFields?.properties?.[code]?.label||code;
}
function showStatus(message){$('status').textContent=message;}
function downloadBytes(bytes,name){
  const url=URL.createObjectURL(new Blob([bytes],{type:'application/octet-stream'}));
  const a=create('a');a.href=url;a.download=name.replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').slice(0,180)||'attachment';
  document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
function appendValue(target,val){
  if(val===null||val===undefined){target.append(create('span','（空）','muted'));return;}
  if(Array.isArray(val)){
    if(val.length===0){target.append(create('span','（空）','muted'));return;}
    for(const item of val){
      if(item&&typeof item==='object'&&Object.hasOwn(item,'ref')){
        const row=create('div',undefined,'file');
        row.append(create('span',item.name+' ('+item.size+' bytes)'));
        const b=create('button','保存');
        b.onclick=()=>{
          const bytes=current.archive.files['attachments/'+item.ref];
          if(!bytes){showStatus('添付ファイルの実体がありません');return;}
          downloadBytes(bytes,item.name);
        };row.append(b);target.append(row);
      }else if(item&&typeof item==='object'&&item.value&&typeof item.value==='object'&&!Array.isArray(item.value)){
        const table=create('div',undefined,'subtable');
        for(const [code,value] of Object.entries(item.value)){
          const line=create('div');
          line.append(create('strong',code+': '));
          appendValue(line,value?.value);table.append(line);
        }
        target.append(table);
      }else {
        const line=create('div');line.textContent=fmt(item);target.append(line);
      }
    }return;
  }
  // RICH_TEXT values are shown as literal text, not evaluated as HTML.
  target.append(create('span',fmt(val)));
}
function showDetail(index){
  chosen=index;const archive=current.archive;const item=archive.records[index];
  clear($('detail'));
  $('detailTitle').textContent='レコード詳細 #'+(current.meta[index]?.['$id']||String(index+1));
  for(const [code,def] of Object.entries(archive.schema)){
    const box=create('div',undefined,'field');
    const label=create('label',fieldLabel(code)+'　('+def.type+')');
    const value=create('div',undefined,'field-value');
    appendValue(value,item[code]?.value);
    box.append(label,value);$('detail').append(box);
  }
  const info=current.meta[index]||{};
  if(Object.keys(info).length){
    const box=create('div',undefined,'field');
    box.append(create('label','元のシステム情報（参考。移行時に同一値は保証されません）'));
    box.append(create('pre',JSON.stringify(info,null,2)));
    $('detail').append(box);
  }
  $('detailTitle').scrollIntoView({block:'nearest'});
}
function listRows(){
  if(!current)return;
  const {archive,meta}=current;
  const matches=[];
  for(let i=0;i<archive.records.length;i++){
    if(!filter || JSON.stringify(archive.records[i]).toLowerCase().includes(filter) ||
      JSON.stringify(meta[i]||{}).toLowerCase().includes(filter))matches.push(i);
  }
  const pages=Math.max(1,Math.ceil(matches.length/PAGE));
  page=Math.min(page,pages-1);
  $('page').textContent=(page+1)+' / '+pages+'ページ　'+matches.length+'件';
  $('prev').disabled=page===0;$('next').disabled=page>=pages-1;
  clear($('results'));
  const codes=Object.keys(archive.schema).filter(code=>archive.schema[code].type!=='SUBTABLE').slice(0,3);
  const head=create('tr');
  for(const h of ['元ID',...codes.map(fieldLabel),'開く'])head.append(create('th',h));
  $('results').append(head);
  for(const i of matches.slice(page*PAGE,(page+1)*PAGE)){
    const tr=create('tr');
    tr.append(create('td',meta[i]?.['$id']||String(i+1)));
    for(const code of codes)tr.append(create('td',fmt(archive.records[i][code]?.value).slice(0,160)));
    const cell=create('td');const b=create('button','詳細');b.onclick=()=>showDetail(i);cell.append(b);tr.append(cell);
    $('results').append(tr);
  }
}
function showSettings(){
  const archive=current.archive;
  const fields=archive.sourceFields?.properties||{};
  clear($('fields'));
  for(const [code,info] of Object.entries(fields)){
    const line=create('div',undefined,'field');
    line.append(create('strong',(info.label||code)+' ('+code+')'));
    line.append(create('small','　'+info.type+(info.required?' / 必須':'')));
    $('fields').append(line);
  }
  // Purely presentational layout; never execute stored customization.
  clear($('layout'));
  const walk=(items,container,depth=0)=>{
    if(!Array.isArray(items)||depth>12)return;
    for(const item of items){
      const el=create('div',undefined,'layout-node');
      if(item.type==='ROW'){
        el.append(create('small','行'));
        const row=create('div',undefined,'layout-row');
        for(const field of item.fields||[])row.append(create('span',fieldLabel(field.code||field.elementId||field.type||'?'),'layout-cell'));
        el.append(row);
      }else if(item.type==='GROUP'){
        el.append(create('strong',item.code||'グループ'));
        walk(item.layout,el,depth+1);
      }else el.append(create('span',item.type||'未対応要素'));
      container.append(el);
    }
  };
  walk(archive.layout?.layout||archive.layout,$('layout'));
  if(!$('layout').children.length)$('layout').append(create('p','フォーム配置情報はありません。'));
  const coverage=getCoverage(archive);
  clear($('coverage'));
  if(coverage){
    const sections=coverage.sections||{};
    for(const [name,entry] of Object.entries(sections)){
      const line=create('div',(entry.status==='captured'?'取得済':'未取得')+'　'+name+(entry.reason?' : '+entry.reason:''),'coverage-row');
      line.classList.add(entry.status==='captured'?'ok':'warn');$('coverage').append(line);
    }
    for(const lim of coverage.limitations||[])$('coverage').append(create('p','制限: '+lim,'muted'));
  }else $('coverage').append(create('p','旧形式：設定の取得範囲を示す台帳はありません。'));
  const settings=getSettings(archive);
  $('settingsJson').textContent=settings?JSON.stringify(settings,null,2).slice(0,300000):'旧形式：設定スナップショットなし';
}
function reset(){
  current=null;chosen=0;page=0;filter='';
  $('search').value='';$('loaded').hidden=true;
  for(const id of ['results','detail','fields','coverage','layout'])clear($(id));
  showStatus('ローカルのアーカイブを選択してください。外部通信は行いません。');
}
$('file').addEventListener('change',async event=>{
  reset();const files=[...event.target.files||[]];if(!files.length)return;
  showStatus('整合性とSHA-256を検証しています…');
  try{
    let archive;
    const indexFile=files.find(f=>f.name==='resoarc-collection.ra-collection.json');
    if(indexFile){
      const indexBytes=new Uint8Array(await indexFile.arrayBuffer());
      let index;
      try{index=JSON.parse(new TextDecoder().decode(indexBytes));}catch{throw Error('コレクション索引JSONを読み取れません');}
      const pass=index.encrypted?window.prompt('分割アーカイブ共通のパスフレーズを入力してください',''):'';
      if(pass===null){reset();return;}
      const map=new Map();
      for(const f of files){if(map.has(f.name))throw Error('ファイル名が重複しています: '+f.name);map.set(f.name,f);}
      archive=await openCollection(indexBytes,async name=>{
        const f=map.get(name);
        if(!f)throw Error('必要な分割ファイルがありません: '+name);
        if(f.size>MAX_BYTES+56)throw Error('分割ファイルの容量上限を超えています');
        return new Uint8Array(await f.arrayBuffer());
      },{passphrase:pass});
    } else {
      if(files.length!==1)throw Error('分割保存の場合は索引JSONとすべてのパートを同時に選んでください');
      const file=files[0];
      if(file.size>MAX_BYTES+56)throw Error('サイズ超過：単一ファイルは25MiBまでです');
      const bytes=new Uint8Array(await file.arrayBuffer());
      if(isPotentialEncryptedArchive(bytes)&&!isEncryptedArchive(bytes))throw Error('暗号化ヘッダーが破損しています');
      let plaintext=bytes;
      if(isEncryptedArchive(bytes)){
        const pass=window.prompt('暗号化アーカイブのパスフレーズを入力してください（ブラウザー内で復号します）','');
        if(pass===null){reset();return;}
        plaintext=await decryptLocalArchive(bytes,pass);
      }
      try{archive=await inspectArchive(plaintext);}finally{if(plaintext!==bytes)plaintext.fill(0);}
    }
    current={archive,meta:getMeta(archive)};
    const settings=getSettings(archive);
    $('title').textContent=settings?.app?.name||('kintone アプリ #'+archive.manifest.sourceAppId);
    $('summary').textContent='元アプリ '+archive.manifest.sourceAppId+' ・ '+archive.manifest.recordCount+
      '件 ・ '+archive.manifest.createdAt+' ・ 形式v'+archive.manifest.version+
      (archive.manifest.collection?' ・ 分割 '+archive.collectionIndex.parts.length+'ファイル':'');
    $('checksum').textContent='SHA-256: '+archive.archiveHash;
    $('loaded').hidden=false;
    showSettings();listRows();
    if(archive.records.length)showDetail(0);
    showStatus('検証完了。データはこの端末のブラウザー内だけで処理しています。');
  }catch(e){reset();showStatus('読み込みを拒否しました：'+String(e.message||e));}
});
$('search').addEventListener('input',event=>{filter=event.target.value.toLowerCase();page=0;listRows();});
$('prev').onclick=()=>{if(page>0){page--;listRows();}};
$('next').onclick=()=>{page++;listRows();};
$('clear').onclick=()=>{$('file').value='';reset();};
$('exportJson').onclick=()=>{
  if(!current)return;
  if(!window.confirm('JSON形式は暗号化されません。業務データ・個人情報が平文で保存されます。続行しますか？'))return;
  const a=current.archive;
  const data={manifest:a.manifest,sourceFields:a.sourceFields,layout:a.layout,
    settings:getSettings(a),coverage:getCoverage(a),sourceMeta:current.meta,records:a.records};
  const bytes=new TextEncoder().encode(JSON.stringify(data,null,2));
  downloadBytes(bytes,'resoarc-kintone-'+a.manifest.sourceAppId+'.json');
};
reset();
