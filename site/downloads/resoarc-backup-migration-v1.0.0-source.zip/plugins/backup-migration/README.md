# ResoArc Backup & Migration v1.0.0

kintoneのデータを**利用者が管理するPCへ直接保存**し、ローカル環境で閲覧・別のkintoneアプリへ追記復元するための、カスタマイズJavaScriptとオフラインビューアです。

**本製品はkintoneの署名済みプラグインZIPではありません。kintone内の管理アプリにZIPを保存する旧方式でもありません。** 旧方式の開発経緯は [LEGACY_MANAGED_APP_HISTORY.md](LEGACY_MANAGED_APP_HISTORY.md) に分離してあります。今回の配布セットには旧管理アプリ版 `dist/resoarc-backup.js` を含めません。

## 対応環境

- kintoneの**PC用JavaScriptカスタマイズ**が有効な契約。**ライトコースでは利用できません**。
- 導入には対象アプリのアプリ管理権限が必要です。データ取得や復元に必要な閲覧・追加権限も別途必要です。
- Microsoft Edge / Google ChromeのPC版で検証。kintoneのモバイル画面・アプリは対象外です。
- kintoneの公式ヘルプ：[JavaScriptやCSSでアプリをカスタマイズする](https://jp.kintone.help/k/ja/app/customize/js_customize)。

## 配布セットの内容

| 配布パス | 内容 |
|---|---|
| `kintone/resoarc-archive-kintone.js` | kintoneにアップロードするPC用カスタマイズJavaScript |
| `viewer/index.html` | ネットワーク不要のローカルビューア |
| `viewer/viewer.js` / `viewer/viewer.css` | ローカルビューアの動作用ファイル |
| `LICENSE` | ResoArc MITライセンス |
| `LICENSES/fflate-MIT.txt` / `NOTICE.md` | 第三者ライセンス・注意事項 |
| `RESTORE_GUIDE.md` | 導入・バックアップ・復元・障害時の手順 |
| `MANIFEST.json` | 配布ファイルごとのSHA-256等 |
| `RELEASE_NOTES.md` | バージョン履歴・制約 |

## 導入・動作

1. 業務本番ではなく隔離したkintoneアプリを用意し、アプリ設定 → JavaScript / CSSでカスタマイズ → **PC用JavaScript** へ `resoarc-archive-kintone.js` をアップロードします。適用範囲をまず「アプリ管理者のみ」に限定し、アプリを更新します。
2. レコード一覧に表示される「このアプリをローカル保存」でPCへダウンロードします。初回は少数の合成レコードで試してください。
3. 暗号化を選ぶ場合、12文字以上のパスフレーズを使います。復旧用のマスターキーはありません。未暗号化は平文で、個人情報の取り扱いに注意が必要です。
4. `viewer/index.html` をEdge/Chromeで開き、`.ra-kintone` または `.ra-kintone.enc` を読み込みます。分割保存時は索引ファイルとすべてのパートが必要です。
5. 別アプリへ移行する際は、復元先にフィールドコード `ResoArcRestoreKey` の重複禁止「文字列1行」フィールドを作成します。**プレビュー確認後に明示的な操作を行った場合にだけ追記復元**します。既存レコードは更新・削除しません。
6. 復元中に通信応答がなくなった場合、書込みが成功している可能性があります。すぐ連打せず、復元先のキーと件数を確認してから手動再開します。

## 限界とセキュリティ

- 単一アーカイブ／展開25MiB、20,000レコード、ZIPエントリ50,000。分割は最大256パート・総256MiB、1パート25MiB以内です。
- kintoneのコメント、履歴、全権限、ユーザー、スペース、元レコードID、全カスタマイズの完全再現はしません。厳密な同一時点スナップショットでもありません。
- 取得範囲はログイン利用者のkintoneの権限に従います。アーカイブ・パスフレーズをResoArcのサーバーへ送信する機能はありません。ただしkintoneとのAPI通信は発生します。
- 保管ファイルには業務データと個人情報が含まれます。権限管理・暗号化・別媒体への世代保存を推奨します。分割索引には暗号化後も一部のメタデータが残ります。
- 配布ZIPのSHA-256は破損・改変チェックで、作者の電子署名ではありません。信頼できるResoArc公式サイトで公開されたハッシュを別途照合してください。
- **バックアップの取得だけでは復旧保証にはなりません**。オフラインビューアの閲覧と隔離アプリへの復元を事前に試してください。

## 開発者向け：ビルドと検証

```sh
cd plugins/backup-migration
npm ci
npm run build:local
npm run build
npm test
npm run test:browser
```

`build:local` がカスタマイズJS `dist/resoarc-archive-kintone.js` と `archive-viewer/viewer.js` を生成します。
`build` が生成する `dist/resoarc-backup.js` は**旧管理アプリ方式の開発コード**であり、v1.0.0利用者向け配布セットには入りません。混同しないでください。

本製品の公開前受入は [RELEASE_ACCEPTANCE_v1.0.0.md](RELEASE_ACCEPTANCE_v1.0.0.md)、詳しいデータ形式は [LOCAL_ARCHIVE.md](LOCAL_ARCHIVE.md) を参照してください。[RELEASE_QA.md](RELEASE_QA.md) と [LOCAL_FIRST_INTEGRATION_NOTES.md](LOCAL_FIRST_INTEGRATION_NOTES.md) は過去の開発履歴です。

## ライセンス

ResoArc実装はMIT。圧縮ライブラリfflate 0.8.3はMITで、必要なライセンス全文を配布物に収録します。esbuild 0.25.12はビルド時だけ使用します。詳細は [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) をご覧ください。

本製品はResoArcによる独立開発であり、サイボウズ株式会社の公式製品ではありません。
