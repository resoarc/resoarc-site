import test from 'node:test';
import assert from 'node:assert/strict';
import {makeArchive,inspectArchive} from '../src/core.js';
import {createMappedRestorePlan,previewRestoreProgress,runResumableRestore,restoreKeyBase} from '../src/restore.js';

const fields={properties:{Title:{code:'Title',type:'SINGLE_LINE_TEXT',label:'Title'}}};
const target={properties:{...fields.properties,ResoArcRestoreKey:{
  code:'ResoArcRestoreKey',type:'SINGLE_LINE_TEXT',unique:true,label:'Marker'}}};
async function fixture(){
 const build=await makeArchive({appId:55,fields,layout:{layout:[]},
  records:[{Title:{value:'QA synthetic'}}],download:async()=>new Uint8Array(),
  settings:{app:{name:'QA55'}},coverage:{sections:{records:{status:'captured'}}},
  sourceMeta:[{$id:'1'}],now:'2026-10-20T00:00:00Z'});
 const archive=await inspectArchive(build.zip);
 const plan=createMappedRestorePlan(archive,target,56,0);
 return {archive,plan};
}
function fakeDestination(initial){
 const state={keys:[...initial],writes:[],deletes:0,created:0};
 const api=async(path,method,body)=>{
  if(path==='/k/v1/records/cursor.json'){
   if(method==='POST'){state.created++;return {id:'qa-cursor'};}
   if(method==='GET')return {next:false,records:state.keys.map(value=>({ResoArcRestoreKey:{value}}))};
   if(method==='DELETE'){state.deletes++;return {};}
  }
  if(path==='/k/v1/records.json'&&method==='POST'){
   assert.equal(body.app,56);
   state.writes.push(body);
   for(const row of body.records)state.keys.push(row.ResoArcRestoreKey.value);
   return {ids:body.records.map((_,i)=>String(i+101))};
  }
  throw Error('Unexpected '+method+' '+path);
 };
 return {api,state};
}
test('v3 preview detects another archive and blocks implicit append before any PUT/POST records',async()=>{
 const {archive,plan}=await fixture();
 const unrelated='RA3_'+'0'.repeat(32)+'_abcdef012345_0';
 const {api,state}=fakeDestination([unrelated]);
 const preview=await previewRestoreProgress({archive,plan,api});
 assert.equal(preview.otherArchiveKeyCount,1);
 assert.equal(preview.already,0);assert.equal(preview.remaining,1);
 await assert.rejects(runResumableRestore({archive,plan,api,
   upload:async()=>{throw Error('NO FILES')}}),/別バックアップZIP/);
 assert.equal(state.writes.length,0);
});
test('explicit cross-archive consent enables append, and repeat is idempotent',async()=>{
 const {archive,plan}=await fixture();
 const unrelated='RA3_'+'f'.repeat(32)+'_abcdef012345_0';
 const {api,state}=fakeDestination([unrelated]);
 const first=await runResumableRestore({archive,plan,api,
   upload:async()=>{throw Error('NO FILES')},allowCrossArchiveAppend:true});
 assert.deepEqual([first.added,first.already],[1,0]);
 assert.equal(state.writes.length,1);
 const second=await runResumableRestore({archive,plan,api,
   upload:async()=>{throw Error('NO FILES')}});
 assert.deepEqual([second.added,second.already],[0,1]);
 assert.equal(state.writes.length,1);
});
test('same v3 archive and same mapping is harmless repeated restore',async()=>{
 const {archive,plan}=await fixture();
 const {base}=await restoreKeyBase(archive,plan);
 const dest=fakeDestination([base+'0']);
 const preview=await previewRestoreProgress({archive,plan,api:dest.api});
 assert.equal(preview.otherArchiveKeyCount,0);
 assert.equal(preview.already,1);assert.equal(preview.remaining,0);
 const result=await runResumableRestore({archive,plan,api:dest.api,
    upload:async()=>{throw Error('NO FILES')}});
 assert.equal(result.added,0);
 assert.equal(dest.state.writes.length,0);
});

test('unmarked existing destination records block append unless explicitly approved',async()=>{
 const {archive,plan}=await fixture();
 const dest=fakeDestination(['','']);
 const preview=await previewRestoreProgress({archive,plan,api:dest.api});
 assert.equal(preview.otherArchiveKeyCount,0);
 assert.equal(preview.unmarkedRecordCount,2);
 assert.equal(preview.remaining,1);
 await assert.rejects(runResumableRestore({archive,plan,api:dest.api,
   upload:async()=>{throw Error('NO FILES')}}),/復元識別子がない既存レコード/);
 assert.equal(dest.state.writes.length,0);
 const authorized=await runResumableRestore({archive,plan,api:dest.api,
   upload:async()=>{throw Error('NO FILES')},allowCrossArchiveAppend:true});
 assert.equal(authorized.added,1);
 assert.equal(dest.state.writes.length,1);
 const repeat=await runResumableRestore({archive,plan,api:dest.api,
   upload:async()=>{throw Error('NO FILES')}});
 assert.equal(repeat.added,0);
 assert.equal(dest.state.writes.length,1);
});
test('mixed unmarked and other archive markers are both disclosed in preview',async()=>{
 const {archive,plan}=await fixture();
 const dest=fakeDestination(['', 'RA3_'+'a'.repeat(32)+'_abc000000000_0']);
 const progress=await previewRestoreProgress({archive,plan,api:dest.api});
 assert.equal(progress.unmarkedRecordCount,1);
 assert.equal(progress.otherArchiveKeyCount,1);
 await assert.rejects(runResumableRestore({archive,plan,api:dest.api,
   upload:async()=>{throw Error('NO FILES')}}),/別バックアップZIP/);
 assert.equal(dest.state.writes.length,0);
});

test('field-level access denial is not mistaken for an empty restore marker',async()=>{
 const {archive,plan}=await fixture();
 for(const concealed of [{}, {ResoArcRestoreKey:{}}, {ResoArcRestoreKey:{value:null}}]){
  let attemptedWrite=0,closed=0;
  const api=async(path,method)=>{
   if(path==='/k/v1/records/cursor.json'&&method==='POST')return {id:'restricted'};
   if(path==='/k/v1/records/cursor.json'&&method==='GET')return {records:[concealed],next:false};
   if(path==='/k/v1/records.json'&&method==='POST'){attemptedWrite++;throw Error('WRITE MUST NOT OCCUR');}
   if(path==='/k/v1/records/cursor.json'&&method==='DELETE'){closed++;return {};}
   throw Error('Unexpected API');
  };
  await assert.rejects(previewRestoreProgress({archive,plan,api}),/閲覧権限/);
  await assert.rejects(runResumableRestore({archive,plan,api,allowCrossArchiveAppend:true,
   upload:async()=>new Uint8Array()}),/閲覧権限/);
  assert.equal(attemptedWrite,0);
 }
});
test('invalid or legacy-shaped marker does not allow cross-archive bypass',async()=>{
 const {archive,plan}=await fixture();
 for(const badKey of ['legacy-restore-1','RA3_notahash','RA3_'+'f'.repeat(32)+'_deadbeefdead_0?']){
  const dest=fakeDestination([badKey]);
  await assert.rejects(previewRestoreProgress({archive,plan,api:dest.api}),/非対応の識別子/);
  await assert.rejects(runResumableRestore({archive,plan,api:dest.api,allowCrossArchiveAppend:true,
   upload:async()=>new Uint8Array()}),/非対応の識別子/);
  assert.equal(dest.state.writes.length,0);
 }
});
test('duplicate restore markers are treated as inconsistent target, not a successful resume',async()=>{
 const {archive,plan}=await fixture();
 const {base}=await restoreKeyBase(archive,plan);
 const dest=fakeDestination([base+'0',base+'0']);
 await assert.rejects(previewRestoreProgress({archive,plan,api:dest.api}),/重複/);
 await assert.rejects(runResumableRestore({archive,plan,api:dest.api,allowCrossArchiveAppend:true,
   upload:async()=>new Uint8Array()}),/重複/);
 assert.equal(dest.state.writes.length,0);
});

test('finish requires reading back every committed restore marker',async()=>{
 const {archive,plan}=await fixture();
 const dest=fakeDestination([]);
 const api=async(path,method,body)=>{
  if(path==='/k/v1/records/cursor.json'&&method==='GET'&&dest.state.writes.length>0)
   return {records:[],next:false}; // proxy lost read visibility after real acceptance
  return dest.api(path,method,body);
 };
 await assert.rejects(runResumableRestore({archive,plan,api,
  upload:async()=>new Uint8Array()}),/再読込で未確認/);
 assert.equal(dest.state.writes.length,1,'server accepted a batch despite verification failure');
 const restart=await runResumableRestore({archive,plan,api:dest.api,
  upload:async()=>new Uint8Array()});
 assert.equal(restart.added,0,'manual restart scans and skips existing marker');
 assert.equal(restart.verifiedRows,1);
 assert.equal(dest.state.writes.length,1,'no duplicate POST after manual retry');
});
test('successful restore includes count of server-readback verified records',async()=>{
 const {archive,plan}=await fixture();
 const dest=fakeDestination([]);
 const done=await runResumableRestore({archive,plan,api:dest.api,
   upload:async()=>new Uint8Array()});
 assert.deepEqual({added:done.added,verified:done.verifiedRows}, {added:1,verified:1});
});
