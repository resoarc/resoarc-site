import test from 'node:test';
import assert from 'node:assert/strict';
import {makeArchive,inspectArchive} from '../src/core.js';
import {createMappedRestorePlan,restoreKeyBase} from '../src/restore.js';
import {auditRestoredContent} from '../src/restore-audit.js';
const bytes=new TextEncoder().encode('Real bytes for independent QA');
const srcFields={properties:{Title:{type:'SINGLE_LINE_TEXT'},Count:{type:'NUMBER'},
 Rows:{type:'SUBTABLE',fields:{Memo:{type:'MULTI_LINE_TEXT'}}},File:{type:'FILE'}}};
const dstFields={properties:{...srcFields.properties,
 ResoArcRestoreKey:{type:'SINGLE_LINE_TEXT',unique:true}}};
async function fixture(){
 const rec={Title:{value:'テスト'},Count:{value:'123'},
  Rows:{value:[{value:{Memo:{value:'注記'}}}]},
  File:{value:[{fileKey:'src-key',name:'test.txt',size:bytes.length,contentType:'text/plain'}]}};
 const built=await makeArchive({appId:55,fields:srcFields,records:[rec],download:async()=>bytes});
 const archive=await inspectArchive(built.zip,{expectedHash:built.hash});
 const plan=createMappedRestorePlan(archive,dstFields,56,0);
 const {base}=await restoreKeyBase(archive,plan);
 const row={Title:{value:'テスト'},Count:{value:'123.00'},
  Rows:{value:[{id:'22',value:{Memo:{value:'注記'}}}]},
  File:{value:[{fileKey:'restored-key',name:'test.txt',size:bytes.length}]},
  ResoArcRestoreKey:{value:base+'0'}};
 return {archive,plan,row};
}
function server(rows,{broken=false}={}){
 let position=0,deleted=0,calls=0;
 return {api:async(path,method)=>{
  if(method==='POST')return {id:'audit-cursor'};
  if(method==='DELETE'){deleted++;return {};}
  if(method==='GET'){
   calls++;
   if(broken)throw Error('HTTP 403');
   const r=rows.slice(position,position+500);position+=r.length;
   return {records:r,next:position<rows.length};
  }
 },deleted:()=>deleted,calls:()=>calls};
}
test('read-only audit verifies real record structure and file SHA256',async()=>{
 const f=await fixture(),s=server([f.row]);
 const d=await auditRestoredContent({...f,api:s.api,download:async()=>bytes});
 assert.deepEqual({passed:d.passed,matched:d.matched,attachments:d.attachmentsVerified},
  {passed:true,matched:1,attachments:1});
 assert.equal(d.mismatchedPaths.length,0);
});
test('changed record with intact restore marker cannot masquerade as restored data',async()=>{
 const f=await fixture();
 f.row.Rows.value[0].value.Memo.value='変造された値';
 const d=await auditRestoredContent({...f,api:server([f.row]).api,download:async()=>bytes});
 assert.equal(d.passed,false);
 assert.deepEqual(d.mismatchedPaths,['record[0].Rows[0].Memo']);
 assert.equal(JSON.stringify(d).includes('変造'),false);
});
test('same filename and file size but different attachment bytes is caught',async()=>{
 const f=await fixture();
 const d=await auditRestoredContent({...f,api:server([f.row]).api,
  download:async()=>new Uint8Array(bytes.length).fill(2)});
 assert.equal(d.passed,false);
 assert.deepEqual(d.mismatchedPaths,['record[0].File[0]']);
});
test('missing record returns failed audit and no false completeness',async()=>{
 const f=await fixture();
 const d=await auditRestoredContent({...f,api:server([]).api,download:async()=>bytes});
 assert.deepEqual({passed:d.passed,missing:d.missing,matched:d.matched},
  {passed:false,missing:1,matched:0});
});
test('missing field permissions do not return a passed audit',async()=>{
 const f=await fixture();
 delete f.row.Title;
 const d=await auditRestoredContent({...f,api:server([f.row]).api,download:async()=>bytes});
 assert.equal(d.passed,false);
 assert.deepEqual(d.mismatchedPaths,['record[0].Title']);
});
test('cursor 403 propagates and cleans up cursor',async()=>{
 const f=await fixture(),s=server([],{broken:true});
 await assert.rejects(auditRestoredContent({...f,api:s.api,download:async()=>bytes}),/403/);
 assert.equal(s.deleted(),1);
});
test('file API rejection fails closed instead of incorrectly reporting success',async()=>{
 const f=await fixture(),s=server([f.row]);
 await assert.rejects(auditRestoredContent({...f,api:s.api,download:async()=>{throw Error('HTTP 403 file')}}),/403/);
 assert.equal(s.deleted(),1);
});
test('already aborted audit does not create cursor',async()=>{
 const f=await fixture(),stop=new AbortController();stop.abort();
 let used=false;
 await assert.rejects(auditRestoredContent({...f,api:async()=>{used=true;throw Error('called');},
  download:async()=>bytes,signal:stop.signal}),/中止/);
 assert.equal(used,false);
});

test('duplicate target marker fails audit and never claims clean completion',async()=>{
 const f=await fixture(),s=server([f.row,f.row]);
 await assert.rejects(auditRestoredContent({...f,api:s.api,download:async()=>bytes}),/重複/);
 assert.equal(s.deleted(),1);
});
test('audit scan limit fails closed and releases open cursor',async()=>{
 const f=await fixture(),s=server([f.row,f.row]);
 await assert.rejects(auditRestoredContent({...f,api:s.api,download:async()=>bytes,maxRecords:1}),/上限/);
 assert.equal(s.deleted(),1);
});
test('malformed cursor page cannot become successful audit',async()=>{
 const f=await fixture();let deleted=0;
 const api=async(path,method)=>{
  if(method==='POST')return {id:'badcursor'};
  if(method==='DELETE'){deleted++;return {};}
  if(method==='GET')return {records:[],next:true};
 };
 await assert.rejects(auditRestoredContent({...f,api,download:async()=>bytes}),/不正/);
 assert.equal(deleted,1);
});
test('abort after cursor is created releases cursor without further reads',async()=>{
 const f=await fixture(),controller=new AbortController();let deleted=0,reads=0;
 const api=async(path,method)=>{
  if(method==='POST')return {id:'abortcursor'};
  if(method==='DELETE'){deleted++;return {};}
  if(method==='GET'){reads++;controller.abort();return {records:[f.row],next:true};}
 };
 await assert.rejects(auditRestoredContent({...f,api,download:async()=>bytes,signal:controller.signal}),/中止/);
 assert.equal(reads,1);assert.equal(deleted,1);
});
