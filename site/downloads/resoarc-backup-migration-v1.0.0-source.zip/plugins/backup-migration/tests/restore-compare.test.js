import test from 'node:test';
import assert from 'node:assert/strict';
import {compareRestoreRecord} from '../src/restore-compare.js';
const schema={Title:{type:'SINGLE_LINE_TEXT'},Amount:{type:'NUMBER'},
 Choice:{type:'MULTI_SELECT'},Owners:{type:'USER_SELECT'},
 Notes:{type:'SUBTABLE',fields:{Memo:{type:'MULTI_LINE_TEXT'}}},
 File:{type:'FILE'}};
const original={
 Title:{value:'日本語の記録'},Amount:{value:'0100.00'},
 Choice:{value:['Beta','Alpha']},Owners:{value:[{code:'b'},{code:'a'}]},
 Notes:{value:[{value:{Memo:{value:'1行目'}}},{value:{Memo:{value:'2行目'}}}]},
 File:{value:[{ref:'a'.repeat(64),name:'foo.txt',size:5}]}
};
const restored={
 Title:{value:'日本語の記録'},Amount:{value:'100'},
 Choice:{value:['Alpha','Beta']},Owners:{value:[{code:'a',name:'Ａ'},{code:'b',name:'Ｂ'}]},
 Notes:{value:[{id:'10',value:{Memo:{value:'1行目'}}},{id:'11',value:{Memo:{value:'2行目'}}}]},
 File:{value:[{fileKey:'k2',name:'foo.txt',size:'5'}]}
};
test('Japanese, exact fields, decimal strings, unordered multiselect, nested row IDs',()=>{
 const x=compareRestoreRecord(original,restored,schema);
 assert.equal(x.passed,true);assert.equal(x.differences.length,0);
 assert.deepEqual(x.attachments,[{path:'File[0]',sha256:'a'.repeat(64),fileKey:'k2'}]);
});
test('one changed scalar or subtable is detected with no values in report',()=>{
 for(const [mutate,location] of [
  [x=>x.Title.value='書換え','Title'],
  [x=>x.Amount.value='101','Amount'],
  [x=>x.Notes.value[1].value.Memo.value='書換え','Notes[1].Memo'],
  [x=>x.Choice.value=['Beta'],'Choice'],
  [x=>delete x.Title,'Title']]){
  const x=structuredClone(restored);mutate(x);
  const report=compareRestoreRecord(original,x,schema);
  assert.equal(report.passed,false);
  assert.ok(report.differences.includes(location));
  assert.equal(JSON.stringify(report).includes('書換え'),false);
 }
});
test('attachment name and size mismatches rejected',()=>{
 for(const mutate of [x=>x.File.value[0].name='wrong',x=>x.File.value[0].size=6,
  x=>x.File.value[0].fileKey='',x=>x.File.value=[]]){
  const x=structuredClone(restored);mutate(x);
  const report=compareRestoreRecord(original,x,schema);
  assert.equal(report.passed,false);
  assert.ok(report.differences.some(v=>v.startsWith('File')));
 }
});
test('large decimal number is compared without double float precision loss',()=>{
 const a={Amount:{value:'9007199254740993.00'}};
 assert.equal(compareRestoreRecord(a,{Amount:{value:'9007199254740993'}},{Amount:{type:'NUMBER'}}).passed,true);
 assert.equal(compareRestoreRecord(a,{Amount:{value:'9007199254740992'}},{Amount:{type:'NUMBER'}}).passed,false);
});
test('unchanged expected source object and subtable ordering is significant',()=>{
 const before=JSON.stringify(original);
 const x=structuredClone(restored);
 x.Notes.value.reverse();
 assert.equal(compareRestoreRecord(original,x,schema).passed,false);
 assert.equal(JSON.stringify(original),before);
});
