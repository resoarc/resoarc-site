import test from 'node:test';
import assert from 'node:assert/strict';
import {makeArchive,inspectArchive,MAX_BYTES} from '../src/core.js';
import {encryptLocalArchive,decryptLocalArchive,isEncryptedArchive,isPotentialEncryptedArchive} from '../src/encryption.js';

const passphrase='Some meaningful sentence 2026!';
async function fixture(){
  return makeArchive({appId:44,fields:{properties:{Name:{type:'SINGLE_LINE_TEXT',label:'名前'}}},
    layout:{layout:[]},records:[{Name:{value:'顧客秘密 2026'}}],
    now:'2026-10-20T00:00:00Z',download:async()=>new Uint8Array()});
}
test('encrypted local archive roundtrip, restores checksummed v2 ZIP',async()=>{
  const original=await fixture();
  const encrypted=await encryptLocalArchive(original.zip,passphrase);
  assert.equal(isEncryptedArchive(encrypted),true);
  assert.equal(isPotentialEncryptedArchive(encrypted),true);
  assert.equal(encrypted.length,original.zip.length+56);
  assert.equal(new TextDecoder().decode(encrypted).includes('顧客秘密'),false);
  const decrypted=await decryptLocalArchive(encrypted,passphrase);
  const loaded=await inspectArchive(decrypted);
  assert.equal(loaded.records[0].Name.value,'顧客秘密 2026');
});
test('encrypted envelopes always use fresh salt and IV',async()=>{
  const original=await fixture();
  const a=await encryptLocalArchive(original.zip,passphrase);
  const b=await encryptLocalArchive(original.zip,passphrase);
  assert.notDeepEqual(a,b);
});
test('wrong passphrase, tampered ciphertext, and tampered header all fail',async()=>{
  const original=await fixture();
  const encrypted=await encryptLocalArchive(original.zip,passphrase);
  await assert.rejects(()=>decryptLocalArchive(encrypted,'incorrect-phrase!'),/復号できません/);
  const tampered=encrypted.slice();tampered[tampered.length-5]^=1;
  await assert.rejects(()=>decryptLocalArchive(tampered,passphrase),/復号できません/);
  const badHeader=encrypted.slice();badHeader[8]^=1;
  await assert.rejects(()=>decryptLocalArchive(badHeader,passphrase),/復号できません/);
});
test('reject unsupported passphrase lengths and invalid iteration work factor',async()=>{
  const original=await fixture();
  await assert.rejects(()=>encryptLocalArchive(original.zip,'short'),/パスフレーズ/);
  await assert.rejects(()=>encryptLocalArchive(original.zip,passphrase,{iterations:500}),/反復回数/);
  const encrypted=await encryptLocalArchive(original.zip,passphrase);
  const bad=encrypted.slice();new DataView(bad.buffer).setUint32(36,0);
  await assert.rejects(()=>decryptLocalArchive(bad,passphrase),/反復回数/);
});
test('reject oversized encrypted envelope before deriving the key',async()=>{
  await assert.rejects(()=>decryptLocalArchive(new Uint8Array(MAX_BYTES+57),passphrase),/サイズ/);
});
