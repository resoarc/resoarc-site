import test from 'node:test';
import assert from 'node:assert/strict';
import {buildCollectionStream,openCollection} from '../src/collection.js';

const N=10001;
const fields={properties:{Title:{type:'SINGLE_LINE_TEXT',label:'Title',code:'Title'},Amount:{type:'NUMBER',code:'Amount',label:'Amount'}}};
async function* pages(){
 for(let start=0;start<N;start+=500){
  yield Array.from({length:Math.min(500,N-start)},(_,i)=>({
   $id:{value:String(start+i+1)},
   Title:{value:'QA synthetic '+String(start+i+1).padStart(5,'0')},
   Amount:{value:String((start+i)*7)}
  }));
 }
}
async function build(onPart,opts={}){
 return buildCollectionStream({appId:55,fields,layout:{layout:[]},
  settings:{app:{name:'QA synthetic only'}},
  coverage:{sections:{records:{status:'captured'}}},
  pages:pages(),metadataOf:r=>({'$id':r.$id.value}),
  download:async()=>new Uint8Array(),onPart,
  createdAt:'2026-10-20T00:00:00.000Z',...opts});
}
test('10001 synthetic records, 21 parts, index LAST, all restored read-only',async()=>{
 const files=new Map();let counter=0;
 const out=await build(async(name,bytes)=>{
  assert.equal(counter+1,Number(name.match(/part-(\d+)/)[1]));
  files.set(name,bytes);counter++;
 });
 assert.equal(out.index.recordCount,N);
 assert.equal(out.index.parts.length,21);
 assert.equal(out.index.parts.at(-1).count,1);
 assert.equal(files.size,21);
 const reassembled=await openCollection(out.bytes,async name=>files.get(name));
 assert.equal(reassembled.records.length,N);
 assert.equal(reassembled.sourceMeta.length,N);
 assert.equal(reassembled.records[0].Amount.value,'0');
 assert.equal(reassembled.records.at(-1).Amount.value,String((N-1)*7));
 assert.equal(reassembled.records.at(-1).Title.value,'QA synthetic 10001');
 assert.equal(new Set(reassembled.sourceMeta.map(r=>r.$id)).size,N);
 const saved=out.index.parts[10];
 const missing=new Map(files);missing.delete(saved.file);
 await assert.rejects(openCollection(out.bytes,async name=>missing.get(name)),/破損|欠落|file|size/i);
 const tampered=new Map(files);const bytes=tampered.get(saved.file).slice();
 bytes[bytes.length-3]^=1;tampered.set(saved.file,bytes);
 await assert.rejects(openCollection(out.bytes,async name=>tampered.get(name)),/破損|欠落|file|size/i);
});
test('streaming disk-full after fourth part produces NO final index',async()=>{
 let count=0,completed=false;
 await assert.rejects(async()=>{
  await build(async()=>{if(++count===4)throw Error('QA_DISK_FULL');});
  completed=true;
 },/QA_DISK_FULL/);
 assert.equal(count,4);
 assert.equal(completed,false);
});
test('streaming max-record guard rejects 10001 rows without success index',async()=>{
 let wrote=0,completed=false;
 await assert.rejects(async()=>{
  await build(async()=>{wrote++;},{maxRecords:10000});
  completed=true;
 },/上限/);
 assert.equal(completed,false);assert.equal(wrote,20);
});
