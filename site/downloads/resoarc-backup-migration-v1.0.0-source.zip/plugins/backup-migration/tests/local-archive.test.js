import test from 'node:test';
import assert from 'node:assert/strict';
import {unzipSync,zipSync,strToU8} from 'fflate';
import {makeArchive,inspectArchive,sha256} from '../src/core.js';
import {planNewApp} from '../src/migration.js';

const fields={properties:{
  Title:{type:'SINGLE_LINE_TEXT',code:'Title',label:'案件名'},
  File:{type:'FILE',code:'File',label:'添付'}
}};
const records=[{
  '$id':{type:'__ID__',value:'87'},
  Title:{type:'SINGLE_LINE_TEXT',value:'Alpha <script>alert(1)</script>'},
  File:{type:'FILE',value:[{fileKey:'demo',name:'見積書.txt',size:'7',contentType:'text/plain'}]}
}];
const sourceMeta=[{'$id':'87','作成日時':'2026-10-20T00:00:00Z'}];
const settings={app:{id:'77',name:'案件管理'},views:{views:{}}};
const coverage={sections:{views:{status:'captured'},reports:{status:'unavailable',reason:'権限不足'}},
  limitations:['変更履歴は取得できません']};
const make=extra=>makeArchive({appId:77,fields,layout:{layout:[{type:'ROW',fields:[{code:'Title'}]}]},
  records,download:async()=>strToU8('sample!'),now:'2026-10-20T00:00:00Z',...extra});

test('v3 local archive contains records, attachments, settings, metadata and coverage',async()=>{
  const archive=await make({settings,coverage,sourceMeta});
  assert.equal(archive.manifest.version,3);
  const result=await inspectArchive(archive.zip,{expectedHash:archive.hash});
  assert.equal(result.records.length,1);
  assert.match(result.records[0].Title.value,/script/);
  assert.equal(JSON.parse(new TextDecoder().decode(result.files['schema/settings.json'])).app.name,'案件管理');
  assert.equal(JSON.parse(new TextDecoder().decode(result.files['schema/coverage.json'])).sections.reports.status,'unavailable');
  assert.equal(new TextDecoder().decode(result.files['data/source-meta.jsonl']).trim().includes('87'),true);
  assert.equal(result.manifest.files.length,1);
  const draft=planNewApp(result,'案件管理移行');
  assert.equal(draft.name,'案件管理移行');
});
test('tampering with settings inside a re-zipped archive is detected',async()=>{
  const orig=await make({settings,coverage,sourceMeta});
  const contents=unzipSync(orig.zip);
  contents['schema/settings.json']=strToU8('{"app":{"name":"tampered"}}');
  await assert.rejects(()=>inspectArchive(zipSync(contents)),/ハッシュ/);
});
test('tampering with coverage and metadata is also rejected',async()=>{
  const orig=await make({settings,coverage,sourceMeta});
  for(const path of ['schema/coverage.json','data/source-meta.jsonl']){
    const contents=unzipSync(orig.zip);
    contents[path]=strToU8('{}');
    await assert.rejects(()=>inspectArchive(zipSync(contents)),/ハッシュ|メタデータ/);
  }
});
test('v2 legacy archives remain inspectable',async()=>{
  const archive=await make({});
  assert.equal(archive.manifest.version,2);
  const result=await inspectArchive(archive.zip);
  assert.equal(result.records.length,1);
  assert.equal(result.archiveHash,await sha256(archive.zip));
});
test('local mode requires equally sized and valid metadata inputs',async()=>{
  await assert.rejects(()=>make({settings,coverage,sourceMeta:[]}),/メタ情報/);
});
