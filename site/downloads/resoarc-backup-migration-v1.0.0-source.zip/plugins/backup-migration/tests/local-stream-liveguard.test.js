import test from 'node:test';
import assert from 'node:assert/strict';
import {streamRecordPages} from '../src/transport.js';
import {buildCollectionStream,openCollection} from '../src/collection.js';

const row=i=>({Title:{value:'QA-'+i},$id:{value:String(i)}});
function apiFactory(count,{forbidden=false,failAfter=-1,malformed=false}={}){
 const list=Array.from({length:count},(_,i)=>row(i+1));
 const state={index:0,create:0,get:0,deleted:0,closed:false};
 const api=async(path,method,payload)=>{
  assert.equal(path,'/k/v1/records/cursor.json');
  if(method==='POST'){
   assert.equal(payload.app,55);
   state.create++;return {id:'cursor-qa'};
  }
  if(method==='DELETE'){
   state.deleted++;state.closed=true;return {};
  }
  assert.equal(method,'GET');
  if(forbidden)throw Object.assign(new Error('HTTP 403'),{status:403});
  if(failAfter>=0&&state.get>=failAfter)throw Error('READ_FAILURE');
  state.get++;
  if(malformed)return {records:[],next:true};
  const n=list.slice(state.index,state.index+500);state.index+=n.length;
  return {records:n,next:state.index<list.length};
 };
 return {api,state};
}
test('cursor streaming 1001 records in 3 pages and no orphan cursor after completion',async()=>{
 const {api,state}=apiFactory(1001);
 const lengths=[];
 for await(const page of streamRecordPages(55,api))lengths.push(page.length);
 assert.deepEqual(lengths,[500,500,1]);assert.equal(state.create,1);
 assert.equal(state.get,3);assert.equal(state.deleted,0);
});
test('explicit early break deletes cursor',async()=>{
 const {api,state}=apiFactory(1001);
 for await(const page of streamRecordPages(55,api)){
  assert.equal(page.length,500);break;
 }
 assert.equal(state.deleted,1);
});
test('AbortSignal after page fails closed and deletes cursor',async()=>{
 const {api,state}=apiFactory(1001);
 const controller=new AbortController();
 await assert.rejects(async()=>{
  for await(const page of streamRecordPages(55,api,{signal:controller.signal}))
   if(page.length===500)controller.abort();
 },/中止/);
 assert.equal(state.deleted,1);
});
test('403 from cursor request is surfaced and cursor is deleted',async()=>{
 const {api,state}=apiFactory(1000,{forbidden:true});
 await assert.rejects(async()=>{for await(const _ of streamRecordPages(55,api)){}},/403/);
 assert.equal(state.deleted,1);
});
test('malformed empty next page cannot silently complete',async()=>{
 const {api,state}=apiFactory(1000,{malformed:true});
 await assert.rejects(async()=>{for await(const _ of streamRecordPages(55,api)){}},/不正/);
 assert.equal(state.deleted,1);
});
test('bound overrun terminates and releases cursor',async()=>{
 const {api,state}=apiFactory(1001);
 await assert.rejects(async()=>{for await(const _ of streamRecordPages(55,api,{maxRecords:1000})){}},/上限/);
 assert.equal(state.deleted,1);
});
test('network failure after first page deletes cursor',async()=>{
 const {api,state}=apiFactory(1001,{failAfter:1});
 await assert.rejects(async()=>{for await(const _ of streamRecordPages(55,api)){}},/READ_FAILURE/);
 assert.equal(state.deleted,1);
});
test('invalid app, page size and ceiling rejected before cursor creation',async()=>{
 const {api,state}=apiFactory(501);
 for(const opts of [{app:0,config:{}},{app:55,config:{pageSize:501}},
  {app:55,config:{pageSize:0}},{app:55,config:{maxRecords:250001}}]){
  await assert.rejects(async()=>{for await(const _ of streamRecordPages(opts.app,api,opts.config)){}});
 }
 assert.equal(state.create,0);
});
const schema={properties:{Title:{type:'SINGLE_LINE_TEXT',label:'Title',code:'Title'}}};
const settings={app:{name:'QA55 local'}};
const coverage={sections:{fields:{status:'captured'}}};
test('stream collection 1201 records assembles encrypted-ready v3 multipart with readback',async()=>{
 const {api}=apiFactory(1201);const parts=new Map();
 const output=await buildCollectionStream({
  appId:55,fields:schema,layout:{layout:[]},pages:streamRecordPages(55,api),
  metadataOf:rec=>({'$id':rec.$id.value}),settings,coverage,
  download:async()=>new Uint8Array(),onPart:async(name,bytes)=>{parts.set(name,bytes);}
 });
 assert.equal(output.index.recordCount,1201);assert.deepEqual(output.index.parts.map(x=>x.count),[500,500,201]);
 assert.equal(parts.size,3);
 const assembled=await openCollection(output.bytes,async name=>{
  assert.ok(parts.has(name));return parts.get(name);
 });
 assert.equal(assembled.records.length,1201);assert.equal(assembled.sourceMeta.length,1201);
 assert.equal(assembled.records[0].Title.value,'QA-1');
 assert.equal(assembled.records.at(-1).Title.value,'QA-1201');
});
test('filesystem failure does not produce complete collection index',async()=>{
 const {api,state}=apiFactory(1201);const parts=[];let indexMade=false;
 await assert.rejects(async()=>{
  const result=await buildCollectionStream({
   appId:55,fields:schema,layout:{layout:[]},pages:streamRecordPages(55,api),
   metadataOf:r=>({'$id':r.$id.value}),settings,coverage,download:async()=>new Uint8Array(),
   onPart:async(name,bytes)=>{
    parts.push(name);
    if(parts.length===2)throw Error('DISK_FULL');
   }
  });
  indexMade=Boolean(result.index);
 },/DISK_FULL/);
 assert.deepEqual(parts,['part-00001.ra-kintone','part-00002.ra-kintone']);
 assert.equal(indexMade,false);assert.equal(state.deleted,1);
});
test('maxRecords limit stops without any success index',async()=>{
 const {api,state}=apiFactory(1201);let committed=false;
 await assert.rejects(async()=>{
  const result=await buildCollectionStream({
   appId:55,fields:schema,layout:{layout:[]},pages:streamRecordPages(55,api),
   metadataOf:r=>({'$id':r.$id.value}),settings,coverage,maxRecords:700,
   download:async()=>new Uint8Array(),onPart:async()=>{}
  });
  committed=Boolean(result.index);
 },/上限/);
 assert.equal(committed,false);assert.equal(state.deleted,1);
});
