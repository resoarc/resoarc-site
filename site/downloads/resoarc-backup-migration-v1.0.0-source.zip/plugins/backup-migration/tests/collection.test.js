import test from 'node:test';
import assert from 'node:assert/strict';
import {buildCollection,openCollection} from '../src/collection.js';
const fields={properties:{Title:{type:'SINGLE_LINE_TEXT',label:'Title'}}};
const source=Array.from({length:17},(_,i)=>({Title:{value:'Record '+i+' repeated value '+('x'.repeat(80))}}));
const metadata=source.map((_,i)=>({'$id':String(i+100)}));
const settings={app:{name:'Collection QA'}};
const coverage={sections:{fields:{status:'captured'}}};
async function prepare({encrypted=false,partRecordLimit=5,maxPartBytes,records=source}={}){
  const store=new Map();
  const args={appId:45,fields,layout:{layout:[]},records,sourceMeta:metadata.slice(0,records.length),settings,coverage,
    download:async()=>new Uint8Array(),createdAt:'2026-10-20T00:00:00Z',
    partRecordLimit,passphrase:encrypted?'a very long archive passphrase':undefined,
    onPart:async(file,bytes)=>{store.set(file,bytes)}};
  if(maxPartBytes)args.maxPartBytes=maxPartBytes;
  const {index,bytes}=await buildCollection(args);
  return {store,index,bytes};
}
test('collection creates ordered v3 parts and fully reassembles for import',async()=>{
  const {store,index,bytes}=await prepare();
  assert.equal(index.parts.length,4);
  assert.deepEqual(index.parts.map(x=>x.count),[5,5,5,2]);
  const archive=await openCollection(bytes,async name=>store.get(name));
  assert.equal(archive.records.length,17);
  assert.equal(archive.sourceMeta[16]['$id'],'116');
  assert.equal(archive.records[14].Title.value,source[14].Title.value);
  assert.equal(archive.manifest.collection,true);
  assert.match(archive.archiveHash,/^[0-9a-f]{64}$/);
});
test('encrypted multi-part collection reassembles with one passphrase',async()=>{
  const {store,bytes}=await prepare({encrypted:true,partRecordLimit:7});
  const result=await openCollection(bytes,async name=>store.get(name),{passphrase:'a very long archive passphrase'});
  assert.equal(result.records.length,17);
  await assert.rejects(()=>openCollection(bytes,async name=>store.get(name),{passphrase:'wrong very long passphrase'}),/復号できません/);
});
test('missing, modified, reordered, altered count, and extra part are rejected',async()=>{
  const {store,index,bytes}=await prepare();
  await assert.rejects(()=>openCollection(bytes,async name=> name===index.parts[1].file?null:store.get(name)),/欠落/);
  const bad=store.get(index.parts[0].file).slice();bad[50]^=1;
  await assert.rejects(()=>openCollection(bytes,async name=> name===index.parts[0].file?bad:store.get(name)),/破損/);
  const reordered=structuredClone(index);reordered.parts.reverse();
  await assert.rejects(()=>openCollection(new TextEncoder().encode(JSON.stringify(reordered)),async name=>store.get(name)),/索引/);
  const changed=structuredClone(index);changed.recordCount++;
  await assert.rejects(()=>openCollection(new TextEncoder().encode(JSON.stringify(changed)),async name=>store.get(name)),/件数/);
});
test('strict size limit forces split while maintaining every source record',async()=>{
  const {store,bytes,index}=await prepare({partRecordLimit:17,maxPartBytes:3200});
  assert.ok(index.parts.length>1);
  const restored=await openCollection(bytes,async name=>store.get(name));
  assert.equal(restored.records.length,17);
  assert.deepEqual(restored.records.map(r=>r.Title.value),source.map(r=>r.Title.value));
});
test('disallow partial export with a single oversize record',async()=>{
  const huge=[{Title:{value:Array.from({length:8000},(_,i)=>String.fromCharCode(33+((i*7919+i*i*13)%90))).join('')}}];
  const store=new Map();
  await assert.rejects(()=>prepare({records:huge,maxPartBytes:1024}),/単一レコード/);
});
