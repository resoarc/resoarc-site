# ResoArc Sheet v0.7.0 beta: third party licenses

The ResoArc-authored code uses MIT. Third party licenses apply separately.
Original texts for all 21 immediately bundled Vite/Rollup npm packages
and all 68 ExcelJS prebundled vendor names are retained in licenses/.
JSZip is used under its MIT option rather than its GPL alternative.

## Direct runtime packages

| Package | Version | License evidence |
|---|---|---|
| @corbe30/fortune-excel | 2.3.4 | MIT; licenses/corbe30_fortune-excel/1-LICENSE |
| @formulajs/formulajs | 2.9.3 | MIT; licenses/formulajs_formulajs/1-LICENSE |
| @fortune-sheet/core | 1.0.4 | MIT; licenses/fortune-sheet_core/1-fortune-sheet-api-license.txt |
| @fortune-sheet/formula-parser | 0.2.13 | MIT; licenses/fortune-sheet_formula-parser/1-LICENSE |
| @fortune-sheet/react | 1.0.4 | MIT; licenses/fortune-sheet_react/1-fortune-sheet-api-license.txt |
| @xmldom/xmldom | 0.9.12 | MIT; licenses/xmldom_xmldom/1-LICENSE |
| bessel | 1.0.2 | Apache-2.0; licenses/bessel/1-LICENSE |
| dayjs | 1.11.23 | MIT; licenses/dayjs/1-LICENSE |
| exceljs | 4.4.0 | MIT; licenses/exceljs/1-LICENSE |
| file-saver | 2.0.5 | MIT; licenses/file-saver/1-LICENSE.md |
| immer | 9.0.21 | MIT; licenses/immer/1-LICENSE |
| jstat | 1.9.6 | MIT (installed LICENSE, package.json license field absent); licenses/jstat/1-LICENSE |
| jszip | 3.10.1 | (MIT OR GPL-3.0-or-later); licenses/jszip/1-LICENSE.markdown |
| lodash | 4.18.1 | MIT; licenses/lodash/1-LICENSE |
| numeral | 2.0.6 | MIT; licenses/numeral/1-LICENSE |
| react | 18.3.1 | MIT; licenses/react/1-LICENSE |
| react-dom | 18.3.1 | MIT; licenses/react-dom/1-LICENSE |
| regenerator-runtime | 0.14.1 | MIT; licenses/regenerator-runtime/1-LICENSE |
| scheduler | 0.23.2 | MIT; licenses/scheduler/1-LICENSE |
| tiny-emitter | 2.1.0 | MIT; licenses/tiny-emitter/1-LICENSE |
| uuid | 11.1.1 | MIT; licenses/uuid/1-LICENSE.md |

## ExcelJS 4.4.0 original prebundled library origins
A license original and source-map origin are separate from byte-identical npm version proof.
59 vendor sources have complete source text, JSON-semantic identity, or AST-structural identity.
Nine vendor source sets were browser-transformed or modified; their reference package
versions are not asserted to be the exact source bytes. Their permissive MIT/ISC licenses
and upstream original copyright notices are retained.

| Vendor | Candidate original version | License | Source correspondence | Notice documents |
|---|---|---|---|---|
| @fast-csv/format | 4.3.5 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/fast-csv_format-4.3.5/1-fast-csv_format__4.3.5__LICENSE |
| @fast-csv/parse | 4.3.6 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/fast-csv_parse-4.3.6/1-fast-csv_parse__4.3.6__LICENSE |
| asn1.js | 5.4.1 | MIT | source matched | licenses/exceljs-vendors/asn1.js-5.4.1/1-asn1.js__5.4.1__LICENSE |
| base64-js | 1.5.1 | MIT | source matched | licenses/exceljs-vendors/base64-js-1.5.1/1-base64-js__1.5.1__LICENSE |
| bn.js | 5.2.1 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/bn.js-5.2.1/1-bn.js__5.2.1__LICENSE |
| brorand | 1.1.0 | MIT | source matched | licenses/exceljs-vendors/brorand-1.1.0/1-brorand-1.1.0-README.md |
| browser-pack | 6.1.0 | MIT | source matched | licenses/exceljs-vendors/browser-pack-6.1.0/1-browser-pack__6.1.0__LICENSE |
| browserify-aes | 1.2.0 | MIT | source matched | licenses/exceljs-vendors/browserify-aes-1.2.0/1-browserify-aes__1.2.0__LICENSE |
| browserify-cipher | 1.0.1 | MIT | source matched | licenses/exceljs-vendors/browserify-cipher-1.0.1/1-browserify-cipher__1.0.1__LICENSE |
| browserify-des | 1.0.2 | MIT | source matched | licenses/exceljs-vendors/browserify-des-1.0.2/1-browserify-des__1.0.2__license |
| browserify-rsa | 4.1.0 | MIT | source matched | licenses/exceljs-vendors/browserify-rsa-4.1.0/1-browserify-rsa__4.1.0__LICENSE |
| browserify-sign | 4.2.1 | ISC | source matched | licenses/exceljs-vendors/browserify-sign-4.2.1/1-browserify-sign__4.2.1__LICENSE |
| buffer | 6.0.3 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/buffer-6.0.3/1-buffer__6.0.3__LICENSE |
| buffer-xor | 1.0.3 | MIT | source matched | licenses/exceljs-vendors/buffer-xor-1.0.3/1-buffer-xor__1.0.3__LICENSE |
| cipher-base | 1.0.4 | MIT | source matched | licenses/exceljs-vendors/cipher-base-1.0.4/1-cipher-base__1.0.4__LICENSE |
| core-js | 3.33.0 | MIT | source matched | licenses/exceljs-vendors/core-js-3.33.0/1-core-js__3.33.0__LICENSE |
| core-util-is | 1.0.3 | MIT | source matched | licenses/exceljs-vendors/core-util-is-1.0.3/1-core-util-is__1.0.3__LICENSE |
| create-ecdh | 4.0.4 | MIT | source matched | licenses/exceljs-vendors/create-ecdh-4.0.4/1-create-ecdh__4.0.4__LICENSE |
| create-hash | 1.2.0 | MIT | source matched | licenses/exceljs-vendors/create-hash-1.2.0/1-create-hash__1.2.0__LICENSE |
| create-hmac | 1.1.7 | MIT | source matched | licenses/exceljs-vendors/create-hmac-1.1.7/1-create-hmac__1.1.7__LICENSE |
| crypto-browserify | 3.12.0 | MIT | source matched | licenses/exceljs-vendors/crypto-browserify-3.12.0/1-crypto-browserify__3.12.0__LICENSE |
| dayjs | 1.11.10 | MIT | source matched | licenses/exceljs-vendors/dayjs-1.11.10/1-dayjs__1.11.10__LICENSE |
| des.js | 1.1.0 | MIT | source matched | licenses/exceljs-vendors/des.js-1.1.0/1-des.js-1.1.0-README.md |
| diffie-hellman | 5.0.3 | MIT | source matched | licenses/exceljs-vendors/diffie-hellman-5.0.3/1-diffie-hellman__5.0.3__LICENSE |
| elliptic | 6.5.4 | MIT | source matched | licenses/exceljs-vendors/elliptic-6.5.4/1-elliptic-6.5.4-README.md |
| events | 3.3.0 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/events-3.3.0/1-events__3.3.0__LICENSE |
| evp_bytestokey | 1.0.3 | MIT | source matched | licenses/exceljs-vendors/evp_bytestokey-1.0.3/1-evp_bytestokey__1.0.3__LICENSE |
| fast-csv | 4.3.6 | MIT | source matched | licenses/exceljs-vendors/fast-csv-4.3.6/1-fast-csv__4.3.6__LICENSE |
| hash-base | 3.1.0 | MIT | source matched | licenses/exceljs-vendors/hash-base-3.1.0/1-hash-base__3.1.0__LICENSE |
| hash.js | 1.1.7 | MIT | source matched | licenses/exceljs-vendors/hash.js-1.1.7/1-hash.js-1.1.7-README.md |
| hmac-drbg | 1.0.1 | MIT | source matched | licenses/exceljs-vendors/hmac-drbg-1.0.1/1-hmac-drbg-1.0.1-README.md |
| ieee754 | 1.2.1 | BSD-3-Clause | source matched | licenses/exceljs-vendors/ieee754-1.2.1/1-ieee754__1.2.1__LICENSE |
| inherits | 2.0.4 | ISC | transformed; exact source edition not proven | licenses/exceljs-vendors/inherits-2.0.4/1-inherits__2.0.4__LICENSE |
| isarray | 2.0.5 | MIT | source matched | licenses/exceljs-vendors/isarray-2.0.5/1-isarray__2.0.5__LICENSE |
| jszip | 3.10.1 | (MIT OR GPL-3.0-or-later) | source matched | licenses/exceljs-vendors/jszip-3.10.1/1-jszip__3.10.1__LICENSE.markdown |
| lodash.escaperegexp | 4.1.2 | MIT | source matched | licenses/exceljs-vendors/lodash.escaperegexp-4.1.2/1-lodash.escaperegexp__4.1.2__LICENSE |
| lodash.groupby | 4.6.0 | MIT | source matched | licenses/exceljs-vendors/lodash.groupby-4.6.0/1-lodash.groupby__4.6.0__LICENSE |
| lodash.isboolean | 3.0.3 | MIT | source matched | licenses/exceljs-vendors/lodash.isboolean-3.0.3/1-lodash.isboolean__3.0.3__LICENSE |
| lodash.isequal | 4.5.0 | MIT | source matched | licenses/exceljs-vendors/lodash.isequal-4.5.0/1-lodash.isequal__4.5.0__LICENSE |
| lodash.isfunction | 3.0.9 | MIT | source matched | licenses/exceljs-vendors/lodash.isfunction-3.0.9/1-lodash.isfunction__3.0.9__LICENSE |
| lodash.isnil | 4.0.0 | MIT | source matched | licenses/exceljs-vendors/lodash.isnil-4.0.0/1-lodash.isnil__4.0.0__LICENSE |
| lodash.isundefined | 3.0.1 | MIT | source matched | licenses/exceljs-vendors/lodash.isundefined-3.0.1/1-lodash.isundefined__3.0.1__LICENSE.txt |
| lodash.uniq | 4.5.0 | MIT | source matched | licenses/exceljs-vendors/lodash.uniq-4.5.0/1-lodash.uniq__4.5.0__LICENSE |
| md5.js | 1.3.5 | MIT | source matched | licenses/exceljs-vendors/md5.js-1.3.5/1-md5.js__1.3.5__LICENSE |
| miller-rabin | 4.0.1 | MIT | source matched | licenses/exceljs-vendors/miller-rabin-4.0.1/1-miller-rabin-4.0.1-README.md |
| minimalistic-assert | 1.0.1 | ISC | source matched | licenses/exceljs-vendors/minimalistic-assert-1.0.1/1-minimalistic-assert__1.0.1__LICENSE |
| minimalistic-crypto-utils | 1.0.1 | MIT | source matched | licenses/exceljs-vendors/minimalistic-crypto-utils-1.0.1/1-minimalistic-crypto-utils-1.0.1-README.md |
| parse-asn1 | 5.1.6 | ISC | source matched | licenses/exceljs-vendors/parse-asn1-5.1.6/1-parse-asn1__5.1.6__LICENSE |
| pbkdf2 | 3.1.2 | MIT | source matched | licenses/exceljs-vendors/pbkdf2-3.1.2/1-pbkdf2__3.1.2__LICENSE |
| process | 0.11.10 | MIT | source matched | licenses/exceljs-vendors/process-0.11.10/1-process__0.11.10__LICENSE |
| process-nextick-args | 2.0.1 | MIT | source matched | licenses/exceljs-vendors/process-nextick-args-2.0.1/1-process-nextick-args__2.0.1__license.md |
| public-encrypt | 4.0.3 | MIT | source matched | licenses/exceljs-vendors/public-encrypt-4.0.3/1-public-encrypt__4.0.3__LICENSE |
| randombytes | 2.1.0 | MIT | source matched | licenses/exceljs-vendors/randombytes-2.1.0/1-randombytes__2.1.0__LICENSE |
| randomfill | 1.0.4 | MIT | source matched | licenses/exceljs-vendors/randomfill-1.0.4/1-randomfill__1.0.4__LICENSE |
| readable-stream | 3.6.2 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/readable-stream-3.6.2/1-readable-stream__3.6.2__LICENSE |
| regenerator-runtime | 0.13.11 | MIT | source matched | licenses/exceljs-vendors/regenerator-runtime-0.13.11/1-regenerator-runtime__0.13.11__LICENSE |
| ripemd160 | 2.0.2 | MIT | source matched | licenses/exceljs-vendors/ripemd160-2.0.2/1-ripemd160__2.0.2__LICENSE |
| safe-buffer | 5.2.1 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/safe-buffer-5.2.1/1-safe-buffer__5.2.1__LICENSE |
| safer-buffer | 2.1.2 | MIT | source matched | licenses/exceljs-vendors/safer-buffer-2.1.2/1-safer-buffer__2.1.2__LICENSE |
| saxes | 5.0.1 | ISC | source matched | licenses/exceljs-vendors/saxes-5.0.1/1-saxes__5.0.1__upstream-tag-LICENSE |
| sha.js | 2.4.11 | (MIT AND BSD-3-Clause) | source matched | licenses/exceljs-vendors/sha.js-2.4.11/1-sha.js__2.4.11__LICENSE |
| stream-browserify | 2.0.2 | MIT | source matched | licenses/exceljs-vendors/stream-browserify-2.0.2/1-stream-browserify__2.0.2__LICENSE |
| string_decoder | 1.3.0 | MIT | source matched | licenses/exceljs-vendors/string_decoder-1.3.0/1-string_decoder__1.3.0__LICENSE |
| timers-browserify | 1.4.2 | None | source matched | licenses/exceljs-vendors/timers-browserify-1.4.2/1-timers-browserify__1.4.2__LICENSE.md |
| util | 0.10.4 | MIT | source matched | licenses/exceljs-vendors/util-0.10.4/1-util__0.10.4__LICENSE |
| util-deprecate | 1.0.2 | MIT | source matched | licenses/exceljs-vendors/util-deprecate-1.0.2/1-util-deprecate__1.0.2__LICENSE |
| uuid | 8.3.2 | MIT | source matched | licenses/exceljs-vendors/uuid-8.3.2/1-uuid__8.3.2__LICENSE.md |
| xmlchars | 2.2.0 | MIT | transformed; exact source edition not proven | licenses/exceljs-vendors/xmlchars-2.2.0/1-xmlchars__2.2.0__LICENSE |

## Original copyright preservation
The bundle also contains original copyright headers from Joyent/Node contributors,
Paul Johnston, Sebastian Tschan, Feross Aboukhadijeh, JSZip and pako authors.
Where those banners were identified they are retained separately under
licenses/original-bundle-copyright-headers and the original package LICENSE texts.

This is an internally reviewed permissive-license attribution, not legal certification.
Source version candidate ambiguity is disclosed rather than asserting an exact SBOM.
Please retain this notice and all original license files in redistributions.
