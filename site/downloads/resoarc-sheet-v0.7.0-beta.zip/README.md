# ResoArc Sheet v0.7.0 beta

A free offline spreadsheet editor. This software is NOT Microsoft Excel.
All ResoArc-authored code is MIT licensed.

Extract the ZIP and double-click ResoArc-Sheet.html in a recent Edge, Chrome
or Firefox. No web server, account, setup wizard or Internet connection required.
Open an XLSX or CSV from the file picker. Downloads are saved as a new file;
your original workbook is never overwritten by the application.

Advanced charts, fonts, Excel macros and proprietary spreadsheet extensions
are not fully compatible. Macro-capable xlsm and xlsb input is rejected.
Check the resulting XLSX in desktop Excel before critical production use.

Release candidate QA on 2026-11-10: 26/26 unit tests; 3/3 browser file://
XLSX import/export and mobile viewport checks; npm production advisory scan 0.
These tests do not guarantee all Excel file formats or absence of vulnerabilities.

Retain LICENSE, THIRD_PARTY_NOTICES.md and all files under licenses/.
VENDOR_ORIGIN_REVIEW.json documents nine vendor packages whose exact
prebundled source editions have not been reconstructed byte-for-byte.
This does not invalidate the upstream permissive license grants, but it limits
the accuracy of the exact transitive version inventory.
