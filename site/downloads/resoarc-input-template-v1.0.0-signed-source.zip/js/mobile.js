/* SPDX-FileCopyrightText: 2026 ResoArc Open Technology Project
 * SPDX-License-Identifier: MIT
 * Mobile Kintone API version. UI and data changes remain scoped to the current app. */
(function(){'use strict';
const stored=kintone.plugin.app.getConfig(kintone.$PLUGIN_ID)||{};
let cfg={};try{cfg=JSON.parse(stored.ra_settings||'{}')}catch(_){}
cfg=Object.assign({},{"templates": [{"name": "標準", "values": {"Title": "サンプル"}}]},cfg);
const on=(events,cb)=>kintone.events.on(events,cb);
const parse=s=>String(s||'').split(',').map(x=>x.trim()).filter(Boolean);
const el=(tag,content)=>{const x=document.createElement(tag);if(content!==undefined)x.textContent=String(content);return x;};
const btn=(label,fn)=>{const x=el('button',label);x.type='button';x.className='ra-mini-button';x.style.cssText='background:#176c68;color:white;border:none;border-radius:5px;padding:7px 11px;margin:3px;cursor:pointer';x.addEventListener('click',fn);return x;};
const panel=()=>{let space=null;try{space=kintone.mobile.app.getHeaderSpaceElement?.();}catch(_){}if(!space)return null;let x=document.getElementById('ra-mini-'+"input-template");if(x){x.replaceChildren();return x;}x=el('div');x.id='ra-mini-'+"input-template";x.style.cssText='display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin:8px 0;padding:7px;border:1px solid #bbd8d2;border-radius:6px;background:#f6fbfa;color:#1e4240';space.appendChild(x);return x;};
const cur=()=>{try{return kintone.mobile.app.record.get()?.record||null;}catch(_){return null;}};
const val=(r,k)=>r?.[k]?.value;
const scalar=x=>x==null?'':Array.isArray(x)?x.map(v=>v.name||v.code||String(v)).join(', '):String(x);
const template=(t,r,encode=false)=>String(t??'').replace(/\{\{([A-Za-z0-9_]+)\}\}/g,(_,k)=>encode?encodeURIComponent(scalar(val(r,k))):scalar(val(r,k)));
const set=(r,k,value)=>{const item=r?.[k];if(!item||['CALC','RECORD_NUMBER','CREATED_TIME','UPDATED_TIME','CREATOR','MODIFIER','STATUS','STATUS_ASSIGNEE','FILE','SUBTABLE','REFERENCE_TABLE','CATEGORY'].includes(item.type))return false;
const arrays=['CHECK_BOX','MULTI_SELECT','USER_SELECT','ORGANIZATION_SELECT','GROUP_SELECT'];
if(arrays.includes(item.type)){if(!Array.isArray(value))return false;}
else if(value!==null&&typeof value==='object')return false;
item.value=value;return true;};
const apply=r=>{try{kintone.mobile.app.record.set({record:r});return true;}catch(err){console.warn('[ResoArc Mini]',err);return false;}};
const TEMPLATE_WRITABLE_TYPES=new Set(['SINGLE_LINE_TEXT','MULTI_LINE_TEXT','RICH_TEXT','LINK','NUMBER','DATE','TIME','DATETIME','DROP_DOWN','RADIO_BUTTON','CHECK_BOX','MULTI_SELECT']);
const TEMPLATE_TEXT_TYPES=new Set(['SINGLE_LINE_TEXT','MULTI_LINE_TEXT','RICH_TEXT','LINK','DROP_DOWN','RADIO_BUTTON']);
const templateBlank=value=>value===null||value===undefined||value===''||(Array.isArray(value)&&value.length===0);
const templateValidDate=value=>{
 if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;
 const d=new Date(value+'T00:00:00Z');
 return !Number.isNaN(d.getTime())&&d.toISOString().slice(0,10)===value;
};
const templateCoerce=(entry,value)=>{
 if(value===null||value===undefined)return {ok:false,why:'null/undefined は反映できません'};
 if(TEMPLATE_TEXT_TYPES.has(entry.type)){
  if(typeof value!=='string')return {ok:false,why:'文字列が必要です'};
  if(entry.required&&value==='')return {ok:false,why:'必須項目に空文字は設定できません'};
  return {ok:true,value};
 }
 if(entry.type==='NUMBER'){
  if(value===''&&!entry.required)return {ok:true,value:''};
  const v=typeof value==='number'?String(value):value;
  if(typeof v!=='string'||!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?$/.test(v)||!Number.isFinite(Number(v)))return {ok:false,why:'有限の数値が必要です'};
  return {ok:true,value:v};
 }
 if(entry.type==='DATE'){
  if(value===''&&!entry.required)return {ok:true,value:''};
  return typeof value==='string'&&templateValidDate(value)?{ok:true,value}:{ok:false,why:'有効な日付 YYYY-MM-DD が必要です'};
 }
 if(entry.type==='TIME'){
  if(value===''&&!entry.required)return {ok:true,value:''};
  return typeof value==='string'&&/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value)?{ok:true,value}:{ok:false,why:'時刻 HH:mm が必要です'};
 }
 if(entry.type==='DATETIME'){
  if(value===''&&!entry.required)return {ok:true,value:''};
  const ok=typeof value==='string'&&/^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/.test(value)&&Number.isFinite(Date.parse(value));
  return ok?{ok:true,value}:{ok:false,why:'タイムゾーン付きの日時が必要です'};
 }
 if(entry.type==='CHECK_BOX'||entry.type==='MULTI_SELECT'){
  return Array.isArray(value)&&value.every(v=>typeof v==='string')&&(!entry.required||value.length>0)?{ok:true,value:[...value]}:{ok:false,why:'選択肢文字列の配列が必要です'};
 }
 return {ok:false,why:'型が未対応です'};
};
on(['mobile.app.record.create.show','mobile.app.record.edit.show'],e=>{
 const root=panel();if(!root)return e;root.replaceChildren();
 const templates=Array.isArray(cfg.templates)?cfg.templates:[];
 const choose=el('select');choose.setAttribute('aria-label','入力テンプレート');
 for(const t of templates){const opt=el('option',t?.name||'テンプレート');choose.append(opt)}
 const feedback=el('span','');feedback.setAttribute('role','status');
 const run=btn('反映',()=>{
  feedback.textContent='';
  const template=templates[choose.selectedIndex];
  if(!template||!template.values||Array.isArray(template.values)||typeof template.values!=='object'){
   feedback.textContent='テンプレートの設定がありません';return;
  }
  const current=cur();
  if(!current){feedback.textContent='レコードが取得できません';return;}
  const entries=Object.entries(template.values);
  if(entries.length===0||entries.length>100){feedback.textContent='項目数が不正です（1～100項目）';return;}
  const overwrite=template.overwrite===true;
  const changes=[];const errors=[];
  for(const [code,value] of entries){
   if(!/^[\p{L}\p{N}_]+$/u.test(code)||!Object.prototype.hasOwnProperty.call(current,code)){
    errors.push(code+'：フィールドがありません');continue;
   }
   const field=current[code];
   if(!field||!TEMPLATE_WRITABLE_TYPES.has(field.type)||field.disabled===true){
    errors.push(code+'：編集できない項目です');continue;
   }
   if(!overwrite&&!templateBlank(field.value)){
    errors.push(code+'：既存値の上書きが禁止されています');continue;
   }
   const coerced=templateCoerce(field,value);
   if(!coerced.ok){errors.push(code+'：'+coerced.why);continue;}
   changes.push([code,coerced.value]);
  }
  if(errors.length){feedback.textContent='反映を中止しました：'+errors.slice(0,3).join(' / ')+(errors.length>3?' ほか'+(errors.length-3)+'件':'');return;}
  if(!changes.length){feedback.textContent='反映できる項目がありません';return;}
  // Validate everything first, then write through the authentic kintone record.
  // JSON-cloned record snapshots may be silently ignored by the form API.
  for(const [code,value] of changes)current[code].value=value;
  if(!apply(current)){feedback.textContent='反映できませんでした。権限や入力制約を確認してください';return;}
  const reflected=cur();
  if(!reflected||changes.some(([code,value])=>JSON.stringify(reflected[code]?.value)!==JSON.stringify(value))){
   feedback.textContent='フォームへの反映を確認できませんでした。操作をやり直してください';return;
  }
  feedback.textContent=changes.length+'項目を反映しました';
 });
 if(!templates.length){run.disabled=true;feedback.textContent='テンプレートを設定してください'}
 root.append(el('span','入力テンプレート'),choose,run,feedback);
 return e;
});


})();
