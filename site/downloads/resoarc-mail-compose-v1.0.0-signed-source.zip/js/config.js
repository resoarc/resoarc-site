(function(id){'use strict';
const initial=kintone.plugin.app.getConfig(id)||{};let saved={};try{saved=JSON.parse(initial.ra_settings||'{}')}catch(_){}
const defaults=JSON.parse(document.getElementById('ra-defaults').textContent), root=document.getElementById('ra-fields'),fields={};
for(const [key,def] of Object.entries(defaults)){
 const label=document.createElement('label');label.textContent=key;
 const control=document.createElement(typeof def==='object'?'textarea':'input');
 control.value=typeof(saved[key]??def)==='object'?JSON.stringify(saved[key]??def,null,2):String(saved[key]??def);
 if(control.tagName==='TEXTAREA')control.rows=6;
 label.appendChild(control);root.appendChild(label);fields[key]=control;
}
document.getElementById('ra-save').addEventListener('click',()=>{
 try {const out={};for(const [key,def] of Object.entries(defaults))out[key]=typeof def==='object'?JSON.parse(fields[key].value):fields[key].value;
 kintone.plugin.app.setConfig({ra_settings:JSON.stringify(out)},()=>{document.getElementById('ra-status').textContent='設定を保存しました。アプリを更新してください。'});
 }catch(e){document.getElementById('ra-status').textContent='入力エラー: '+e.message;}
});document.getElementById('ra-back').addEventListener('click',()=>history.back());})(kintone.$PLUGIN_ID);
