/* SPDX-FileCopyrightText: 2026 ResoArc Open Technology Project
 * SPDX-License-Identifier: MIT
 * Mobile Kintone API version. UI and data changes remain scoped to the current app. */
(function(){'use strict';
const stored=kintone.plugin.app.getConfig(kintone.$PLUGIN_ID)||{};
let cfg={};try{cfg=JSON.parse(stored.ra_settings||'{}')}catch(_){}
cfg=Object.assign({},{"toField": "Email", "subject": "{{Title}}", "body": "{{Title}}についてご連絡します。"},cfg);
const on=(events,cb)=>kintone.events.on(events,cb);
const parse=s=>String(s||'').split(',').map(x=>x.trim()).filter(Boolean);
const el=(tag,content)=>{const x=document.createElement(tag);if(content!==undefined)x.textContent=String(content);return x;};
const btn=(label,fn)=>{const x=el('button',label);x.type='button';x.className='ra-mini-button';x.style.cssText='background:#176c68;color:white;border:none;border-radius:5px;padding:7px 11px;margin:3px;cursor:pointer';x.addEventListener('click',fn);return x;};
const panel=()=>{let space=null;try{space=kintone.mobile.app.getHeaderSpaceElement?.();}catch(_){}if(!space)return null;let x=document.getElementById('ra-mini-'+"mail-compose");if(x){x.replaceChildren();return x;}x=el('div');x.id='ra-mini-'+"mail-compose";x.style.cssText='display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin:8px 0;padding:7px;border:1px solid #bbd8d2;border-radius:6px;background:#f6fbfa;color:#1e4240';space.appendChild(x);return x;};
const cur=()=>{try{return kintone.mobile.app.record.get()?.record||null;}catch(_){return null;}};
const val=(r,k)=>r?.[k]?.value;
const scalar=x=>x==null?'':Array.isArray(x)?x.map(v=>v.name||v.code||String(v)).join(', '):String(x);
const template=(t,r,encode=false)=>String(t??'').replace(/\{\{([A-Za-z0-9_]+)\}\}/g,(_,k)=>encode?encodeURIComponent(scalar(val(r,k))):scalar(val(r,k)));
const set=(r,k,value)=>{const item=r?.[k];if(!item||['CALC','RECORD_NUMBER','CREATED_TIME','UPDATED_TIME','CREATOR','MODIFIER','STATUS','STATUS_ASSIGNEE','FILE','SUBTABLE','REFERENCE_TABLE','CATEGORY'].includes(item.type))return false;
const arrays=['CHECK_BOX','MULTI_SELECT','USER_SELECT','ORGANIZATION_SELECT','GROUP_SELECT'];
if(arrays.includes(item.type)){if(!Array.isArray(value))return false;}
else if(value!==null&&typeof value==='object')return false;
item.value=value;return true;};
const apply=r=>{try{kintone.mobile.app.record.set({record:r});return true;}catch(err){console.warn('[ResoArc Mini]',err);return false;}};
on(['mobile.app.record.detail.show','mobile.app.record.edit.show'],e=>{
 const root=panel();if(!root)return e;
 const feedback=el('span','');root.append(btn('メールを作成',()=>{
 const r=cur()||e.record;const to=scalar(val(r,cfg.toField)).trim();
 const subject=template(cfg.subject,r),body=template(cfg.body,r);
 const parts=to.split(/[;,]/).map(x=>x.trim()).filter(Boolean);
 const valid=/^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/;
 if(!parts.length||parts.some(x=>x.length>254||!valid.test(x))){feedback.textContent='宛先メールアドレスを確認してください';return;}
 const address=parts.map(x=>encodeURIComponent(x).replace(/%40/gi,'@')).join(',');
 const mailto='mailto:'+address+'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body);
 location.href=mailto;
 }));root.append(feedback);return e;
});

})();
