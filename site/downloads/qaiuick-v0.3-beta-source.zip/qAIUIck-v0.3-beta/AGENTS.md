# qAIUIck AI development contract

Make small, reviewable changes. Prefer readable HTML over adding new runtime APIs.

1. Read the relevant `examples/<app>/DESIGN.md`, `docs/AI_SPEC.md`, and the actual code.
2. Keep UI in semantic HTML with qAIUIck directives. Avoid large generated JSON UI trees and inline styles. No React, bundlers, `eval`, `innerHTML`, or dynamic script injection.
3. Prefer **one source of truth**. Use `computed` for derived display values; use actions for writes and optional `createStore` for persistence.
4. Use `src/qaiuick.css` tokens and existing classes. Change theme with one `data-q-theme` attribute. Use descriptive labels and focus states.
5. After modifications, update the example's `DESIGN.md` **変更履歴** with what changed, why, and its impact. The notes are a human-readable explanation; Git diffs remain the source of truth for what actually changed.
6. Run `npm run check`; if available, run `python3 tests/browser_smoke.py`. Never claim test success without executing it.
7. Never publish secrets, a demo's database file, or the unauthenticated localhost SQLite API. Document storage limits and user data loss risks.

Useful commands:

```sh
python3 tools/explain.py examples/todo
python3 tools/explain.py examples/todo --since HEAD~1
npm run check
```
