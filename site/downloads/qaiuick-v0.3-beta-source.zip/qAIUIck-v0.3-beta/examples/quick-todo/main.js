import { quickApp } from '../../src/quick.js';
quickApp({
  key: 'example-quick-todo',
  data: { draft: '' },
  sample: [{ id: 'hello', title: 'Try qAIUIck' }],
});
