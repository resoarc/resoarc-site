import { createApp } from '../../src/qaiuick.js';
import { createStore } from '../../src/store.js';

// Add ?db=sqlite and run `python3 server/app.py` to save a real .sqlite file.
const sqlite = new URLSearchParams(location.search).get('db') === 'sqlite';
const store = createStore({
  type: sqlite ? 'remote' : 'local',
  namespace: 'inventory-demo',
  resource: 'items',
});
const state = {
  name: '', quantity: '1', items: [], error: '',
  storageLabel: sqlite ? 'SQLiteファイル' : 'ブラウザ内保存',
  storageHint: sqlite
    ? 'localhostのSQLite APIへ保存します。公開サーバー用の認証はまだありません。'
    : 'このブラウザに保存します。ブラウザデータ削除による消失に注意してください。',
};

const app = createApp({
  root: '#app',
  state,
  computed: {
    count: (s) => s.items.length,
    empty: (s) => s.items.length === 0,
    hasItems: (s) => s.items.length > 0,
  },
  actions: {
    async add(s) {
      const name = s.name.trim();
      const quantity = Number(s.quantity);
      if (!name || name.length > 120 || !String(s.quantity).trim() || !Number.isSafeInteger(quantity) || quantity < 0 || quantity > 1000000) {
        s.error = '品目名（120文字以内）と数量（0〜100万の整数）を確認してください';
        return;
      }
      await store.save({ name, quantity, price: 0 });
      s.name = ''; s.quantity = '1'; s.error = '';
      s.items = await store.list();
    },
    async remove(s, { arg }) {
      await store.remove(arg);
      s.items = await store.list();
    },
  },
  onError(error) { state.error = error.message; app.render(); },
});

try { state.items = await store.list(); app.render(); }
catch (error) { state.error = `データの取得に失敗: ${error.message}`; app.render(); }
