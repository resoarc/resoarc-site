"""Human-readable qAIUIck design map. Built only from existing files and Git.

Usage:
    python3 tools/explain.py examples/todo
    python3 tools/explain.py examples/todo --since HEAD~1
No source code is executed. DESIGN.md contains authored intent, not verified provenance.
"""
from argparse import ArgumentParser
from collections import defaultdict
from html.parser import HTMLParser
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
DIRECTIVES = {'q-text', 'q-model', 'q-show', 'q-submit', 'q-action', 'q-arg', 'q-each'}


class MapParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.bindings = defaultdict(set)

    def handle_starttag(self, tag, attrs):
        for key, value in attrs:
            if key in DIRECTIVES and value:
                self.bindings[key].add(value)


def describe(folder: Path, since=None):
    folder = folder.resolve()
    if ROOT not in folder.parents or not folder.is_dir():
        raise ValueError('Specify a demo folder inside this qAIUIck repository')
    html = folder / 'index.html'
    design = folder / 'DESIGN.md'
    if not html.is_file() or not design.is_file():
        raise ValueError('Both index.html and DESIGN.md are required')
    parser = MapParser()
    parser.feed(html.read_text(encoding='utf-8'))
    doc = design.read_text(encoding='utf-8').strip()
    if '## 目的' not in doc or '## 変更履歴' not in doc:
        raise ValueError('DESIGN.md must include 目的 and 変更履歴 headings')
    print(doc)
    print('\n--- HTMLから自動抽出した画面マップ（実装に基づく） ---')
    labels = {
        'q-model': '入力', 'q-text': '表示', 'q-show': '表示条件',
        'q-submit': 'フォーム操作', 'q-action': 'ボタン操作',
        'q-arg': '操作へ渡す値', 'q-each': '一覧データ',
    }
    for key, label in labels.items():
        values = sorted(parser.bindings.get(key, set()))
        if values:
            print(f'  {label} ({key}): {", ".join(values)}')
    if since:
        paths = [str(folder.relative_to(ROOT)), 'src/qaiuick.js', 'src/qaiuick.css']
        command = ['git', 'diff', '--stat', since, '--', *paths]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
        if result.returncode:
            raise ValueError(f'Cannot compare Git ref {since!r}: {result.stderr.strip()}')
        print(f'\n--- Gitによる実変更の統計（{since} との比較） ---')
        print(result.stdout.strip() or '追跡済みファイルに差分なし')
        print('※ 未追跡ファイルはGit diffに含まれません。設計メモは作業者による説明です。')


def main(argv=None):
    cli = ArgumentParser(description='Explain a qAIUIck screen and its Git changes')
    cli.add_argument('folder', help='Directory containing index.html and DESIGN.md')
    cli.add_argument('--since', help='Git ref to compare against (e.g. HEAD~1)')
    args = cli.parse_args(argv)
    try:
        describe(ROOT / args.folder, args.since)
        return 0
    except (ValueError, OSError) as error:
        print(error, file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
