"""qAIUIck Check: strict, zero-dependency HTML directive validator.

Usage: python3 tools/check.py examples/todo/index.html
This is a static guard, NOT a sanitizer, complete HTML validator, or security audit.
"""
from html.parser import HTMLParser
from pathlib import Path
import re
import sys

DIRECTIVES = {"q-text", "q-show", "q-model", "q-action", "q-arg", "q-each", "q-as", "q-submit"}
IDENT = r"[A-Za-z_$][A-Za-z0-9_$]*"
PATH = re.compile(rf"^{IDENT}(?:\.{IDENT})*$")
DISALLOWED_SEGMENTS = {"__proto__", "prototype", "constructor"}
EVENT_HANDLER = re.compile(r"^on[a-z]+$", re.IGNORECASE)


class Checker(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.errors = []
        self.seen_ids = set()

    def error_at(self, message):
        line, col = self.getpos()
        self.errors.append(f"{line}:{col + 1}: {message}")

    def check_path(self, name, value):
        if not value or len(value) > 200 or not PATH.fullmatch(value) or \
                len(value.split('.')) > 12 or any(s in DISALLOWED_SEGMENTS for s in value.split('.')):
            self.error_at(f"Invalid {name} binding: {value!r}")

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        for name, value in attrs.items():
            if name.startswith('q-') and name not in DIRECTIVES:
                self.error_at(f"Unknown directive {name}")
            if name in DIRECTIVES:
                self.check_path(name, value)
            if EVENT_HANDLER.fullmatch(name):
                self.error_at(f"Inline event handler not permitted: {name}")
            if name in ('href', 'src', 'action', 'formaction') and value and \
                    re.match(r"^\s*(javascript|data)\s*:", value, re.IGNORECASE):
                self.error_at(f"Unsafe URL scheme in {name}")
            if name == 'srcdoc':
                self.error_at("srcdoc is not allowed in generated HTML")
        if 'q-submit' in attrs and tag != 'form':
            self.error_at('q-submit must be placed on a <form>')
        if 'q-model' in attrs and tag not in ('input', 'select', 'textarea'):
            self.error_at('q-model must be placed on an input, select, or textarea')
        if 'q-each' in attrs and tag != 'template':
            self.error_at('q-each must be placed on a <template>')
        if 'q-as' in attrs and 'q-each' not in attrs:
            self.error_at('q-as requires q-each on the same <template>')
        if 'q-as' in attrs and '.' in (attrs['q-as'] or ''):
            self.error_at('q-as must be a single identifier')
        if 'q-arg' in attrs and 'q-action' not in attrs:
            self.error_at('q-arg requires q-action on the same element')
        if 'id' in attrs:
            if attrs['id'] in self.seen_ids:
                self.error_at(f"Duplicate id: {attrs['id']}")
            self.seen_ids.add(attrs['id'])


def check_file(path):
    parser = Checker()
    parser.feed(Path(path).read_text(encoding='utf-8'))
    parser.close()
    return parser.errors


def main(argv):
    if not argv:
        print('Usage: python3 tools/check.py file.html [file.html ...]', file=sys.stderr)
        return 2
    failures = 0
    for filename in argv:
        try:
            errors = check_file(filename)
        except (OSError, UnicodeError) as error:
            errors = [str(error)]
        if errors:
            failures += len(errors)
            for error in errors:
                print(f'{filename}:{error}', file=sys.stderr)
        else:
            print(f'PASS {filename}')
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
