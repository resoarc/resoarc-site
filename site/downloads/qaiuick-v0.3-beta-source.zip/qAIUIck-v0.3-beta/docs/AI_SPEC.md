# qAIUIck AI specification v0.2

**Goal:** readable, accessible, good-looking apps without a build step or dependencies. Keep the screen simple enough that humans can read the generated HTML.

## The shortest recipe

1. Link `src/qaiuick.css` and add `class="q-app"` to `<body>`.
2. Put page content in `<main class="q-page" id="app">`.
3. Use `<section class="q-panel">` for a card, `class="q-form"` for a responsive form, and standard `<label>`, `<input>`, `<button>`, `<table>`.
4. Use `createApp({ root, state, computed, actions })` from `src/qaiuick.js`.
5. Before generating code, read the demo's `DESIGN.md`. After changing code, update its change history with **what** and **why**.
6. Run the checks. Explain the result using `python3 tools/explain.py examples/<name>`.

**Start by copying [`examples/hello/index.html`](../examples/hello/index.html):** a working one-file, build-free application. Use `examples/todo` for localStorage and `examples/inventory` for optional local SQLite.

## HTML API (only these directives exist)

| Directive | Meaning | Example |
| --- | --- | --- |
| `q-model` | Bind an input/select/textarea to writable state | `<input q-model="name">` |
| `q-text` | Display plain text, never HTML | `<b q-text="count"></b>` |
| `q-show` | Show when the value is truthy | `<p q-show="empty">Empty</p>` |
| `q-submit` | Handle form submit, including Enter | `<form q-submit="add">` |
| `q-action` | Handle a button click | `<button q-action="remove">` |
| `q-arg` | Pass a field to the action | `<button q-action="remove" q-arg="item.id">` |
| `q-each` | Render a list using a template | `<template q-each="items" q-as="item">` |

All paths are dot-separated identifiers, **not JavaScript expressions**. `q-as` names the row object; `q-arg` passes row or state values. Nested `q-each` blocks are unsupported in v0.2. No `q-html`, `eval`, expressions, or untrusted HTML rendering.

## JavaScript API

```js
import { createApp } from '../../src/qaiuick.js';

const state = { name: '', items: [], error: '' };
const app = createApp({
  root: '#app',
  state,
  computed: {
    count: (s) => s.items.length,       // read-only display value
    empty: (s) => s.items.length === 0,
  },
  actions: {
    add(s) {
      if (!s.name.trim()) { s.error = 'Name is required'; return; }
      s.items.push({ id: crypto.randomUUID(), name: s.name.trim() });
      s.name = ''; s.error = '';
    },
    remove(s, { arg }) { s.items = s.items.filter((item) => item.id !== arg); },
  },
  onError(error) { state.error = error.message; app.render(); },
});
```

**How it works:** `q-model` writes to `state` and rerenders; actions receive `(state, { arg, event, app })` and rerender after completion (including async). `computed` functions calculate display-only values each render; they cannot have the same name as state properties. After external asynchronous writes, call `app.render()` explicitly. `app.set(path,value)` updates state and renders; `app.destroy()` unregisters listeners.

## Styling without style spaghetti

```html
<html data-q-theme="teal">
<body class="q-app">
  <main class="q-page">
    <header class="q-hero"><h1>My app</h1><p class="q-lead">Useful description</p></header>
    <section class="q-panel">
      <form q-submit="save" class="q-form">
        <label>Title <input q-model="title"></label>
        <button type="submit">Save</button>
      </form>
    </section>
  </main>
</body>
```

- Themes: violet (default), teal, rose; change **one HTML attribute**. Follows system dark mode by default. `data-q-mode="light"` or `"dark"` on `<html>` can force mode.
- Components: `.q-page`, `.q-topbar`, `.q-hero`, `.q-panel`, `.q-stack`, `.q-form`, `.q-row`, `.q-pill`, `.q-list`, `.q-empty`, `.q-table`, `.q-design-notes`.
- Under `.q-app`, inputs and buttons have styled defaults. Prefer semantic elements and the fewest classes needed.
- CSS tokens such as `--q-primary`, `--q-radius`, `--q-space`, and `--q-bg` are centralized in `src/qaiuick.css`.
- No external fonts, CDNs, images, network calls, or JS dependencies are required to style a screen.

## Storage

```js
import { createStore } from '../../src/store.js';
const store = createStore({ type: 'local', namespace: 'demo', resource: 'items' });
const rows = await store.list();
const saved = await store.save({ name: 'Sample' });
await store.remove(saved.id);
```

Store drivers: `memory`, `local` (browser localStorage), `remote` (HTTP API). `remote` uses same-origin REST `GET /api/items`, `GET /api/items/:id`, `POST /api/items`, `DELETE /api/items/:id`. Python SQLite sample is localhost-only and unauthenticated; it must not be publicly exposed. Browser localStorage is **not** a backup. Browser SQLite WASM, sync, migrations and production DB adapters are not implemented yet.

## Explain and verify AI changes

```sh
python3 tools/explain.py examples/todo                 # Intent + current bindings
python3 tools/explain.py examples/todo --since HEAD~1 # Git diff statistics too
python3 tools/check.py examples/hello/index.html examples/todo/index.html examples/inventory/index.html
npm test
python3 -m unittest discover -s tests -p 'test_*.py'
```

`DESIGN.md` records human/AI-authored intent and why changes were chosen. `tools/explain.py` separately scans **real HTML** for bindings and, optionally, reads **Git diffs**; it does not falsely claim to infer intent from code or prove who authored a change. A passed static check is not a security audit. Continue to test actual browser interactions and accessibility.
