"""qAIUIck optional SQLite API. Python standard library only, localhost by default.

Run from any working directory: python3 server/app.py
Open http://127.0.0.1:8765/examples/inventory/?db=sqlite
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import sqlite3
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, unquote
from uuid import uuid4

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get("QAIUICK_DB", str(ROOT / "server" / "data" / "inventory.sqlite")))
HOST = "127.0.0.1"  # Do not expose without authentication, authorization, and TLS.
PORT = int(os.environ.get("QAIUICK_PORT", "8765"))
MAX_BODY = 16_384
ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


def connect(path: Path = DB_PATH):
    connection = sqlite3.connect(path, timeout=5)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout=5000")
    return connection


def init_db(path: Path = DB_PATH):
    path.parent.mkdir(parents=True, exist_ok=True)
    with connect(path) as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""CREATE TABLE IF NOT EXISTS items (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity BETWEEN 0 AND 1000000),
            price INTEGER NOT NULL DEFAULT 0 CHECK(price BETWEEN 0 AND 1000000000)
        )""")


def validate_item(item):
    if not isinstance(item, dict):
        raise ValueError("Expected a JSON object")
    if set(item) - {"id", "name", "quantity", "price"}:
        raise ValueError("Unknown item field")
    name = item.get("name")
    quantity = item.get("quantity")
    price = item.get("price", 0)
    item_id = item.get("id") or uuid4().hex
    if not isinstance(name, str) or not name.strip() or len(name) > 120:
        raise ValueError("name must contain 1–120 characters")
    if type(quantity) is not int or not 0 <= quantity <= 1_000_000:
        raise ValueError("quantity must be an integer between 0 and 1000000")
    if type(price) is not int or not 0 <= price <= 1_000_000_000:
        raise ValueError("price must be a nonnegative integer")
    if not isinstance(item_id, str) or not ID_RE.fullmatch(item_id):
        raise ValueError("Invalid item id")
    return {"id": item_id, "name": name.strip(), "quantity": quantity, "price": price}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def item_id(self):
        path = urlsplit(self.path).path
        if path == "/api/items":
            return None
        if path.startswith("/api/items/"):
            value = unquote(path.removeprefix("/api/items/"))
            if ID_RE.fullmatch(value):
                return value
        raise ValueError("Unknown or invalid resource path")

    def do_GET(self):
        if not self.path.startswith("/api/"):
            # Serve only the demonstrator assets. Never expose .git, database files,
            # source maps, local secrets or any other repository content.
            target = Path(self.translate_path(self.path)).resolve()
            if target.is_relative_to(ROOT / "examples") or target.is_relative_to(ROOT / "src"):
                return super().do_GET()
            return self.send_json(404, {"error": "Not found"})
        try:
            item_id = self.item_id()
            with connect() as db:
                if item_id is None:
                    rows = db.execute("SELECT id, name, quantity, price FROM items ORDER BY rowid DESC").fetchall()
                    return self.send_json(200, [dict(row) for row in rows])
                row = db.execute("SELECT id, name, quantity, price FROM items WHERE id = ?", (item_id,)).fetchone()
                return self.send_json(200, dict(row)) if row else self.send_json(404, {"error": "Not found"})
        except (ValueError, sqlite3.Error) as exc:
            return self.send_json(400, {"error": str(exc)})

    def same_origin(self):
        origin = self.headers.get("Origin")
        if origin is None:
            return True
        # Exact origin comparison, no wildcard CORS. This is for local development only.
        return origin == f"http://{self.headers.get('Host')}" and self.headers.get('Host') in {
            f"127.0.0.1:{PORT}", f"localhost:{PORT}"
        }

    def do_POST(self):
        if not self.same_origin():
            return self.send_json(403, {"error": "Cross-origin writes are disabled"})
        try:
            if self.item_id() is not None:
                return self.send_json(404, {"error": "Unknown endpoint"})
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_BODY:
                return self.send_json(413, {"error": "Request body too large or empty"})
            if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                return self.send_json(415, {"error": "Use application/json"})
            record = validate_item(json.loads(self.rfile.read(length)))
            with connect() as db:
                db.execute("""INSERT INTO items (id,name,quantity,price) VALUES (:id,:name,:quantity,:price)
                    ON CONFLICT(id) DO UPDATE SET name=excluded.name,quantity=excluded.quantity,price=excluded.price""", record)
            return self.send_json(200, record)
        except (ValueError, json.JSONDecodeError) as exc:
            return self.send_json(400, {"error": str(exc)})
        except sqlite3.Error:
            return self.send_json(500, {"error": "Database error"})

    def do_DELETE(self):
        if not self.same_origin():
            return self.send_json(403, {"error": "Cross-origin writes are disabled"})
        try:
            item_id = self.item_id()
            if item_id is None:
                return self.send_json(405, {"error": "Specify an item id"})
            with connect() as db:
                result = db.execute("DELETE FROM items WHERE id = ?", (item_id,))
            return self.send_json(200, {"deleted": result.rowcount > 0})
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        except sqlite3.Error:
            return self.send_json(500, {"error": "Database error"})

    def do_OPTIONS(self):
        return self.send_json(405, {"error": "No CORS access"})


def main():
    init_db()
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"qAIUIck SQLite demo: http://{HOST}:{PORT}/examples/inventory/?db=sqlite", flush=True)
    print(f"SQLite file: {DB_PATH}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
