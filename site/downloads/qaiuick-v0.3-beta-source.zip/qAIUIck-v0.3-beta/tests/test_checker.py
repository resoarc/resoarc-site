import sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from check import Checker, check_file  # noqa: E402


class CheckerTests(unittest.TestCase):
    def test_existing_demos_pass(self):
        root = Path(__file__).resolve().parents[1]
        for name in ('hello', 'todo', 'inventory'):
            self.assertEqual(check_file(root / 'examples' / name / 'index.html'), [])

    def test_unknown_and_unsafe_directives(self):
        parser = Checker()
        parser.feed('<div q-html="foo" onclick="bad()"><template q-each="items.map(x)"><a href="javascript:alert(1)">x</a></template></div>')
        self.assertGreaterEqual(len(parser.errors), 4)

    def test_submit_and_model_require_semantic_elements(self):
        parser = Checker()
        parser.feed('<div q-submit="save"></div><div q-model="field"></div>')
        self.assertEqual(len(parser.errors), 2)

    def test_submit_form_is_allowed(self):
        parser = Checker()
        parser.feed('<form q-submit="add"><label>Name<input q-model="name"></label></form>')
        self.assertEqual(parser.errors, [])


if __name__ == '__main__':
    unittest.main()
