import test from 'node:test';
import assert from 'node:assert/strict';
import { pathSegments, getPath, setPath, createApp } from '../src/qaiuick.js';
import { createStore } from '../src/store.js';

test('safe path reads and writes explicit state properties', () => {
  const obj = { account: { balance: 10 } };
  assert.equal(getPath(obj, 'account.balance'), 10);
  assert.equal(setPath(obj, 'account.balance', 15), 15);
  assert.equal(obj.account.balance, 15);
  assert.equal(getPath(obj, 'account.absent'), undefined);
  assert.deepEqual(pathSegments('item.name'), ['item', 'name']);
});

test('rejects unsafe and executable binding syntax', () => {
  for (const path of ['__proto__.x', 'item.constructor', 'a[b]', 'a || evil()', 'x.y()', '', 'a..b', 'toString']) {
    if (path === 'toString') {
      assert.equal(getPath({}, path), undefined);
    } else {
      assert.throws(() => pathSegments(path));
    }
  }
  assert.throws(() => setPath({}, '__proto__.polluted', true));
  assert.equal({}.polluted, undefined);
});

test('CRUD in local storage persists across store instances', async () => {
  const data = new Map();
  const storage = { getItem: (k) => data.get(k) ?? null, setItem: (k, v) => data.set(k, v) };
  const first = createStore({ storage, namespace: 'test' });
  const saved = await first.save({ title: '<img src=x onerror=alert(1)>' });
  assert.ok(saved.id);
  assert.equal((await createStore({ storage, namespace: 'test' }).get(saved.id)).title, saved.title);
  await first.save({ ...saved, title: 'Updated' });
  assert.equal((await first.list()).length, 1);
  await first.remove(saved.id);
  assert.deepEqual(await first.list(), []);
});

test('in-memory store is isolated and validates resource names', async () => {
  const store = createStore({ type: 'memory' });
  await store.save({ id: 'one', name: 'A' });
  const rows = await store.list(); rows[0].name = 'mutated';
  assert.equal((await store.get('one')).name, 'A');
  assert.deepEqual(await createStore({ type: 'memory' }).list(), []);
  assert.throws(() => createStore({ resource: '../unsafe' }));
});

test('DOM app refuses non-browser runtime', () => {
  assert.throws(() => createApp({}), /browser DOM/);
});

test('computed must be a well-defined mapping (browser required for mount)', () => {
  assert.throws(() => pathSegments('items.length()'));
  assert.deepEqual(pathSegments('count'), ['count']);
});
