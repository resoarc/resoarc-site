import contextlib
from io import StringIO
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from explain import MapParser, describe  # noqa: E402


class ExplainTests(unittest.TestCase):
    def test_detects_real_bindings(self):
        parser = MapParser()
        parser.feed('<form q-submit="add"><input q-model="draft"><p q-text="count"></p></form>')
        self.assertEqual(parser.bindings['q-model'], {'draft'})
        self.assertEqual(parser.bindings['q-submit'], {'add'})
        self.assertEqual(parser.bindings['q-text'], {'count'})

    def test_all_examples_have_design_docs_and_live_map(self):
        root = Path(__file__).resolve().parents[1]
        for example in ('hello', 'todo', 'inventory'):
            with self.subTest(example=example), contextlib.redirect_stdout(StringIO()) as out:
                describe(root / 'examples' / example)
                self.assertIn('HTMLから自動抽出', out.getvalue())
                self.assertIn('変更履歴', out.getvalue())

    def test_outside_project_rejected(self):
        with self.assertRaises(ValueError):
            describe(Path('/tmp'))


if __name__ == '__main__':
    unittest.main()
