"""Optional Chromium smoke tests without browser network access.

The same HTML, JS and CSS files are loaded into an in-memory browser document.
SQLite REST storage is tested independently with urllib against a local server.
Requires `pip install playwright` plus Chromium; NOT required by the framework.
"""
from pathlib import Path
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError

try:
    from playwright.sync_api import sync_playwright
except ImportError as e:
    raise SystemExit('Optional browser test requires playwright: pip install playwright') from e

ROOT = Path(__file__).resolve().parents[1]
BROWSER = '/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None
EXPORT = re.compile(r'^export\s+', re.MULTILINE)
IMPORT = re.compile(r'^[ \t]*import[^\n]*;[ \t]*$', re.MULTILINE)
SCRIPT = re.compile(r'<script\b[^>]*>.*?</script>', re.DOTALL | re.IGNORECASE)


def load_demo(page, name):
    """Load exact source into a sandboxed in-memory DOM; no fake app logic."""
    html = (ROOT / 'examples' / name / 'index.html').read_text(encoding='utf-8')
    inline = ''
    if name == 'hello':
        inline = re.search(r'<script type="module">(.*?)</script>', html, re.DOTALL).group(1)
    page.set_content(SCRIPT.sub('', html))
    page.add_style_tag(content=(ROOT / 'src/qaiuick.css').read_text(encoding='utf-8'))
    page.evaluate('''() => {
      window.__qdata = window.__qdata || new Map();
      Object.defineProperty(window, 'localStorage', {
        configurable: true,
        value: {
          getItem: (key) => window.__qdata.get(key) ?? null,
          setItem: (key, value) => window.__qdata.set(key, String(value)),
        },
      });
    }''')
    core = EXPORT.sub('', (ROOT / 'src/qaiuick.js').read_text(encoding='utf-8'))
    store = EXPORT.sub('', (ROOT / 'src/store.js').read_text(encoding='utf-8'))
    js = inline if name == 'hello' else (ROOT / 'examples' / name / 'main.js').read_text(encoding='utf-8')
    js = IMPORT.sub('', js)
    js = re.sub(r'^\s*//.*$', '', js, flags=re.MULTILINE)
    page.add_script_tag(content='{\n' + core + '\n' + store + '\n(async () => {\n' + js + '\n})().catch(console.error);\n}')


def test_dom(playwright):
    browser = playwright.chromium.launch(headless=True,
        **({'executable_path': BROWSER} if BROWSER else {}), args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1280, 'height': 840}, device_scale_factor=1)
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))

    load_demo(page, 'hello')
    page.get_by_role('textbox', name='名前').fill('AIと人間')
    assert 'AIと人間さん' in page.locator('h2').inner_text()
    page.get_by_role('button', name='名前をリセット').click()
    assert '世界さん' in page.locator('h2').inner_text()
    assert page.evaluate('getComputedStyle(document.querySelector(".q-panel")).borderRadius') == '18px'
    print('HELLO_REACTIVE_THEME_STYLE_OK')

    load_demo(page, 'todo')
    field = page.get_by_role('textbox', name='新しいメモ')
    field.fill('<img src=x onerror=alert(1)>')
    field.press('Enter')  # q-submit handles Enter, preventing navigation
    page.locator('.q-list li').first.wait_for()
    assert page.locator('.q-list li').count() == 1
    assert page.locator('img').count() == 0
    assert page.locator('.q-list li [q-text="item.title"]').inner_text() == '<img src=x onerror=alert(1)>'
    assert page.locator('[q-text="count"]').inner_text() == '1'
    load_demo(page, 'todo')  # in-memory storage survives; mirrors page reload
    page.locator('.q-list li').first.wait_for()
    assert page.locator('.q-list li').count() == 1
    page.get_by_role('button', name='メモを削除').click()
    assert page.locator('.q-list li').count() == 0
    assert page.get_by_text('まだメモはありません。').is_visible()
    print('TODO_ENTER_PERSISTENCE_XSS_EMPTY_OK')

    load_demo(page, 'inventory')
    page.get_by_role('textbox', name='品目名').fill('鉛筆')
    page.get_by_role('spinbutton', name='数量').fill('7')
    page.get_by_role('button', name='品目を追加').click()
    page.get_by_text('鉛筆', exact=True).wait_for()
    assert page.locator('tbody tr').count() == 1
    load_demo(page, 'inventory')
    page.get_by_text('鉛筆', exact=True).wait_for()
    assert page.locator('tbody tr').count() == 1
    page.get_by_role('button', name='削除').click()
    assert page.locator('tbody tr').count() == 0
    assert page.get_by_text('在庫はまだありません。').is_visible()
    print('INVENTORY_BROWSER_PERSISTENCE_DELETE_OK')

    desktop = ROOT.parent / 'qAIUIck-v0.2-preview.png'
    page.wait_for_timeout(300)  # Wait for CSS transitions to settle before capturing.
    page.screenshot(path=str(desktop), full_page=True)
    print(f'DESKTOP_SCREENSHOT={desktop}')
    mobile = browser.new_page(viewport={'width': 390, 'height': 844}, device_scale_factor=1)
    mobile_errors = []
    mobile.on('pageerror', lambda e: mobile_errors.append(str(e)))
    load_demo(mobile, 'todo')
    assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth'), 'Mobile horizontal overflow'
    mobile_file = ROOT.parent / 'qAIUIck-v0.2-mobile.png'
    mobile.wait_for_timeout(300)
    mobile.screenshot(path=str(mobile_file), full_page=True)
    print(f'MOBILE_SCREENSHOT={mobile_file}')
    assert not errors and not mobile_errors, [*errors, *mobile_errors]
    browser.close()
    print('ALL_DOM_BROWSER_CHECKS_PASSED')


def port_available():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def test_sqlite_api():
    with tempfile.TemporaryDirectory(prefix='qaiuick-sqlite-test-') as temp:
        port = port_available()
        path = Path(temp) / 'test.sqlite'
        env = {**os.environ, 'QAIUICK_PORT': str(port), 'QAIUICK_DB': str(path)}
        process = subprocess.Popen([sys.executable, 'server/app.py'], cwd=ROOT, env=env,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            base = f'http://127.0.0.1:{port}'
            for _ in range(50):
                try:
                    with urlopen(base + '/api/items', timeout=.4):
                        break
                except OSError:
                    time.sleep(.1)
            else:
                raise RuntimeError('SQLite demo server was not ready')
            payload = json.dumps({'name': '鉛筆', 'quantity': 7}).encode()
            req = Request(base + '/api/items', method='POST', data=payload,
                          headers={'Content-Type': 'application/json'})
            with urlopen(req, timeout=3) as response:
                saved = json.load(response)
            assert saved['quantity'] == 7
            with urlopen(base + '/api/items', timeout=3) as response:
                assert len(json.load(response)) == 1
            req = Request(base + '/api/items/' + saved['id'], method='DELETE')
            with urlopen(req, timeout=3) as response:
                assert json.load(response)['deleted']
            with urlopen(base + '/api/items', timeout=3) as response:
                assert json.load(response) == []
            for forbidden in ('/server/data/inventory.sqlite', '/.git/config'):
                try:
                    urlopen(base + forbidden, timeout=3)
                except HTTPError as error:
                    assert error.code == 404
                else:
                    raise AssertionError(f'Secret file exposed: {forbidden}')
            assert path.exists(), 'SQLite file was not created'
            print('REAL_SQLITE_API_AND_PROTECTED_FILES_OK')
        finally:
            process.terminate()
            try: process.wait(timeout=4)
            except subprocess.TimeoutExpired: process.kill()


if __name__ == '__main__':
    with sync_playwright() as playwright:
        test_dom(playwright)
    test_sqlite_api()
    print('ALL_BROWSER_AND_SQLITE_CHECKS_PASSED')
