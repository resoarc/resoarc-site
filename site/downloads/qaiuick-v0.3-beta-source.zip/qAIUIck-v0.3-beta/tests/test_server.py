"""Dependency-free SQLite integration unit tests."""
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'server'))
from app import init_db, connect, validate_item  # noqa: E402


class TestSQLite(unittest.TestCase):
    def test_validate_data(self):
        row = validate_item({'name': 'えんぴつ', 'quantity': 3})
        self.assertEqual(row['name'], 'えんぴつ')
        self.assertEqual(row['quantity'], 3)
        self.assertEqual(row['price'], 0)
        with self.assertRaises(ValueError):
            validate_item({'name': 'Bad', 'quantity': True})
        with self.assertRaises(ValueError):
            validate_item({'name': 'Bad', 'quantity': -1})
        with self.assertRaises(ValueError):
            validate_item({'name': 'Bad', 'quantity': 5, 'admin': True})

    def test_real_sqlite_file_roundtrip(self):
        with TemporaryDirectory() as temp:
            path = Path(temp) / 'app.sqlite'
            init_db(path)
            row = validate_item({'name': 'pens', 'quantity': 8})
            with connect(path) as db:
                db.execute('INSERT INTO items(id,name,quantity,price) VALUES (:id,:name,:quantity,:price)', row)
            with connect(path) as db:
                got = db.execute('SELECT name, quantity FROM items WHERE id=?', (row['id'],)).fetchone()
            self.assertEqual((got['name'], got['quantity']), ('pens', 8))
            self.assertTrue(path.is_file())


if __name__ == '__main__':
    unittest.main()
