import { defineApp } from '../../src/define.js';
import { spec } from './spec.js';
defineApp({ ...spec, baseline: './baseline.json' });
