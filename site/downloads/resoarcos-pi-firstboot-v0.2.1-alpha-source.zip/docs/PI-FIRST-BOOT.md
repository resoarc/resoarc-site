# ResoArcOS Raspberry Pi 4/5 SD-card first-boot acceptance checklist

**Status:** experimental hardware-test image, not a production release.

## Before inserting the SD card

1. Use a spare microSD card with **8 GB or more** free capacity (16 GB+ recommended). Back up anything on the card: imaging erases it.
2. Connect HDMI and a USB keyboard to the Raspberry Pi 4 or 5. Use a suitable official/reliable power supply.
3. Open Raspberry Pi Imager on a PC. Choose **Use custom**, select the appropriate `resoarcos-pi4-arm64.img` or `resoarcos-pi5-arm64.img` from the verified candidate folder, and carefully select the removable microSD device.
4. Complete the write and Imager's read-back verification before inserting the card into the Pi.

## First boot

The root partition expansion service should run before the tty1 wizard. A console prompt should then ask for:

- Device name, timezone
- A **new administrator password (12 characters minimum)**
- Optional Wi-Fi SSID and password (leave empty for Ethernet)
- Optional SSH public key
- Explicit SSH password-login choice

The image has no default login password, and SSH is initially disabled.
A first-boot setup marker is written only after successful provisioning.

## After first boot

Log in as `resoarc` and inspect the following:

```sh
resoarc status
findmnt -n -o SOURCE /
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS
df -h /
systemctl status resoarc-grow-root.service --no-pager
test -e /var/lib/resoarc/root-grow-complete && echo "Root grow marked complete"
systemctl is-enabled ssh.service
```

On a card larger than the original image, the root partition and ext4 filesystem should have grown beyond 4 GiB. If not, capture:

```sh
sudo journalctl -u resoarc-grow-root.service -b --no-pager
```

Do not run destructive partition commands manually on the card while troubleshooting.

## Optional browser status page

At the Pi's normal non-root shell, run `resoarc-web`. It prints a one-time password and listens on **127.0.0.1:8765 only**.

From a separate PC on the same network, if SSH was enabled during setup:

```sh
ssh -L 8765:127.0.0.1:8765 resoarc@<PI_IP>
```

Open `http://127.0.0.1:8765/` on the PC. Authenticate with username `resoarc` and the one-time dashboard password printed on the Pi. This is read-only, not a remote setup portal.

## Acceptance gates

- [ ] Raspberry Pi firmware boots the custom IMG without an error
- [ ] First-boot wizard appears without a factory password
- [ ] Wrong passwords are rejected; successful setup returns to login
- [ ] Reboot does not repeat setup
- [ ] SD root filesystem expands to the card capacity
- [ ] Ethernet or configured Wi-Fi connects
- [ ] SSH only accepts the authentication method explicitly selected
- [ ] Local browser dashboard is accessible through SSH tunnel
- [ ] Reboot and power-loss recovery checked

**Do not mark hardware verified until these items are actually observed.**
