# ResoArcOS Raspberry Pi grow-v1 candidate QA

Updated: 2026-10-16 JST. Status: **Pi 5 candidate recovered and structurally verified; Pi 4 build pending; real hardware untested**.

## Changes

- New first-boot `resoarc-grow-root.service` runs before tty1 setup and attempts to grow partition 2 and ext4.
- Root device is resolved through the Linux kernel major:minor sysfs mapping, supporting microSD (`mmcblkXp2`) and NVMe (`nvmeXnYp2`).
- `growpart` NOCHANGE is accepted when the SD is already fully allocated.
- Completion marker is written only after successful `resize2fs`.
- `resoarc-web` provides a read-only localhost-only dashboard with a random session password, available after first-boot provisioning.
- New IMG outputs are isolated in `out/pi-images-grow-v1` and cannot overwrite previously verified `out/pi-images` artifacts.

## Source and mock checks

- Python unit suite: **33 tests passed or skipped as expected** on Debian/Python 3.13 (32 passed, 1 optional zstandard test skipped). The two archive tests also passed on Windows Python with zstandard installed.
- Pi 4 and Pi 5 mock layer composition: **PASS**.
- Bash script syntax: **PASS**.
- PowerShell build/verify scripts parsed without syntax errors.

## Offline simulated 8 GiB SD expansion

Tested using the **previous verified Pi 5 IMG**, copied into a disposable sparse 8 GiB disk file inside Docker. No physical SD, Windows disk, or original IMG was changed.

- `growpart` changed MBR partition 2 from **8,388,608 sectors** to **15,712,223 sectors**.
- `resize2fs` increased ext4 from **262,112 blocks** to **491,006 blocks** (16 KiB per block).
- Result: **PASS** for the original Pi 5 IMG and **PASS again for the new grow-v1 Pi 5 IMG**. The original Pi 4 IMG also passed the 8 GiB expansion simulation, growing ext4 from **1,048,576 to 1,964,027 blocks** (4 KiB per block). These tests validate the actual Pi 4 and Pi 5 image layouts, but **not** the new systemd first-boot unit running on real Pi hardware.

## Release gates remaining

- [x] Pi 5 grow-v1 IMG recovered, SHA-256 matches, and strict ext4 layer verification passes (upstream builder exited 2 after deployment due to Windows bind-mount read error)
- [x] Pi 5 grow-v1 compressed archive SHA-256 matches, and streaming decompression matches the raw IMG SHA-256 (336,161,258 bytes compressed)
- [x] Pi 5 grow-v1 disposable 8 GiB SD root expansion test passes
- [ ] Pi 4 grow-v1 candidate build exit 0 and strict verification passes
- [ ] Verify root-grow service is enabled in both completed images
- [ ] Real Pi 4/5 boot and first-boot console setup
- [ ] Online expansion and restart behavior on physical microSD
- [ ] Read-only browser dashboard over SSH tunnel on physical Pi

## Pi 5 recovery and prevention

The first grow-v1 Pi 5 builder completed image creation and deploy, then exited 2
with `/repo/images/pi/build.sh: error reading input file: No data available`.
The generated raw IMG and Zstandard archive were recovered from the **stopped**
container without rebuilding. The recovered Pi 5 raw IMG passed SHA-256,
MBR/FAT/ext4 boot-layout checks, locked-account checks, SSH host-key absence,
root-grow service checks and dashboard installation checks.

Recovered Pi 5 raw IMG SHA-256:
`bc67a73d23e3217e93a461259afd5352a7363e81b9c36c1cb385a28650f775f9`

The Windows bind-mount read error is consistent with source-file changes during
a long-running Bash script. The builder now snapshots its own wrapper and the
entire ResoArcOS source into the Linux container before launching the ARM64
build. The Pi 4 grow-v1 build is intended to use this corrected method.

The sequential build job verifies Pi 5 and then builds/verifies Pi 4.
Completion is not claimed until its `ACCEPTANCE.txt` file is present and checked.
