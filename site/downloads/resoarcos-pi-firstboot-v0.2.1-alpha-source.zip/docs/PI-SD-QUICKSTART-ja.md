# ResoArcOS Raspberry Pi版：SDカードから初回セットアップ

> **開発・試験版です。** IMG内部の構造検証は実施していますが、Raspberry Pi実機での起動確認はまだ完了していません。

## 準備

- Raspberry Pi 4 または Raspberry Pi 5（対応するIMGを選択）
- 空のmicroSDカード（16GB以上推奨、書き込み時に全データ消去）
- 対応電源、HDMIディスプレイ、USBキーボード
- Windows PCと **Raspberry Pi Imager**（未導入なら公式サイトから入手）
- Ethernetケーブル、または接続先Wi-FiのSSIDとパスワード

## 1. WindowsでSDカードに書き込む

検証済みの候補ファイルは以下にあります。

```text
C:\Users\zin\Documents\GitHub\resoarc-os\out\pi-images-grow-v1\
  resoarcos-pi5-arm64.img     ← Raspberry Pi 5用
  resoarcos-pi4-arm64.img     ← Raspberry Pi 4用（生成・検証完了後）
```

WindowsのPowerShellから次のコマンドを実行すると、IMGのSHA-256と起動構造を検証してからファイルの場所を開き、Imagerが導入済みなら起動します。**このスクリプト自体はSDカードへ書き込みません。**

```powershell
.\scripts\open-pi-imager.ps1 -Model 5
```

1. Raspberry Pi Imagerを開く。
2. デバイスに手元のPiモデルを選択。
3. OSの選択から **カスタムイメージ** を選び、対応する `.img` を指定。
4. 書き込み先microSDカードを選ぶ。**他のUSBドライブやPC内蔵ディスクを選ばないこと。**
5. 書き込みと読み戻し検証を完了させる。

`.img.zst` は保管用の圧縮ファイルです。書き込みには展開済みの `.img` を使ってください。

## 2. Piに挿して起動

microSDをPiに挿入し、HDMIとキーボードを接続して電源を入れます。正常に起動すると、**ログイン前にResoArcOSの初回セットアップ画面**が表示される設計です。

画面で次を入力します。

1. **デバイス名**：初期値 `resoarcos`。
2. **タイムゾーン**：日本なら `Asia/Tokyo`。
3. **管理者パスワード**：12文字以上。初期パスワードは存在しません。
4. **Wi-Fi**：Ethernetを使うなら空欄。Wi-Fiの場合はSSIDとパスワード。
5. **SSH公開鍵**：任意。公開鍵を設定しない場合はSSHパスワードログインを明示的に許可。
6. セットアップが完了すると、`resoarc` ユーザーでログイン可能になります。

初回起動時には、SDカード容量に合わせてルートパーティションを拡張するサービスも実行されます。実機での動作は要確認です。

## 3. 初回起動後の確認

```sh
resoarc status
df -h /
systemctl status resoarc-grow-root.service --no-pager
```

GUIを必要な時だけ起動する場合は、Pi本体のコンソールで `resogui` を実行します。通常はGUIを起動しない軽量構成です。

## 4. ブラウザ管理画面（読み取り専用）

Pi本体で `resoarc-web` を実行すると、画面にランダムな認証パスワードが表示されます。管理画面はPiのローカルループバックでのみ待ち受けます。

別のPCから接続する場合、SSHを有効にした上で次のようにトンネルを作成します。

```sh
ssh -L 8765:127.0.0.1:8765 resoarc@<PiのIPアドレス>
```

PCのブラウザで `http://127.0.0.1:8765/` を開き、ユーザー名 `resoarc` と、Pi側に表示されたパスワードで認証します。

**現状の制約**：初回セットアップはHDMI＋USBキーボードを前提としています。Wi-Fiアクセスポイント型のヘッドレス初期設定や、ブラウザ上での設定変更はまだ実装していません。実機での動作確認が終わるまでは、重要な用途に使わないでください。
