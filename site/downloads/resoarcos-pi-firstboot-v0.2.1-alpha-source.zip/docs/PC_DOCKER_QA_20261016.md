# ResoArcOS PC edition: Docker/QEMU verification, 2026-10-16

## Tested environment

Windows main PC running Docker Desktop 28.4.0 (Linux containers). Debian 13 (trixie) image built with live-build in a fresh Docker-native Linux volume. No host disk partition or boot configuration was altered.

## Final candidate

- ISO: `out/resoarcos-isolated-v3-amd64.iso`
- Size: 611,319,808 bytes (583 MiB)
- SHA-256: `562ad77b607bb0fe8ae31d4fd935141249cb16cf62b06d9aa7071297503a45d6`
- Digest manifest: `out/resoarcos-isolated-v3-amd64.iso.sha256`
- Build container and volume: `resoarcos-iso-isolated-v3`, exited 0
- Verification: `scripts/verify-iso.sh`, exit 0, `RESOARC_ISO_CHECK_PASS`
- Python management file permissions: `0644`; launchers: `0755`
- CLI launcher explicitly uses Python isolated mode (`-I`) and adds only `/usr/local/lib`.

## What was tested

| Check | Result | Meaning |
|---|---|---|
| Docker Debian 13 package build | PASS | Live ISO was generated with exit code 0 |
| ISO kernel/initrd/SquashFS inspection | PASS | Valid payload and expected files found |
| Security-sensitive file modes | PASS | World-writable application code rejected by independent verification |
| Isolated Python launcher | PASS | Deliberate hostile CWD/PYTHONPATH Python package not loaded in test container |
| CLI/unit and state transition tests | PASS | 14 Python unit tests in Debian-based Linux container |
| QEMU direct-kernel smoke | PASS | Multi-user target and `resoarcos login:` reached with final ISO |
| Normal virtual-CD-ROM BIOS boot | PASS for menu and Linux boot startup | Console framebuffer went black later; GUI/login picture not verified |
| UEFI firmware boot | Boot menu observed on previous validated ISO | Full UEFI guest-login and GUI checks pending |
| Openbox desktop and `resogui` | INCONCLUSIVE | Headless QEMU test-only root TTY accepted `resogui`, then VGA showed black screen/cursor; an unprivileged local-session GUI was not proven |
| Disk installation and persistence | NOT IMPLEMENTED | ISO is live environment only |

On the final ISO, the BIOS virtual-CD-ROM test displayed the boot menu and Linux initialization, but the late VGA screenshot was black. Serial login success belongs to the direct-kernel test and must not be used to claim GUI success.\n\nThe QEMU direct-kernel test extracts the kernel and initramfs from the *ISO*. It skips the firmware boot path; its success must not be described as a full BIOS/UEFI proof. For firmware boot, `scripts/qemu-media-smoke.sh` loads the ISO as a virtual CD-ROM.

## Rejected development builds

- `out/resoarcos-amd64-unsafe-permissions-test-only.iso`: 0777 code/config permissions, deliberately rejected.
- `out/resoarcos-amd64-cli-unisolated-test-only.iso`: management entry point inherited caller Python import paths, deliberately rejected.
- Reusing a partially cleaned live-build workspace dropped `chroot/boot/vmlinuz-*`; fresh named volumes resolved this.

**The two rejected ISOs must never be redistributed as ResoArcOS releases.**

## Repeat checks

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/test-pc-docker.ps1
docker inspect resoarcos-iso-isolated-v3 --format '{{.State.ExitCode}}'
Get-FileHash out/resoarcos-isolated-v3-amd64.iso -Algorithm SHA256
```

An extra test-only QEMU boot using `systemd.debug-shell=1` provided a root shell on virtual TTY9, with no guest network attached. The `resogui` invocation was sent and VGA became a black screen with a cursor rather than a visible Openbox desktop. This test is NOT evidence of a working GUI, nor does it prove failure for a normal non-root login. The debug-shell flag was not added to release media. The QEMU test container was stopped after inspection to avoid continuing PC CPU usage.\n\nFurther validation: `resogui` refuses SSH and piped non-interactive execution; its shell/TTY guard has an independent Linux unit test.\n\nFuture work: test GUI from an actual local TTY, add unattended BIOS/UEFI boot-to-login checks, implement image signing and a proper install/update/recovery design. Do not claim production readiness yet.