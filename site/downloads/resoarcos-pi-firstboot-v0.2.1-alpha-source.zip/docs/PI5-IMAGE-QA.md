# ResoArcOS Raspberry Pi 5: IMG acceptance record

Date: 2026-10-16 JST. Status: **SD-card test candidate; NOT hardware-boot verified**.

## Built artifact (local only)

- Path: `out/pi-images/resoarcos-pi5-arm64.img`
- Exact length: **4,840,226,816 bytes**
- SHA-256: `d6fcc71ae97f486520dfa35ea2267ed24af87762f3021212960021d51e20abb4`
- Raw image produced by Raspberry Pi's `rpi-image-gen` from Debian 13 Trixie packages for Raspberry Pi 5 ARM64.
- Compressed: `resoarcos-pi5-arm64.img.zst` and `resoarcos-pi5-arm64.img.zstd` (identical bytes, **335,798,029 bytes**, SHA-256 `4e7d3551dfa62ac496d95ee92fb570dd9ba2ed740f84a17735826fdc417c3ce3`).
- All files are retained on the main development PC. These are not downloadable from public GitHub or a website yet.

## Completed verification

1. Official image generator's build exited 0.
2. Windows hash of exported IMG matches checksum produced in Linux container.
3. Partition 1: MBR type 0x0C FAT32, LBA 16,384, size 512 MiB.
4. Partition 2: MBR type 0x83 Linux ext4, LBA 1,064,960, size 4 GiB.
5. Image contains Pi 5 boot files `config.txt`, `cmdline.txt`, `kernel_2712.img`, and `bcm2712-rpi-5-b.dtb`.
6. Direct, read-only `debugfs` inspection of the **built ext4 image**, not merely the source overlay: `resoarc` executable, console setup launcher, first-boot module, getty override, SSH daemon, and release file exist.
7. Initial `resoarc` password hash is locked; no completion marker; no enabled `ssh.service` or `ssh.socket` service symlinks before provisioning.
8. `scripts/verify-pi-release.ps1 -Model 5` passed. All 28 Python unit/staging tests passed in Debian Python 3.13.
9. Original upstream build logs and Docker container retained for inspection.

## Unverified or incomplete

- Raspberry Pi 5 EEPROM/firmware boot, actual display, keyboard, getty interactivity and physical login.
- Real Wi-Fi association, local timezone and SSH after setup.
- Whether the root partition expands beyond its initial **4 GiB**. No automatic expansion claim.
- GUI usability on Raspberry Pi, power interruption recovery, signed OTA rollback or Secure Boot.
- Raspberry Pi 4 needs its own separately generated image and hardware test.

## Flash acceptance

Use a **spare** microSD (at least 8 GB), HDMI display and USB keyboard, Raspberry Pi Imager's **Use custom** option, and select the `.img`. Confirm the actual removable target disk; imaging destroys its previous contents. After powering on, confirm the one-time wizard starts and creates a new 12+ character admin password, then verify reboot shows a normal login prompt and SSH remains protected.

Do not call this production-ready until these real-device checks pass.
