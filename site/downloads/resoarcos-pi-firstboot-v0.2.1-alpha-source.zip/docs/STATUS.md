# ResoArcOS 0.1 test and delivery matrix

Checked on 2026-10-16.

| Component | State | Evidence / next requirement |
|---|---|---|
| CLI and profile plan | PASS on Windows | Python unit tests |
| Local state write/read | PASS on Windows | Unit tests with temporary state directory |
| Image filesystem overlay staging | PASS on Windows | Stage tests and generated file checks |
| Pi 4 build recipe | PASS, mocked | Fake image generator checks config and payload; needs real ARM64 IMG |
| Pi 5 build recipe | PASS, mocked | Fake image generator checks config and payload; needs real ARM64 IMG |
| PC ISO recipe | Syntax verified | Corrected for Debian 13 live-build CLI; requires real builder |
| PC ISO artifact | NOT BUILT | Build on Debian/CI, verify SHA256, inspect with xorriso |
| PC boot | NOT TESTED | QEMU with virtual graphics + console login |
| Pi 4 real boot | NOT TESTED | SD/SSD boot on actual Pi 4 |
| Pi 5 real boot | NOT TESTED | SD/SSD boot on actual Pi 5 |
| Minimal desktop | NOT TESTED | Launch resogui on local TTY on PC/Pi |
| Auto rollback | NOT IMPLEMENTED | Separate OS update and snapshot design |
| Remote Web UI | NOT IMPLEMENTED | Secure auth, network exposure review and threat model |

The local Windows machine has Python, git and Git Bash, but no running Linux Docker engine or standalone Debian WSL distro. Do not silently start Docker, alter boot configuration or deploy an OS to the host machine. The source repository is local and intentionally not attached to the user's personal public GitHub account.
