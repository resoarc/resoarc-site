# PC edition (Debian 13 amd64 live ISO)

ResoArcOS 0.1-dev is a **live environment**. This does not install over the host drive or provide persistent storage by default. Boot-test the ISO in a disposable VM before flashing any USB drive.

## Docker Desktop on the Windows main PC

Use Docker Desktop in Linux containers mode. The build uses Debian 13 (`trixie`), `live-build` and a **Docker-native named volume** for the writable build tree. A direct bind mount into a Windows filesystem failed during Debian's `debootstrap` extraction and must not be used as the rootfs workspace.

```powershell
cd C:\path\to\resoarc-os
docker build --pull=false -t resoarcos-live-builder:local -f images/pc/Dockerfile.build .
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/test-pc-docker.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/build-pc-docker.ps1
docker logs --tail 40 resoarcos-iso-nativefs
docker inspect -f '{{.State.ExitCode}}' resoarcos-iso-nativefs
```

The ISO build container is limited to 4 CPUs, 6 GiB of memory and 512 processes. It uses `--privileged` because Debian live-build mounts filesystems/chroots within Docker. Only the ResoArcOS source directory is bound from Windows, **read-only**. No Windows system disk or Docker engine socket is bind-mounted. Be aware that privileged mode still grants extensive capabilities *inside the Docker Linux VM*.

If the build succeeds, inspect the actual ISO filename before copying it out:

```powershell
docker exec resoarcos-iso-nativefs sh -lc 'ls -lah /work/out/pc-build/*.iso'
docker cp resoarcos-iso-nativefs:/work/out/pc-build/resoarcos-amd64-amd64.hybrid.iso .\out\
```

The example filename may differ; use the actual output. The Docker volume and build containers are deliberately retained until results have been inspected, to avoid losing failed-build evidence. Cleanup requires a separate deliberate action.

## Building on native Debian

On a Debian 13 build machine:

```sh
sudo apt-get update
sudo apt-get install -y live-build python3 debootstrap xorriso
bash images/pc/build.sh
```

The generated ISO contains an optional Openbox-based minimal desktop that must be started from a local TTY with `resogui`. Real desktop behavior and OS boot are separate verification steps from source/unit tests.
