#!/usr/bin/env bash
# Build an experimental Debian 13 amd64 Live ISO; never modifies system partitions.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
WORK="$ROOT/out/pc-build"
command -v lb >/dev/null || { echo "Install Debian 13 live-build first" >&2; exit 2; }
command -v python3 >/dev/null || { echo "Python 3 required" >&2; exit 2; }
if [ -e "$WORK/config" ]; then
  echo "Workspace already configured: $WORK. Move aside for a clean build." >&2
  exit 2
fi
mkdir -p "$WORK"
cd "$WORK"
# Debian 13 uses --architecture and --binary-image (singular).
lb config \
  --distribution trixie \
  --architecture amd64 \
  --binary-image iso-hybrid \
  --debian-installer none \
  --image-name resoarcos-amd64 \
  --iso-volume "ResoArcOS 0.1" \
  --iso-publisher "ResoArc" \
  --bootappend-live "boot=live components hostname=resoarcos username=resoarc live-config.nocomponents=xinit"
mkdir -p config/package-lists
cp "$ROOT/images/pc/packages.list.chroot" config/package-lists/resoarc.list.chroot
python3 "$ROOT/scripts/stage.py" "$WORK/config/includes.chroot"
echo "Building ResoArcOS PC Live ISO ..."
if [ "$(id -u)" -eq 0 ]; then
  lb build
else
  sudo lb build
fi
sha256sum ./*.iso
