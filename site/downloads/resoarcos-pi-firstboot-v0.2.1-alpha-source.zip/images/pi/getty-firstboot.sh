#!/bin/sh
set -eu
if [ ! -f /var/lib/resoarc/setup-complete.json ]; then
    exec /usr/local/bin/resoarc-setup --console
fi
exec /sbin/agetty --noclear "$1" linux
