#!/bin/sh
# Expand the SD/NVMe root filesystem before the first interactive login.
# Safe to rerun: a missing marker means the previous attempt was incomplete.
set -eu
marker=/var/lib/resoarc/root-grow-complete
[ -e "$marker" ] && exit 0

# The root SOURCE can be /dev/root or a PARTUUID. Resolve its actual block
# device via the kernel's mount major:minor mapping instead of parsing SOURCE.
major_minor="$(findmnt -n -o MAJ:MIN /)"
case "$major_minor" in *:*) ;; *) echo "Cannot resolve root device" >&2; exit 1;; esac
uevent="/sys/dev/block/$major_minor/uevent"
[ -r "$uevent" ] || { echo "Missing root device metadata: $uevent" >&2; exit 1; }
devname="$(sed -n 's/^DEVNAME=//p' "$uevent" | head -n 1)"
case "$devname" in
    mmcblk[0-9]*p2|nvme[0-9]*n[0-9]*p2) ;;
    *) echo "Unsupported root partition: $devname" >&2; exit 1;;
esac
rootdev="/dev/$devname"
disk="${rootdev%p2}"
[ -b "$rootdev" ] && [ -b "$disk" ] || { echo "Root block device missing" >&2; exit 1; }

# growpart reports NOCHANGE with exit 1 when the partition already fills the
# medium. That is a success case; other failures must remain retryable.
if output="$(growpart "$disk" 2 2>&1)"; then
    printf '%s\n' "$output"
else
    case "$output" in
        NOCHANGE:*) printf '%s\n' "$output" ;;
        *) printf '%s\n' "$output" >&2; exit 1 ;;
    esac
fi
# Online ext4 resize. Only mark completion after both operations succeed.
resize2fs "$rootdev"
install -d -m 0700 /var/lib/resoarc
touch "$marker"
