#!/bin/sh
exec env PYTHONPATH=/usr/local/lib /usr/bin/python3 -m resoarcos.firstboot "$@"
