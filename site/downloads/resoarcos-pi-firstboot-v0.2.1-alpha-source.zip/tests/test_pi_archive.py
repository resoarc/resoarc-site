"""Checks compressed SD archive validation without using real multi-GB images."""
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "verify_pi_archive.py"
spec = spec_from_file_location("verify_pi_archive", SCRIPT)
module = module_from_spec(spec)
spec.loader.exec_module(module)


class ArchiveTests(unittest.TestCase):
    def test_manifest_rejects_bad_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.sha256"
            path.write_text("not-a-hash  example.img", encoding="ascii")
            with self.assertRaises(ValueError):
                module.manifest_hash(path)

    def test_archive_matches_raw(self):
        try:
            import zstandard as zstd
        except ImportError:
            self.skipTest("Optional zstandard package not installed")
        with tempfile.TemporaryDirectory() as directory:
            image = Path(directory) / "resoarcos-pi5-arm64.img"
            raw = b"ResoArcOS" * 12345
            image.write_bytes(raw)
            archive = Path(str(image) + ".zst")
            archive.write_bytes(zstd.ZstdCompressor().compress(raw))
            Path(str(image) + ".sha256").write_text(
                hashlib.sha256(raw).hexdigest() + "  " + image.name, encoding="ascii"
            )
            Path(str(archive) + ".sha256").write_text(
                hashlib.sha256(archive.read_bytes()).hexdigest() + "  " + archive.name,
                encoding="ascii",
            )
            result = module.verify(image)
            self.assertEqual(result["bytes"], len(raw))
            self.assertEqual(result["sha256"], hashlib.sha256(raw).hexdigest())
            # A corrupted raw manifest must be rejected even if the archive itself is intact.
            Path(str(image) + ".sha256").write_text("0" * 64, encoding="ascii")
            with self.assertRaisesRegex(ValueError, "does not match"):
                module.verify(image)


if __name__ == "__main__":
    unittest.main()
