#!/usr/bin/env bash
# Run inside an ephemeral Linux container as root; no host paths are changed.
set -euo pipefail
if [[ "$(id -u)" != 0 ]]; then
  echo "Requires root inside a disposable container for isolated /usr/local copy" >&2
  exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 scripts/stage.py "$TMP/image"
cp -a "$TMP/image/usr/local/lib/resoarcos" /usr/local/lib/
cp "$TMP/image/usr/local/bin/resoarc" /usr/local/bin/
mkdir -p "$TMP/attacker/resoarcos"
echo 'raise RuntimeError("malicious CWD module loaded")' >"$TMP/attacker/resoarcos/__init__.py"
cd "$TMP/attacker"
PYTHONPATH="$TMP/attacker" /usr/local/bin/resoarc status --json >"$TMP/out.json"
grep -q '"name": "ResoArcOS"' "$TMP/out.json"
echo "RESOARC_LAUNCHER_ISOLATION_PASS"
