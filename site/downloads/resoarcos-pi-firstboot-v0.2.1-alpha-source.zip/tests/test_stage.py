import stat
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from importlib.util import module_from_spec, spec_from_file_location

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "stage.py"
spec = spec_from_file_location("resoarc_stage", SCRIPT)
stage_module = module_from_spec(spec)
spec.loader.exec_module(stage_module)


class StageTests(unittest.TestCase):
    def test_stage_produces_cli_and_gui(self):
        with tempfile.TemporaryDirectory() as root:
            target = Path(root) / "test-root"
            stage_module.stage(target)
            executable = target / "usr/local/bin/resoarc"
            gui = target / "usr/local/bin/resogui"
            payload = target / "usr/local/lib/resoarcos/cli.py"
            self.assertTrue(executable.is_file())
            self.assertTrue(gui.is_file())
            self.assertTrue(payload.is_file())
            if os.name != "nt":
                self.assertTrue(executable.stat().st_mode & stat.S_IXUSR)
            self.assertIn("python3 -I -c", executable.read_text(encoding="utf-8"))
            self.assertNotIn("PYTHONPATH", executable.read_text(encoding="utf-8"))
            self.assertIn("SSH_CONNECTION", gui.read_text(encoding="utf-8"))
            self.assertIn("RESOARC_VERSION=", (target / "etc/resoarc/release").read_text(encoding="utf-8"))
            self.assertTrue((target / "usr/local/lib/resoarcos/profiles/web.toml").exists())

    def test_staged_code_not_world_writable(self):
        if os.name == "nt":
            self.skipTest("POSIX mode check requires Linux")
        with tempfile.TemporaryDirectory() as root:
            destination = Path(root) / "rootfs"
            stage_module.stage(destination)
            for f in (destination / "usr/local/lib/resoarcos").rglob("*"):
                if f.is_file():
                    self.assertEqual(f.stat().st_mode & 0o022, 0, str(f))

    def test_live_image_boots_headless_by_default(self):
        script = SCRIPT.parent.parent / "images" / "pc" / "build.sh"
        text = script.read_text(encoding="utf-8")
        self.assertIn("live-config.nocomponents=xinit", text)
        self.assertIn("--bootappend-live", text)

    def test_gui_rejects_remote_and_noninteractive_invocations(self):
        if os.name == "nt":
            self.skipTest("Linux shell and TTY guard required")
        with tempfile.TemporaryDirectory() as root:
            dest = Path(root) / "rootfs"
            stage_module.stage(dest)
            gui = dest / "usr/local/bin/resogui"
            env = os.environ.copy()
            env["SSH_CONNECTION"] = "test"
            remote = subprocess.run(["sh", str(gui)], text=True, input="", capture_output=True, env=env, timeout=5)
            self.assertEqual(remote.returncode, 2)
            self.assertIn("physical terminal", remote.stderr)
            env.pop("SSH_CONNECTION", None)
            env.pop("SSH_TTY", None)
            local_pipe = subprocess.run(["sh", str(gui)], text=True, input="", capture_output=True, env=env, timeout=5)
            self.assertEqual(local_pipe.returncode, 2)
            self.assertIn("virtual console", local_pipe.stderr)

    def test_stage_repeatable(self):
        with tempfile.TemporaryDirectory() as root:
            target = Path(root) / "test-root"
            stage_module.stage(target)
            before = (target / "usr/local/bin/resoarc").read_bytes()
            stage_module.stage(target)
            self.assertEqual(before, (target / "usr/local/bin/resoarc").read_bytes())

    def test_reject_root(self):
        with self.assertRaises(ValueError):
            stage_module.stage(Path(Path.cwd().anchor))


if __name__ == "__main__":
    unittest.main()