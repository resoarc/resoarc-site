"""Local-only ResoArcOS dashboard tests."""
import base64
from http.server import ThreadingHTTPServer
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from resoarcos import web


class WebTests(unittest.TestCase):
    def test_snapshot(self):
        with tempfile.TemporaryDirectory() as temp:
            info = web.snapshot(Path(temp), Path(temp))
            self.assertIn("disk_total", info)
            self.assertEqual(info["profiles"], [])

    def test_html_escape(self):
        info = {
            "host": "<script>alert(1)</script>",
            "architecture": "arm64",
            "kernel": "test",
            "profiles": ["<img src=x>"],
            "disk_total": 100,
            "disk_used": 25,
            "disk_free": 75,
        }
        page = web.render(info).decode("utf-8")
        self.assertNotIn("<script>", page)
        self.assertNotIn("<img src=x>", page)
        self.assertIn("&lt;script&gt;", page)

    def test_http_requires_auth_and_local_bind(self):
        with tempfile.TemporaryDirectory() as temp:
            handler = web.make_handler("test-token", Path(temp))
            server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            url = f"http://127.0.0.1:{server.server_port}/"
            try:
                with self.assertRaises(HTTPError) as denied:
                    urlopen(url, timeout=5)
                self.assertEqual(denied.exception.code, 401)
                self.assertEqual(denied.exception.headers["Cache-Control"], "no-store")
                wrong = base64.b64encode(b"resoarc:wrong").decode("ascii")
                with self.assertRaises(HTTPError) as denied:
                    urlopen(Request(url, headers={"Authorization": "Basic " + wrong}), timeout=5)
                self.assertEqual(denied.exception.code, 401)
                correct = base64.b64encode(b"resoarc:test-token").decode("ascii")
                request = Request(url, headers={"Authorization": "Basic " + correct})
                with urlopen(request, timeout=5) as response:
                    self.assertEqual(response.status, 200)
                    self.assertIn(b"ResoArcOS", response.read())
                    self.assertIn("default-src 'none'", response.headers["Content-Security-Policy"])
                with self.assertRaises(HTTPError) as denied:
                    urlopen(Request(url, data=b"action=restart", headers={"Authorization": "Basic " + correct}), timeout=5)
                self.assertEqual(denied.exception.code, 405)
                self.assertEqual(server.server_address[0], "127.0.0.1")
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
