"""Unit checks are host-safe; no real root commands."""
import base64
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from resoarcos import firstboot

class FirstBootTests(unittest.TestCase):
    def test_hostname(self):
        self.assertEqual(firstboot.validate_hostname("ResoArcOS"), "resoarcos")
        for value in ("-host", "host-", "host.name", "a" * 64, ""):
            with self.assertRaises(ValueError):
                firstboot.validate_hostname(value)

    def test_timezone_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            (base / "Asia").mkdir()
            (base / "Asia" / "Tokyo").write_text("tz")
            self.assertEqual(firstboot.validate_timezone("Asia/Tokyo", base), "Asia/Tokyo")
            for value in ("../etc/passwd", "/etc/passwd", "No/Zone"):
                with self.assertRaises(ValueError):
                    firstboot.validate_timezone(value, base)

    def test_password(self):
        for value in ("short", "passabcdefghijkl\n", "a" * 257):
            with self.assertRaises(ValueError):
                firstboot.validate_password(value)
        self.assertEqual(firstboot.validate_password("abcdefghijkl"), "abcdefghijkl")

    def test_wifi(self):
        self.assertEqual(firstboot.validate_wifi("", ""), ("", ""))
        for ssid, password in (("a" * 33, "12345678"), ("wifi", "short"), ("wifi\n", "12345678")):
            with self.assertRaises(ValueError):
                firstboot.validate_wifi(ssid, password)

    @staticmethod
    def key_blob(*parts):
        return b"".join(len(part).to_bytes(4, "big") + part for part in parts)

    def test_ssh_key(self):
        pub = self.key_blob(b"ssh-ed25519", b"q" * 32)
        key = "ssh-ed25519 " + base64.b64encode(pub).decode("ascii") + " pi-key"
        self.assertEqual(firstboot.validate_public_key(key), key)
        self.assertEqual(firstboot.validate_public_key(""), "")
        invalid = (
            "ssh-ed25519 AAAA comment",
            "ssh-ed25519 AAAA\\nbad",
            "ssh-rsa " + base64.b64encode(pub).decode(),
            "ssh-ed25519 " + base64.b64encode(self.key_blob(b"ssh-ed25519", b"x" * 31)).decode(),
            "ssh-ed25519 " + base64.b64encode(pub + b"trailing").decode(),
            "ssh-ed25519 %%not-base64%%",
            "ssh-ed25519 " + base64.b64encode(self.key_blob(b"ssh-rsa", b"q" * 32)).decode()
        )
        for bad in invalid:
            with self.subTest(bad=bad[:35]), self.assertRaises(ValueError):
                firstboot.validate_public_key(bad)

    def test_ecdsa_key_structure(self):
        valid = self.key_blob(b"ecdsa-sha2-nistp256", b"nistp256", bytes([4]) + b"A" * 64)
        key = "ecdsa-sha2-nistp256 " + base64.b64encode(valid).decode()
        self.assertEqual(firstboot.validate_public_key(key), key)

    def test_rsa_key_structure(self):
        modulus = bytes([0]) + bytes([0x80]) + bytes([3]) * 255
        valid = self.key_blob(b"ssh-rsa", bytes([1, 0, 1]), modulus)
        key = "ssh-rsa " + base64.b64encode(valid).decode()
        self.assertEqual(firstboot.validate_public_key(key), key)
        weak = self.key_blob(b"ssh-rsa", bytes([1, 0, 1]), bytes([0x80]) + bytes([1])*127)
        with self.assertRaises(ValueError):
            firstboot.validate_public_key("ssh-rsa " + base64.b64encode(weak).decode())

    def test_console_reprompts_invalid_wifi_key_and_mode_without_writes(self):
        pub = self.key_blob(b"ssh-ed25519", b"z" * 32)
        key = "ssh-ed25519 " + base64.b64encode(pub).decode("ascii")
        inputs = iter([
            "resoarcos", "Asia/Tokyo",
            "my-wifi", "my-wifi",  # first password invalid, re-enter SSID
            "ssh-ed25519 AAAA", key,  # first public key invalid
            "maybe", "no",  # explicit password-login answer required
        ])
        passwords = iter(["longpassword12", "longpassword12", "bad", "wifi-password"])
        with tempfile.TemporaryDirectory() as d:
            marker = Path(d) / "state.json"
            with mock.patch.object(firstboot, "STATE", marker), \
                 mock.patch.object(firstboot, "validate_timezone", return_value="Asia/Tokyo"), \
                 mock.patch("builtins.input", side_effect=lambda _: next(inputs)), \
                 mock.patch.object(firstboot.getpass, "getpass", side_effect=lambda _: next(passwords)), \
                 mock.patch.object(firstboot, "configure") as configure, \
                 mock.patch("sys.stdout", new_callable=__import__("io").StringIO) as output:
                self.assertEqual(firstboot.console(), 0)
                self.assertEqual(configure.call_count, 1)
                args = configure.call_args.kwargs
                self.assertEqual(args["pubkey"], key)
                self.assertEqual(args["ssid"], "my-wifi")
                self.assertEqual(args["wifi_password"], "wifi-password")
                self.assertFalse(args["ssh_password"])
                self.assertIn("Error:", output.getvalue())
                self.assertNotIn("wifi-password", output.getvalue())
                self.assertNotIn("longpassword12", output.getvalue())

    def test_requires_ssh_auth(self):
        with tempfile.TemporaryDirectory() as d:
            with mock.patch.object(firstboot, "validate_timezone", return_value="Asia/Tokyo"):
                with self.assertRaisesRegex(ValueError, "SSH requires"):
                    firstboot.configure(hostname="resoarcos", tz="Asia/Tokyo",
                                        password="abcdefghijkl", state_file=Path(d) / "done")

    def test_completion_marker_prevents_repeat(self):
        with tempfile.TemporaryDirectory() as d:
            marker = Path(d) / "done"
            marker.write_text("{}")
            with mock.patch.object(firstboot, "validate_timezone", return_value="Asia/Tokyo"):
                with self.assertRaisesRegex(RuntimeError, "Already configured"):
                    firstboot.configure(hostname="resoarcos", tz="Asia/Tokyo",
                                        password="abcdefghijkl", ssh_password=True,
                                        state_file=marker)

if __name__ == "__main__":
    unittest.main()
