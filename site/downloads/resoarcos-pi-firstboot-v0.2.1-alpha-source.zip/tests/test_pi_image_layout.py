"""Unit tests for the direct raw SD image format verification."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import io
import struct
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "verify_pi_image_layout.py"
spec = spec_from_file_location("pi_image_layout", SCRIPT)
mod = module_from_spec(spec)
spec.loader.exec_module(mod)


class ImageLayoutTests(unittest.TestCase):
    @staticmethod
    def sample_mbr():
        mbr = bytearray(512)
        mbr[510:] = b"\x55\xaa"
        for i, (ptype, lba, nsectors) in enumerate(
            ((0x0C, 16384, 1048576), (0x83, 1064960, 8388608))
        ):
            off = 446 + i * 16
            mbr[off + 4] = ptype
            struct.pack_into("<II", mbr, off + 8, lba, nsectors)
        return mbr

    def test_mbr(self):
        self.assertEqual(mod.get_partitions(self.sample_mbr())[1][1], 1064960)

    def test_reject_bad_magic(self):
        mbr = self.sample_mbr()
        mbr[510] = 0
        with self.assertRaisesRegex(ValueError, "signature"):
            mod.get_partitions(mbr)

    def test_reject_overlap(self):
        mbr = self.sample_mbr()
        struct.pack_into("<I", mbr, 446 + 16 + 8, 16385)
        with self.assertRaisesRegex(ValueError, "Overlapping"):
            mod.get_partitions(mbr)

    def test_fat_boot_directory(self):
        image = bytearray(4096)
        image[510:512] = b"\x55\xaa"
        struct.pack_into("<H", image, 11, 512)
        image[13] = 1
        struct.pack_into("<H", image, 14, 1)
        image[16] = 2
        struct.pack_into("<I", image, 36, 1)
        struct.pack_into("<I", image, 44, 2)
        struct.pack_into("<I", image, 512 + 2 * 4, 0x0FFFFFFF)
        directory = 3 * 512
        image[directory:directory + 11] = b"CONFIG  TXT"
        image[directory + 11] = 0x20
        struct.pack_into("<I", image, directory + 28, 22)
        image[directory + 32:directory + 43] = b"CMDLINE TXT"
        image[directory + 43] = 0x20
        struct.pack_into("<I", image, directory + 60, 44)
        entries, geometry = mod.fat32_root(io.BytesIO(image), 0)
        self.assertEqual(set(entries), {"config.txt", "cmdline.txt"})
        self.assertEqual(geometry["bps"], 512)

    def test_read_truncated(self):
        with self.assertRaisesRegex(ValueError, "Truncated"):
            mod.read_at(io.BytesIO(b"abc"), 1, 10)


if __name__ == "__main__":
    unittest.main()
