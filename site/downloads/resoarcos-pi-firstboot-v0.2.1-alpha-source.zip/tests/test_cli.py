import contextlib
import io
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from resoarcos.cli import main, profiles, load_state, save_state, apply_profile


class CoreTests(unittest.TestCase):
    def test_profiles(self):
        entries = profiles()
        self.assertEqual(set(entries), {"ai", "files", "iot", "web"})

    def test_default_readonly_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(load_state(Path(tmp))["enabled"], {})

    def test_state_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            save_state(path, {"schema": 1, "enabled": {"ai": "test"}})
            self.assertEqual(load_state(path)["enabled"]["ai"], "test")

    def test_plan_and_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            with contextlib.redirect_stdout(io.StringIO()) as out:
                self.assertEqual(main(["--state-dir", tmp, "profile", "plan", "web", "--json"]), 0)
            self.assertIn("80/tcp", out.getvalue())

    def test_apply_requires_confirmation(self):
        with tempfile.TemporaryDirectory() as tmp:
            with contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(main(["--state-dir", tmp, "profile", "apply", "ai"]), 2)

    def test_network_requires_explicit_acknowledgement(self):
        with tempfile.TemporaryDirectory() as tmp:
            with contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(main(["--state-dir", tmp, "profile", "apply", "web", "--confirm"]), 2)

    def test_no_os_mutation_outside_linux(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch("resoarcos.cli.platform.system", return_value="Windows"):
                with contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(main(["--state-dir", tmp, "profile", "apply", "ai", "--confirm"]), 2)

    def test_apply_success_is_audited_and_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            state_dir = Path(tmp)
            with patch("resoarcos.cli.platform.system", return_value="Linux"), patch("resoarcos.cli.os.geteuid", return_value=0, create=True), patch("resoarcos.cli.run") as command:
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(apply_profile("ai", state_dir, True, False), 0)
                    self.assertEqual(apply_profile("ai", state_dir, True, False), 0)
                command.assert_called_once_with(["apt-get", "install", "--yes", "--no-install-recommends", "podman"])
            self.assertIn("ai", load_state(state_dir)["enabled"])
            events = [json.loads(line) for line in (state_dir / "audit.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0]["result"], "success")

    def test_failed_apply_is_audited_without_false_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            state_dir = Path(tmp)
            error = subprocess.CalledProcessError(1, ["apt-get", "install"])
            with patch("resoarcos.cli.platform.system", return_value="Linux"), patch("resoarcos.cli.os.geteuid", return_value=0, create=True), patch("resoarcos.cli.run", side_effect=error):
                with contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(apply_profile("ai", state_dir, True, False), 1)
            self.assertNotIn("ai", load_state(state_dir)["enabled"])
            event = json.loads((state_dir / "audit.jsonl").read_text(encoding="utf-8").splitlines()[0])
            self.assertEqual(event["result"], "failed")

    def test_network_profile_installs_whitelisted_services(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch("resoarcos.cli.platform.system", return_value="Linux"), patch("resoarcos.cli.os.geteuid", return_value=0, create=True), patch("resoarcos.cli.run") as command:
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(apply_profile("web", Path(tmp), True, True), 0)
                self.assertEqual(command.call_count, 2)
                self.assertEqual(command.call_args_list[0].args[0][-1], "nginx")
                self.assertEqual(command.call_args_list[1].args[0], ["systemctl", "enable", "--now", "nginx"])


if __name__ == "__main__":
    unittest.main()