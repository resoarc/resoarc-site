#!/usr/bin/env bash
# Verify minimal GUI under a nested virtual X server; not a physical TTY or GPU test.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
TMP="$(mktemp -d)"
XVPID=""
GUIPID=""
cleanup() {
  if [[ -n "$GUIPID" ]]; then kill "$GUIPID" 2>/dev/null || true; fi
  if [[ -n "$XVPID" ]]; then kill "$XVPID" 2>/dev/null || true; fi
  rm -rf "$TMP"
}
trap cleanup EXIT
python3 scripts/stage.py "$TMP/stage"
mkdir -p "$TMP/user"
chmod 755 "$TMP"
useradd -u 12345 -U -M -d "$TMP/user" -s /bin/sh resoarctest
chown 12345:12345 "$TMP/user"
export HOME="$TMP/user" USER=resoarc DISPLAY=:99
Xvfb :99 -screen 0 1024x768x24 -nolisten tcp >"$TMP/xvfb.log" 2>&1 &
XVPID=$!
sleep 2
runuser -u resoarctest -- env HOME="$TMP/user" USER=resoarctest DISPLAY=:99 "$TMP/stage/usr/local/bin/resoarc-desktop" >"$TMP/desktop.log" 2>&1 &
GUIPID=$!
sleep 10
if ! kill -0 "$GUIPID" 2>/dev/null; then
  echo "GUI exited:" >&2
  cat "$TMP/desktop.log" >&2
  exit 1
fi
wmctrl_status="$(xprop -root _NET_SUPPORTING_WM_CHECK 2>&1 || true)"
echo "$wmctrl_status"
if ! grep -q _NET_SUPPORTING_WM_CHECK <<< "$wmctrl_status"; then
  echo "Openbox window manager not present" >&2
  cat "$TMP/desktop.log" >&2
  exit 1
fi
xwininfo -root -tree > "$TMP/tree.txt"
head -n 28 "$TMP/tree.txt"
xwd -root -silent -out "$TMP/desktop.xwd"
convert "$TMP/desktop.xwd" /results/resoarcos-xvfb-desktop.png
echo "XVFB_GUI_SMOKE_PASS (unprivileged desktop process)"
