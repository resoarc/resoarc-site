#!/usr/bin/env bash
# Confirm the real layer/config/overlay composition through a strict mock.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/mock-image-gen" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
test "$1" = build
test "$2" = -S
SRC="$3"
test "$4" = -c
CFG="$5"
OVERLAY="$SRC/layer/resoarc-firstboot.d/customize.overlay"
test -s "$OVERLAY/usr/local/lib/resoarcos/firstboot.py"
test -s "$OVERLAY/usr/local/bin/resoarc"
test -s "$OVERLAY/usr/local/bin/resoarc-setup"
test -s "$OVERLAY/usr/local/bin/resoarc-getty-firstboot"
test -s "$OVERLAY/usr/local/bin/resoarc-web"
test -s "$OVERLAY/usr/local/lib/resoarcos/web.py"
grep -q "RESOARC_PI_FEATURES=firstboot,root-grow,local-web" "$OVERLAY/etc/resoarc/release"
test -s "$OVERLAY/usr/local/sbin/resoarc-grow-root"
test -s "$OVERLAY/etc/systemd/system/resoarc-grow-root.service"
test -L "$OVERLAY/etc/systemd/system/multi-user.target.wants/resoarc-grow-root.service"
test -s "$OVERLAY/etc/systemd/system/getty@tty1.service.d/resoarc.conf"
test -s "$SRC/layer/resoarc-firstboot.yaml"
grep -q 'user1: resoarc' "$CFG"
grep -q 'user1sudo: passwd' "$CFG"
grep -q 'resoarc-firstboot' "$CFG"
grep -q 'pubkey_only: n' "$CFG"
grep -Eq 'layer: rpi[45]' "$CFG"
if grep -Eiq 'user1pass|private.key' "$CFG"; then
    echo "Credential material detected in image recipe" >&2
    exit 1
fi
SH
chmod +x "$TMP/mock-image-gen"
export RPI_IMAGE_GEN="$TMP/mock-image-gen"
export RESOARC_BUILD_ROOT="$TMP/build"
for model in 4 5; do
    bash images/pi/build.sh "$model"
done
echo "Pi4/Pi5 firstboot layer composition: PASS (mock builder)"
