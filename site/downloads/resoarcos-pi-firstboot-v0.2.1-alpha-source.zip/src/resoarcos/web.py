"""Local-only, read-only ResoArcOS status dashboard.

Access over an SSH local port-forward; never bind to a public interface.
"""
from __future__ import annotations

import argparse
import base64
from html import escape
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import os
import platform
import secrets
import shutil
from pathlib import Path

from .cli import load_state

SETUP_MARKER = Path("/var/lib/resoarc/setup-complete.json")
DEFAULT_PORT = 8765


def snapshot(state_dir: Path = Path("/var/lib/resoarc"), root: Path = Path("/")) -> dict:
    total, used, free = shutil.disk_usage(root)
    enabled = load_state(state_dir)["enabled"]
    return {
        "host": platform.node() or "resoarcos",
        "architecture": platform.machine(),
        "kernel": platform.release(),
        "disk_total": total,
        "disk_used": used,
        "disk_free": free,
        "profiles": sorted(enabled),
    }


def render(info: dict) -> bytes:
    def human(value: int) -> str:
        return f"{value / (1024 ** 3):.1f} GiB"

    def safe(value: object) -> str:
        return escape(str(value), quote=True)

    profile_list = ", ".join(safe(x) for x in info["profiles"]) or "なし"
    html = f"""<!doctype html>
<html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="30">
<title>ResoArcOS | System</title>
<style>
:root {{ color-scheme: dark; }}
body {{ margin: 0; background: #101722; color: #eaf0f8; font: 16px system-ui, sans-serif; }}
main {{ max-width: 780px; margin: 48px auto; padding: 0 20px; }}
h1 {{ font-size: 2rem; letter-spacing: .04em; }}
p {{ color: #9fb3c9; }}
section {{ background: #1b2635; border: 1px solid #314154; border-radius: 16px; padding: 20px; margin: 18px 0; }}
dl {{ display: grid; grid-template-columns: minmax(100px, 1fr) 2fr; gap: 12px; }}
dt {{ color: #a8bacd; }} dd {{ margin: 0; overflow-wrap: anywhere; }}
meter {{ width: 100%; height: 18px; }}
footer {{ font-size: .85rem; margin-top: 30px; }}
</style></head><body><main>
<h1>ResoArcOS</h1><p>ローカル管理ダッシュボード · 読み取り専用</p>
<section><h2>システム</h2><dl>
<dt>ホスト名</dt><dd>{safe(info["host"])}</dd>
<dt>CPUアーキテクチャ</dt><dd>{safe(info["architecture"])}</dd>
<dt>カーネル</dt><dd>{safe(info["kernel"])}</dd>
<dt>有効なプロファイル</dt><dd>{profile_list}</dd>
</dl></section>
<section><h2>ルートストレージ</h2>
<meter min="0" max="{int(info["disk_total"])}" value="{int(info["disk_used"])}"></meter>
<p>{human(info["disk_used"])} / {human(info["disk_total"])} 使用中
（空き {human(info["disk_free"])}）</p></section>
<footer>30秒ごとに更新 · ネットワーク越しにはSSHトンネルを使用してください。</footer>
</main></body></html>"""
    return html.encode("utf-8")


def make_handler(token: str, state_dir: Path = Path("/var/lib/resoarc")):
    class Handler(BaseHTTPRequestHandler):
        server_version = "ResoArcOS"
        sys_version = ""

        def log_message(self, fmt: str, *args: object) -> None:
            # Do not record Basic Authorization or requests to the dashboard.
            return

        def _headers(self, code: int, size: int = 0, auth: bool = False) -> None:
            self.send_response(code)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            if auth:
                self.send_header("WWW-Authenticate", 'Basic realm="ResoArcOS", charset="UTF-8"')
            if size:
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(size))
            self.end_headers()

        def _authorized(self) -> bool:
            header = self.headers.get("Authorization", "")
            if not header.startswith("Basic ") or len(header) > 300:
                return False
            try:
                raw = base64.b64decode(header[6:], validate=True).decode("utf-8")
            except (ValueError, UnicodeError):
                return False
            user, sep, password = raw.partition(":")
            return bool(sep) and hmac.compare_digest(user, "resoarc") and hmac.compare_digest(password, token)

        def do_GET(self) -> None:
            if not self._authorized():
                self._headers(401, auth=True)
                return
            if self.path != "/":
                self._headers(404)
                return
            data = render(snapshot(state_dir))
            self._headers(200, size=len(data))
            self.wfile.write(data)

        def do_POST(self) -> None:
            self._headers(405)

    return Handler


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ResoArcOS local read-only dashboard")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    args = parser.parse_args(argv)
    if not 1024 <= args.port <= 65535:
        parser.error("port must be between 1024 and 65535")
    if not SETUP_MARKER.exists():
        parser.error("complete first-boot console setup before opening the dashboard")
    if os.geteuid() == 0:
        parser.error("run as the non-root resoarc account")
    token = secrets.token_urlsafe(24)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(token))
    print(f"ResoArcOS dashboard: http://127.0.0.1:{args.port}/", flush=True)
    print(f"Browser Basic Auth: user=resoarc, password={token}", flush=True)
    print(f"Remote access: ssh -L {args.port}:127.0.0.1:{args.port} resoarc@<PI_IP>", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
