#!/usr/bin/env python3
"""Take a headless QEMU monitor screenshot from an isolated QA container.

The QEMU HMP listener is on container-local 127.0.0.1:4555, never host published.
"""
import argparse
import re
import socket
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("filename", help="Plain file name for screenshot in /results")
    parser.add_argument("--key", help="Optional QEMU key to send before screenshot")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-zA-Z0-9_-]{1,60}\.ppm", args.filename):
        raise SystemExit("A simple .ppm file name is required")
    with socket.create_connection(("127.0.0.1", 4555), timeout=5) as sock:
        sock.settimeout(5)
        sock.recv(4096)
        if args.key:
            if not re.fullmatch(r"[a-zA-Z0-9-]{1,30}", args.key):
                raise SystemExit("Unsupported HMP key sequence")
            sock.sendall(("sendkey " + args.key + "\n").encode("ascii"))
            time.sleep(0.3)
            sock.recv(4096)
        sock.sendall(("screendump /results/" + args.filename + "\n").encode("ascii"))
        time.sleep(1)
        print(sock.recv(4096).decode("utf-8", "replace"))


if __name__ == "__main__":
    main()
