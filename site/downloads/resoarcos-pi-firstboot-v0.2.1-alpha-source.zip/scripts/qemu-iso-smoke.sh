#!/usr/bin/env bash
# BIOS/serial boot smoke test for a live-build ISO using QEMU TCG (no KVM needed).
set -euo pipefail
ISO="${1:?Usage: qemu-iso-smoke.sh /path/to/resoarcos.iso}"
test -s "$ISO" || { echo "ISO missing: $ISO" >&2; exit 2; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
xorriso -osirrox on -indev "$ISO" -extract /live/vmlinuz "$TMP/vmlinuz" -extract /live/initrd.img "$TMP/initrd.img" >"$TMP/extract.log" 2>&1 || {
  cat "$TMP/extract.log" >&2
  echo "ISO kernel or initrd extraction failed" >&2
  exit 2
}
set +e
timeout -k 5 240 qemu-system-x86_64 \
  -machine pc,accel=tcg -smp 2 -m 1536 \
  -display none -monitor none -serial stdio \
  -kernel "$TMP/vmlinuz" -initrd "$TMP/initrd.img" \
  -append "boot=live components hostname=resoarcos username=resoarc console=ttyS0,115200n8 systemd.log_target=console" \
  -drive "file=$ISO,media=cdrom,readonly=on" -nic none \
  -no-reboot > "$TMP/qemu.log" 2>&1
rc=$?
set -e
if [ -d /results ]; then cp "$TMP/qemu.log" /results/resoarcos-qemu-boot.log; fi
tail -n 45 "$TMP/qemu.log"
if grep -qi 'Kernel panic' "$TMP/qemu.log"; then
  echo "QEMU smoke: FAIL (kernel panic)" >&2
  exit 1
fi
if grep -Eq '(login:|Reached target .*Multi-User System|Started .*Getty|Debian GNU/Linux.*ttyS0)' "$TMP/qemu.log"; then
  echo "QEMU smoke: PASS (serial login or multi-user state observed); qemu_exit=$rc"
  exit 0
fi
echo "QEMU smoke: INCONCLUSIVE (no login target observed); qemu_exit=$rc" >&2
exit 1
