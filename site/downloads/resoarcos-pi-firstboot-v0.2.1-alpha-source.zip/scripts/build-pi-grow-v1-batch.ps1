# Complete the running Pi 5 build, verify, then build and verify Pi 4.
# Writes only to the isolated out/pi-images-grow-v1 candidate folder.
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Tag = 'grow-v1'
$Pi5Name = 'resoarc-pi5-grow-v1-builder'
$Deadline = (Get-Date).AddMinutes(95)

Write-Output '[ResoArc] Waiting for the Pi 5 candidate builder'
while ((Get-Date) -lt $Deadline) {
    $State = docker inspect $Pi5Name --format '{{.State.Status}}:{{.State.ExitCode}}' 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'Pi 5 builder disappeared' }
    if ($State -match '^exited:(\d+)$') {
        if ([int]$Matches[1] -ne 0) {
            # The upstream IMG can be complete even when a Windows-mounted
            # wrapper fails after deployment. Only accept recovered artifacts
            # after their checksum and full filesystem verification below.
            $Candidate = Join-Path $Root 'out\pi-images-grow-v1\resoarcos-pi5-arm64.img'
            if (-not (Test-Path $Candidate) -or -not (Test-Path ($Candidate + '.sha256'))) {
                throw ('Pi 5 builder failed without recoverable IMG: ' + $State)
            }
            Write-Warning 'Pi 5 builder exit was nonzero; verifying recovered image before proceeding'
        }
        break
    }
    if ($State -match '^(dead|removing):') { throw ('Pi 5 builder failed: ' + $State) }
    Start-Sleep -Seconds 30
}
if ((Get-Date) -ge $Deadline) { throw 'Pi 5 builder timed out' }

Write-Output '[ResoArc] Verify Pi 5 grow-v1 image'
& (Join-Path $PSScriptRoot 'verify-pi-release.ps1') -Model 5 -BuildTag $Tag
if ($LASTEXITCODE -ne 0) { throw 'Pi 5 verification failed' }

Write-Output '[ResoArc] Build Pi 4 grow-v1 image'
& (Join-Path $PSScriptRoot 'build-pi-docker.ps1') -Model 4 -BuildTag $Tag
if ($LASTEXITCODE -ne 0) { throw 'Pi 4 build failed' }

Write-Output '[ResoArc] Verify Pi 4 grow-v1 image'
& (Join-Path $PSScriptRoot 'verify-pi-release.ps1') -Model 4 -BuildTag $Tag
if ($LASTEXITCODE -ne 0) { throw 'Pi 4 verification failed' }

$Output = Join-Path $Root 'out\pi-images-grow-v1'
$Lines = @('ResoArcOS Pi grow-v1 static image acceptance', ('Verified UTC: ' + (Get-Date).ToUniversalTime().ToString('o')), 'Real Raspberry Pi hardware boot NOT TESTED')
foreach ($Model in @('4','5')) {
    $Image = Join-Path $Output ('resoarcos-pi' + $Model + '-arm64.img')
    $Lines += ('Pi ' + $Model + ': ' + (Get-Item $Image).Length + ' bytes, SHA256 ' + (Get-FileHash $Image -Algorithm SHA256).Hash.ToLowerInvariant())
}
$Lines | Set-Content -Path (Join-Path $Output 'ACCEPTANCE.txt') -Encoding UTF8
Write-Output '[ResoArc] Pi 4 and Pi 5 candidate images passed static acceptance'
