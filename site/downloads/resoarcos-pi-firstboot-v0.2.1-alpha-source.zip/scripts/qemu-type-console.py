#!/usr/bin/env python3
"""Type a short test command into a disposable QEMU VM over private HMP."""
import argparse
import re
import socket
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9 /._-]{1,100}", args.command):
        raise SystemExit("Only minimal shell test commands are permitted")
    mapping = {" ": "spc", "/": "slash", ".": "dot", "-": "minus", "_": "shift-minus"}
    with socket.create_connection(("127.0.0.1", 4555), timeout=6) as sock:
        sock.settimeout(10)
        sock.recv(4096)
        for char in args.command:
            key = mapping.get(char, char)
            sock.sendall(f"sendkey {key}\n".encode("ascii"))
            time.sleep(0.10)
            sock.recv(8192)
        sock.sendall(b"sendkey ret\n")
        time.sleep(0.6)
    print("KEYBOARD_TEST_COMMAND_SENT: " + args.command)


if __name__ == "__main__":
    main()
