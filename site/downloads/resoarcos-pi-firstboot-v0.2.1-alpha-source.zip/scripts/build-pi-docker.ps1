# Build a Pi 4 or Pi 5 ARM64 IMG from Windows using a disposable Debian Docker container.
# Only the final IMG and checksum are exported to out/pi-images.
param([ValidateSet('4','5')][string]$Model = '5', [ValidatePattern('^[A-Za-z0-9_-]{1,32}$')][string]$BuildTag = 'grow-v1')
$ErrorActionPreference = 'Stop'
$Repo = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Reference = Join-Path $Repo 'out\rpi-image-gen-reference'
if (-not (Test-Path (Join-Path $Reference 'rpi-image-gen'))) {
    throw 'Clone the official raspberrypi/rpi-image-gen repo into out\rpi-image-gen-reference first.'
}
$Name = 'resoarc-pi' + $Model + '-' + $BuildTag + '-builder'
$OutputDir = 'out/pi-images-' + $BuildTag
New-Item -ItemType Directory -Path (Join-Path $Repo $OutputDir) -Force | Out-Null
$Existing = docker ps -a --filter ('name=^/' + $Name + '$') --format '{{.ID}}'
if ($Existing) { throw ('A previous builder exists: ' + $Name + '. Inspect its logs first.') }
$DockerArgs = @(
    'run', '--name', $Name, '--pull=never',
    '--privileged', '--cpus=2', '--memory=6g',
    '-v', ($Repo + ':/repo'),
    '-v', ($Reference + ':/reference:ro'),
    '-e', ('RESOARC_MODEL=' + $Model),
    '-e', ('RESOARC_IMAGE_OUTPUT_DIR=/repo/' + $OutputDir),
    'debian:trixie-slim', 'bash', '-c', 'sed ''s/\r$//'' /repo/scripts/build-pi-inside-container.sh > /tmp/resoarc-build.sh && exec bash /tmp/resoarc-build.sh'
)
& docker @DockerArgs
if ($LASTEXITCODE -ne 0) {
    throw ('IMG build failed. Inspect with: docker logs ' + $Name)
}
Write-Output ('Candidate image: ' + (Join-Path $Repo ($OutputDir + '/resoarcos-pi' + $Model + '-arm64.img')))
