#!/usr/bin/env python3
"""Verify a Raspberry Pi .img.zst decompresses byte-for-byte to the IMG SHA256.

Requires the optional 'zstandard' Python package. Reads the archive as a
stream and never writes an uncompressed temporary image to disk.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import sys


def manifest_hash(path: Path) -> str:
    first = path.read_text(encoding="ascii").split()[0].lower()
    if len(first) != 64 or any(c not in "0123456789abcdef" for c in first):
        raise ValueError(f"Invalid SHA-256 manifest: {path}")
    return first


def verify(image: Path) -> dict[str, object]:
    import zstandard as zstd

    archive = Path(str(image) + ".zst")
    expected = manifest_hash(Path(str(image) + ".sha256"))
    archive_expected = manifest_hash(Path(str(archive) + ".sha256"))
    archive_digest = hashlib.sha256()
    with archive.open("rb") as source:
        while chunk := source.read(4 * 1024 * 1024):
            archive_digest.update(chunk)
    if archive_digest.hexdigest() != archive_expected:
        raise ValueError("Compressed archive SHA-256 mismatch")

    digest = hashlib.sha256()
    count = 0
    with archive.open("rb") as source:
        with zstd.ZstdDecompressor().stream_reader(source) as reader:
            while chunk := reader.read(8 * 1024 * 1024):
                digest.update(chunk)
                count += len(chunk)
    if digest.hexdigest() != expected:
        raise ValueError("Decompressed archive does not match the IMG SHA-256")
    if image.exists() and image.stat().st_size != count:
        raise ValueError("Decompressed size differs from raw IMG size")
    return {"bytes": count, "sha256": digest.hexdigest(), "archive_bytes": archive.stat().st_size}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path, help="Path to .img with .sha256 and .zst files")
    args = parser.parse_args(argv)
    try:
        result = verify(args.image)
        print("PASS compressed archive integrity and decompressed IMG SHA-256")
        print(result)
        return 0
    except (OSError, ValueError, ImportError) as error:
        print("FAIL:", error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
