#!/usr/bin/env bash
# Invoked INSIDE the resource-limited Docker build container.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
echo "[ResoArc] Installing build prerequisites"
apt-get update -qq
apt-get install -y -qq --no-install-recommends ca-certificates git arch-test qemu-user-static binfmt-support debian-archive-keyring bash python3 python3-yaml python3-debian dpkg-dev mmdebstrap podman uidmap dbus-user-session zip dosfstools e2fsprogs grep rsync curl xz-utils mtools pv btrfs-progs dctrl-tools uuid-runtime fdisk python3-jsonschema cryptsetup python3-pip make build-essential autoconf automake libtool autopoint flex gettext pkgconf
mountpoint -q /proc/sys/fs/binfmt_misc || mount -t binfmt_misc binfmt_misc /proc/sys/fs/binfmt_misc
if [ ! -f /proc/sys/fs/binfmt_misc/aarch64 ]; then
    echo '[ResoArc] Missing active aarch64 binfmt; refusing broken cross-build' >&2
    exit 8
fi
arch-test arm64 || { echo '[ResoArc] arm64 emulation test failed' >&2; exit 9; }
# Some slim Docker bases clear APT lists after package installation.
apt-get update -qq
mkdir -p /builder
cp -a /reference/. /builder/
# Git for Windows can turn upstream text files into CRLF, including shebangs.
# Normalize text only in the private Linux build copy, not the source clone.
python3 - <<'PY'
from pathlib import Path
for f in Path('/builder').rglob('*'):
    if not f.is_file() or '.git' in f.parts:
        continue
    if f.suffix.lower() in {'.png','.jpg','.jpeg','.ico','.gif','.pdf','.zip','.img','.deb','.so','.a','.gz','.xz','.dtb','.elf','.bin'}:
        continue
    data = f.read_bytes()
    if b'\0' not in data and b'\r\n' in data:
        f.write_bytes(data.replace(b'\r\n', b'\n'))
PY
chmod +x /builder/rpi-image-gen /builder/install_deps.sh
cd /builder
./install_deps.sh
# Keep a stable Linux-local snapshot of source files throughout the long
# ARM64 QEMU build. Windows bind-mounted scripts may disappear if edited.
mkdir -p /builder/resoarc-project
cp -a /repo/src /repo/images /repo/scripts /builder/resoarc-project/
python3 - <<'PY'
from pathlib import Path
for script in Path('/builder/resoarc-project').rglob('*.sh'):
    raw = script.read_bytes()
    if b'\r\n' in raw:
        script.write_bytes(raw.replace(b'\r\n', b'\n'))
PY
export RPI_IMAGE_GEN=/builder/rpi-image-gen
export RESOARC_BUILD_ROOT=/builder/resoarc-sources-v4
cd /builder
bash /builder/resoarc-project/images/pi/build.sh "$RESOARC_MODEL"
output_dir="${RESOARC_IMAGE_OUTPUT_DIR:-/repo/out/pi-images}"
case "$output_dir" in /repo/out/*) ;; *) echo "Unsafe image output path" >&2; exit 11;; esac
mkdir -p "$output_dir"
image="$(find /builder/work -type f -name 'resoarcos-pi*-arm64.img' -print -quit)"
test -n "$image" || { echo "No image produced under /builder/work" >&2; exit 5; }
dest="$output_dir/resoarcos-pi$RESOARC_MODEL-arm64.img"
cp "$image" "$dest.part"
mv "$dest.part" "$dest"
(
    cd "$output_dir"
    sha256sum "resoarcos-pi$RESOARC_MODEL-arm64.img" > "resoarcos-pi$RESOARC_MODEL-arm64.img.sha256"
)
archive="$(find /builder/work -type f -name "resoarcos-pi$RESOARC_MODEL-arm64.img.zst" -print -quit)"
if [ -n "$archive" ]; then
    cp "$archive" "$dest.zst.part"
    mv "$dest.zst.part" "$dest.zst"
    (cd "$output_dir" && sha256sum "resoarcos-pi$RESOARC_MODEL-arm64.img.zst" > "resoarcos-pi$RESOARC_MODEL-arm64.img.zst.sha256")
fi
echo "[ResoArc] Image and checksums complete."
