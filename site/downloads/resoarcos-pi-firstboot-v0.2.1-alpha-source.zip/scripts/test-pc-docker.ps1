# Safe nonprivileged Linux-container smoke test for the ResoArcOS management core.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$image = 'resoarcos-live-builder:local'
docker image inspect $image *> $null
if ($LASTEXITCODE -ne 0) {
    throw "Builder image not found: $image. Build images/pc/Dockerfile.build first."
}
$test = 'PYTHONPATH=src python3 -m unittest discover -s tests -q >/tmp/tests.log 2>&1; result=$?; cat /tmp/tests.log; if [ "$result" -ne 0 ]; then exit "$result"; fi; PYTHONPATH=src python3 -m resoarcos status --json; PYTHONPATH=src python3 -m resoarcos profile plan web --json'
docker run --rm --cpus=2 --memory=2g --pids-limit=256 --mount "type=bind,src=$root,dst=/src,readonly" -w /src $image bash -lc $test
if ($LASTEXITCODE -ne 0) {
    throw 'Container smoke test failed'
}
Write-Output 'ResoArcOS Linux Docker core smoke test: PASS'
