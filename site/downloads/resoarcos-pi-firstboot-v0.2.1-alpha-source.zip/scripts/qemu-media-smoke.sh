#!/usr/bin/env bash
# Real virtual-CD-ROM BIOS boot test (not direct kernel boot).
# QEMU runs without networking or host hardware access.
set -euo pipefail
ISO="${1:?Usage: qemu-media-smoke.sh /path/to/live.iso [screenshot prefix]}"
PREFIX="${2:-resoarcos-bios}"
test -s "$ISO"
TMP="$(mktemp -d)"
QPID=""
cleanup() {
  if [[ -n "$QPID" ]]; then kill "$QPID" 2>/dev/null || true; wait "$QPID" 2>/dev/null || true; fi
  rm -rf "$TMP"
}
trap cleanup EXIT
QEMU_FIRMWARE_ARGS=(-machine pc,accel=tcg)
if [[ "${RESOARC_QEMU_FIRMWARE:-bios}" == "uefi" ]]; then
  cp /usr/share/OVMF/OVMF_VARS_4M.fd "$TMP/OVMF_VARS.fd"
  QEMU_FIRMWARE_ARGS=(-machine q35,accel=tcg
    -drive "if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd"
    -drive "if=pflash,format=raw,unit=1,file=$TMP/OVMF_VARS.fd")
fi
qemu-system-x86_64 -m 1536 -smp 2 \
  "${QEMU_FIRMWARE_ARGS[@]}" -boot d -display none -vga std \
  -monitor tcp:127.0.0.1:4555,server,nowait \
  -serial file:"$TMP/serial.log" -cdrom "$ISO" -nic none \
  -no-reboot -no-shutdown >"$TMP/qemu.log" 2>&1 &
QPID=$!
sleep 25
export PREFIX
python3 - <<'PY'
import os, socket, time
prefix = os.environ["PREFIX"]
for i in (1, 2):
    with socket.create_connection(("127.0.0.1", 4555), timeout=5) as sock:
        sock.recv(4096)
        path = f"/results/{prefix}-{i}.ppm"
        sock.sendall(f"screendump {path}\n".encode("ascii"))
        time.sleep(2)
        output = sock.recv(4096).decode("utf-8", "replace")
        if "Error" in output:
            raise RuntimeError(output)
        print(f"QEMU firmware screenshot {i}: {path}")
    if i == 1:
        with socket.create_connection(("127.0.0.1", 4555), timeout=5) as sock:
            sock.recv(4096)
            sock.sendall(b"sendkey ret\n")
            time.sleep(1)
            sock.recv(4096)
        time.sleep(180)
PY
echo "QEMU virtual-CD-ROM boot inspection screenshots created."