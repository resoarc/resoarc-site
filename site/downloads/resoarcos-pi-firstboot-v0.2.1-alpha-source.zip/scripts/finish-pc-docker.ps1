# Validate a finished ResoArcOS Docker ISO build and copy it to Windows.
param([Parameter(Mandatory=$true)][string]$BuildId)
$ErrorActionPreference = 'Stop'
if ($BuildId -notmatch '^[a-z0-9][a-z0-9-]{0,24}$') { throw 'Invalid BuildId' }
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$name = "resoarcos-iso-$BuildId"
$state = (docker inspect $name --format '{{.State.Status}}|{{.State.ExitCode}}' 2>&1 | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $state -ne 'exited|0') {
    throw "Build $name is not finished successfully: $state"
}
$iso = '/work/out/pc-build/resoarcos-amd64-amd64.hybrid.iso'
docker run --rm --cpus=2 --memory=2g --pids-limit=256 --mount "type=bind,src=$root,dst=/src,readonly" --mount "type=volume,src=$name,dst=/work,readonly" -w /src resoarcos-live-builder:local bash scripts/verify-iso.sh $iso
if ($LASTEXITCODE -ne 0) { throw 'ISO verification failed; refusing to copy it' }
$destination = Join-Path $root "out/resoarcos-$BuildId-amd64.iso"
if (Test-Path $destination) { throw "Destination already exists: $destination" }
docker cp ($name + ':' + $iso) $destination
if ($LASTEXITCODE -ne 0) { throw 'Copy failed' }
$hash = (Get-FileHash $destination -Algorithm SHA256).Hash.ToLowerInvariant()
($hash + '  ' + (Split-Path $destination -Leaf)) | Set-Content ($destination + '.sha256') -Encoding Ascii
Write-Output "Verified ISO: $destination"
Write-Output "SHA-256: $hash"
