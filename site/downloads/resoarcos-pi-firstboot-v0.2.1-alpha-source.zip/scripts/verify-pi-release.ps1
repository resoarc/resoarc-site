# Verify a generated ResoArcOS Pi SD image before using Raspberry Pi Imager.
param([ValidateSet('4','5')][string]$Model = '5', [ValidatePattern('^[A-Za-z0-9_-]{1,32}$')][string]$BuildTag = '')
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Images = Join-Path $Root ('out\pi-images' + $(if ($BuildTag) { '-' + $BuildTag } else { '' }))
$Name = 'resoarcos-pi' + $Model + '-arm64.img'
$Image = Join-Path $Images $Name
$Manifest = $Image + '.sha256'
if (-not (Test-Path $Image)) { throw ('Image not generated: ' + $Image) }
if (-not (Test-Path $Manifest)) { throw ('Checksum manifest missing: ' + $Manifest) }
$Expected = ((Get-Content $Manifest -Raw).Trim() -split '\s+')[0].ToLowerInvariant()
$Actual = (Get-FileHash -Path $Image -Algorithm SHA256).Hash.ToLowerInvariant()
if ($Expected -ne $Actual) { throw ('SHA256 MISMATCH. Expected ' + $Expected + ' actual ' + $Actual) }
Write-Output ('PASS SHA256: ' + $Actual)
& python (Join-Path $Root 'scripts\verify_pi_image_layout.py') $Image
if ($LASTEXITCODE -ne 0) { throw 'Pi image partition/FAT/EXT4 layout verification failed' }
$Verifier = 'resoarcos-pi-verifier:local'
& docker image inspect $Verifier --format '{{.Id}}' 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    & docker build --pull=false -t $Verifier -f (Join-Path $Root 'images\pi\Dockerfile.verify') $Root
    if ($LASTEXITCODE -ne 0) { throw 'Could not build the open-source Pi image verification container' }
}
$Args = @(
 'run','--rm','--privileged','--pull=never','--entrypoint','bash',
 '-v',($Images + ':/images:ro'),'-v',($Root + ':/repo:ro'),
 $Verifier,'/repo/scripts/verify-pi-image.sh',$Model
)
if ($BuildTag) { $Args += '--require-grow' }
& docker @Args
if ($LASTEXITCODE -ne 0) { throw 'Pi ext4 rootfs verification failed' }
if (Test-Path ($Image + '.zst')) {
    & python (Join-Path $Root 'scripts\verify_pi_archive.py') $Image
    if ($LASTEXITCODE -ne 0) {
        throw 'Compressed IMG archive failed integrity verification. Install Python zstandard if missing.'
    }
}
Write-Output ('PASS: ' + $Name + ' is a structurally verified SD test image.')
Write-Output 'WARNING: Raspberry Pi 4/5 hardware boot and first-login still require physical verification.'
