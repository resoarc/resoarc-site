# Build experimental PC ISO in a fresh Linux-native Docker volume.
# Old runs remain untouched for separate failure inspection.
param([Parameter(Mandatory=$true)][string]$BuildId)
$ErrorActionPreference = 'Stop'
if ($BuildId -notmatch '^[a-z0-9][a-z0-9-]{0,24}$') { throw 'Invalid BuildId' }
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$name = "resoarcos-iso-$BuildId"
$image = 'resoarcos-live-builder:local'
$names = @(docker ps -a --format '{{.Names}}')
if ($LASTEXITCODE -ne 0) { throw 'Docker Linux engine unavailable' }
if ($names -contains $name) { throw "Container $name already exists" }
$volumes = @(docker volume ls --format '{{.Name}}')
if ($LASTEXITCODE -ne 0) { throw 'Unable to list volumes' }
if ($volumes -contains $name) { throw "Volume $name already exists" }
docker image inspect $image *> $null
if ($LASTEXITCODE -ne 0) { throw "Build $image first" }
docker volume create $name | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Volume creation failed' }
$command = 'set -e; cp -a /source/images /source/scripts /source/src /work/; cd /work; bash images/pc/build.sh'
docker run -d --name $name --cpus=4 --memory=6g --memory-swap=6g --pids-limit=512 --privileged --mount "type=bind,src=$root,dst=/source,readonly" --mount "type=volume,src=$name,dst=/work" --workdir /work $image bash -lc $command
if ($LASTEXITCODE -ne 0) { throw 'ISO container failed to start' }
Write-Output "Container/volume: $name"
Write-Output "Inspect: docker logs --tail 50 $name"
Write-Output 'Verify ISO and digest before copying to Windows.'
