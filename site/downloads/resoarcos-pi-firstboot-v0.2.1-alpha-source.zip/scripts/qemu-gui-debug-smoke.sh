#!/usr/bin/env bash
# EXPLICIT TEST-ONLY: Uses systemd.debug-shell=1 to inspect a disposable QA VM.
# No debug root shell is ever inserted into or enabled in the release ISO.
set -euo pipefail
ISO="${1:?Usage: qemu-gui-debug-smoke.sh /path/to/resoarcos.iso}"
test -s "$ISO"
TMP="$(mktemp -d)"
QPID=""
cleanup() {
  if [[ -n "$QPID" ]]; then kill "$QPID" 2>/dev/null || true; wait "$QPID" 2>/dev/null || true; fi
  rm -rf "$TMP"
}
trap cleanup EXIT
xorriso -osirrox on -indev "$ISO" \
  -extract /live/vmlinuz "$TMP/vmlinuz" \
  -extract /live/initrd.img "$TMP/initrd.img" >"$TMP/extract.log" 2>&1
qemu-system-x86_64 \
  -machine pc,accel=tcg -m 1536 -smp 2 -display none -vga std \
  -monitor tcp:127.0.0.1:4555,server,nowait \
  -serial file:"$TMP/serial.log" \
  -kernel "$TMP/vmlinuz" -initrd "$TMP/initrd.img" \
  -append "boot=live components hostname=resoarcos username=resoarc live-config.nocomponents=xinit systemd.debug-shell=1 console=tty0" \
  -cdrom "$ISO" -nic none -no-reboot -no-shutdown >"$TMP/qemu.log" 2>&1 &
QPID=$!
echo "QEMU GUI debug VM running PID=$QPID, access container-local HMP 127.0.0.1:4555"
sleep 480
echo "QEMU test window finished; VM will be terminated."
