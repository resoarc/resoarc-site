#!/usr/bin/env python3
"""Test headless -> on-demand GUI on a disposable, completely offline QEMU guest.

Loads ISO kernel/initrd directly (firmware/installer not tested). Assumes Debian
live-config's test-only console autologin and sends "resogui" via QEMU HMP.
No debug root shell, login credentials, or guest network are enabled.
"""
import argparse
import json
import os
import pathlib
import socket
import subprocess
import tempfile
import time

PORT = 4555


def monitor(command: str) -> str:
    with socket.create_connection(("127.0.0.1", PORT), timeout=8) as sock:
        sock.settimeout(5)
        sock.recv(4096)
        sock.sendall((command + "\n").encode("ascii"))
        time.sleep(0.4)
        data = sock.recv(32768)
        return data.decode("utf-8", "replace")


def wait_monitor(deadline: float) -> None:
    while time.monotonic() < deadline:
        try:
            monitor("info status")
            return
        except (ConnectionError, TimeoutError, OSError):
            time.sleep(2)
    raise TimeoutError("QEMU monitor did not start")


def white_ratio(path: pathlib.Path) -> float:
    # QEMU may acknowledge screendump before the multi-megabyte PPM is flushed.
    # Do not incorrectly reject a healthy VM because a screenshot is still writing.
    last_problem = "Screenshot not complete"
    for _ in range(40):
        try:
            with path.open("rb") as f:
                if f.readline().strip() != b"P6":
                    raise ValueError("Unexpected screenshot format")
                dimensions = f.readline().split()
                while dimensions and dimensions[0].startswith(b"#"):
                    dimensions = f.readline().split()
                width, height = map(int, dimensions)
                if int(f.readline()) != 255:
                    raise ValueError("Unsupported PPM bit depth")
                data = f.read()
            if len(data) != width * height * 3:
                last_problem = f"PPM still writing: {len(data)} of {width * height * 3} bytes"
            else:
                n = 0
                bright = 0
                for offset in range(0, len(data), 3 * 31):
                    r, g, b = data[offset:offset+3]
                    n += 1
                    bright += (r > 220 and g > 220 and b > 220)
                return bright / n
        except (FileNotFoundError, ValueError) as error:
            last_problem = str(error)
        time.sleep(.25)
    raise RuntimeError("Screenshot could not be read: " + last_problem)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("iso", type=pathlib.Path)
    parser.add_argument("--out-dir", type=pathlib.Path, default=pathlib.Path("/results"))
    parser.add_argument("--boot-wait", type=int, default=170)
    parser.add_argument("--gui-wait", type=int, default=35)
    args = parser.parse_args()
    if args.boot_wait < 30 or args.gui_wait < 10:
        parser.error("Wait periods too small")
    if not args.iso.is_file():
        parser.error("ISO not found")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="resoarc-qemu-") as tmp:
        temp = pathlib.Path(tmp)
        subprocess.run(
            ["xorriso", "-osirrox", "on", "-indev", str(args.iso),
             "-extract", "/live/vmlinuz", str(temp / "vmlinuz"),
             "-extract", "/live/initrd.img", str(temp / "initrd.img")],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True, timeout=90)
        command = [
            "qemu-system-x86_64", "-machine", "pc,accel=tcg",
            "-smp", "2", "-m", "1536", "-display", "none", "-vga", "std",
            "-monitor", f"tcp:127.0.0.1:{PORT},server,nowait",
            "-serial", f"file:{temp / 'serial.log'}",
            "-kernel", str(temp / "vmlinuz"),
            "-initrd", str(temp / "initrd.img"),
            "-append", "boot=live components hostname=resoarcos username=resoarc live-config.nocomponents=xinit console=tty0",
            "-cdrom", str(args.iso), "-nic", "none", "-no-reboot", "-no-shutdown",
        ]
        with (temp / "qemu-process.log").open("wb") as qlog:
            proc = subprocess.Popen(command, stdout=qlog, stderr=subprocess.STDOUT)
            try:
                wait_monitor(time.monotonic() + 30)
                time.sleep(args.boot_wait)
                if proc.poll() is not None:
                    raise RuntimeError("QEMU stopped before CLI inspection")
                before = args.out_dir / "resoarc-headless-before.ppm"
                after = args.out_dir / "resoarc-gui-after.ppm"
                output = monitor(f"screendump {before}")
                if "Error" in output:
                    raise RuntimeError(output)
                before_ratio = white_ratio(before)
                # Never enter 'resogui' until we have the expected low-activity CLI screen.
                if before_ratio > .09:
                    raise RuntimeError(f"Desktop may have auto-started: bright pixels={before_ratio:.3f}")
                for letter in "resogui":
                    monitor("sendkey " + letter)
                    time.sleep(.09)
                monitor("sendkey ret")
                time.sleep(args.gui_wait)
                output = monitor(f"screendump {after}")
                if "Error" in output:
                    raise RuntimeError(output)
                after_ratio = white_ratio(after)
                verdict = {
                    "cli_bright_fraction": round(before_ratio, 4),
                    "gui_bright_fraction": round(after_ratio, 4),
                    "gui_visible": after_ratio > max(.08, before_ratio * 4),
                    "note": "QEMU direct-kernel boot; visual heuristic for visible xterm, not full GUI usability",
                }
                (args.out_dir / "resoarc-gui-qa.json").write_text(json.dumps(verdict, indent=2) + "\n")
                print(json.dumps(verdict))
                if not verdict["gui_visible"]:
                    raise RuntimeError("GUI screenshot did not change to a visible terminal")
                print("RESOARC_HEADLESS_GUI_QEMU_PASS")
                return 0
            finally:
                proc.terminate()
                try:
                    proc.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=8)


if __name__ == "__main__":
    raise SystemExit(main())