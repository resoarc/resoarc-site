#!/usr/bin/env python3
"""Read-only Raspberry Pi SD image layout verifier (standard library only)."""
from __future__ import annotations

import argparse
from pathlib import Path
import struct
import sys


def read_at(fp, offset: int, count: int) -> bytes:
    fp.seek(offset)
    data = fp.read(count)
    if len(data) != count:
        raise ValueError(f"Truncated image at byte {offset}")
    return data


def get_partitions(mbr: bytes) -> list[tuple[int, int, int]]:
    if len(mbr) != 512 or mbr[510:] != b"\x55\xaa":
        raise ValueError("Invalid MBR sector signature")
    partitions = []
    for i in range(4):
        start = 446 + 16 * i
        ptype = mbr[start + 4]
        lba, sectors = struct.unpack_from("<II", mbr, start + 8)
        if ptype and sectors:
            partitions.append((ptype, lba, sectors))
    if len(partitions) != 2:
        raise ValueError("Expected exactly two MBR partitions")
    if partitions[0][0] not in (0x0B, 0x0C) or partitions[1][0] != 0x83:
        raise ValueError("Expected FAT32 boot and Linux root partitions")
    a, b = partitions
    if a[1] == 0 or a[1] + a[2] > b[1]:
        raise ValueError("Overlapping or invalid partitions")
    return partitions


def fat32_root(fp, start_bytes: int) -> tuple[dict[str, tuple[int, int]], dict]:
    sector = read_at(fp, start_bytes, 512)
    if sector[510:] != b"\x55\xaa":
        raise ValueError("Invalid FAT boot-sector signature")
    bps = struct.unpack_from("<H", sector, 11)[0]
    spc = sector[13]
    reserved = struct.unpack_from("<H", sector, 14)[0]
    count = sector[16]
    fat_size = struct.unpack_from("<I", sector, 36)[0]
    root_cluster = struct.unpack_from("<I", sector, 44)[0]
    if bps != 512 or spc not in (1, 2, 4, 8, 16, 32, 64, 128):
        raise ValueError("Unexpected FAT bytes per sector or cluster")
    if count not in (1, 2) or not fat_size or root_cluster < 2:
        raise ValueError("Invalid FAT32 geometry")
    fat_start = start_bytes + reserved * bps
    data_start = fat_start + count * fat_size * bps

    def next_cluster(n: int) -> int:
        return struct.unpack("<I", read_at(fp, fat_start + n * 4, 4))[0] & 0x0FFFFFFF

    def chain(n: int, max_clusters: int):
        visited = set()
        while 2 <= n < 0x0FFFFFF8:
            if n in visited or len(visited) >= max_clusters:
                raise ValueError("Invalid cyclic or excessive FAT chain")
            visited.add(n)
            yield read_at(fp, data_start + (n - 2) * spc * bps, spc * bps)
            n = next_cluster(n)
    filenames: dict[str, tuple[int, int]] = {}
    lfn_parts: list[str] = []
    for cluster in chain(root_cluster, 128):
        for start in range(0, len(cluster), 32):
            entry = cluster[start:start + 32]
            if entry[0] == 0:
                return filenames, {"bps": bps, "sectors_per_cluster": spc, "data_start": data_start}
            if entry[0] == 0xE5:
                lfn_parts.clear()
                continue
            attribute = entry[11]
            if attribute == 0x0F:
                # Windows FAT long file names: up to 13 UTF-16 codepoints per entry.
                part = entry[1:11] + entry[14:26] + entry[28:32]
                lfn_parts.insert(0, part.decode("utf-16le", errors="replace").split("\x00")[0].rstrip("\uffff"))
                continue
            short = entry[:8].decode("ascii", errors="replace").strip()
            ext = entry[8:11].decode("ascii", errors="replace").strip()
            name = "".join(lfn_parts) if lfn_parts else short + ("." + ext if ext else "")
            lfn_parts.clear()
            if not (attribute & 0x08):
                filenames[name.casefold()] = (struct.unpack_from("<I", entry, 28)[0], attribute)
    raise ValueError("No terminal FAT32 directory entry")


def inspect(path: Path) -> dict:
    size = path.stat().st_size
    with path.open("rb") as fp:
        partitions = get_partitions(read_at(fp, 0, 512))
        for ptype, lba, count in partitions:
            if (lba + count) * 512 > size:
                raise ValueError("Partition extends past IMG file end")
        boot, root = partitions
        root_magic = read_at(fp, root[1] * 512 + 1024 + 56, 2)
        if root_magic != b"\x53\xef":
            raise ValueError("Missing ext-family filesystem superblock")
        # Pi 4 uses a 4 KiB kernel page size; Pi 5's 2712 kernel uses
        # 16 KiB pages. An ext4 block larger than PAGE_SIZE cannot mount.
        shift = struct.unpack("<I", read_at(fp, root[1] * 512 + 1024 + 24, 4))[0]
        if shift > 4:
            raise ValueError("Invalid ext4 block-size exponent")
        block_size = 1024 << shift
        expected = 4096 if "pi4" in path.name else 16384 if "pi5" in path.name else None
        if expected and block_size != expected:
            raise ValueError(f"Unexpected ext4 block size for {path.name}: {block_size}, expected {expected}")
        filenames, geometry = fat32_root(fp, boot[1] * 512)
        required = ("config.txt", "cmdline.txt")
        if "pi5" in path.name:
            required += ("kernel_2712.img", "bcm2712-rpi-5-b.dtb")
        elif "pi4" in path.name:
            required += ("kernel8.img", "bcm2711-rpi-4-b.dtb")
        missing = [name for name in required if name not in filenames]
        if missing:
            raise ValueError("Missing Raspberry Pi boot config files: " + ", ".join(missing))
    return {
        "size": size,
        "boot_lba": boot[1],
        "boot_bytes": boot[2] * 512,
        "root_lba": root[1],
        "root_bytes": root[2] * 512,
        "root_ext4_block_size": block_size,
        "fat_bps": geometry["bps"],
        "boot_root_names": sorted(filenames),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path)
    args = parser.parse_args()
    try:
        result = inspect(args.image)
        for key, value in result.items():
            print(f"{key}: {value}")
        print("PASS: Raspberry Pi FAT boot / ext4 root layout")
        return 0
    except (OSError, ValueError) as exc:
        print("FAIL:", exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
