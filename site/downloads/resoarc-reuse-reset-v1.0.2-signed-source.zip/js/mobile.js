/* SPDX-FileCopyrightText: 2026 ResoArc Open Technology Project
 * SPDX-License-Identifier: MIT
 * Mobile Kintone API version. UI and data changes remain scoped to the current app. */
(function(){'use strict';
const stored=kintone.plugin.app.getConfig(kintone.$PLUGIN_ID)||{};
let cfg={};try{cfg=JSON.parse(stored.ra_settings||'{}')}catch(_){}
cfg=Object.assign({},{"fields": "Date,Status"},cfg);
const on=(events,cb)=>kintone.events.on(events,cb);
const parse=s=>String(s||'').split(',').map(x=>x.trim()).filter(Boolean);
const el=(tag,content)=>{const x=document.createElement(tag);if(content!==undefined)x.textContent=String(content);return x;};
const btn=(label,fn)=>{const x=el('button',label);x.type='button';x.className='ra-mini-button';x.style.cssText='background:#176c68;color:white;border:none;border-radius:5px;padding:7px 11px;margin:3px;cursor:pointer';x.addEventListener('click',fn);return x;};
const panel=()=>{let space=null;try{space=kintone.mobile.app.getHeaderSpaceElement?.();}catch(_){}if(!space)return null;let x=document.getElementById('ra-mini-'+"reuse-reset");if(x){x.replaceChildren();return x;}x=el('div');x.id='ra-mini-'+"reuse-reset";x.style.cssText='display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin:8px 0;padding:7px;border:1px solid #bbd8d2;border-radius:6px;background:#f6fbfa;color:#1e4240';space.appendChild(x);return x;};
const cur=()=>{try{return kintone.mobile.app.record.get()?.record||null;}catch(_){return null;}};
const val=(r,k)=>r?.[k]?.value;
const scalar=x=>x==null?'':Array.isArray(x)?x.map(v=>v.name||v.code||String(v)).join(', '):String(x);
const template=(t,r,encode=false)=>String(t??'').replace(/\{\{([A-Za-z0-9_]+)\}\}/g,(_,k)=>encode?encodeURIComponent(scalar(val(r,k))):scalar(val(r,k)));
const set=(r,k,value)=>{const item=r?.[k];if(!item||['CALC','RECORD_NUMBER','CREATED_TIME','UPDATED_TIME','CREATOR','MODIFIER','STATUS','STATUS_ASSIGNEE','FILE','SUBTABLE','REFERENCE_TABLE','CATEGORY'].includes(item.type))return false;
const arrays=['CHECK_BOX','MULTI_SELECT','USER_SELECT','ORGANIZATION_SELECT','GROUP_SELECT'];
if(arrays.includes(item.type)){if(!Array.isArray(value))return false;}
else if(value!==null&&typeof value==='object')return false;
item.value=value;return true;};
const apply=r=>{try{kintone.mobile.app.record.set({record:r});return true;}catch(err){console.warn('[ResoArc Mini]',err);return false;}};
// Another create.show handler may overwrite reuse fields depending on load order.
const clearReuseValue=(entry)=>{
  if(!entry)return false;
  if(entry.type==='SUBTABLE' || ['CHECK_BOX','MULTI_SELECT','USER_SELECT','ORGANIZATION_SELECT','GROUP_SELECT','FILE'].includes(entry.type)) entry.value=[];
  else if(['SINGLE_LINE_TEXT','MULTI_LINE_TEXT','RICH_TEXT','LINK','NUMBER'].includes(entry.type)) entry.value='';
  else if(['CALC','RECORD_NUMBER','CREATED_TIME','UPDATED_TIME','CREATOR','MODIFIER','STATUS','STATUS_ASSIGNEE','REFERENCE_TABLE','CATEGORY'].includes(entry.type))return false;
  else entry.value=null;
  return true;
};
let reuseOriginals=new Map();
let reuseGeneration=0;
on('mobile.app.record.create.show',e=>{
  const currentGeneration=++reuseGeneration;
  reuseOriginals=new Map();
  if(!e.reuse)return e;
  const previous=reuseOriginals;
  for(const code of parse(cfg.fields)){
    const entry=e.record?.[code];
    if(!entry)continue;
    const old=JSON.stringify(entry.value);
    if(clearReuseValue(entry)&&JSON.stringify(entry.value)!==old)previous.set(code,old);
  }
  const locationAtShow=location.pathname+location.search;
  const reconcile=()=>{
    // Never allow a previous reused record's delayed timer to modify this one.
    if(currentGeneration!==reuseGeneration)return;
    if(location.pathname+location.search!==locationAtShow)return;
    try{
      const now=cur();
      if(!now)return;
      let changed=false;
      for(const [code,old] of previous){
        const entry=now[code];
        if(!entry||JSON.stringify(entry.value)!==old)continue;
        if(clearReuseValue(entry))changed=true;
      }
      if(changed)apply(now);
    }catch(err){console.warn('[ResoArc reuse-reset] Reconciliation failed:',err);}
  };
  [0,120,350,800,1600].forEach(ms=>setTimeout(reconcile,ms));
  return e;
});

// Last line of defense if another plugin reintroduces reused values after hydration.
on('mobile.app.record.create.submit',e=>{
  for(const [code,old] of reuseOriginals){
    const entry=e.record?.[code];
    if(entry && JSON.stringify(entry.value)===old)clearReuseValue(entry);
  }
  return e;
});

})();
