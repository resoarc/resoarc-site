# LICENSE / NOTICE: ResoArc Backup & Migration v1.0.0

- ResoArcの実装・ガイドはMIT License。正本は`LICENSE`を参照。
- 実行時に同梱する`fflate 0.8.3`はMIT License。著作権は原著作権者に帰属し、全文を`LICENSES/fflate-MIT.txt`に同梱。ビルドされたJSの先頭にも表示。
- `esbuild 0.25.12`はビルド時のみ利用するMITツール。配布JSに実行時同梱しない。
- kintoneはサイボウズ株式会社の商標です。本製品はResoArcによる独立開発であり、サイボウズ公式提供・認定製品を意味しません。
- v1.0.0はkintoneカスタマイズJS+閲覧ツールの配布形式。署名付きkintoneプラグインIDを持つZIPではなく、ZIPのSHA-256は破損・改変検出用で署名とは異なります。
- ソースコードは公式配布ページから別途ダウンロードできるSOURCE ZIPをご参照ください。リリース状況はResoArc公式サイトでご確認ください。
