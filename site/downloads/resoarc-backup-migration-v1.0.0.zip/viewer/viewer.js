/* ResoArc kintone Archive v1.0.0 (local-first distribution) MIT
Bundled fflate 0.8.3 under MIT license:
MIT License

Copyright (c) 2026 Arjun Barrett

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
(() => {
  // node_modules/fflate/esm/browser.js
  var u8 = Uint8Array;
  var u16 = Uint16Array;
  var i32 = Int32Array;
  var fleb = new u8([
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    0,
    /* unused */
    0,
    0,
    /* impossible */
    0
  ]);
  var fdeb = new u8([
    0,
    0,
    0,
    0,
    1,
    1,
    2,
    2,
    3,
    3,
    4,
    4,
    5,
    5,
    6,
    6,
    7,
    7,
    8,
    8,
    9,
    9,
    10,
    10,
    11,
    11,
    12,
    12,
    13,
    13,
    /* unused */
    0,
    0
  ]);
  var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
  var freb = function(eb, start) {
    var b = new u16(31);
    for (var i = 0; i < 31; ++i) {
      b[i] = start += 1 << eb[i - 1];
    }
    var r = new i32(b[30]);
    for (var i = 1; i < 30; ++i) {
      for (var j = b[i]; j < b[i + 1]; ++j) {
        r[j] = j - b[i] << 5 | i;
      }
    }
    return { b, r };
  };
  var _a = freb(fleb, 2);
  var fl = _a.b;
  var revfl = _a.r;
  fl[28] = 258, revfl[258] = 28;
  var _b = freb(fdeb, 0);
  var fd = _b.b;
  var revfd = _b.r;
  var rev = new u16(32768);
  for (i = 0; i < 32768; ++i) {
    x = (i & 43690) >> 1 | (i & 21845) << 1;
    x = (x & 52428) >> 2 | (x & 13107) << 2;
    x = (x & 61680) >> 4 | (x & 3855) << 4;
    rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
  }
  var x;
  var i;
  var hMap = (function(cd, mb, r) {
    var s = cd.length;
    var i = 0;
    var l = new u16(mb);
    for (; i < s; ++i) {
      if (cd[i])
        ++l[cd[i] - 1];
    }
    var le = new u16(mb);
    for (i = 1; i < mb; ++i) {
      le[i] = le[i - 1] + l[i - 1] << 1;
    }
    var co;
    if (r) {
      co = new u16(1 << mb);
      var rvb = 15 - mb;
      for (i = 0; i < s; ++i) {
        if (cd[i]) {
          var sv = i << 4 | cd[i];
          var r_1 = mb - cd[i];
          var v = le[cd[i] - 1]++ << r_1;
          for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
            co[rev[v] >> rvb] = sv;
          }
        }
      }
    } else {
      co = new u16(s);
      for (i = 0; i < s; ++i) {
        if (cd[i]) {
          co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
        }
      }
    }
    return co;
  });
  var flt = new u8(288);
  for (i = 0; i < 144; ++i)
    flt[i] = 8;
  var i;
  for (i = 144; i < 256; ++i)
    flt[i] = 9;
  var i;
  for (i = 256; i < 280; ++i)
    flt[i] = 7;
  var i;
  for (i = 280; i < 288; ++i)
    flt[i] = 8;
  var i;
  var fdt = new u8(32);
  for (i = 0; i < 32; ++i)
    fdt[i] = 5;
  var i;
  var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
  var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
  var max = function(a) {
    var m = a[0];
    for (var i = 1; i < a.length; ++i) {
      if (a[i] > m)
        m = a[i];
    }
    return m;
  };
  var bits = function(d, p, m) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
  };
  var bits16 = function(d, p) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
  };
  var shft = function(p) {
    return (p + 7) / 8 | 0;
  };
  var slc = function(v, s, e) {
    if (s == null || s < 0)
      s = 0;
    if (e == null || e > v.length)
      e = v.length;
    return new u8(v.subarray(s, e));
  };
  var ec = [
    "unexpected EOF",
    "invalid block type",
    "invalid length/literal",
    "invalid distance",
    "stream finished",
    "no stream handler",
    ,
    // determined by compression function
    "no callback",
    "invalid UTF-8 data",
    "extra field too long",
    "date not in range 1980-2099",
    "filename too long",
    "stream finishing",
    "invalid zip data"
    // determined by unknown compression method
  ];
  var err = function(ind, msg, nt) {
    var e = new Error(msg || ec[ind]);
    e.code = ind;
    if (Error.captureStackTrace)
      Error.captureStackTrace(e, err);
    if (!nt)
      throw e;
    return e;
  };
  var inflt = function(dat, st, buf, dict) {
    var sl = dat.length, dl = dict ? dict.length : 0;
    if (!sl || st.f && !st.l)
      return buf || new u8(0);
    var noBuf = !buf;
    var resize = noBuf || st.i != 2;
    var noSt = st.i;
    if (noBuf)
      buf = new u8(sl * 3);
    var cbuf = function(l2) {
      var bl = buf.length;
      if (l2 > bl) {
        var nbuf = new u8(Math.max(bl * 2, l2));
        nbuf.set(buf);
        buf = nbuf;
      }
    };
    var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
    var tbts = sl * 8;
    do {
      if (!lm) {
        final = bits(dat, pos, 1);
        var type = bits(dat, pos + 1, 3);
        pos += 3;
        if (!type) {
          var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
          if (t > sl) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + l);
          buf.set(dat.subarray(s, t), bt);
          st.b = bt += l, st.p = pos = t * 8, st.f = final;
          continue;
        } else if (type == 1)
          lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
        else if (type == 2) {
          var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
          var tl = hLit + bits(dat, pos + 5, 31) + 1;
          pos += 14;
          var ldt = new u8(tl);
          var clt = new u8(19);
          for (var i = 0; i < hcLen; ++i) {
            clt[clim[i]] = bits(dat, pos + i * 3, 7);
          }
          pos += hcLen * 3;
          var clb = max(clt), clbmsk = (1 << clb) - 1;
          var clm = hMap(clt, clb, 1);
          for (var i = 0; i < tl; ) {
            var r = clm[bits(dat, pos, clbmsk)];
            pos += r & 15;
            var s = r >> 4;
            if (s < 16) {
              ldt[i++] = s;
            } else {
              var c = 0, n = 0;
              if (s == 16)
                n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
              else if (s == 17)
                n = 3 + bits(dat, pos, 7), pos += 3;
              else if (s == 18)
                n = 11 + bits(dat, pos, 127), pos += 7;
              while (n--)
                ldt[i++] = c;
            }
          }
          var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
          lbt = max(lt);
          dbt = max(dt);
          lm = hMap(lt, lbt, 1);
          dm = hMap(dt, dbt, 1);
        } else
          err(1);
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
      }
      if (resize)
        cbuf(bt + 131072);
      var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
      var lpos = pos;
      for (; ; lpos = pos) {
        var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
        pos += c & 15;
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (!c)
          err(2);
        if (sym < 256)
          buf[bt++] = sym;
        else if (sym == 256) {
          lpos = pos, lm = null;
          break;
        } else {
          var add = sym - 254;
          if (sym > 264) {
            var i = sym - 257, b = fleb[i];
            add = bits(dat, pos, (1 << b) - 1) + fl[i];
            pos += b;
          }
          var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
          if (!d)
            err(3);
          pos += d & 15;
          var dt = fd[dsym];
          if (dsym > 3) {
            var b = fdeb[dsym];
            dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
          }
          if (pos > tbts) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + 131072);
          var end = bt + add;
          if (bt < dt) {
            var shift = dl - dt, dend = Math.min(dt, end);
            if (shift + bt < 0)
              err(3);
            for (; bt < dend; ++bt)
              buf[bt] = dict[shift + bt];
          }
          for (; bt < end; ++bt)
            buf[bt] = buf[bt - dt];
        }
      }
      st.l = lm, st.p = lpos, st.b = bt, st.f = final;
      if (lm)
        final = 1, st.m = lbt, st.d = dm, st.n = dbt;
    } while (!final);
    return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
  };
  var et = /* @__PURE__ */ new u8(0);
  var b2 = function(d, b) {
    return d[b] | d[b + 1] << 8;
  };
  var b4 = function(d, b) {
    return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
  };
  var b8 = function(d, b) {
    return b4(d, b) + b4(d, b + 4) * 4294967296;
  };
  function inflateSync(data, opts) {
    return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
  }
  var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
  var tds = 0;
  try {
    td.decode(et, { stream: true });
    tds = 1;
  } catch (e) {
  }
  var dutf8 = function(d) {
    for (var r = "", i = 0; ; ) {
      var c = d[i++];
      var eb = (c > 127) + (c > 223) + (c > 239);
      if (i + eb > d.length)
        return { s: r, r: slc(d, i - 1) };
      if (!eb)
        r += String.fromCharCode(c);
      else if (eb == 3) {
        c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | d[i++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
      } else if (eb & 1)
        r += String.fromCharCode((c & 31) << 6 | d[i++] & 63);
      else
        r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | d[i++] & 63);
    }
  };
  function strFromU8(dat, latin1) {
    if (latin1) {
      var r = "";
      for (var i = 0; i < dat.length; i += 16384)
        r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
      return r;
    } else if (td) {
      return td.decode(dat);
    } else {
      var _a2 = dutf8(dat), s = _a2.s, r = _a2.r;
      if (r.length)
        err(8);
      return s;
    }
  }
  var slzh = function(d, b) {
    return b + 30 + b2(d, b + 26) + b2(d, b + 28);
  };
  var zh = function(d, b, z) {
    var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
    var _a2 = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a2[0], su = _a2[1], off = _a2[2];
    return [b2(d, b + 10), sc, su, fn, es + efl + b2(d, b + 32), off];
  };
  var z64hs = function(d, b, l, z, sc, su, off) {
    var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
    var nf = nsc + nsu + noff;
    if (z && nf) {
      for (; b + 4 < e; b += 4 + b2(d, b + 2)) {
        if (b2(d, b) == 1) {
          return [
            nsc ? b8(d, b + 4 + 8 * nsu) : sc,
            nsu ? b8(d, b + 4) : su,
            noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
            1
          ];
        }
      }
      if (z < 2)
        err(13);
    }
    return [sc, su, off, 0];
  };
  function unzipSync(data, opts) {
    var files = {};
    var e = data.length - 22;
    for (; b4(data, e) != 101010256; --e) {
      if (!e || data.length - e > 65558)
        err(13);
    }
    ;
    var c = b2(data, e + 8);
    if (!c)
      return {};
    var o = b4(data, e + 16);
    var z = b4(data, e - 20) == 117853008;
    if (z) {
      var ze = b4(data, e - 12);
      z = b4(data, ze) == 101075792;
      if (z) {
        c = b4(data, ze + 32);
        o = b4(data, ze + 48);
      }
    }
    var fltr = opts && opts.filter;
    for (var i = 0; i < c; ++i) {
      var _a2 = zh(data, o, z), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn = _a2[3], no = _a2[4], off = _a2[5], b = slzh(data, off);
      o = no;
      if (!fltr || fltr({
        name: fn,
        size: sc,
        originalSize: su,
        compression: c_2
      })) {
        if (!c_2)
          files[fn] = slc(data, b, b + sc);
        else if (c_2 == 8)
          files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
        else
          err(14, "unknown compression type " + c_2);
      }
    }
    return files;
  }

  // src/core.js
  var FORMAT = "resoarc.kintone.backup";
  var MAX_BYTES = 25 * 1024 * 1024;
  var MAX_RECORDS = 2e4;
  var MAX_ZIP_ENTRIES = 5e4;
  var WRITABLE = /* @__PURE__ */ new Set(["SINGLE_LINE_TEXT", "MULTI_LINE_TEXT", "RICH_TEXT", "NUMBER", "RADIO_BUTTON", "DROP_DOWN", "CHECK_BOX", "MULTI_SELECT", "DATE", "TIME", "DATETIME", "LINK", "USER_SELECT", "ORGANIZATION_SELECT", "GROUP_SELECT", "FILE"]);
  var RESERVED_CODES = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
  var u82 = (v) => v instanceof Uint8Array ? v : new Uint8Array(v);
  var stop = (reason) => {
    throw new Error(reason);
  };
  var sha256 = async (b) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", u82(b)))).map((v) => v.toString(16).padStart(2, "0")).join("");
  var allowedField = (d) => !!d && WRITABLE.has(d.type) && !d.lookup && !d.referenceTable && !(d.type === "SINGLE_LINE_TEXT" && typeof d.expression === "string" && d.expression.trim());
  var obj = (v) => v && typeof v === "object" && !Array.isArray(v);
  function fieldContents(props) {
    const fields = /* @__PURE__ */ Object.create(null);
    for (const [code, def] of Object.entries(props || {})) {
      if (RESERVED_CODES.has(code)) stop("\u4E88\u7D04\u6E08\u307F\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u30B3\u30FC\u30C9\u306F\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3067\u304D\u307E\u305B\u3093: " + code);
      if (def?.type === "SUBTABLE") {
        const members = fieldContents(def.fields);
        if (Object.keys(members).length) fields[code] = { type: "SUBTABLE", fields: members };
      } else if (allowedField(def)) fields[code] = { type: def.type };
    }
    return fields;
  }
  var writableSchema = (raw) => fieldContents(raw?.properties || raw);
  function validatePortableSchema(schema, nested = false) {
    if (!obj(schema)) stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059");
    for (const [code, def] of Object.entries(schema)) {
      if (RESERVED_CODES.has(code) || !code || code.length > 128)
        stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u306B\u4E0D\u6B63\u306A\u30D5\u30A3\u30FC\u30EB\u30C9\u30B3\u30FC\u30C9\u304C\u3042\u308A\u307E\u3059: " + code);
      if (!obj(def)) stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u5B9A\u7FA9\u304C\u4E0D\u6B63\u3067\u3059: " + code);
      if (def.type === "SUBTABLE") {
        if (nested) stop("\u30C6\u30FC\u30D6\u30EB\u306E\u5165\u308C\u5B50\u306F\u672A\u5BFE\u5FDC\u3067\u3059");
        validatePortableSchema(def.fields, true);
      } else if (!WRITABLE.has(def.type)) stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u7A2E\u5225\u304C\u4E0D\u6B63\u3067\u3059: " + code);
    }
  }
  function validatePortableRecord(record, schema, location = "record") {
    if (!obj(record)) stop("\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u306E\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059: " + location);
    const scalar = /* @__PURE__ */ new Set(["SINGLE_LINE_TEXT", "MULTI_LINE_TEXT", "RICH_TEXT", "RADIO_BUTTON", "DROP_DOWN", "DATE", "TIME", "DATETIME", "LINK"]);
    const multi = /* @__PURE__ */ new Set(["CHECK_BOX", "MULTI_SELECT"]);
    const codes = /* @__PURE__ */ new Set(["USER_SELECT", "ORGANIZATION_SELECT", "GROUP_SELECT"]);
    for (const [code, payload] of Object.entries(record)) {
      if (!Object.hasOwn(schema, code)) stop("\u5B9A\u7FA9\u3055\u308C\u3066\u3044\u306A\u3044\u30EC\u30B3\u30FC\u30C9\u9805\u76EE\u304C\u3042\u308A\u307E\u3059: " + location + "." + code);
      if (!obj(payload) || !Object.hasOwn(payload, "value"))
        stop("\u30EC\u30B3\u30FC\u30C9\u9805\u76EE\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + location + "." + code);
      const def = schema[code];
      const value = payload.value;
      const where = location + "." + code;
      if (def.type === "SUBTABLE") {
        if (!Array.isArray(value)) stop("\u30C6\u30FC\u30D6\u30EB\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
        for (const [i, row] of value.entries()) {
          if (!obj(row) || !obj(row.value) || Object.keys(row).some((k) => k !== "value"))
            stop("\u30C6\u30FC\u30D6\u30EB\u884C\u306E\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059: " + where + "[" + i + "]");
          validatePortableRecord(row.value, def.fields, where + "[" + i + "]");
        }
      } else if (def.type === "FILE") {
        if (!Array.isArray(value)) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u9805\u76EE\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
        for (const item of value) {
          if (!obj(item) || typeof item.ref !== "string" || !/^[0-9a-f]{64}$/.test(item.ref) || typeof item.name !== "string" || typeof item.contentType !== "string" || !Number.isSafeInteger(item.size) || item.size < 0 || Object.hasOwn(item, "fileKey"))
            stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u53C2\u7167\u306E\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059: " + where);
        }
      } else if (multi.has(def.type)) {
        if (!Array.isArray(value) || value.some((x) => typeof x !== "string"))
          stop("\u8907\u6570\u9078\u629E\u30D5\u30A3\u30FC\u30EB\u30C9\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      } else if (codes.has(def.type)) {
        if (!Array.isArray(value) || value.some((x) => !obj(x) || typeof x.code !== "string"))
          stop("\u30E6\u30FC\u30B6\u30FC\u30FB\u7D44\u7E54\u30FB\u30B0\u30EB\u30FC\u30D7\u9805\u76EE\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      } else if (def.type === "NUMBER") {
        if (value !== null && typeof value !== "string" && typeof value !== "number")
          stop("\u6570\u5024\u30D5\u30A3\u30FC\u30EB\u30C9\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      } else if (scalar.has(def.type)) {
        if (value !== null && typeof value !== "string")
          stop("\u6587\u5B57\u5217\u30FB\u65E5\u4ED8\u30D5\u30A3\u30FC\u30EB\u30C9\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      }
    }
  }
  function visitFiles(rec, schema, visit) {
    for (const [code, def] of Object.entries(schema)) {
      const val = rec[code]?.value;
      if (def.type === "FILE" && Array.isArray(val)) {
        for (const f of val) visit(f);
      } else if (def.type === "SUBTABLE" && Array.isArray(val)) {
        for (const row of val) visitFiles(row.value, def.fields, visit);
      }
    }
  }
  var checkPath = (name) => {
    if (!/^(manifest\.json|schema\/(fields|layout|source-fields|settings|coverage)\.json|data\/(records|source-meta)\.jsonl|attachments\/[0-9a-f]{64})$/.test(name)) stop("ZIP\u5185\u306E\u4E0D\u6B63\u306A\u30D1\u30B9: " + name);
  };
  function sizeCheck(bytes, limit = MAX_BYTES) {
    if (bytes > limit) stop("\u5BB9\u91CF\u4E0A\u9650\uFF0825MiB\uFF09\u3092\u8D85\u3048\u307E\u3057\u305F\u3002\u5B89\u5168\u306E\u305F\u3081\u51E6\u7406\u3092\u4E2D\u6B62\u3057\u307E\u3059");
  }
  async function inspectArchive(zipInput, { expectedHash, maxBytes = MAX_BYTES, maxEntries = MAX_ZIP_ENTRIES } = {}) {
    if (!Number.isSafeInteger(maxEntries) || maxEntries < 1 || maxEntries > MAX_ZIP_ENTRIES) stop("ZIP\u5185\u306E\u30D5\u30A1\u30A4\u30EB\u6570\u4E0A\u9650\u304C\u4E0D\u6B63\u3067\u3059");
    const bytes = u82(zipInput);
    sizeCheck(bytes.byteLength, maxBytes);
    if (expectedHash && await sha256(bytes) !== expectedHash.toLowerCase()) stop("ZIP\u5168\u4F53\u306ESHA-256\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    let inflatedTotal = 0, entries, entryCount = 0;
    const seenPaths = /* @__PURE__ */ new Set();
    try {
      entries = unzipSync(bytes, { filter: (file) => {
        if (++entryCount > maxEntries) stop("ZIP\u5185\u306E\u30D5\u30A1\u30A4\u30EB\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F");
        checkPath(file.name);
        if (seenPaths.has(file.name)) stop("ZIP\u5185\u306B\u540C\u3058\u30D5\u30A1\u30A4\u30EB\u304C\u91CD\u8907\u3057\u3066\u3044\u307E\u3059: " + file.name);
        seenPaths.add(file.name);
        const n = Number(file.originalSize);
        if (!Number.isSafeInteger(n) || n < 0) stop("ZIP\u306E\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
        inflatedTotal += n;
        sizeCheck(inflatedTotal, maxBytes);
        return true;
      } });
    } catch (e) {
      throw new Error("ZIP\u5C55\u958B\u30FB\u691C\u8A3C\u306B\u5931\u6557\u3057\u307E\u3057\u305F: " + e.message);
    }
    const load = (path) => {
      if (!entries[path]) stop("\u5FC5\u9808\u30D5\u30A1\u30A4\u30EB\u304C\u3042\u308A\u307E\u305B\u3093: " + path);
      return strFromU8(entries[path]);
    };
    let manifest, schema, layout, sourceFields = null, records, settings = null, coverage = null, sourceMeta = null;
    try {
      manifest = JSON.parse(load("manifest.json"));
      schema = JSON.parse(load("schema/fields.json"));
      layout = JSON.parse(load("schema/layout.json"));
      const text = load("data/records.jsonl");
      records = text.trim() ? text.trimEnd().split("\n").map((line) => JSON.parse(line)) : [];
    } catch (e) {
      throw new Error("\u5185\u5BB9\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093: " + e.message);
    }
    if (manifest?.format !== FORMAT || ![1, 2, 3].includes(manifest?.version)) stop("\u672A\u5BFE\u5FDC\u306E\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u5F62\u5F0F\u3067\u3059");
    const expectedTextPaths = ["schema/fields.json", "schema/layout.json", "data/records.jsonl"];
    if (manifest.version >= 2) {
      try {
        sourceFields = JSON.parse(load("schema/source-fields.json"));
      } catch (e) {
        stop("v2\u5F62\u5F0F\u306E\u30D5\u30A9\u30FC\u30E0\u5B9A\u7FA9\u304C\u4E0D\u6B63\u3067\u3059: " + e.message);
      }
      if (!obj(sourceFields) || !obj(sourceFields.properties)) stop("\u30D5\u30A9\u30FC\u30E0\u5B9A\u7FA9\u304C\u4E0D\u6B63\u3067\u3059");
      expectedTextPaths.push("schema/source-fields.json");
    }
    if (manifest.version === 1 && entries["schema/source-fields.json"]) stop("v1\u5F62\u5F0F\u306B\u672A\u691C\u8A3C\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u8A2D\u5B9A\u304C\u3042\u308A\u307E\u3059");
    if (manifest.version === 3) {
      try {
        settings = JSON.parse(load("schema/settings.json"));
        coverage = JSON.parse(load("schema/coverage.json"));
        const text = load("data/source-meta.jsonl");
        sourceMeta = text.trim() ? text.trimEnd().split("\n").map((line) => JSON.parse(line)) : [];
      } catch (e) {
        stop("v3\u306E\u62E1\u5F35\u30C7\u30FC\u30BF\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093: " + e.message);
      }
      if (!obj(settings) || !obj(coverage) || !Array.isArray(sourceMeta) || sourceMeta.length !== records.length || sourceMeta.some((x) => !obj(x))) stop("v3\u306E\u30E1\u30BF\u30C7\u30FC\u30BF\u304C\u4E0D\u6B63\u3067\u3059");
      expectedTextPaths.push("schema/settings.json", "schema/coverage.json", "data/source-meta.jsonl");
    } else if (entries["schema/settings.json"] || entries["schema/coverage.json"] || entries["data/source-meta.jsonl"]) stop("\u65E7\u5F62\u5F0F\u306B\u672A\u691C\u8A3C\u306E\u62E1\u5F35\u30C7\u30FC\u30BF\u304C\u3042\u308A\u307E\u3059");
    if (!obj(schema) || !Array.isArray(records) || records.length > MAX_RECORDS || records.length !== manifest.recordCount) stop("\u4EF6\u6570\u307E\u305F\u306F\u30D5\u30A3\u30FC\u30EB\u30C9\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059");
    validatePortableSchema(schema);
    for (const p of expectedTextPaths) {
      if (await sha256(entries[p]) !== manifest.digests?.[p]) stop("\u5185\u5BB9\u306E\u30CF\u30C3\u30B7\u30E5\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093: " + p);
    }
    if (sourceFields && JSON.stringify(writableSchema(sourceFields)) !== JSON.stringify(schema))
      stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u3068\u5143\u30A2\u30D7\u30EA\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u5B9A\u7FA9\u304C\u77DB\u76FE\u3057\u3066\u3044\u307E\u3059");
    if (!Array.isArray(manifest.files)) stop("\u30D5\u30A1\u30A4\u30EB\u4E00\u89A7\u304C\u4E0D\u6B63\u3067\u3059");
    const manifestPaths = /* @__PURE__ */ new Set();
    for (const f of manifest.files) {
      if (!f || typeof f.path !== "string" || !/^attachments\/[0-9a-f]{64}$/.test(f.path) || manifestPaths.has(f.path)) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u4E00\u89A7\u304C\u4E0D\u6B63\u3067\u3059");
      manifestPaths.add(f.path);
      if (!entries[f.path] || entries[f.path].length !== f.size || await sha256(entries[f.path]) !== f.sha256 || f.path !== "attachments/" + f.sha256) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u6574\u5408\u6027\u30A8\u30E9\u30FC");
    }
    for (const p of Object.keys(entries)) {
      checkPath(p);
      if (p.startsWith("attachments/") && !manifestPaths.has(p)) stop("\u672A\u7533\u544A\u306E\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u304C\u3042\u308A\u307E\u3059");
    }
    for (const [index, r] of records.entries()) {
      validatePortableRecord(r, schema, "record[" + index + "]");
      visitFiles(r, schema, (f) => {
        if (!manifestPaths.has("attachments/" + f.ref)) stop("\u30EC\u30B3\u30FC\u30C9\u304C\u53C2\u7167\u3059\u308B\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u304C\u6B20\u843D\u3057\u3066\u3044\u307E\u3059");
      });
    }
    return { manifest, schema, layout, sourceFields, records, settings, coverage, sourceMeta, files: entries, archiveHash: await sha256(bytes) };
  }

  // src/encryption.js
  var MAGIC = new TextEncoder().encode("RAKENC01");
  var HEADER_SIZE = 40;
  var MIN_ITERATIONS = 31e4;
  var MAX_ITERATIONS = 2e6;
  var TAG_LEN = 16;
  var error = (reason) => {
    throw new Error(reason);
  };
  var toBytes = (value) => value instanceof Uint8Array ? value : new Uint8Array(value);
  var digest = () => globalThis.crypto?.subtle || error("\u3053\u306E\u74B0\u5883\u3067\u306FWeb Crypto\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093");
  function checkPassphrase(value) {
    if (typeof value !== "string" || value.length < 12 || value.length > 1024) error("\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u306F12\u301C1024\u6587\u5B57\u3067\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044");
    return new TextEncoder().encode(value);
  }
  function isEncryptedArchive(value) {
    const bytes = toBytes(value);
    return bytes.length >= MAGIC.length && MAGIC.every((b, i) => bytes[i] === b);
  }
  function isPotentialEncryptedArchive(value) {
    const bytes = toBytes(value);
    return bytes.length >= 4 && bytes[0] === 82 && bytes[1] === 65 && bytes[2] === 75 && bytes[3] === 69;
  }
  async function derive(passphrase, salt, iterations, usage) {
    const subtle = digest();
    const raw = checkPassphrase(passphrase);
    const key = await subtle.importKey("raw", raw, "PBKDF2", false, ["deriveKey"]);
    raw.fill(0);
    return subtle.deriveKey(
      { name: "PBKDF2", salt, iterations, hash: "SHA-256" },
      key,
      { name: "AES-GCM", length: 256 },
      false,
      [usage]
    );
  }
  async function decryptLocalArchive(envelope, passphrase) {
    const bytes = toBytes(envelope);
    if (bytes.length < HEADER_SIZE + TAG_LEN + 1 || bytes.length > HEADER_SIZE + TAG_LEN + MAX_BYTES)
      error("\u6697\u53F7\u5316\u30A2\u30FC\u30AB\u30A4\u30D6\u306E\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
    if (!isEncryptedArchive(bytes)) error("\u975E\u5BFE\u5FDC\u306E\u6697\u53F7\u5316\u30A2\u30FC\u30AB\u30A4\u30D6\u5F62\u5F0F\u3067\u3059");
    const header = bytes.slice(0, HEADER_SIZE);
    const iterations = new DataView(header.buffer).getUint32(36, false);
    if (iterations < MIN_ITERATIONS || iterations > MAX_ITERATIONS) error("\u9375\u5C0E\u51FA\u306E\u53CD\u5FA9\u56DE\u6570\u304C\u4E0D\u6B63\u3067\u3059");
    const key = await derive(passphrase, header.slice(8, 24), iterations, "decrypt");
    try {
      const plaintext = new Uint8Array(await digest().decrypt(
        {
          name: "AES-GCM",
          iv: header.slice(24, 36),
          additionalData: header,
          tagLength: 128
        },
        key,
        bytes.subarray(HEADER_SIZE)
      ));
      if (plaintext.length > MAX_BYTES) {
        plaintext.fill(0);
        error("\u5FA9\u53F7\u30C7\u30FC\u30BF\u304C\u5BB9\u91CF\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
      }
      return plaintext;
    } catch {
      error("\u5FA9\u53F7\u3067\u304D\u307E\u305B\u3093\u3002\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u304B\u30D5\u30A1\u30A4\u30EB\u306E\u5B8C\u5168\u6027\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
    }
  }

  // src/collection.js
  var COLLECTION_FORMAT = "resoarc.kintone.archive.collection";
  var COLLECTION_VERSION = 1;
  var MAX_PARTS = 256;
  var MAX_COLLECTION_RECORDS = 25e4;
  var MAX_COLLECTION_BYTES = 256 * 1024 * 1024;
  var encoder = new TextEncoder();
  var decoder = new TextDecoder();
  var fail = (reason) => {
    throw Error(reason);
  };
  var object = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
  var NAME = /^part-[0-9]{5}\.ra-kintone(?:\.enc)?$/;
  var sha = /^[0-9a-f]{64}$/;
  function pathName(i, encrypted) {
    return "part-" + String(i).padStart(5, "0") + ".ra-kintone" + (encrypted ? ".enc" : "");
  }
  function validateIndex(index) {
    if (!object(index) || index.format !== COLLECTION_FORMAT || index.version !== COLLECTION_VERSION)
      fail("\u672A\u5BFE\u5FDC\u306E\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u5F62\u5F0F\u3067\u3059");
    if (!Number.isSafeInteger(index.sourceAppId) || index.sourceAppId < 1 || !Number.isSafeInteger(index.recordCount) || index.recordCount < 0 || index.recordCount > MAX_COLLECTION_RECORDS || !Array.isArray(index.parts) || index.parts.length < 1 || index.parts.length > MAX_PARTS || typeof index.encrypted !== "boolean") fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u7D22\u5F15\u304C\u4E0D\u6B63\u3067\u3059");
    let expected = 0, total = 0;
    for (const [i, p] of index.parts.entries()) {
      if (!object(p) || !NAME.test(p.file) || p.file !== pathName(i + 1, index.encrypted) || p.start !== expected || !Number.isSafeInteger(p.count) || p.count < 0 || p.count > 1e3 || !Number.isSafeInteger(p.bytes) || p.bytes < 1 || p.bytes > MAX_BYTES + 56 || !sha.test(p.sha256) || !sha.test(p.zipSha256)) fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u7D22\u5F15\u304C\u4E0D\u6B63\u3067\u3059");
      expected += p.count;
      total += p.bytes;
    }
    if (expected !== index.recordCount || total !== index.totalBytes || total > MAX_COLLECTION_BYTES)
      fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u7D22\u5F15\u306E\u4EF6\u6570\u307E\u305F\u306F\u5BB9\u91CF\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
  }
  async function openCollection(indexBytes, readPart, { passphrase = "" } = {}) {
    if (typeof readPart !== "function") fail("\u30ED\u30FC\u30AB\u30EB\u30D5\u30A1\u30A4\u30EB\u8AAD\u307F\u8FBC\u307F\u95A2\u6570\u304C\u5FC5\u8981\u3067\u3059");
    const indexRaw = indexBytes instanceof Uint8Array ? indexBytes : new Uint8Array(indexBytes);
    if (indexRaw.length < 1 || indexRaw.length > 1024 * 1024) fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u7D22\u5F15\u306E\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
    let index;
    try {
      index = JSON.parse(decoder.decode(indexRaw));
    } catch {
      fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u7D22\u5F15\u3092\u89E3\u91C8\u3067\u304D\u307E\u305B\u3093");
    }
    validateIndex(index);
    if (index.encrypted && (!passphrase || passphrase.length < 12)) fail("\u6697\u53F7\u5316\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u306E\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u304C\u5FC5\u8981\u3067\u3059");
    const allRecords = [], allMeta = [], mergedFiles = /* @__PURE__ */ Object.create(null), uniqueFiles = /* @__PURE__ */ new Map();
    let first = null;
    for (const part of index.parts) {
      const raw = await readPart(part.file);
      if (!(raw instanceof Uint8Array) || raw.length !== part.bytes || await sha256(raw) !== part.sha256) fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u304C\u6B20\u843D\u30FB\u7834\u640D\u3057\u3066\u3044\u307E\u3059: " + part.file);
      let zip = raw;
      if (index.encrypted) zip = await decryptLocalArchive(raw, passphrase);
      let archive;
      try {
        archive = await inspectArchive(zip, { expectedHash: part.zipSha256 });
      } finally {
        if (zip !== raw) zip.fill(0);
      }
      if (archive.manifest.sourceAppId !== index.sourceAppId || archive.manifest.recordCount !== part.count || archive.manifest.createdAt !== index.createdAt || archive.manifest.version !== 3) fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u306E\u5185\u5BB9\u30FB\u30A2\u30D7\u30EAID\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (!first) first = archive;
      else if (JSON.stringify(archive.schema) !== JSON.stringify(first.schema) || JSON.stringify(archive.sourceFields) !== JSON.stringify(first.sourceFields) || JSON.stringify(archive.layout) !== JSON.stringify(first.layout) || JSON.stringify(archive.settings) !== JSON.stringify(first.settings) || JSON.stringify(archive.coverage) !== JSON.stringify(first.coverage))
        fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u9593\u3067\u30D5\u30A9\u30FC\u30E0\u30FB\u8A2D\u5B9A\u304C\u5909\u5316\u3057\u3066\u3044\u307E\u3059");
      allRecords.push(...archive.records);
      allMeta.push(...archive.sourceMeta);
      for (const file of archive.manifest.files) {
        const prior = uniqueFiles.get(file.path);
        if (prior && JSON.stringify(prior) !== JSON.stringify(file)) fail("\u5206\u5272\u9593\u3067\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u30CF\u30C3\u30B7\u30E5\u304C\u77DB\u76FE\u3057\u3066\u3044\u307E\u3059");
        uniqueFiles.set(file.path, file);
        mergedFiles[file.path] = archive.files[file.path];
      }
    }
    if (allRecords.length !== index.recordCount || allMeta.length !== index.recordCount) fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u306E\u7DCF\u4EF6\u6570\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    const indexHash = await sha256(indexRaw);
    return {
      ...first,
      records: allRecords,
      sourceMeta: allMeta,
      files: mergedFiles,
      manifest: { ...first.manifest, files: [...uniqueFiles.values()], recordCount: index.recordCount, collection: true },
      archiveHash: indexHash,
      collectionIndex: index
    };
  }

  // src/local-viewer.js
  var $ = (id) => document.getElementById(id);
  var create = (tag, content, cls) => {
    const el = document.createElement(tag);
    if (content !== void 0) el.textContent = content;
    if (cls) el.className = cls;
    return el;
  };
  var current = null;
  var chosen = 0;
  var page = 0;
  var filter = "";
  var PAGE = 50;
  var getMeta = (archive) => {
    if (!archive.files["data/source-meta.jsonl"]) return [];
    const source = new TextDecoder().decode(archive.files["data/source-meta.jsonl"]);
    return source.trim() ? source.trimEnd().split("\n").map(JSON.parse) : [];
  };
  var getCoverage = (archive) => {
    if (!archive.files["schema/coverage.json"]) return null;
    return JSON.parse(new TextDecoder().decode(archive.files["schema/coverage.json"]));
  };
  var getSettings = (archive) => {
    if (!archive.files["schema/settings.json"]) return null;
    return JSON.parse(new TextDecoder().decode(archive.files["schema/settings.json"]));
  };
  function clear(node) {
    node.replaceChildren();
  }
  function fmt(val) {
    if (val === null || val === void 0) return "";
    if (Array.isArray(val)) return val.map(fmt).join(", ");
    if (typeof val === "object") return JSON.stringify(val);
    return String(val);
  }
  function fieldLabel(code) {
    return current?.archive?.sourceFields?.properties?.[code]?.label || code;
  }
  function showStatus(message) {
    $("status").textContent = message;
  }
  function downloadBytes(bytes, name) {
    const url = URL.createObjectURL(new Blob([bytes], { type: "application/octet-stream" }));
    const a = create("a");
    a.href = url;
    a.download = name.replace(/[\\/:*?"<>|\x00-\x1f]/g, "_").slice(0, 180) || "attachment";
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3e4);
  }
  function appendValue(target, val) {
    if (val === null || val === void 0) {
      target.append(create("span", "\uFF08\u7A7A\uFF09", "muted"));
      return;
    }
    if (Array.isArray(val)) {
      if (val.length === 0) {
        target.append(create("span", "\uFF08\u7A7A\uFF09", "muted"));
        return;
      }
      for (const item of val) {
        if (item && typeof item === "object" && Object.hasOwn(item, "ref")) {
          const row = create("div", void 0, "file");
          row.append(create("span", item.name + " (" + item.size + " bytes)"));
          const b = create("button", "\u4FDD\u5B58");
          b.onclick = () => {
            const bytes = current.archive.files["attachments/" + item.ref];
            if (!bytes) {
              showStatus("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u5B9F\u4F53\u304C\u3042\u308A\u307E\u305B\u3093");
              return;
            }
            downloadBytes(bytes, item.name);
          };
          row.append(b);
          target.append(row);
        } else if (item && typeof item === "object" && item.value && typeof item.value === "object" && !Array.isArray(item.value)) {
          const table = create("div", void 0, "subtable");
          for (const [code, value] of Object.entries(item.value)) {
            const line = create("div");
            line.append(create("strong", code + ": "));
            appendValue(line, value?.value);
            table.append(line);
          }
          target.append(table);
        } else {
          const line = create("div");
          line.textContent = fmt(item);
          target.append(line);
        }
      }
      return;
    }
    target.append(create("span", fmt(val)));
  }
  function showDetail(index) {
    chosen = index;
    const archive = current.archive;
    const item = archive.records[index];
    clear($("detail"));
    $("detailTitle").textContent = "\u30EC\u30B3\u30FC\u30C9\u8A73\u7D30 #" + (current.meta[index]?.["$id"] || String(index + 1));
    for (const [code, def] of Object.entries(archive.schema)) {
      const box = create("div", void 0, "field");
      const label = create("label", fieldLabel(code) + "\u3000(" + def.type + ")");
      const value = create("div", void 0, "field-value");
      appendValue(value, item[code]?.value);
      box.append(label, value);
      $("detail").append(box);
    }
    const info = current.meta[index] || {};
    if (Object.keys(info).length) {
      const box = create("div", void 0, "field");
      box.append(create("label", "\u5143\u306E\u30B7\u30B9\u30C6\u30E0\u60C5\u5831\uFF08\u53C2\u8003\u3002\u79FB\u884C\u6642\u306B\u540C\u4E00\u5024\u306F\u4FDD\u8A3C\u3055\u308C\u307E\u305B\u3093\uFF09"));
      box.append(create("pre", JSON.stringify(info, null, 2)));
      $("detail").append(box);
    }
    $("detailTitle").scrollIntoView({ block: "nearest" });
  }
  function listRows() {
    if (!current) return;
    const { archive, meta } = current;
    const matches = [];
    for (let i = 0; i < archive.records.length; i++) {
      if (!filter || JSON.stringify(archive.records[i]).toLowerCase().includes(filter) || JSON.stringify(meta[i] || {}).toLowerCase().includes(filter)) matches.push(i);
    }
    const pages = Math.max(1, Math.ceil(matches.length / PAGE));
    page = Math.min(page, pages - 1);
    $("page").textContent = page + 1 + " / " + pages + "\u30DA\u30FC\u30B8\u3000" + matches.length + "\u4EF6";
    $("prev").disabled = page === 0;
    $("next").disabled = page >= pages - 1;
    clear($("results"));
    const codes = Object.keys(archive.schema).filter((code) => archive.schema[code].type !== "SUBTABLE").slice(0, 3);
    const head = create("tr");
    for (const h of ["\u5143ID", ...codes.map(fieldLabel), "\u958B\u304F"]) head.append(create("th", h));
    $("results").append(head);
    for (const i of matches.slice(page * PAGE, (page + 1) * PAGE)) {
      const tr = create("tr");
      tr.append(create("td", meta[i]?.["$id"] || String(i + 1)));
      for (const code of codes) tr.append(create("td", fmt(archive.records[i][code]?.value).slice(0, 160)));
      const cell = create("td");
      const b = create("button", "\u8A73\u7D30");
      b.onclick = () => showDetail(i);
      cell.append(b);
      tr.append(cell);
      $("results").append(tr);
    }
  }
  function showSettings() {
    const archive = current.archive;
    const fields = archive.sourceFields?.properties || {};
    clear($("fields"));
    for (const [code, info] of Object.entries(fields)) {
      const line = create("div", void 0, "field");
      line.append(create("strong", (info.label || code) + " (" + code + ")"));
      line.append(create("small", "\u3000" + info.type + (info.required ? " / \u5FC5\u9808" : "")));
      $("fields").append(line);
    }
    clear($("layout"));
    const walk = (items, container, depth = 0) => {
      if (!Array.isArray(items) || depth > 12) return;
      for (const item of items) {
        const el = create("div", void 0, "layout-node");
        if (item.type === "ROW") {
          el.append(create("small", "\u884C"));
          const row = create("div", void 0, "layout-row");
          for (const field of item.fields || []) row.append(create("span", fieldLabel(field.code || field.elementId || field.type || "?"), "layout-cell"));
          el.append(row);
        } else if (item.type === "GROUP") {
          el.append(create("strong", item.code || "\u30B0\u30EB\u30FC\u30D7"));
          walk(item.layout, el, depth + 1);
        } else el.append(create("span", item.type || "\u672A\u5BFE\u5FDC\u8981\u7D20"));
        container.append(el);
      }
    };
    walk(archive.layout?.layout || archive.layout, $("layout"));
    if (!$("layout").children.length) $("layout").append(create("p", "\u30D5\u30A9\u30FC\u30E0\u914D\u7F6E\u60C5\u5831\u306F\u3042\u308A\u307E\u305B\u3093\u3002"));
    const coverage = getCoverage(archive);
    clear($("coverage"));
    if (coverage) {
      const sections = coverage.sections || {};
      for (const [name, entry] of Object.entries(sections)) {
        const line = create("div", (entry.status === "captured" ? "\u53D6\u5F97\u6E08" : "\u672A\u53D6\u5F97") + "\u3000" + name + (entry.reason ? " : " + entry.reason : ""), "coverage-row");
        line.classList.add(entry.status === "captured" ? "ok" : "warn");
        $("coverage").append(line);
      }
      for (const lim of coverage.limitations || []) $("coverage").append(create("p", "\u5236\u9650: " + lim, "muted"));
    } else $("coverage").append(create("p", "\u65E7\u5F62\u5F0F\uFF1A\u8A2D\u5B9A\u306E\u53D6\u5F97\u7BC4\u56F2\u3092\u793A\u3059\u53F0\u5E33\u306F\u3042\u308A\u307E\u305B\u3093\u3002"));
    const settings = getSettings(archive);
    $("settingsJson").textContent = settings ? JSON.stringify(settings, null, 2).slice(0, 3e5) : "\u65E7\u5F62\u5F0F\uFF1A\u8A2D\u5B9A\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u306A\u3057";
  }
  function reset() {
    current = null;
    chosen = 0;
    page = 0;
    filter = "";
    $("search").value = "";
    $("loaded").hidden = true;
    for (const id of ["results", "detail", "fields", "coverage", "layout"]) clear($(id));
    showStatus("\u30ED\u30FC\u30AB\u30EB\u306E\u30A2\u30FC\u30AB\u30A4\u30D6\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5916\u90E8\u901A\u4FE1\u306F\u884C\u3044\u307E\u305B\u3093\u3002");
  }
  $("file").addEventListener("change", async (event) => {
    reset();
    const files = [...event.target.files || []];
    if (!files.length) return;
    showStatus("\u6574\u5408\u6027\u3068SHA-256\u3092\u691C\u8A3C\u3057\u3066\u3044\u307E\u3059\u2026");
    try {
      let archive;
      const indexFile = files.find((f) => f.name === "resoarc-collection.ra-collection.json");
      if (indexFile) {
        const indexBytes = new Uint8Array(await indexFile.arrayBuffer());
        let index;
        try {
          index = JSON.parse(new TextDecoder().decode(indexBytes));
        } catch {
          throw Error("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u7D22\u5F15JSON\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093");
        }
        const pass = index.encrypted ? window.prompt("\u5206\u5272\u30A2\u30FC\u30AB\u30A4\u30D6\u5171\u901A\u306E\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044", "") : "";
        if (pass === null) {
          reset();
          return;
        }
        const map = /* @__PURE__ */ new Map();
        for (const f of files) {
          if (map.has(f.name)) throw Error("\u30D5\u30A1\u30A4\u30EB\u540D\u304C\u91CD\u8907\u3057\u3066\u3044\u307E\u3059: " + f.name);
          map.set(f.name, f);
        }
        archive = await openCollection(indexBytes, async (name) => {
          const f = map.get(name);
          if (!f) throw Error("\u5FC5\u8981\u306A\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u304C\u3042\u308A\u307E\u305B\u3093: " + name);
          if (f.size > MAX_BYTES + 56) throw Error("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u306E\u5BB9\u91CF\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
          return new Uint8Array(await f.arrayBuffer());
        }, { passphrase: pass });
      } else {
        if (files.length !== 1) throw Error("\u5206\u5272\u4FDD\u5B58\u306E\u5834\u5408\u306F\u7D22\u5F15JSON\u3068\u3059\u3079\u3066\u306E\u30D1\u30FC\u30C8\u3092\u540C\u6642\u306B\u9078\u3093\u3067\u304F\u3060\u3055\u3044");
        const file = files[0];
        if (file.size > MAX_BYTES + 56) throw Error("\u30B5\u30A4\u30BA\u8D85\u904E\uFF1A\u5358\u4E00\u30D5\u30A1\u30A4\u30EB\u306F25MiB\u307E\u3067\u3067\u3059");
        const bytes = new Uint8Array(await file.arrayBuffer());
        if (isPotentialEncryptedArchive(bytes) && !isEncryptedArchive(bytes)) throw Error("\u6697\u53F7\u5316\u30D8\u30C3\u30C0\u30FC\u304C\u7834\u640D\u3057\u3066\u3044\u307E\u3059");
        let plaintext = bytes;
        if (isEncryptedArchive(bytes)) {
          const pass = window.prompt("\u6697\u53F7\u5316\u30A2\u30FC\u30AB\u30A4\u30D6\u306E\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u30D6\u30E9\u30A6\u30B6\u30FC\u5185\u3067\u5FA9\u53F7\u3057\u307E\u3059\uFF09", "");
          if (pass === null) {
            reset();
            return;
          }
          plaintext = await decryptLocalArchive(bytes, pass);
        }
        try {
          archive = await inspectArchive(plaintext);
        } finally {
          if (plaintext !== bytes) plaintext.fill(0);
        }
      }
      current = { archive, meta: getMeta(archive) };
      const settings = getSettings(archive);
      $("title").textContent = settings?.app?.name || "kintone \u30A2\u30D7\u30EA #" + archive.manifest.sourceAppId;
      $("summary").textContent = "\u5143\u30A2\u30D7\u30EA " + archive.manifest.sourceAppId + " \u30FB " + archive.manifest.recordCount + "\u4EF6 \u30FB " + archive.manifest.createdAt + " \u30FB \u5F62\u5F0Fv" + archive.manifest.version + (archive.manifest.collection ? " \u30FB \u5206\u5272 " + archive.collectionIndex.parts.length + "\u30D5\u30A1\u30A4\u30EB" : "");
      $("checksum").textContent = "SHA-256: " + archive.archiveHash;
      $("loaded").hidden = false;
      showSettings();
      listRows();
      if (archive.records.length) showDetail(0);
      showStatus("\u691C\u8A3C\u5B8C\u4E86\u3002\u30C7\u30FC\u30BF\u306F\u3053\u306E\u7AEF\u672B\u306E\u30D6\u30E9\u30A6\u30B6\u30FC\u5185\u3060\u3051\u3067\u51E6\u7406\u3057\u3066\u3044\u307E\u3059\u3002");
    } catch (e) {
      reset();
      showStatus("\u8AAD\u307F\u8FBC\u307F\u3092\u62D2\u5426\u3057\u307E\u3057\u305F\uFF1A" + String(e.message || e));
    }
  });
  $("search").addEventListener("input", (event) => {
    filter = event.target.value.toLowerCase();
    page = 0;
    listRows();
  });
  $("prev").onclick = () => {
    if (page > 0) {
      page--;
      listRows();
    }
  };
  $("next").onclick = () => {
    page++;
    listRows();
  };
  $("clear").onclick = () => {
    $("file").value = "";
    reset();
  };
  $("exportJson").onclick = () => {
    if (!current) return;
    if (!window.confirm("JSON\u5F62\u5F0F\u306F\u6697\u53F7\u5316\u3055\u308C\u307E\u305B\u3093\u3002\u696D\u52D9\u30C7\u30FC\u30BF\u30FB\u500B\u4EBA\u60C5\u5831\u304C\u5E73\u6587\u3067\u4FDD\u5B58\u3055\u308C\u307E\u3059\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F")) return;
    const a = current.archive;
    const data = {
      manifest: a.manifest,
      sourceFields: a.sourceFields,
      layout: a.layout,
      settings: getSettings(a),
      coverage: getCoverage(a),
      sourceMeta: current.meta,
      records: a.records
    };
    const bytes = new TextEncoder().encode(JSON.stringify(data, null, 2));
    downloadBytes(bytes, "resoarc-kintone-" + a.manifest.sourceAppId + ".json");
  };
  reset();
})();
