/* ResoArc kintone Archive v1.0.0 (local-first distribution) MIT
Bundled fflate 0.8.3 under MIT license:
MIT License

Copyright (c) 2026 Arjun Barrett

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
(() => {
  // node_modules/fflate/esm/browser.js
  var u8 = Uint8Array;
  var u16 = Uint16Array;
  var i32 = Int32Array;
  var fleb = new u8([
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    0,
    /* unused */
    0,
    0,
    /* impossible */
    0
  ]);
  var fdeb = new u8([
    0,
    0,
    0,
    0,
    1,
    1,
    2,
    2,
    3,
    3,
    4,
    4,
    5,
    5,
    6,
    6,
    7,
    7,
    8,
    8,
    9,
    9,
    10,
    10,
    11,
    11,
    12,
    12,
    13,
    13,
    /* unused */
    0,
    0
  ]);
  var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
  var freb = function(eb, start) {
    var b = new u16(31);
    for (var i = 0; i < 31; ++i) {
      b[i] = start += 1 << eb[i - 1];
    }
    var r = new i32(b[30]);
    for (var i = 1; i < 30; ++i) {
      for (var j = b[i]; j < b[i + 1]; ++j) {
        r[j] = j - b[i] << 5 | i;
      }
    }
    return { b, r };
  };
  var _a = freb(fleb, 2);
  var fl = _a.b;
  var revfl = _a.r;
  fl[28] = 258, revfl[258] = 28;
  var _b = freb(fdeb, 0);
  var fd = _b.b;
  var revfd = _b.r;
  var rev = new u16(32768);
  for (i = 0; i < 32768; ++i) {
    x = (i & 43690) >> 1 | (i & 21845) << 1;
    x = (x & 52428) >> 2 | (x & 13107) << 2;
    x = (x & 61680) >> 4 | (x & 3855) << 4;
    rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
  }
  var x;
  var i;
  var hMap = (function(cd, mb, r) {
    var s2 = cd.length;
    var i = 0;
    var l = new u16(mb);
    for (; i < s2; ++i) {
      if (cd[i])
        ++l[cd[i] - 1];
    }
    var le = new u16(mb);
    for (i = 1; i < mb; ++i) {
      le[i] = le[i - 1] + l[i - 1] << 1;
    }
    var co;
    if (r) {
      co = new u16(1 << mb);
      var rvb = 15 - mb;
      for (i = 0; i < s2; ++i) {
        if (cd[i]) {
          var sv = i << 4 | cd[i];
          var r_1 = mb - cd[i];
          var v = le[cd[i] - 1]++ << r_1;
          for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
            co[rev[v] >> rvb] = sv;
          }
        }
      }
    } else {
      co = new u16(s2);
      for (i = 0; i < s2; ++i) {
        if (cd[i]) {
          co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
        }
      }
    }
    return co;
  });
  var flt = new u8(288);
  for (i = 0; i < 144; ++i)
    flt[i] = 8;
  var i;
  for (i = 144; i < 256; ++i)
    flt[i] = 9;
  var i;
  for (i = 256; i < 280; ++i)
    flt[i] = 7;
  var i;
  for (i = 280; i < 288; ++i)
    flt[i] = 8;
  var i;
  var fdt = new u8(32);
  for (i = 0; i < 32; ++i)
    fdt[i] = 5;
  var i;
  var flm = /* @__PURE__ */ hMap(flt, 9, 0);
  var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
  var fdm = /* @__PURE__ */ hMap(fdt, 5, 0);
  var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
  var max = function(a) {
    var m = a[0];
    for (var i = 1; i < a.length; ++i) {
      if (a[i] > m)
        m = a[i];
    }
    return m;
  };
  var bits = function(d, p, m) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
  };
  var bits16 = function(d, p) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
  };
  var shft = function(p) {
    return (p + 7) / 8 | 0;
  };
  var slc = function(v, s2, e) {
    if (s2 == null || s2 < 0)
      s2 = 0;
    if (e == null || e > v.length)
      e = v.length;
    return new u8(v.subarray(s2, e));
  };
  var ec = [
    "unexpected EOF",
    "invalid block type",
    "invalid length/literal",
    "invalid distance",
    "stream finished",
    "no stream handler",
    ,
    // determined by compression function
    "no callback",
    "invalid UTF-8 data",
    "extra field too long",
    "date not in range 1980-2099",
    "filename too long",
    "stream finishing",
    "invalid zip data"
    // determined by unknown compression method
  ];
  var err = function(ind, msg, nt) {
    var e = new Error(msg || ec[ind]);
    e.code = ind;
    if (Error.captureStackTrace)
      Error.captureStackTrace(e, err);
    if (!nt)
      throw e;
    return e;
  };
  var inflt = function(dat, st, buf, dict) {
    var sl = dat.length, dl = dict ? dict.length : 0;
    if (!sl || st.f && !st.l)
      return buf || new u8(0);
    var noBuf = !buf;
    var resize = noBuf || st.i != 2;
    var noSt = st.i;
    if (noBuf)
      buf = new u8(sl * 3);
    var cbuf = function(l2) {
      var bl = buf.length;
      if (l2 > bl) {
        var nbuf = new u8(Math.max(bl * 2, l2));
        nbuf.set(buf);
        buf = nbuf;
      }
    };
    var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
    var tbts = sl * 8;
    do {
      if (!lm) {
        final = bits(dat, pos, 1);
        var type = bits(dat, pos + 1, 3);
        pos += 3;
        if (!type) {
          var s2 = shft(pos) + 4, l = dat[s2 - 4] | dat[s2 - 3] << 8, t = s2 + l;
          if (t > sl) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + l);
          buf.set(dat.subarray(s2, t), bt);
          st.b = bt += l, st.p = pos = t * 8, st.f = final;
          continue;
        } else if (type == 1)
          lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
        else if (type == 2) {
          var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
          var tl = hLit + bits(dat, pos + 5, 31) + 1;
          pos += 14;
          var ldt = new u8(tl);
          var clt = new u8(19);
          for (var i = 0; i < hcLen; ++i) {
            clt[clim[i]] = bits(dat, pos + i * 3, 7);
          }
          pos += hcLen * 3;
          var clb = max(clt), clbmsk = (1 << clb) - 1;
          var clm = hMap(clt, clb, 1);
          for (var i = 0; i < tl; ) {
            var r = clm[bits(dat, pos, clbmsk)];
            pos += r & 15;
            var s2 = r >> 4;
            if (s2 < 16) {
              ldt[i++] = s2;
            } else {
              var c = 0, n = 0;
              if (s2 == 16)
                n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
              else if (s2 == 17)
                n = 3 + bits(dat, pos, 7), pos += 3;
              else if (s2 == 18)
                n = 11 + bits(dat, pos, 127), pos += 7;
              while (n--)
                ldt[i++] = c;
            }
          }
          var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
          lbt = max(lt);
          dbt = max(dt);
          lm = hMap(lt, lbt, 1);
          dm = hMap(dt, dbt, 1);
        } else
          err(1);
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
      }
      if (resize)
        cbuf(bt + 131072);
      var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
      var lpos = pos;
      for (; ; lpos = pos) {
        var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
        pos += c & 15;
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (!c)
          err(2);
        if (sym < 256)
          buf[bt++] = sym;
        else if (sym == 256) {
          lpos = pos, lm = null;
          break;
        } else {
          var add = sym - 254;
          if (sym > 264) {
            var i = sym - 257, b = fleb[i];
            add = bits(dat, pos, (1 << b) - 1) + fl[i];
            pos += b;
          }
          var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
          if (!d)
            err(3);
          pos += d & 15;
          var dt = fd[dsym];
          if (dsym > 3) {
            var b = fdeb[dsym];
            dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
          }
          if (pos > tbts) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + 131072);
          var end = bt + add;
          if (bt < dt) {
            var shift = dl - dt, dend = Math.min(dt, end);
            if (shift + bt < 0)
              err(3);
            for (; bt < dend; ++bt)
              buf[bt] = dict[shift + bt];
          }
          for (; bt < end; ++bt)
            buf[bt] = buf[bt - dt];
        }
      }
      st.l = lm, st.p = lpos, st.b = bt, st.f = final;
      if (lm)
        final = 1, st.m = lbt, st.d = dm, st.n = dbt;
    } while (!final);
    return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
  };
  var wbits = function(d, p, v) {
    v <<= p & 7;
    var o = p / 8 | 0;
    d[o] |= v;
    d[o + 1] |= v >> 8;
  };
  var wbits16 = function(d, p, v) {
    v <<= p & 7;
    var o = p / 8 | 0;
    d[o] |= v;
    d[o + 1] |= v >> 8;
    d[o + 2] |= v >> 16;
  };
  var hTree = function(d, mb) {
    var t = [];
    for (var i = 0; i < d.length; ++i) {
      if (d[i])
        t.push({ s: i, f: d[i] });
    }
    var s2 = t.length;
    var t2 = t.slice();
    if (!s2)
      return { t: et, l: 0 };
    if (s2 == 1) {
      var v = new u8(t[0].s + 1);
      v[t[0].s] = 1;
      return { t: v, l: 1 };
    }
    t.sort(function(a, b) {
      return a.f - b.f;
    });
    t.push({ s: -1, f: 25001 });
    var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
    t[0] = { s: -1, f: l.f + r.f, l, r };
    while (i1 != s2 - 1) {
      l = t[t[i0].f < t[i2].f ? i0++ : i2++];
      r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
      t[i1++] = { s: -1, f: l.f + r.f, l, r };
    }
    var maxSym = t2[0].s;
    for (var i = 1; i < s2; ++i) {
      if (t2[i].s > maxSym)
        maxSym = t2[i].s;
    }
    var tr = new u16(maxSym + 1);
    var mbt = ln(t[i1 - 1], tr, 0);
    if (mbt > mb) {
      var i = 0, dt = 0;
      var lft = mbt - mb, cst = 1 << lft;
      t2.sort(function(a, b) {
        return tr[b.s] - tr[a.s] || a.f - b.f;
      });
      for (; i < s2; ++i) {
        var i2_1 = t2[i].s;
        if (tr[i2_1] > mb) {
          dt += cst - (1 << mbt - tr[i2_1]);
          tr[i2_1] = mb;
        } else
          break;
      }
      dt >>= lft;
      while (dt > 0) {
        var i2_2 = t2[i].s;
        if (tr[i2_2] < mb)
          dt -= 1 << mb - tr[i2_2]++ - 1;
        else
          ++i;
      }
      for (; i >= 0 && dt; --i) {
        var i2_3 = t2[i].s;
        if (tr[i2_3] == mb) {
          --tr[i2_3];
          ++dt;
        }
      }
      mbt = mb;
    }
    return { t: new u8(tr), l: mbt };
  };
  var ln = function(n, l, d) {
    return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
  };
  var lc = function(c) {
    var s2 = c.length;
    while (s2 && !c[--s2])
      ;
    var cl = new u16(++s2);
    var cli = 0, cln = c[0], cls = 1;
    var w = function(v) {
      cl[cli++] = v;
    };
    for (var i = 1; i <= s2; ++i) {
      if (c[i] == cln && i != s2)
        ++cls;
      else {
        if (!cln && cls > 2) {
          for (; cls > 138; cls -= 138)
            w(32754);
          if (cls > 2) {
            w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
            cls = 0;
          }
        } else if (cls > 3) {
          w(cln), --cls;
          for (; cls > 6; cls -= 6)
            w(8304);
          if (cls > 2)
            w(cls - 3 << 5 | 8208), cls = 0;
        }
        while (cls--)
          w(cln);
        cls = 1;
        cln = c[i];
      }
    }
    return { c: cl.subarray(0, cli), n: s2 };
  };
  var clen = function(cf, cl) {
    var l = 0;
    for (var i = 0; i < cl.length; ++i)
      l += cf[i] * cl[i];
    return l;
  };
  var wfblk = function(out, pos, dat) {
    var s2 = dat.length;
    var o = shft(pos + 2);
    out[o] = s2 & 255;
    out[o + 1] = s2 >> 8;
    out[o + 2] = out[o] ^ 255;
    out[o + 3] = out[o + 1] ^ 255;
    for (var i = 0; i < s2; ++i)
      out[o + i + 4] = dat[i];
    return (o + 4 + s2) * 8;
  };
  var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
    wbits(out, p++, final);
    ++lf[256];
    var _a2 = hTree(lf, 15), dlt = _a2.t, mlb = _a2.l;
    var _b2 = hTree(df, 15), ddt = _b2.t, mdb = _b2.l;
    var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
    var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
    var lcfreq = new u16(19);
    for (var i = 0; i < lclt.length; ++i)
      ++lcfreq[lclt[i] & 31];
    for (var i = 0; i < lcdt.length; ++i)
      ++lcfreq[lcdt[i] & 31];
    var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
    var nlcc = 19;
    for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc)
      ;
    var flen = bl + 5 << 3;
    var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
    var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
    if (bs >= 0 && flen <= ftlen && flen <= dtlen)
      return wfblk(out, p, dat.subarray(bs, bs + bl));
    var lm, ll, dm, dl;
    wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
    if (dtlen < ftlen) {
      lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
      var llm = hMap(lct, mlcb, 0);
      wbits(out, p, nlc - 257);
      wbits(out, p + 5, ndc - 1);
      wbits(out, p + 10, nlcc - 4);
      p += 14;
      for (var i = 0; i < nlcc; ++i)
        wbits(out, p + 3 * i, lct[clim[i]]);
      p += 3 * nlcc;
      var lcts = [lclt, lcdt];
      for (var it = 0; it < 2; ++it) {
        var clct = lcts[it];
        for (var i = 0; i < clct.length; ++i) {
          var len = clct[i] & 31;
          wbits(out, p, llm[len]), p += lct[len];
          if (len > 15)
            wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
        }
      }
    } else {
      lm = flm, ll = flt, dm = fdm, dl = fdt;
    }
    for (var i = 0; i < li; ++i) {
      var sym = syms[i];
      if (sym > 255) {
        var len = sym >> 18 & 31;
        wbits16(out, p, lm[len + 257]), p += ll[len + 257];
        if (len > 7)
          wbits(out, p, sym >> 23 & 31), p += fleb[len];
        var dst = sym & 31;
        wbits16(out, p, dm[dst]), p += dl[dst];
        if (dst > 3)
          wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
      } else {
        wbits16(out, p, lm[sym]), p += ll[sym];
      }
    }
    wbits16(out, p, lm[256]);
    return p + ll[256];
  };
  var deo = /* @__PURE__ */ new i32([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]);
  var et = /* @__PURE__ */ new u8(0);
  var dflt = function(dat, lvl, plvl, pre, post, st) {
    var s2 = st.z || dat.length;
    var o = new u8(pre + s2 + 5 * (1 + Math.ceil(s2 / 7e3)) + post);
    var w = o.subarray(pre, o.length - post);
    var lst = st.l;
    var pos = (st.r || 0) & 7;
    if (lvl) {
      if (pos)
        w[0] = st.r >> 3;
      var opt = deo[lvl - 1];
      var n = opt >> 13, c = opt & 8191;
      var msk_1 = (1 << plvl) - 1;
      var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
      var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
      var hsh = function(i2) {
        return (dat[i2] ^ dat[i2 + 1] << bs1_1 ^ dat[i2 + 2] << bs2_1) & msk_1;
      };
      var syms = new i32(25e3);
      var lf = new u16(288), df = new u16(32);
      var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
      for (; i + 2 < s2; ++i) {
        var hv = hsh(i);
        var imod = i & 32767, pimod = head[hv];
        prev[imod] = pimod;
        head[hv] = imod;
        if (wi <= i) {
          var rem = s2 - i;
          if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
            pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
            li = lc_1 = eb = 0, bs = i;
            for (var j = 0; j < 286; ++j)
              lf[j] = 0;
            for (var j = 0; j < 30; ++j)
              df[j] = 0;
          }
          var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
          if (rem > 2 && hv == hsh(i - dif)) {
            var maxn = Math.min(n, rem) - 1;
            var maxd = Math.min(32767, i);
            var ml = Math.min(258, rem);
            while (dif <= maxd && --ch_1 && imod != pimod) {
              if (dat[i + l] == dat[i + l - dif]) {
                var nl = 0;
                for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl)
                  ;
                if (nl > l) {
                  l = nl, d = dif;
                  if (nl > maxn)
                    break;
                  var mmd = Math.min(dif, nl - 2);
                  var md = 0;
                  for (var j = 0; j < mmd; ++j) {
                    var ti = i - dif + j & 32767;
                    var pti = prev[ti];
                    var cd = ti - pti & 32767;
                    if (cd > md)
                      md = cd, pimod = ti;
                  }
                }
              }
              imod = pimod, pimod = prev[imod];
              dif += imod - pimod & 32767;
            }
          }
          if (d) {
            syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
            var lin = revfl[l] & 31, din = revfd[d] & 31;
            eb += fleb[lin] + fdeb[din];
            ++lf[257 + lin];
            ++df[din];
            wi = i + l;
            ++lc_1;
          } else {
            syms[li++] = dat[i];
            ++lf[dat[i]];
          }
        }
      }
      for (i = Math.max(i, wi); i < s2; ++i) {
        syms[li++] = dat[i];
        ++lf[dat[i]];
      }
      pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
      if (!lst) {
        st.r = pos & 7 | w[pos / 8 | 0] << 3;
        pos -= 7;
        st.h = head, st.p = prev, st.i = i, st.w = wi;
      }
    } else {
      for (var i = st.w || 0; i < s2 + lst; i += 65535) {
        var e = i + 65535;
        if (e >= s2) {
          w[pos / 8 | 0] = lst;
          e = s2;
        }
        pos = wfblk(w, pos + 1, dat.subarray(i, e));
      }
      st.i = s2;
    }
    return slc(o, 0, pre + shft(pos) + post);
  };
  var crct = /* @__PURE__ */ (function() {
    var t = new Int32Array(256);
    for (var i = 0; i < 256; ++i) {
      var c = i, k = 9;
      while (--k)
        c = (c & 1 && -306674912) ^ c >>> 1;
      t[i] = c;
    }
    return t;
  })();
  var crc = function() {
    var c = -1;
    return {
      p: function(d) {
        var cr = c;
        for (var i = 0; i < d.length; ++i)
          cr = crct[cr & 255 ^ d[i]] ^ cr >>> 8;
        c = cr;
      },
      d: function() {
        return ~c;
      }
    };
  };
  var dopt = function(dat, opt, pre, post, st) {
    if (!st) {
      st = { l: 1 };
      if (opt.dictionary) {
        var dict = opt.dictionary.subarray(-32768);
        var newDat = new u8(dict.length + dat.length);
        newDat.set(dict);
        newDat.set(dat, dict.length);
        dat = newDat;
        st.w = dict.length;
      }
    }
    return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
  };
  var mrg = function(a, b) {
    var o = {};
    for (var k in a)
      o[k] = a[k];
    for (var k in b)
      o[k] = b[k];
    return o;
  };
  var b2 = function(d, b) {
    return d[b] | d[b + 1] << 8;
  };
  var b4 = function(d, b) {
    return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
  };
  var b8 = function(d, b) {
    return b4(d, b) + b4(d, b + 4) * 4294967296;
  };
  var wbytes = function(d, b, v) {
    for (; v; ++b)
      d[b] = v, v >>>= 8;
  };
  function deflateSync(data, opts) {
    return dopt(data, opts || {}, 0, 0);
  }
  function inflateSync(data, opts) {
    return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
  }
  var fltn = function(d, p, t, o) {
    for (var k in d) {
      var val = d[k], n = p + k, op = o;
      if (Array.isArray(val))
        op = mrg(o, val[1]), val = val[0];
      if (ArrayBuffer.isView(val))
        t[n] = [val, op];
      else {
        t[n += "/"] = [new u8(0), op];
        fltn(val, n, t, o);
      }
    }
  };
  var te = typeof TextEncoder != "undefined" && /* @__PURE__ */ new TextEncoder();
  var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
  var tds = 0;
  try {
    td.decode(et, { stream: true });
    tds = 1;
  } catch (e) {
  }
  var dutf8 = function(d) {
    for (var r = "", i = 0; ; ) {
      var c = d[i++];
      var eb = (c > 127) + (c > 223) + (c > 239);
      if (i + eb > d.length)
        return { s: r, r: slc(d, i - 1) };
      if (!eb)
        r += String.fromCharCode(c);
      else if (eb == 3) {
        c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | d[i++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
      } else if (eb & 1)
        r += String.fromCharCode((c & 31) << 6 | d[i++] & 63);
      else
        r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | d[i++] & 63);
    }
  };
  function strToU8(str2, latin1) {
    if (latin1) {
      var ar_1 = new u8(str2.length);
      for (var i = 0; i < str2.length; ++i)
        ar_1[i] = str2.charCodeAt(i);
      return ar_1;
    }
    if (te)
      return te.encode(str2);
    var l = str2.length;
    var ar = new u8(str2.length + (str2.length >> 1));
    var ai = 0;
    var w = function(v) {
      ar[ai++] = v;
    };
    for (var i = 0; i < l; ++i) {
      if (ai + 5 > ar.length) {
        var n = new u8(ai + 8 + (l - i << 1));
        n.set(ar);
        ar = n;
      }
      var c = str2.charCodeAt(i);
      if (c < 128 || latin1)
        w(c);
      else if (c < 2048)
        w(192 | c >> 6), w(128 | c & 63);
      else if (c > 55295 && c < 57344)
        c = 65536 + (c & 1023 << 10) | str2.charCodeAt(++i) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
      else
        w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
    }
    return slc(ar, 0, ai);
  }
  function strFromU8(dat, latin1) {
    if (latin1) {
      var r = "";
      for (var i = 0; i < dat.length; i += 16384)
        r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
      return r;
    } else if (td) {
      return td.decode(dat);
    } else {
      var _a2 = dutf8(dat), s2 = _a2.s, r = _a2.r;
      if (r.length)
        err(8);
      return s2;
    }
  }
  var slzh = function(d, b) {
    return b + 30 + b2(d, b + 26) + b2(d, b + 28);
  };
  var zh = function(d, b, z) {
    var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
    var _a2 = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a2[0], su = _a2[1], off = _a2[2];
    return [b2(d, b + 10), sc, su, fn, es + efl + b2(d, b + 32), off];
  };
  var z64hs = function(d, b, l, z, sc, su, off) {
    var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
    var nf = nsc + nsu + noff;
    if (z && nf) {
      for (; b + 4 < e; b += 4 + b2(d, b + 2)) {
        if (b2(d, b) == 1) {
          return [
            nsc ? b8(d, b + 4 + 8 * nsu) : sc,
            nsu ? b8(d, b + 4) : su,
            noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
            1
          ];
        }
      }
      if (z < 2)
        err(13);
    }
    return [sc, su, off, 0];
  };
  var exfl = function(ex) {
    var le = 0;
    if (ex) {
      for (var k in ex) {
        var l = ex[k].length;
        if (l > 65535)
          err(9);
        le += l + 4;
      }
    }
    return le;
  };
  var wzh = function(d, b, f, fn, u, c, ce, co) {
    var fl2 = fn.length, ex = f.extra, col = co && co.length;
    var exl = exfl(ex);
    wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
    if (ce != null)
      d[b++] = 20, d[b++] = f.os;
    d[b] = 20, b += 2;
    d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
    d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
    var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
    if (y < 0 || y > 119)
      err(10);
    wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
    if (c != -1) {
      wbytes(d, b, f.crc);
      wbytes(d, b + 4, c < 0 ? -c - 2 : c);
      wbytes(d, b + 8, f.size);
    }
    wbytes(d, b + 12, fl2);
    wbytes(d, b + 14, exl), b += 16;
    if (ce != null) {
      wbytes(d, b, col);
      wbytes(d, b + 6, f.attrs);
      wbytes(d, b + 10, ce), b += 14;
    }
    d.set(fn, b);
    b += fl2;
    if (exl) {
      for (var k in ex) {
        var exf = ex[k], l = exf.length;
        wbytes(d, b, +k);
        wbytes(d, b + 2, l);
        d.set(exf, b + 4), b += 4 + l;
      }
    }
    if (col)
      d.set(co, b), b += col;
    return b;
  };
  var wzf = function(o, b, c, d, e) {
    wbytes(o, b, 101010256);
    wbytes(o, b + 8, c);
    wbytes(o, b + 10, c);
    wbytes(o, b + 12, d);
    wbytes(o, b + 16, e);
  };
  function zipSync(data, opts) {
    if (!opts)
      opts = {};
    var r = {};
    var files = [];
    fltn(data, "", r, opts);
    var o = 0;
    var tot = 0;
    for (var fn in r) {
      var _a2 = r[fn], file = _a2[0], p = _a2[1];
      var compression = p.level == 0 ? 0 : 8;
      var f = strToU8(fn), s2 = f.length;
      var com = p.comment, m = com && strToU8(com), ms = m && m.length;
      var exl = exfl(p.extra);
      if (s2 > 65535)
        err(11);
      var d = compression ? deflateSync(file, p) : file, l = d.length;
      var c = crc();
      c.p(file);
      files.push(mrg(p, {
        size: file.length,
        crc: c.d(),
        c: d,
        f,
        m,
        u: s2 != fn.length || m && com.length != ms,
        o,
        compression
      }));
      o += 30 + s2 + exl + l;
      tot += 76 + 2 * (s2 + exl) + (ms || 0) + l;
    }
    var out = new u8(tot + 22), oe = o, cdl = tot - o;
    for (var i = 0; i < files.length; ++i) {
      var f = files[i];
      wzh(out, f.o, f, f.f, f.u, f.c.length);
      var badd = 30 + f.f.length + exfl(f.extra);
      out.set(f.c, f.o + badd);
      wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
    }
    wzf(out, o, files.length, cdl, oe);
    return out;
  }
  function unzipSync(data, opts) {
    var files = {};
    var e = data.length - 22;
    for (; b4(data, e) != 101010256; --e) {
      if (!e || data.length - e > 65558)
        err(13);
    }
    ;
    var c = b2(data, e + 8);
    if (!c)
      return {};
    var o = b4(data, e + 16);
    var z = b4(data, e - 20) == 117853008;
    if (z) {
      var ze = b4(data, e - 12);
      z = b4(data, ze) == 101075792;
      if (z) {
        c = b4(data, ze + 32);
        o = b4(data, ze + 48);
      }
    }
    var fltr = opts && opts.filter;
    for (var i = 0; i < c; ++i) {
      var _a2 = zh(data, o, z), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn = _a2[3], no = _a2[4], off = _a2[5], b = slzh(data, off);
      o = no;
      if (!fltr || fltr({
        name: fn,
        size: sc,
        originalSize: su,
        compression: c_2
      })) {
        if (!c_2)
          files[fn] = slc(data, b, b + sc);
        else if (c_2 == 8)
          files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
        else
          err(14, "unknown compression type " + c_2);
      }
    }
    return files;
  }

  // src/core.js
  var FORMAT = "resoarc.kintone.backup";
  var VERSION = 2;
  var MAX_BYTES = 25 * 1024 * 1024;
  var MAX_RECORDS = 2e4;
  var MAX_ZIP_ENTRIES = 5e4;
  var WRITABLE = /* @__PURE__ */ new Set(["SINGLE_LINE_TEXT", "MULTI_LINE_TEXT", "RICH_TEXT", "NUMBER", "RADIO_BUTTON", "DROP_DOWN", "CHECK_BOX", "MULTI_SELECT", "DATE", "TIME", "DATETIME", "LINK", "USER_SELECT", "ORGANIZATION_SELECT", "GROUP_SELECT", "FILE"]);
  var RESERVED_CODES = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
  var s = (v) => JSON.stringify(v);
  var u82 = (v) => v instanceof Uint8Array ? v : new Uint8Array(v);
  var stop = (reason) => {
    throw new Error(reason);
  };
  var sha256 = async (b) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", u82(b)))).map((v) => v.toString(16).padStart(2, "0")).join("");
  var allowedField = (d) => !!d && WRITABLE.has(d.type) && !d.lookup && !d.referenceTable && !(d.type === "SINGLE_LINE_TEXT" && typeof d.expression === "string" && d.expression.trim());
  var obj = (v) => v && typeof v === "object" && !Array.isArray(v);
  function fieldContents(props) {
    const fields = /* @__PURE__ */ Object.create(null);
    for (const [code2, def] of Object.entries(props || {})) {
      if (RESERVED_CODES.has(code2)) stop("\u4E88\u7D04\u6E08\u307F\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u30B3\u30FC\u30C9\u306F\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3067\u304D\u307E\u305B\u3093: " + code2);
      if (def?.type === "SUBTABLE") {
        const members = fieldContents(def.fields);
        if (Object.keys(members).length) fields[code2] = { type: "SUBTABLE", fields: members };
      } else if (allowedField(def)) fields[code2] = { type: def.type };
    }
    return fields;
  }
  var writableSchema = (raw) => fieldContents(raw?.properties || raw);
  function validatePortableSchema(schema, nested = false) {
    if (!obj(schema)) stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059");
    for (const [code2, def] of Object.entries(schema)) {
      if (RESERVED_CODES.has(code2) || !code2 || code2.length > 128)
        stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u306B\u4E0D\u6B63\u306A\u30D5\u30A3\u30FC\u30EB\u30C9\u30B3\u30FC\u30C9\u304C\u3042\u308A\u307E\u3059: " + code2);
      if (!obj(def)) stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u5B9A\u7FA9\u304C\u4E0D\u6B63\u3067\u3059: " + code2);
      if (def.type === "SUBTABLE") {
        if (nested) stop("\u30C6\u30FC\u30D6\u30EB\u306E\u5165\u308C\u5B50\u306F\u672A\u5BFE\u5FDC\u3067\u3059");
        validatePortableSchema(def.fields, true);
      } else if (!WRITABLE.has(def.type)) stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u7A2E\u5225\u304C\u4E0D\u6B63\u3067\u3059: " + code2);
    }
  }
  function validatePortableRecord(record, schema, location = "record") {
    if (!obj(record)) stop("\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u306E\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059: " + location);
    const scalar = /* @__PURE__ */ new Set(["SINGLE_LINE_TEXT", "MULTI_LINE_TEXT", "RICH_TEXT", "RADIO_BUTTON", "DROP_DOWN", "DATE", "TIME", "DATETIME", "LINK"]);
    const multi = /* @__PURE__ */ new Set(["CHECK_BOX", "MULTI_SELECT"]);
    const codes = /* @__PURE__ */ new Set(["USER_SELECT", "ORGANIZATION_SELECT", "GROUP_SELECT"]);
    for (const [code2, payload] of Object.entries(record)) {
      if (!Object.hasOwn(schema, code2)) stop("\u5B9A\u7FA9\u3055\u308C\u3066\u3044\u306A\u3044\u30EC\u30B3\u30FC\u30C9\u9805\u76EE\u304C\u3042\u308A\u307E\u3059: " + location + "." + code2);
      if (!obj(payload) || !Object.hasOwn(payload, "value"))
        stop("\u30EC\u30B3\u30FC\u30C9\u9805\u76EE\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + location + "." + code2);
      const def = schema[code2];
      const value = payload.value;
      const where = location + "." + code2;
      if (def.type === "SUBTABLE") {
        if (!Array.isArray(value)) stop("\u30C6\u30FC\u30D6\u30EB\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
        for (const [i, row] of value.entries()) {
          if (!obj(row) || !obj(row.value) || Object.keys(row).some((k) => k !== "value"))
            stop("\u30C6\u30FC\u30D6\u30EB\u884C\u306E\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059: " + where + "[" + i + "]");
          validatePortableRecord(row.value, def.fields, where + "[" + i + "]");
        }
      } else if (def.type === "FILE") {
        if (!Array.isArray(value)) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u9805\u76EE\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
        for (const item of value) {
          if (!obj(item) || typeof item.ref !== "string" || !/^[0-9a-f]{64}$/.test(item.ref) || typeof item.name !== "string" || typeof item.contentType !== "string" || !Number.isSafeInteger(item.size) || item.size < 0 || Object.hasOwn(item, "fileKey"))
            stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u53C2\u7167\u306E\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059: " + where);
        }
      } else if (multi.has(def.type)) {
        if (!Array.isArray(value) || value.some((x) => typeof x !== "string"))
          stop("\u8907\u6570\u9078\u629E\u30D5\u30A3\u30FC\u30EB\u30C9\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      } else if (codes.has(def.type)) {
        if (!Array.isArray(value) || value.some((x) => !obj(x) || typeof x.code !== "string"))
          stop("\u30E6\u30FC\u30B6\u30FC\u30FB\u7D44\u7E54\u30FB\u30B0\u30EB\u30FC\u30D7\u9805\u76EE\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      } else if (def.type === "NUMBER") {
        if (value !== null && typeof value !== "string" && typeof value !== "number")
          stop("\u6570\u5024\u30D5\u30A3\u30FC\u30EB\u30C9\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      } else if (scalar.has(def.type)) {
        if (value !== null && typeof value !== "string")
          stop("\u6587\u5B57\u5217\u30FB\u65E5\u4ED8\u30D5\u30A3\u30FC\u30EB\u30C9\u306E\u5024\u304C\u4E0D\u6B63\u3067\u3059: " + where);
      }
    }
  }
  function filterValue(value, def) {
    if (def.type === "SUBTABLE") {
      if (!Array.isArray(value)) return [];
      return value.map((row) => {
        const result = {};
        for (const [code2, fd2] of Object.entries(def.fields)) {
          if (row?.value?.[code2]) result[code2] = { value: filterValue(row.value[code2].value, fd2) };
        }
        return { value: result };
      });
    }
    if (def.type === "FILE") {
      return (Array.isArray(value) ? value : []).map((f) => ({ fileKey: String(f.fileKey || ""), name: String(f.name || ""), size: Number(f.size || 0), contentType: String(f.contentType || "application/octet-stream") }));
    }
    if (["USER_SELECT", "GROUP_SELECT", "ORGANIZATION_SELECT"].includes(def.type)) {
      return (Array.isArray(value) ? value : []).map((x) => ({ code: String(x.code) }));
    }
    if (Array.isArray(value)) return value.map((v) => obj(v) ? structuredClone(v) : v);
    return value === void 0 ? null : value;
  }
  function normalizeRecord(record, schema) {
    if (!obj(record) || !obj(schema)) stop("\u4E0D\u6B63\u306A\u30EC\u30B3\u30FC\u30C9\u5F62\u5F0F\u3067\u3059");
    const result = {};
    for (const [code2, def] of Object.entries(schema)) {
      if (record[code2]) result[code2] = { value: filterValue(record[code2].value, def) };
    }
    return result;
  }
  function visitFiles(rec, schema, visit) {
    for (const [code2, def] of Object.entries(schema)) {
      const val = rec[code2]?.value;
      if (def.type === "FILE" && Array.isArray(val)) {
        for (const f of val) visit(f);
      } else if (def.type === "SUBTABLE" && Array.isArray(val)) {
        for (const row of val) visitFiles(row.value, def.fields, visit);
      }
    }
  }
  var checkPath = (name) => {
    if (!/^(manifest\.json|schema\/(fields|layout|source-fields|settings|coverage)\.json|data\/(records|source-meta)\.jsonl|attachments\/[0-9a-f]{64})$/.test(name)) stop("ZIP\u5185\u306E\u4E0D\u6B63\u306A\u30D1\u30B9: " + name);
  };
  function sizeCheck(bytes, limit = MAX_BYTES) {
    if (bytes > limit) stop("\u5BB9\u91CF\u4E0A\u9650\uFF0825MiB\uFF09\u3092\u8D85\u3048\u307E\u3057\u305F\u3002\u5B89\u5168\u306E\u305F\u3081\u51E6\u7406\u3092\u4E2D\u6B62\u3057\u307E\u3059");
  }
  async function makeArchive({ appId, fields, layout, records, download, now = (/* @__PURE__ */ new Date()).toISOString(), maxBytes = MAX_BYTES, settings = null, coverage = null, sourceMeta = null }) {
    if (!Number.isSafeInteger(Number(appId)) || Number(appId) <= 0) stop("\u30A2\u30D7\u30EAID\u304C\u4E0D\u6B63\u3067\u3059");
    if (!Array.isArray(records) || records.length > MAX_RECORDS) stop("\u30EC\u30B3\u30FC\u30C9\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F");
    if (typeof download !== "function") stop("\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u51E6\u7406\u304C\u5FC5\u8981\u3067\u3059");
    const schema = writableSchema(fields);
    const out = records.map((r) => normalizeRecord(r, schema));
    const contents = {};
    const attachments = {};
    let size = 0;
    for (const rec of out) {
      const pending = [];
      visitFiles(rec, schema, (f) => pending.push(f));
      for (const f of pending) {
        if (!f.fileKey) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u8B58\u5225\u5B50\u304C\u3042\u308A\u307E\u305B\u3093");
        sizeCheck(size + f.size, maxBytes);
        if (!attachments[f.fileKey]) {
          const bytes = u82(await download(f.fileKey));
          size += bytes.byteLength;
          sizeCheck(size, maxBytes);
          const hash = await sha256(bytes);
          contents["attachments/" + hash] = bytes;
          attachments[f.fileKey] = { ref: hash, name: f.name, size: bytes.byteLength, contentType: f.contentType };
        }
        const info = attachments[f.fileKey];
        f.ref = info.ref;
        f.name = info.name;
        f.size = info.size;
        f.contentType = info.contentType;
        delete f.fileKey;
      }
    }
    const texts = {
      "schema/fields.json": s(schema),
      "schema/layout.json": s(layout || {}),
      // Full source field definitions are only used to create a NEW app draft.
      // Never apply raw definitions to an existing app.
      "schema/source-fields.json": s({ properties: fields?.properties || fields || {} }),
      "data/records.jsonl": out.map((r) => s(r)).join("\n") + (out.length ? "\n" : "")
    };
    const localArchive = settings !== null || coverage !== null || sourceMeta !== null;
    if (localArchive) {
      if (!obj(settings) || !obj(coverage) || !Array.isArray(sourceMeta) || sourceMeta.length !== out.length)
        stop("\u30ED\u30FC\u30AB\u30EB\u30A2\u30FC\u30AB\u30A4\u30D6\u306E\u8A2D\u5B9A\u30FB\u53D6\u5F97\u72B6\u6CC1\u30FB\u30E1\u30BF\u60C5\u5831\u304C\u4E0D\u6B63\u3067\u3059");
      texts["schema/settings.json"] = s(settings);
      texts["schema/coverage.json"] = s(coverage);
      texts["data/source-meta.jsonl"] = sourceMeta.map((r) => s(r)).join("\n") + (sourceMeta.length ? "\n" : "");
    }
    const digests = {};
    for (const [path, body] of Object.entries(texts)) {
      const bytes = strToU8(body);
      size += bytes.length;
      sizeCheck(size, maxBytes);
      contents[path] = bytes;
      digests[path] = await sha256(bytes);
    }
    const uniqueFiles = Object.entries(contents).filter(([name]) => name.startsWith("attachments/")).map(([path, b]) => ({ path, size: b.length, sha256: path.slice("attachments/".length) }));
    const manifest = {
      format: FORMAT,
      version: localArchive ? 3 : VERSION,
      createdAt: now,
      sourceAppId: Number(appId),
      recordCount: out.length,
      files: uniqueFiles,
      digests,
      limitations: ["append-only restore", "no system fields or audit history", "no process status reconstruction", "new-app draft only", "no permissions or views", "lookup values omitted"]
    };
    const manifestBytes = strToU8(s(manifest));
    size += manifestBytes.length;
    sizeCheck(size, maxBytes);
    contents["manifest.json"] = manifestBytes;
    if (Object.keys(contents).length > MAX_ZIP_ENTRIES) stop("ZIP\u5185\u306E\u30D5\u30A1\u30A4\u30EB\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F");
    const mtime = new Date(now);
    if (!Number.isFinite(mtime.getTime()) || mtime.getUTCFullYear() < 1980 || mtime.getUTCFullYear() > 2107)
      stop("\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u65E5\u6642\u304C\u4E0D\u6B63\u3067\u3059");
    const timestamped = Object.fromEntries(Object.entries(contents).map(([name, bytes]) => [name, [bytes, { mtime }]]));
    const zip = zipSync(timestamped, { level: 6 });
    sizeCheck(zip.length, maxBytes);
    return { zip, manifest, hash: await sha256(zip) };
  }
  async function inspectArchive(zipInput, { expectedHash, maxBytes = MAX_BYTES, maxEntries = MAX_ZIP_ENTRIES } = {}) {
    if (!Number.isSafeInteger(maxEntries) || maxEntries < 1 || maxEntries > MAX_ZIP_ENTRIES) stop("ZIP\u5185\u306E\u30D5\u30A1\u30A4\u30EB\u6570\u4E0A\u9650\u304C\u4E0D\u6B63\u3067\u3059");
    const bytes = u82(zipInput);
    sizeCheck(bytes.byteLength, maxBytes);
    if (expectedHash && await sha256(bytes) !== expectedHash.toLowerCase()) stop("ZIP\u5168\u4F53\u306ESHA-256\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    let inflatedTotal = 0, entries, entryCount = 0;
    const seenPaths = /* @__PURE__ */ new Set();
    try {
      entries = unzipSync(bytes, { filter: (file) => {
        if (++entryCount > maxEntries) stop("ZIP\u5185\u306E\u30D5\u30A1\u30A4\u30EB\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F");
        checkPath(file.name);
        if (seenPaths.has(file.name)) stop("ZIP\u5185\u306B\u540C\u3058\u30D5\u30A1\u30A4\u30EB\u304C\u91CD\u8907\u3057\u3066\u3044\u307E\u3059: " + file.name);
        seenPaths.add(file.name);
        const n = Number(file.originalSize);
        if (!Number.isSafeInteger(n) || n < 0) stop("ZIP\u306E\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
        inflatedTotal += n;
        sizeCheck(inflatedTotal, maxBytes);
        return true;
      } });
    } catch (e) {
      throw new Error("ZIP\u5C55\u958B\u30FB\u691C\u8A3C\u306B\u5931\u6557\u3057\u307E\u3057\u305F: " + e.message);
    }
    const load = (path) => {
      if (!entries[path]) stop("\u5FC5\u9808\u30D5\u30A1\u30A4\u30EB\u304C\u3042\u308A\u307E\u305B\u3093: " + path);
      return strFromU8(entries[path]);
    };
    let manifest, schema, layout, sourceFields = null, records, settings = null, coverage = null, sourceMeta = null;
    try {
      manifest = JSON.parse(load("manifest.json"));
      schema = JSON.parse(load("schema/fields.json"));
      layout = JSON.parse(load("schema/layout.json"));
      const text2 = load("data/records.jsonl");
      records = text2.trim() ? text2.trimEnd().split("\n").map((line) => JSON.parse(line)) : [];
    } catch (e) {
      throw new Error("\u5185\u5BB9\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093: " + e.message);
    }
    if (manifest?.format !== FORMAT || ![1, 2, 3].includes(manifest?.version)) stop("\u672A\u5BFE\u5FDC\u306E\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u5F62\u5F0F\u3067\u3059");
    const expectedTextPaths = ["schema/fields.json", "schema/layout.json", "data/records.jsonl"];
    if (manifest.version >= 2) {
      try {
        sourceFields = JSON.parse(load("schema/source-fields.json"));
      } catch (e) {
        stop("v2\u5F62\u5F0F\u306E\u30D5\u30A9\u30FC\u30E0\u5B9A\u7FA9\u304C\u4E0D\u6B63\u3067\u3059: " + e.message);
      }
      if (!obj(sourceFields) || !obj(sourceFields.properties)) stop("\u30D5\u30A9\u30FC\u30E0\u5B9A\u7FA9\u304C\u4E0D\u6B63\u3067\u3059");
      expectedTextPaths.push("schema/source-fields.json");
    }
    if (manifest.version === 1 && entries["schema/source-fields.json"]) stop("v1\u5F62\u5F0F\u306B\u672A\u691C\u8A3C\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u8A2D\u5B9A\u304C\u3042\u308A\u307E\u3059");
    if (manifest.version === 3) {
      try {
        settings = JSON.parse(load("schema/settings.json"));
        coverage = JSON.parse(load("schema/coverage.json"));
        const text2 = load("data/source-meta.jsonl");
        sourceMeta = text2.trim() ? text2.trimEnd().split("\n").map((line) => JSON.parse(line)) : [];
      } catch (e) {
        stop("v3\u306E\u62E1\u5F35\u30C7\u30FC\u30BF\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093: " + e.message);
      }
      if (!obj(settings) || !obj(coverage) || !Array.isArray(sourceMeta) || sourceMeta.length !== records.length || sourceMeta.some((x) => !obj(x))) stop("v3\u306E\u30E1\u30BF\u30C7\u30FC\u30BF\u304C\u4E0D\u6B63\u3067\u3059");
      expectedTextPaths.push("schema/settings.json", "schema/coverage.json", "data/source-meta.jsonl");
    } else if (entries["schema/settings.json"] || entries["schema/coverage.json"] || entries["data/source-meta.jsonl"]) stop("\u65E7\u5F62\u5F0F\u306B\u672A\u691C\u8A3C\u306E\u62E1\u5F35\u30C7\u30FC\u30BF\u304C\u3042\u308A\u307E\u3059");
    if (!obj(schema) || !Array.isArray(records) || records.length > MAX_RECORDS || records.length !== manifest.recordCount) stop("\u4EF6\u6570\u307E\u305F\u306F\u30D5\u30A3\u30FC\u30EB\u30C9\u69CB\u9020\u304C\u4E0D\u6B63\u3067\u3059");
    validatePortableSchema(schema);
    for (const p of expectedTextPaths) {
      if (await sha256(entries[p]) !== manifest.digests?.[p]) stop("\u5185\u5BB9\u306E\u30CF\u30C3\u30B7\u30E5\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093: " + p);
    }
    if (sourceFields && JSON.stringify(writableSchema(sourceFields)) !== JSON.stringify(schema))
      stop("\u30EC\u30B3\u30FC\u30C9\u69CB\u9020\u3068\u5143\u30A2\u30D7\u30EA\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u5B9A\u7FA9\u304C\u77DB\u76FE\u3057\u3066\u3044\u307E\u3059");
    if (!Array.isArray(manifest.files)) stop("\u30D5\u30A1\u30A4\u30EB\u4E00\u89A7\u304C\u4E0D\u6B63\u3067\u3059");
    const manifestPaths = /* @__PURE__ */ new Set();
    for (const f of manifest.files) {
      if (!f || typeof f.path !== "string" || !/^attachments\/[0-9a-f]{64}$/.test(f.path) || manifestPaths.has(f.path)) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u4E00\u89A7\u304C\u4E0D\u6B63\u3067\u3059");
      manifestPaths.add(f.path);
      if (!entries[f.path] || entries[f.path].length !== f.size || await sha256(entries[f.path]) !== f.sha256 || f.path !== "attachments/" + f.sha256) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u6574\u5408\u6027\u30A8\u30E9\u30FC");
    }
    for (const p of Object.keys(entries)) {
      checkPath(p);
      if (p.startsWith("attachments/") && !manifestPaths.has(p)) stop("\u672A\u7533\u544A\u306E\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u304C\u3042\u308A\u307E\u3059");
    }
    for (const [index, r] of records.entries()) {
      validatePortableRecord(r, schema, "record[" + index + "]");
      visitFiles(r, schema, (f) => {
        if (!manifestPaths.has("attachments/" + f.ref)) stop("\u30EC\u30B3\u30FC\u30C9\u304C\u53C2\u7167\u3059\u308B\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u304C\u6B20\u843D\u3057\u3066\u3044\u307E\u3059");
      });
    }
    return { manifest, schema, layout, sourceFields, records, settings, coverage, sourceMeta, files: entries, archiveHash: await sha256(bytes) };
  }
  function createRestorePlan(archive, targetFields, targetAppId, managementAppId) {
    if (!archive?.manifest || !obj(archive.schema) || !Array.isArray(archive.records)) stop("\u691C\u8A3C\u6E08\u307F\u30A2\u30FC\u30AB\u30A4\u30D6\u304C\u5FC5\u8981\u3067\u3059");
    const id = Number(targetAppId);
    if (!Number.isSafeInteger(id) || id <= 0 || id === Number(managementAppId)) stop("\u5FA9\u5143\u5148\u30A2\u30D7\u30EAID\u304C\u4E0D\u6B63\u307E\u305F\u306F\u7BA1\u7406\u30A2\u30D7\u30EA\u3067\u3059");
    const target = writableSchema(targetFields);
    const mapped = {}, skipped = [];
    for (const [code2, def] of Object.entries(archive.schema)) {
      const t = target[code2];
      if (!t) {
        skipped.push(code2 + ": \u5FA9\u5143\u5148\u306B\u5B58\u5728\u3057\u307E\u305B\u3093");
        continue;
      }
      if (t.type !== def.type) stop("\u4E92\u63DB\u6027\u306E\u306A\u3044\u30D5\u30A3\u30FC\u30EB\u30C9\u578B: " + code2 + " (" + def.type + " -> " + t.type + ")");
      if (def.type === "SUBTABLE") {
        const members = {};
        for (const [sub, sd] of Object.entries(def.fields)) {
          if (!t.fields[sub]) {
            skipped.push(code2 + "." + sub + ": \u5FA9\u5143\u5148\u306B\u5B58\u5728\u3057\u307E\u305B\u3093");
            continue;
          }
          if (t.fields[sub].type !== sd.type) stop("\u30C6\u30FC\u30D6\u30EB\u5185\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u578B\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093: " + code2 + "." + sub);
          members[sub] = sd;
        }
        mapped[code2] = { type: "SUBTABLE", fields: members };
      } else mapped[code2] = def;
    }
    const copyMapped = (r, defs) => {
      const targetRecord = {};
      for (const [code2, def] of Object.entries(defs)) {
        if (!r[code2]) continue;
        if (def.type === "SUBTABLE") {
          targetRecord[code2] = { value: (r[code2].value || []).map((row) => ({ value: copyMapped(row.value || {}, def.fields) })) };
        } else targetRecord[code2] = { value: structuredClone(r[code2].value) };
      }
      return targetRecord;
    };
    const rows = archive.records.map((r) => copyMapped(r, mapped));
    if (rows.length && Object.keys(mapped).length === 0) stop("\u8EE2\u9001\u3067\u304D\u308B\u30D5\u30A3\u30FC\u30EB\u30C9\u304C\u3042\u308A\u307E\u305B\u3093");
    const fileRefs = new Set(archive.manifest.files.map((f) => f.sha256));
    for (const r of rows) visitFiles(r, mapped, (f) => {
      if (!fileRefs.has(f.ref)) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u53C2\u7167\u304C\u4E0D\u6B63\u3067\u3059");
    });
    return { targetAppId: id, rows, mapped, skipped, recordCount: rows.length, sourceAppId: archive.manifest.sourceAppId, archiveCreatedAt: archive.manifest.createdAt };
  }
  async function materializeRestoreRow(row, schema, upload, entries) {
    const out = structuredClone(row);
    const todo = [];
    visitFiles(out, schema, (f) => todo.push(f));
    for (const f of todo) {
      const bytes = entries["attachments/" + f.ref];
      if (!bytes) stop("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u5B9F\u4F53\u304C\u3042\u308A\u307E\u305B\u3093");
      const key = await upload(bytes, f.name || "file.bin", f.contentType || "application/octet-stream");
      delete f.ref;
      delete f.name;
      delete f.size;
      delete f.contentType;
      f.fileKey = key;
    }
    return out;
  }

  // src/encryption.js
  var MAGIC = new TextEncoder().encode("RAKENC01");
  var HEADER_SIZE = 40;
  var SALT_LEN = 16;
  var IV_LEN = 12;
  var MIN_ITERATIONS = 31e4;
  var MAX_ITERATIONS = 2e6;
  var TAG_LEN = 16;
  var error = (reason) => {
    throw new Error(reason);
  };
  var toBytes = (value) => value instanceof Uint8Array ? value : new Uint8Array(value);
  var digest = () => globalThis.crypto?.subtle || error("\u3053\u306E\u74B0\u5883\u3067\u306FWeb Crypto\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093");
  function checkPassphrase(value) {
    if (typeof value !== "string" || value.length < 12 || value.length > 1024) error("\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u306F12\u301C1024\u6587\u5B57\u3067\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044");
    return new TextEncoder().encode(value);
  }
  function isEncryptedArchive(value) {
    const bytes = toBytes(value);
    return bytes.length >= MAGIC.length && MAGIC.every((b, i) => bytes[i] === b);
  }
  function isPotentialEncryptedArchive(value) {
    const bytes = toBytes(value);
    return bytes.length >= 4 && bytes[0] === 82 && bytes[1] === 65 && bytes[2] === 75 && bytes[3] === 69;
  }
  async function derive(passphrase, salt, iterations, usage) {
    const subtle = digest();
    const raw = checkPassphrase(passphrase);
    const key = await subtle.importKey("raw", raw, "PBKDF2", false, ["deriveKey"]);
    raw.fill(0);
    return subtle.deriveKey(
      { name: "PBKDF2", salt, iterations, hash: "SHA-256" },
      key,
      { name: "AES-GCM", length: 256 },
      false,
      [usage]
    );
  }
  async function encryptLocalArchive(archive, passphrase, { iterations = MIN_ITERATIONS, salt, iv } = {}) {
    const plaintext = toBytes(archive);
    if (plaintext.byteLength < 1 || plaintext.byteLength > MAX_BYTES) error("\u6697\u53F7\u5316\u5BFE\u8C61\u306F25MiB\u4EE5\u5185\u306E\u30A2\u30FC\u30AB\u30A4\u30D6\u306B\u3057\u3066\u304F\u3060\u3055\u3044");
    if (!Number.isSafeInteger(iterations) || iterations < MIN_ITERATIONS || iterations > MAX_ITERATIONS)
      error("\u9375\u5C0E\u51FA\u306E\u53CD\u5FA9\u56DE\u6570\u304C\u8A31\u5BB9\u7BC4\u56F2\u5916\u3067\u3059");
    const randomSalt = salt ? toBytes(salt) : crypto.getRandomValues(new Uint8Array(SALT_LEN));
    const randomIv = iv ? toBytes(iv) : crypto.getRandomValues(new Uint8Array(IV_LEN));
    if (randomSalt.length !== SALT_LEN || randomIv.length !== IV_LEN) error("Salt\u307E\u305F\u306FIV\u306E\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
    const header = new Uint8Array(HEADER_SIZE);
    header.set(MAGIC);
    header.set(randomSalt, 8);
    header.set(randomIv, 24);
    new DataView(header.buffer).setUint32(36, iterations, false);
    const key = await derive(passphrase, randomSalt, iterations, "encrypt");
    const ciphertext = new Uint8Array(await digest().encrypt({
      name: "AES-GCM",
      iv: randomIv,
      additionalData: header,
      tagLength: 128
    }, key, plaintext));
    const encrypted = new Uint8Array(HEADER_SIZE + ciphertext.length);
    encrypted.set(header);
    encrypted.set(ciphertext, HEADER_SIZE);
    return encrypted;
  }
  async function decryptLocalArchive(envelope, passphrase) {
    const bytes = toBytes(envelope);
    if (bytes.length < HEADER_SIZE + TAG_LEN + 1 || bytes.length > HEADER_SIZE + TAG_LEN + MAX_BYTES)
      error("\u6697\u53F7\u5316\u30A2\u30FC\u30AB\u30A4\u30D6\u306E\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
    if (!isEncryptedArchive(bytes)) error("\u975E\u5BFE\u5FDC\u306E\u6697\u53F7\u5316\u30A2\u30FC\u30AB\u30A4\u30D6\u5F62\u5F0F\u3067\u3059");
    const header = bytes.slice(0, HEADER_SIZE);
    const iterations = new DataView(header.buffer).getUint32(36, false);
    if (iterations < MIN_ITERATIONS || iterations > MAX_ITERATIONS) error("\u9375\u5C0E\u51FA\u306E\u53CD\u5FA9\u56DE\u6570\u304C\u4E0D\u6B63\u3067\u3059");
    const key = await derive(passphrase, header.slice(8, 24), iterations, "decrypt");
    try {
      const plaintext = new Uint8Array(await digest().decrypt(
        {
          name: "AES-GCM",
          iv: header.slice(24, 36),
          additionalData: header,
          tagLength: 128
        },
        key,
        bytes.subarray(HEADER_SIZE)
      ));
      if (plaintext.length > MAX_BYTES) {
        plaintext.fill(0);
        error("\u5FA9\u53F7\u30C7\u30FC\u30BF\u304C\u5BB9\u91CF\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
      }
      return plaintext;
    } catch {
      error("\u5FA9\u53F7\u3067\u304D\u307E\u305B\u3093\u3002\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u304B\u30D5\u30A1\u30A4\u30EB\u306E\u5B8C\u5168\u6027\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
    }
  }

  // src/collection.js
  var COLLECTION_FORMAT = "resoarc.kintone.archive.collection";
  var COLLECTION_VERSION = 1;
  var MAX_PARTS = 256;
  var MAX_COLLECTION_RECORDS = 25e4;
  var MAX_COLLECTION_BYTES = 256 * 1024 * 1024;
  var encoder = new TextEncoder();
  var decoder = new TextDecoder();
  var fail = (reason) => {
    throw Error(reason);
  };
  var object = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
  var NAME = /^part-[0-9]{5}\.ra-kintone(?:\.enc)?$/;
  var sha = /^[0-9a-f]{64}$/;
  function pathName(i, encrypted) {
    return "part-" + String(i).padStart(5, "0") + ".ra-kintone" + (encrypted ? ".enc" : "");
  }
  function validateIndex(index) {
    if (!object(index) || index.format !== COLLECTION_FORMAT || index.version !== COLLECTION_VERSION)
      fail("\u672A\u5BFE\u5FDC\u306E\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u5F62\u5F0F\u3067\u3059");
    if (!Number.isSafeInteger(index.sourceAppId) || index.sourceAppId < 1 || !Number.isSafeInteger(index.recordCount) || index.recordCount < 0 || index.recordCount > MAX_COLLECTION_RECORDS || !Array.isArray(index.parts) || index.parts.length < 1 || index.parts.length > MAX_PARTS || typeof index.encrypted !== "boolean") fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u7D22\u5F15\u304C\u4E0D\u6B63\u3067\u3059");
    let expected = 0, total = 0;
    for (const [i, p] of index.parts.entries()) {
      if (!object(p) || !NAME.test(p.file) || p.file !== pathName(i + 1, index.encrypted) || p.start !== expected || !Number.isSafeInteger(p.count) || p.count < 0 || p.count > 1e3 || !Number.isSafeInteger(p.bytes) || p.bytes < 1 || p.bytes > MAX_BYTES + 56 || !sha.test(p.sha256) || !sha.test(p.zipSha256)) fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u7D22\u5F15\u304C\u4E0D\u6B63\u3067\u3059");
      expected += p.count;
      total += p.bytes;
    }
    if (expected !== index.recordCount || total !== index.totalBytes || total > MAX_COLLECTION_BYTES)
      fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u7D22\u5F15\u306E\u4EF6\u6570\u307E\u305F\u306F\u5BB9\u91CF\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
  }
  async function openCollection(indexBytes, readPart, { passphrase = "" } = {}) {
    if (typeof readPart !== "function") fail("\u30ED\u30FC\u30AB\u30EB\u30D5\u30A1\u30A4\u30EB\u8AAD\u307F\u8FBC\u307F\u95A2\u6570\u304C\u5FC5\u8981\u3067\u3059");
    const indexRaw = indexBytes instanceof Uint8Array ? indexBytes : new Uint8Array(indexBytes);
    if (indexRaw.length < 1 || indexRaw.length > 1024 * 1024) fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u7D22\u5F15\u306E\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
    let index;
    try {
      index = JSON.parse(decoder.decode(indexRaw));
    } catch {
      fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u7D22\u5F15\u3092\u89E3\u91C8\u3067\u304D\u307E\u305B\u3093");
    }
    validateIndex(index);
    if (index.encrypted && (!passphrase || passphrase.length < 12)) fail("\u6697\u53F7\u5316\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u306E\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u304C\u5FC5\u8981\u3067\u3059");
    const allRecords = [], allMeta = [], mergedFiles = /* @__PURE__ */ Object.create(null), uniqueFiles = /* @__PURE__ */ new Map();
    let first = null;
    for (const part of index.parts) {
      const raw = await readPart(part.file);
      if (!(raw instanceof Uint8Array) || raw.length !== part.bytes || await sha256(raw) !== part.sha256) fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u304C\u6B20\u843D\u30FB\u7834\u640D\u3057\u3066\u3044\u307E\u3059: " + part.file);
      let zip = raw;
      if (index.encrypted) zip = await decryptLocalArchive(raw, passphrase);
      let archive;
      try {
        archive = await inspectArchive(zip, { expectedHash: part.zipSha256 });
      } finally {
        if (zip !== raw) zip.fill(0);
      }
      if (archive.manifest.sourceAppId !== index.sourceAppId || archive.manifest.recordCount !== part.count || archive.manifest.createdAt !== index.createdAt || archive.manifest.version !== 3) fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u306E\u5185\u5BB9\u30FB\u30A2\u30D7\u30EAID\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (!first) first = archive;
      else if (JSON.stringify(archive.schema) !== JSON.stringify(first.schema) || JSON.stringify(archive.sourceFields) !== JSON.stringify(first.sourceFields) || JSON.stringify(archive.layout) !== JSON.stringify(first.layout) || JSON.stringify(archive.settings) !== JSON.stringify(first.settings) || JSON.stringify(archive.coverage) !== JSON.stringify(first.coverage))
        fail("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u9593\u3067\u30D5\u30A9\u30FC\u30E0\u30FB\u8A2D\u5B9A\u304C\u5909\u5316\u3057\u3066\u3044\u307E\u3059");
      allRecords.push(...archive.records);
      allMeta.push(...archive.sourceMeta);
      for (const file of archive.manifest.files) {
        const prior = uniqueFiles.get(file.path);
        if (prior && JSON.stringify(prior) !== JSON.stringify(file)) fail("\u5206\u5272\u9593\u3067\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u30CF\u30C3\u30B7\u30E5\u304C\u77DB\u76FE\u3057\u3066\u3044\u307E\u3059");
        uniqueFiles.set(file.path, file);
        mergedFiles[file.path] = archive.files[file.path];
      }
    }
    if (allRecords.length !== index.recordCount || allMeta.length !== index.recordCount) fail("\u30B3\u30EC\u30AF\u30B7\u30E7\u30F3\u306E\u7DCF\u4EF6\u6570\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    const indexHash = await sha256(indexRaw);
    return {
      ...first,
      records: allRecords,
      sourceMeta: allMeta,
      files: mergedFiles,
      manifest: { ...first.manifest, files: [...uniqueFiles.values()], recordCount: index.recordCount, collection: true },
      archiveHash: indexHash,
      collectionIndex: index
    };
  }
  async function buildCollectionStream({
    appId,
    fields,
    layout,
    pages,
    metadataOf,
    settings,
    coverage,
    download,
    onPart,
    passphrase = "",
    partRecordLimit = 500,
    maxPartBytes = MAX_BYTES,
    maxRecords = MAX_COLLECTION_RECORDS,
    createdAt = (/* @__PURE__ */ new Date()).toISOString(),
    onProgress = () => {
    }
  }) {
    if (!Number.isSafeInteger(Number(appId)) || Number(appId) < 1) fail("\u30A2\u30D7\u30EAID\u304C\u4E0D\u6B63\u3067\u3059");
    if (!pages || typeof pages[Symbol.asyncIterator] !== "function") fail("\u30DA\u30FC\u30B8\u306E\u975E\u540C\u671F\u30A4\u30C6\u30EC\u30FC\u30BF\u30FC\u304C\u5FC5\u8981\u3067\u3059");
    if (typeof metadataOf !== "function" || typeof download !== "function" || typeof onPart !== "function")
      fail("\u30E1\u30BF\u30C7\u30FC\u30BF\u30FB\u8AAD\u307F\u51FA\u3057\u30FB\u4FDD\u5B58\u30B3\u30FC\u30EB\u30D0\u30C3\u30AF\u304C\u5FC5\u8981\u3067\u3059");
    if (!Number.isSafeInteger(partRecordLimit) || partRecordLimit < 1 || partRecordLimit > 1e3)
      fail("\u5206\u5272\u30EC\u30B3\u30FC\u30C9\u6570\u304C\u4E0D\u6B63\u3067\u3059");
    if (!Number.isSafeInteger(maxPartBytes) || maxPartBytes < 1024 || maxPartBytes > MAX_BYTES)
      fail("\u5206\u5272ZIP\u4E0A\u9650\u304C\u4E0D\u6B63\u3067\u3059");
    if (!Number.isSafeInteger(maxRecords) || maxRecords < 1 || maxRecords > MAX_COLLECTION_RECORDS)
      fail("\u7DCF\u30EC\u30B3\u30FC\u30C9\u4E0A\u9650\u304C\u4E0D\u6B63\u3067\u3059");
    if (passphrase && (typeof passphrase !== "string" || passphrase.length < 12))
      fail("\u6697\u53F7\u5316\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u306F12\u6587\u5B57\u4EE5\u4E0A\u3067\u3059");
    const parts = [];
    let offset = 0, readCount = 0, totalBytes = 0;
    let batch = [], meta = [];
    async function emit(rows, metas) {
      let archive;
      try {
        archive = await makeArchive({
          appId,
          fields,
          layout,
          records: rows,
          sourceMeta: metas,
          settings,
          coverage,
          download,
          now: createdAt,
          maxBytes: maxPartBytes
        });
      } catch (error2) {
        if (!/容量上限/.test(String(error2.message))) throw error2;
        if (rows.length === 1) fail("1\u30EC\u30B3\u30FC\u30C9\u304C\u5206\u5272\u30B5\u30A4\u30BA\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002\u958B\u59CB\u30EC\u30B3\u30FC\u30C9: " + offset);
        const mid = Math.floor(rows.length / 2);
        await emit(rows.slice(0, mid), metas.slice(0, mid));
        await emit(rows.slice(mid), metas.slice(mid));
        return;
      }
      if (parts.length >= MAX_PARTS) fail("\u6700\u5927\u5206\u5272\u6570 " + MAX_PARTS + " \u3092\u8D85\u3048\u307E\u3057\u305F\u3002\u7D22\u5F15\u30D5\u30A1\u30A4\u30EB\u306F\u751F\u6210\u3055\u308C\u307E\u305B\u3093");
      let bytes = archive.zip;
      if (passphrase) bytes = await encryptLocalArchive(bytes, passphrase);
      if (totalBytes + bytes.length > MAX_COLLECTION_BYTES) fail("\u7DCF\u4FDD\u5B58\u5BB9\u91CF\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F\u3002\u7D22\u5F15\u30D5\u30A1\u30A4\u30EB\u306F\u751F\u6210\u3055\u308C\u307E\u305B\u3093");
      const file = pathName(parts.length + 1, !!passphrase);
      const entry = {
        file,
        start: offset,
        count: rows.length,
        bytes: bytes.length,
        sha256: await sha256(bytes),
        zipSha256: archive.hash
      };
      await onPart(file, bytes, entry);
      parts.push(entry);
      totalBytes += bytes.length;
      offset += rows.length;
      onProgress({ read: readCount, written: offset, parts: parts.length, bytes: totalBytes });
    }
    for await (const page of pages) {
      if (!Array.isArray(page) || page.length > 500) fail("\u30B9\u30C8\u30EA\u30FC\u30E0\u306E\u30EC\u30B3\u30FC\u30C9\u30DA\u30FC\u30B8\u304C\u4E0D\u6B63\u3067\u3059");
      if (readCount + page.length > maxRecords) fail("\u30EC\u30B3\u30FC\u30C9\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F");
      for (const record of page) {
        if (!object(record)) fail("\u30EC\u30B3\u30FC\u30C9\u306E\u5F62\u5F0F\u304C\u4E0D\u6B63\u3067\u3059");
        batch.push(record);
        const m = metadataOf(record);
        if (!object(m)) fail("\u30E1\u30BF\u30C7\u30FC\u30BF\u306E\u5F62\u5F0F\u304C\u4E0D\u6B63\u3067\u3059");
        meta.push(m);
        readCount++;
        if (batch.length >= partRecordLimit) {
          await emit(batch, meta);
          batch = [];
          meta = [];
        }
      }
    }
    if (batch.length || readCount === 0) await emit(batch, meta);
    if (offset !== readCount) fail("\u4FDD\u5B58\u4EF6\u6570\u3068\u53D6\u5F97\u4EF6\u6570\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
    const index = {
      format: COLLECTION_FORMAT,
      version: COLLECTION_VERSION,
      sourceAppId: Number(appId),
      createdAt,
      recordCount: readCount,
      encrypted: !!passphrase,
      totalBytes,
      parts,
      limitations: [
        "Cursor\u8D70\u67FB\u4E2D\u306E\u540C\u6642\u66F4\u65B0\u306B\u3064\u3044\u3066\u53B3\u5BC6\u306A\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u6574\u5408\u6027\u306F\u4FDD\u8A3C\u3057\u307E\u305B\u3093",
        "\u3059\u3079\u3066\u306E\u30D1\u30FC\u30C8\u3092\u691C\u8A3C\u3059\u308B\u307E\u3067\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u6210\u529F\u3068\u3057\u3066\u6271\u308F\u306A\u3044\u3067\u304F\u3060\u3055\u3044"
      ]
    };
    validateIndex(index);
    return {
      index,
      bytes: encoder.encode(JSON.stringify(index, null, 2) + "\n"),
      filename: "resoarc-collection.ra-collection.json"
    };
  }

  // src/transport.js
  async function fetchAllRecords(app, api2, { maxRecords = 2e4 } = {}) {
    if (typeof api2 !== "function") throw Error("kintone API\u95A2\u6570\u304C\u5FC5\u8981\u3067\u3059");
    if (!Number.isSafeInteger(maxRecords) || maxRecords < 1) throw Error("\u53D6\u5F97\u4EF6\u6570\u306E\u4E0A\u9650\u304C\u4E0D\u6B63\u3067\u3059");
    const created = await api2("/k/v1/records/cursor.json", "POST", { app, size: 500 });
    if (typeof created?.id !== "string" || !created.id) throw Error("\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u7528Cursor\u306E\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    const records = [];
    let finished = false;
    try {
      while (!finished) {
        const page = await api2("/k/v1/records/cursor.json", "GET", { id: created.id });
        if (!Array.isArray(page?.records) || typeof page.next !== "boolean" || page.records.length > 500)
          throw Error("\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u7528Cursor\u306E\u53D6\u5F97\u7D50\u679C\u304C\u4E0D\u6B63\u3067\u3059");
        if (page.next && page.records.length === 0)
          throw Error("\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u7528Cursor\u304C\u9032\u884C\u3057\u307E\u305B\u3093\u3002\u51E6\u7406\u3092\u4E2D\u6B62\u3057\u307E\u3059");
        if (records.length + page.records.length > maxRecords)
          throw Error("\u4E00\u5EA6\u306B\u51E6\u7406\u3067\u304D\u308B\u30EC\u30B3\u30FC\u30C9\u306F" + maxRecords.toLocaleString("en-US") + "\u4EF6\u307E\u3067\u3067\u3059");
        records.push(...page.records);
        finished = !page.next;
      }
    } finally {
      if (!finished) {
        try {
          await api2("/k/v1/records/cursor.json", "DELETE", { id: created.id });
        } catch (error2) {
          console.warn("Backup cursor cleanup failed", error2);
        }
      }
    }
    return records;
  }
  async function* streamRecordPages(app, api2, { pageSize = 500, maxRecords = 25e4, signal } = {}) {
    if (typeof api2 !== "function") throw Error("kintone API\u95A2\u6570\u304C\u5FC5\u8981\u3067\u3059");
    if (!Number.isSafeInteger(Number(app)) || Number(app) < 1) throw Error("\u53D6\u5F97\u5BFE\u8C61\u30A2\u30D7\u30EAID\u304C\u4E0D\u6B63\u3067\u3059");
    if (!Number.isSafeInteger(pageSize) || pageSize < 1 || pageSize > 500) throw Error("\u53D6\u5F97\u30DA\u30FC\u30B8\u30B5\u30A4\u30BA\u304C\u4E0D\u6B63\u3067\u3059");
    if (!Number.isSafeInteger(maxRecords) || maxRecords < 1 || maxRecords > 25e4) throw Error("\u30B9\u30C8\u30EA\u30FC\u30E0\u306E\u53D6\u5F97\u4EF6\u6570\u4E0A\u9650\u304C\u4E0D\u6B63\u3067\u3059");
    if (signal?.aborted) throw Error("\u51E6\u7406\u304C\u4E2D\u6B62\u3055\u308C\u307E\u3057\u305F");
    const created = await api2("/k/v1/records/cursor.json", "POST", { app, size: pageSize });
    if (typeof created?.id !== "string" || !created.id) throw Error("Cursor\u306E\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F");
    let finished = false, received = 0;
    try {
      do {
        if (signal?.aborted) throw Error("\u51E6\u7406\u304C\u4E2D\u6B62\u3055\u308C\u307E\u3057\u305F");
        const response = await api2("/k/v1/records/cursor.json", "GET", { id: created.id });
        if (!Array.isArray(response?.records) || typeof response.next !== "boolean" || response.records.length > pageSize || response.next && response.records.length === 0)
          throw Error("Cursor\u306E\u5FDC\u7B54\u304C\u4E0D\u6B63\u307E\u305F\u306F\u505C\u6B62\u3057\u3066\u3044\u307E\u3059");
        received += response.records.length;
        if (received > maxRecords) throw Error("\u30B9\u30C8\u30EA\u30FC\u30E0\u306E\u30EC\u30B3\u30FC\u30C9\u4EF6\u6570\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F");
        finished = !response.next;
        yield response.records;
      } while (!finished);
    } finally {
      if (!finished) {
        try {
          await api2("/k/v1/records/cursor.json", "DELETE", { id: created.id });
        } catch (e) {
          console.warn("Stream cursor cleanup failed", e);
        }
      }
    }
  }

  // src/restore.js
  var MARKER_CODE = "ResoArcRestoreKey";
  var bad = (message) => {
    throw new Error(message);
  };
  var object2 = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
  var unsafe = /* @__PURE__ */ new Set(["__proto__", "prototype", "constructor"]);
  var code = (v) => typeof v === "string" && v.length > 0 && v.length <= 128 && !unsafe.has(v) && !/[/\\\[\].\s]/u.test(v);
  var ensureCode = (v) => {
    if (!code(v)) bad("\u4E0D\u6B63\u306A\u30D5\u30A3\u30FC\u30EB\u30C9\u30B3\u30FC\u30C9: " + String(v));
    return v;
  };
  var put = (obj2, key, value) => Object.defineProperty(obj2, key, { value, writable: true, enumerable: true, configurable: true });
  var own = (obj2, key) => Object.hasOwn(obj2, key);
  function createMappedRestorePlan(archive, targetFields, targetAppId, managementAppId, mapping = {}) {
    if (!object2(mapping)) bad("\u30D5\u30A3\u30FC\u30EB\u30C9\u5BFE\u5FDC\u8868\u306FJSON\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u306B\u3057\u3066\u304F\u3060\u3055\u3044");
    if (!archive?.schema || !Array.isArray(archive?.records)) bad("\u691C\u8A3C\u6E08\u307F\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u304C\u5FC5\u8981\u3067\u3059");
    const src = archive.schema, usedTargets = /* @__PURE__ */ new Set();
    const target = targetFields?.properties || targetFields;
    if (!object2(target)) bad("\u79FB\u884C\u5148\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u8A2D\u5B9A\u304C\u3042\u308A\u307E\u305B\u3093");
    const sourcePaths = /* @__PURE__ */ new Set();
    for (const [name, def] of Object.entries(src)) {
      sourcePaths.add(name);
      if (def.type === "SUBTABLE") for (const child of Object.keys(def.fields || {})) sourcePaths.add(name + "." + child);
    }
    for (const [from, to] of Object.entries(mapping)) {
      if (!sourcePaths.has(from)) bad("\u5BFE\u5FDC\u8868\u306B\u5B58\u5728\u3057\u306A\u3044\u5143\u30D5\u30A3\u30FC\u30EB\u30C9\u304C\u3042\u308A\u307E\u3059: " + from);
      if (typeof to !== "string") bad("\u79FB\u884C\u5148\u30D5\u30A3\u30FC\u30EB\u30C9\u30B3\u30FC\u30C9\u306F\u6587\u5B57\u5217\u3067\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044: " + from);
      for (const p of to.split(".")) ensureCode(p);
      if (from.split(".").length !== to.split(".").length) bad("\u30C6\u30FC\u30D6\u30EB\u968E\u5C64\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093: " + from);
      if (to.split(".").length > 2) bad("\u30C6\u30FC\u30D6\u30EB\u306E\u5165\u308C\u5B50\u306F\u672A\u5BFE\u5FDC\u3067\u3059");
      if (to === MARKER_CODE || to.endsWith("." + MARKER_CODE)) bad("\u5FA9\u5143\u7BA1\u7406\u7528\u30D5\u30A3\u30FC\u30EB\u30C9\u306F\u5BFE\u5FDC\u5148\u306B\u6307\u5B9A\u3067\u304D\u307E\u305B\u3093");
    }
    const renamedSchema = /* @__PURE__ */ Object.create(null);
    const schemaCopy = (defs, mappedDefs, tableSource = "", tableTarget = "") => {
      for (const [name, def] of Object.entries(defs)) {
        if (!tableSource && name === MARKER_CODE) continue;
        const from = tableSource ? tableSource + "." + name : name;
        const destName = own(mapping, from) ? mapping[from] : tableTarget ? tableTarget + "." + name : name;
        const destParts = destName.split(".");
        const expectedDepth = tableSource ? 2 : 1;
        if (destParts.length !== expectedDepth) bad("\u30D5\u30A3\u30FC\u30EB\u30C9\u5BFE\u5FDC\u306E\u968E\u5C64\u304C\u4E0D\u6B63\u3067\u3059: " + from);
        destParts.forEach(ensureCode);
        if (tableSource && destParts[0] !== tableTarget) bad("\u30C6\u30FC\u30D6\u30EB\u5185\u30D5\u30A3\u30FC\u30EB\u30C9\u306E\u5BFE\u5FDC\u5148\u304C\u89AA\u30C6\u30FC\u30D6\u30EB\u3068\u7570\u306A\u308A\u307E\u3059: " + from);
        const destField = destParts.at(-1);
        if (!tableSource && destField === MARKER_CODE) bad("\u5FA9\u5143\u7BA1\u7406\u7528\u30D5\u30A3\u30FC\u30EB\u30C9\u3092\u4E0A\u66F8\u304D\u3067\u304D\u307E\u305B\u3093");
        const complete = tableSource ? destParts.join(".") : destField;
        if (usedTargets.has(complete)) bad("\u8907\u6570\u306E\u5143\u30D5\u30A3\u30FC\u30EB\u30C9\u304C\u540C\u3058\u79FB\u884C\u5148\u3092\u53C2\u7167\u3057\u3066\u3044\u307E\u3059: " + complete);
        usedTargets.add(complete);
        if (def.type === "SUBTABLE") {
          const nestedSchema = /* @__PURE__ */ Object.create(null);
          schemaCopy(def.fields, nestedSchema, name, destField);
          put(mappedDefs, destField, { type: "SUBTABLE", fields: nestedSchema });
        } else put(mappedDefs, destField, { type: def.type });
      }
    };
    schemaCopy(src, renamedSchema);
    const remapRow = (defs, row, tableSource = "", tableTarget = "") => {
      const out = /* @__PURE__ */ Object.create(null);
      for (const [name, def] of Object.entries(defs)) {
        if (!tableSource && name === MARKER_CODE) continue;
        if (!own(row || {}, name)) continue;
        const from = tableSource ? tableSource + "." + name : name;
        const targetPath = own(mapping, from) ? mapping[from] : tableTarget ? tableTarget + "." + name : name;
        const dest = targetPath.split(".").at(-1);
        if (def.type === "SUBTABLE") {
          put(out, dest, { value: (row[name].value || []).map((r) => ({ value: remapRow(def.fields, r.value, name, dest) })) });
        } else put(out, dest, { value: structuredClone(row[name].value) });
      }
      return out;
    };
    const rows = archive.records.map((r) => remapRow(src, r));
    const mappedArchive = { ...archive, schema: renamedSchema, records: rows };
    const plan = createRestorePlan(mappedArchive, targetFields, targetAppId, managementAppId);
    plan.mapping = structuredClone(mapping);
    for (const [from, to] of Object.entries(mapping)) {
      const targetParts = to.split(".");
      const schemaEntry = targetParts.length === 1 ? target[targetParts[0]] : target[targetParts[0]]?.fields?.[targetParts[1]];
      if (!schemaEntry) bad("\u5BFE\u5FDC\u8868\u306E\u79FB\u884C\u5148\u30D5\u30A3\u30FC\u30EB\u30C9\u304C\u5B58\u5728\u3057\u307E\u305B\u3093: " + to);
      if (plan.skipped.some((x) => x === to + ": \u5FA9\u5143\u5148\u306B\u5B58\u5728\u3057\u307E\u305B\u3093")) bad("\u5BFE\u5FDC\u5148\u3092\u79FB\u884C\u3067\u304D\u307E\u305B\u3093: " + to);
    }
    const validChoices = /* @__PURE__ */ new Set(["DROP_DOWN", "RADIO_BUTTON", "CHECK_BOX", "MULTI_SELECT"]);
    const checkRow = (row, defs, fieldDefs, location) => {
      for (const [field, info] of Object.entries(defs)) {
        const dest = fieldDefs?.[field];
        if (!dest) continue;
        const value = row[field]?.value;
        if (info.type === "SUBTABLE") {
          for (const [index, sub] of (Array.isArray(value) ? value : []).entries())
            checkRow(sub.value || {}, info.fields, dest.fields, location + field + "[" + index + "].");
        } else if (validChoices.has(info.type) && value !== void 0 && value !== null) {
          const choices = new Set(Object.keys(dest.options || {}));
          const chosen = Array.isArray(value) ? value : [value];
          for (const selected of chosen) {
            if (selected !== "" && selected !== null && !choices.has(String(selected)))
              bad("\u79FB\u884C\u5148\u306E\u9078\u629E\u80A2\u306B\u5B58\u5728\u3057\u306A\u3044\u5024: " + location + field + " = " + String(selected));
          }
        }
      }
    };
    for (const [index, row] of plan.rows.entries()) checkRow(row, plan.mapped, target, "record[" + index + "].");
    for (const [name, definition2] of Object.entries(target)) {
      if (name === MARKER_CODE) continue;
      if (definition2.required === true && !own(plan.mapped, name) && (definition2.defaultValue === void 0 || definition2.defaultValue === null || definition2.defaultValue === ""))
        bad("\u5FA9\u5143\u5148\u306B\u672A\u5BFE\u5FDC\u306E\u5FC5\u9808\u30D5\u30A3\u30FC\u30EB\u30C9\u304C\u3042\u308A\u307E\u3059: " + name);
    }
    const marker = target[MARKER_CODE];
    if (!marker || marker.type !== "SINGLE_LINE_TEXT" || marker.unique !== true || marker.lookup || marker.expression)
      bad("\u79FB\u884C\u5148\u306B\u91CD\u8907\u7981\u6B62\u306E\u6587\u5B57\u5217\uFF081\u884C\uFF09\u30D5\u30A3\u30FC\u30EB\u30C9 " + MARKER_CODE + " \u304C\u5FC5\u8981\u3067\u3059\u3002\u65E2\u5B58\u30A2\u30D7\u30EA\u306E\u5834\u5408\u306F\u7BA1\u7406\u8005\u304C\u8FFD\u52A0\u3057\u3066\u304F\u3060\u3055\u3044");
    if (plan.rows.some((row) => own(row, MARKER_CODE))) bad("\u5FA9\u5143\u7BA1\u7406\u7528\u30D5\u30A3\u30FC\u30EB\u30C9\u306F\u30C7\u30FC\u30BF\u306B\u542B\u3081\u3089\u308C\u307E\u305B\u3093");
    plan.markerCode = MARKER_CODE;
    return plan;
  }
  function digestUtf8(s2) {
    return sha256(new TextEncoder().encode(s2));
  }
  async function restoreKeyBase(archive, plan) {
    if (!/^[0-9a-f]{64}$/.test(archive?.archiveHash || "")) bad("\u691C\u8A3C\u6E08\u307F\u30A2\u30FC\u30AB\u30A4\u30D6\u306E\u30CF\u30C3\u30B7\u30E5\u304C\u5FC5\u8981\u3067\u3059");
    const canonicalMapping = Object.fromEntries(Object.entries(plan.mapping || {}).sort(([a], [b]) => a.localeCompare(b, "en")));
    const mapDigest = await digestUtf8(JSON.stringify(canonicalMapping));
    const base = "RA3_" + archive.archiveHash.slice(0, 32) + "_" + mapDigest.slice(0, 12) + "_";
    return { base, archivePrefix: "RA3_" + archive.archiveHash.slice(0, 32) + "_", mappingFingerprint: mapDigest.slice(0, 12) };
  }
  function keyForIndex(base, index) {
    if (!Number.isSafeInteger(index) || index < 0) bad("\u5FA9\u5143\u884C\u756A\u53F7\u304C\u4E0D\u6B63\u3067\u3059");
    const key = base + index.toString(36);
    if (key.length > 64) bad("\u5FA9\u5143\u8B58\u5225\u5B50\u304C\u9577\u3059\u304E\u307E\u3059");
    return key;
  }
  async function scanRestoreInventory(app, api2, { maxRows = 2e5 } = {}) {
    const response = await api2("/k/v1/records/cursor.json", "POST", { app, fields: [MARKER_CODE], size: 500 });
    if (!response?.id) bad("\u5FA9\u5143\u6E08\u307F\u78BA\u8A8D\u7528\u306ECursor\u3092\u4F5C\u6210\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F");
    let finished = false, count = 0, unmarkedRecordCount = 0;
    const keys = /* @__PURE__ */ new Set();
    try {
      while (!finished) {
        const page = await api2("/k/v1/records/cursor.json", "GET", { id: response.id });
        if (!Array.isArray(page?.records) || typeof page.next !== "boolean" || page.records.length > 500)
          bad("\u79FB\u884C\u5148\u306E\u53D6\u5F97\u7D50\u679C\u304C\u4E0D\u6B63\u3067\u3059");
        if (page.next && page.records.length === 0)
          bad("\u5FA9\u5143\u6E08\u307F\u78BA\u8A8D\u7528Cursor\u304C\u9032\u884C\u3057\u307E\u305B\u3093\u3002\u51E6\u7406\u3092\u4E2D\u6B62\u3057\u307E\u3059");
        count += page.records.length;
        if (count > maxRows) bad("\u79FB\u884C\u5148\u306E\u30EC\u30B3\u30FC\u30C9\u6570\u304C\u691C\u7D22\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
        for (const record of page.records) {
          if (!object2(record) || !own(record, MARKER_CODE) || !object2(record[MARKER_CODE]) || typeof record[MARKER_CODE].value !== "string")
            bad("\u5FA9\u5143\u7BA1\u7406\u30D5\u30A3\u30FC\u30EB\u30C9\u3092\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093\u3002\u30D5\u30A3\u30FC\u30EB\u30C9\u95B2\u89A7\u6A29\u9650\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
          const k = record[MARKER_CODE].value;
          if (!k) unmarkedRecordCount++;
          else {
            if (!/^RA3_[0-9a-f]{32}_[0-9a-f]{12}_[0-9a-z]+$/.test(k))
              bad("\u5FA9\u5143\u7BA1\u7406\u30D5\u30A3\u30FC\u30EB\u30C9\u306B\u975E\u5BFE\u5FDC\u306E\u8B58\u5225\u5B50\u304C\u3042\u308A\u307E\u3059\u3002\u65E2\u5B58\u30C7\u30FC\u30BF\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
            if (keys.has(k)) bad("\u5FA9\u5143\u8B58\u5225\u5B50\u306E\u91CD\u8907\u304C\u691C\u51FA\u3055\u308C\u307E\u3057\u305F\u3002\u8FFD\u52A0\u3092\u4E2D\u6B62\u3057\u307E\u3059");
            keys.add(k);
          }
        }
        finished = !page.next;
      }
    } finally {
      if (!finished) try {
        await api2("/k/v1/records/cursor.json", "DELETE", { id: response.id });
      } catch {
      }
    }
    return { keys, unmarkedRecordCount, totalRecords: count };
  }
  async function scanRestoreKeys(app, api2, options = {}) {
    return (await scanRestoreInventory(app, api2, options)).keys;
  }
  async function previewRestoreProgress({ archive, plan, api: api2 }) {
    if (plan?.markerCode !== MARKER_CODE || !Array.isArray(plan?.rows)) bad("\u5FA9\u5143\u7528\u30D7\u30E9\u30F3\u304C\u4E0D\u6B63\u3067\u3059");
    const { base, archivePrefix } = await restoreKeyBase(archive, plan);
    const { keys, unmarkedRecordCount } = await scanRestoreInventory(plan.targetAppId, api2);
    if ([...keys].some((k) => k.startsWith(archivePrefix) && !k.startsWith(base)))
      bad("\u540C\u3058\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3092\u5225\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u5BFE\u5FDC\u4ED8\u3051\u3067\u79FB\u884C\u3057\u305F\u5C65\u6B74\u304C\u3042\u308A\u307E\u3059\u3002\u30C7\u30FC\u30BF\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
    const missingIndexes = [];
    for (let i = 0; i < plan.rows.length; i++) if (!keys.has(keyForIndex(base, i))) missingIndexes.push(i);
    const otherArchiveKeyCount = [...keys].filter((k) => k.startsWith("RA3_") && !k.startsWith(archivePrefix)).length;
    return { base, missingIndexes, total: plan.rows.length, already: plan.rows.length - missingIndexes.length, remaining: missingIndexes.length, otherArchiveKeyCount, unmarkedRecordCount };
  }
  async function runResumableRestore({ archive, plan, api: api2, upload, onProgress = () => {
  }, batchSize = 20, allowCrossArchiveAppend = false }) {
    if (typeof api2 !== "function" || typeof upload !== "function") bad("kintone API\u306E\u5B9F\u88C5\u304C\u5FC5\u8981\u3067\u3059");
    if (!Number.isSafeInteger(batchSize) || batchSize < 1 || batchSize > 100) bad("\u30D0\u30C3\u30C1\u4EF6\u6570\u304C\u4E0D\u6B63\u3067\u3059");
    if (plan?.markerCode !== MARKER_CODE || !Array.isArray(plan?.rows)) bad("\u5FA9\u5143\u7528\u30D7\u30E9\u30F3\u304C\u4E0D\u6B63\u3067\u3059");
    const snapshot = await previewRestoreProgress({ archive, plan, api: api2 });
    const { base } = snapshot;
    const missing = snapshot.missingIndexes;
    if (snapshot.otherArchiveKeyCount > 0 && missing.length > 0 && allowCrossArchiveAppend !== true)
      bad("\u5FA9\u5143\u5148\u306B\u5225\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7ZIP\u7531\u6765\u306E\u5FA9\u5143\u5C65\u6B74\u304C\u3042\u308A\u307E\u3059\u3002\u91CD\u8907\u8FFD\u52A0\u3092\u907F\u3051\u308B\u305F\u3081\u4E2D\u6B62\u3057\u307E\u3057\u305F\u3002\u65B0\u898F\u7A7A\u30A2\u30D7\u30EA\u3092\u4F7F\u3046\u304B\u3001\u660E\u793A\u7684\u306B\u5225ZIP\u8FFD\u52A0\u3092\u627F\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
    if (snapshot.unmarkedRecordCount > 0 && missing.length > 0 && allowCrossArchiveAppend !== true)
      bad("\u5FA9\u5143\u5148\u306B\u5FA9\u5143\u8B58\u5225\u5B50\u304C\u306A\u3044\u65E2\u5B58\u30EC\u30B3\u30FC\u30C9\u304C\u3042\u308A\u307E\u3059\u3002\u91CD\u8907\u8FFD\u52A0\u3092\u907F\u3051\u308B\u305F\u3081\u4E2D\u6B62\u3057\u307E\u3057\u305F\u3002\u7A7A\u306E\u65B0\u898F\u30A2\u30D7\u30EA\u3092\u4F7F\u3046\u304B\u3001\u65E2\u5B58\u30EC\u30B3\u30FC\u30C9\u3068\u306E\u7167\u5408\u5F8C\u306B\u660E\u793A\u7684\u306B\u8FFD\u52A0\u3092\u627F\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
    onProgress({ total: plan.rows.length, already: snapshot.already, added: 0, remaining: missing.length });
    let completed = 0;
    for (let start = 0; start < missing.length; start += batchSize) {
      const indexes = missing.slice(start, start + batchSize);
      const records = [];
      for (const index of indexes) {
        const row = await materializeRestoreRow(plan.rows[index], plan.mapped, upload, archive.files);
        row[MARKER_CODE] = { value: keyForIndex(base, index) };
        records.push(row);
      }
      const result = await api2("/k/v1/records.json", "POST", { app: plan.targetAppId, records });
      if (!Array.isArray(result?.ids) || result.ids.length !== records.length)
        bad("\u767B\u9332\u7D50\u679C\u3092\u78BA\u8A8D\u3067\u304D\u307E\u305B\u3093\u3002\u5FA9\u5143\u5148\u3092\u518D\u78BA\u8A8D\u3057\u3066\u304B\u3089\u518D\u958B\u3057\u3066\u304F\u3060\u3055\u3044");
      completed += records.length;
      onProgress({ total: plan.rows.length, already: plan.rows.length - missing.length, added: completed, remaining: missing.length - completed });
    }
    const verifiedKeys = await scanRestoreKeys(plan.targetAppId, api2);
    for (let i = 0; i < plan.rows.length; i++) {
      if (!verifiedKeys.has(keyForIndex(base, i)))
        bad("\u5FA9\u5143\u5148\u306E\u518D\u8AAD\u8FBC\u3067\u672A\u78BA\u8A8D\u306E\u30EC\u30B3\u30FC\u30C9\u304C\u3042\u308A\u307E\u3059\u3002\u5B8C\u4E86\u6271\u3044\u306B\u305B\u305A\u5FA9\u5143\u5148\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
    }
    return {
      total: plan.rows.length,
      added: completed,
      already: plan.rows.length - missing.length,
      verifiedRows: plan.rows.length,
      completed: true
    };
  }

  // src/restore-compare.js
  var isObject = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
  var lists = /* @__PURE__ */ new Set(["CHECK_BOX", "MULTI_SELECT"]);
  var actors = /* @__PURE__ */ new Set(["USER_SELECT", "ORGANIZATION_SELECT", "GROUP_SELECT"]);
  function canonical(value, type) {
    if (lists.has(type)) return (Array.isArray(value) ? value : []).map(String).sort();
    if (actors.has(type)) return (Array.isArray(value) ? value : []).map((x) => String(x?.code || "")).sort();
    if (type === "NUMBER") {
      const s2 = String(value ?? "");
      if (!/^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)$/.test(s2)) return s2;
      const neg = s2.startsWith("-");
      const [whole, fraction = ""] = s2.replace(/^[+-]/, "").split(".");
      const a = whole.replace(/^0+(?=[0-9])/, "") || "0", b = fraction.replace(/0+$/, "");
      const result = a + (b ? "." + b : "");
      return neg && result !== "0" ? "-" + result : result;
    }
    return value;
  }
  function compareRestoreRecord(expected, actual, schema) {
    const differences = [], attachments = [];
    function visit(src, dst, definitions, path) {
      if (!isObject(src) || !isObject(dst)) {
        differences.push(path || "record");
        return;
      }
      for (const [field, definition2] of Object.entries(definitions)) {
        if (!Object.hasOwn(src, field)) continue;
        const at = path ? path + "." + field : field;
        if (!isObject(dst[field]) || !Object.hasOwn(dst[field], "value")) {
          differences.push(at);
          continue;
        }
        const a = src[field].value, b = dst[field].value;
        if (definition2.type === "SUBTABLE") {
          if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
            differences.push(at);
            continue;
          }
          a.forEach((row, i) => visit(row.value, b[i]?.value, definition2.fields, at + "[" + i + "]"));
        } else if (definition2.type === "FILE") {
          if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
            differences.push(at);
            continue;
          }
          a.forEach((f, i) => {
            const g = b[i], where = at + "[" + i + "]";
            if (!isObject(f) || !isObject(g) || !g.fileKey || f.name !== g.name || Number(f.size) !== Number(g.size)) {
              differences.push(where);
              return;
            }
            attachments.push({ path: where, sha256: f.ref, fileKey: g.fileKey });
          });
        } else if (JSON.stringify(canonical(a, definition2.type)) !== JSON.stringify(canonical(b, definition2.type))) {
          differences.push(at);
        }
      }
    }
    visit(expected, actual, schema, "");
    return { passed: differences.length === 0, differences, attachments };
  }

  // src/restore-audit.js
  var bad2 = (message) => {
    throw Error(message);
  };
  async function auditRestoredContent({
    archive,
    plan,
    api: api2,
    download,
    maxRecords = 2e5,
    signal,
    onProgress = () => {
    }
  }) {
    if (typeof api2 !== "function" || !Array.isArray(plan?.rows) || !plan?.mapped || !Number.isSafeInteger(Number(plan.targetAppId)) || Number(plan.targetAppId) < 1)
      bad2("\u5FA9\u5143\u306E\u76E3\u67FB\u30D7\u30E9\u30F3\u304C\u4E0D\u6B63\u3067\u3059");
    if (!Number.isSafeInteger(maxRecords) || maxRecords < 1 || maxRecords > 2e5)
      bad2("\u76E3\u67FB\u4EF6\u6570\u4E0A\u9650\u304C\u4E0D\u6B63\u3067\u3059");
    if (signal?.aborted) bad2("\u76E3\u67FB\u304C\u4E2D\u6B62\u3055\u308C\u307E\u3057\u305F");
    const { base } = await restoreKeyBase(archive, plan);
    const expected = /* @__PURE__ */ new Map();
    for (let i = 0; i < plan.rows.length; i++) expected.set(keyForIndex(base, i), plan.rows[i]);
    const fields = [MARKER_CODE, ...Object.keys(plan.mapped)];
    const cursor = await api2("/k/v1/records/cursor.json", "POST", { app: plan.targetAppId, fields, size: 500 });
    if (typeof cursor?.id !== "string" || !cursor.id) bad2("\u76E3\u67FBCursor\u3092\u4F5C\u6210\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F");
    let finished = false, scanned = 0, matched = 0, attachmentCount = 0;
    const seen = /* @__PURE__ */ new Set(), differences = [];
    try {
      do {
        if (signal?.aborted) bad2("\u76E3\u67FB\u304C\u4E2D\u6B62\u3055\u308C\u307E\u3057\u305F");
        const data = await api2("/k/v1/records/cursor.json", "GET", { id: cursor.id });
        if (!Array.isArray(data?.records) || typeof data.next !== "boolean" || data.records.length > 500 || data.next && data.records.length === 0)
          bad2("\u76E3\u67FBCursor\u306E\u5FDC\u7B54\u304C\u4E0D\u6B63\u3067\u3059");
        scanned += data.records.length;
        if (scanned > maxRecords) bad2("\u76E3\u67FB\u30EC\u30B3\u30FC\u30C9\u306E\u4EF6\u6570\u4E0A\u9650\u3092\u8D85\u3048\u307E\u3057\u305F");
        for (const row of data.records) {
          const key = row?.[MARKER_CODE]?.value;
          if (typeof key !== "string") bad2("\u5FA9\u5143\u8B58\u5225\u5B50\u3092\u95B2\u89A7\u3067\u304D\u307E\u305B\u3093");
          if (!expected.has(key)) continue;
          if (seen.has(key)) bad2("\u5FA9\u5143\u8B58\u5225\u5B50\u304C\u91CD\u8907\u3057\u3066\u3044\u307E\u3059");
          seen.add(key);
          const index = parseInt(key.slice(base.length), 36);
          const result = compareRestoreRecord(expected.get(key), row, plan.mapped);
          for (const task of result.attachments) {
            if (signal?.aborted) bad2("\u76E3\u67FB\u304C\u4E2D\u6B62\u3055\u308C\u307E\u3057\u305F");
            if (typeof download !== "function") bad2("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u76E3\u67FB\u306B\u306F\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u51E6\u7406\u304C\u5FC5\u8981\u3067\u3059");
            const bytes = await download(task.fileKey);
            if (!(bytes instanceof Uint8Array) && !(bytes instanceof ArrayBuffer))
              bad2("\u6DFB\u4ED8\u306E\u53D6\u5F97\u7D50\u679C\u304C\u4E0D\u6B63\u3067\u3059");
            if (await sha256(bytes) !== task.sha256) result.differences.push(task.path);
            attachmentCount++;
          }
          if (result.differences.length) {
            for (const field of result.differences) {
              if (differences.length < 30) differences.push("record[" + index + "]." + field);
            }
          } else {
            matched++;
          }
        }
        onProgress({ scanned, matched, expected: expected.size, attachmentCount });
        finished = !data.next;
      } while (!finished);
    } finally {
      if (!finished) try {
        await api2("/k/v1/records/cursor.json", "DELETE", { id: cursor.id });
      } catch {
      }
    }
    const missing = expected.size - seen.size;
    return {
      passed: missing === 0 && differences.length === 0,
      expected: expected.size,
      matched,
      missing,
      mismatchedPaths: differences,
      attachmentsVerified: attachmentCount,
      scanned
    };
  }

  // src/migration.js
  var TYPES = /* @__PURE__ */ new Set([
    "SINGLE_LINE_TEXT",
    "MULTI_LINE_TEXT",
    "RICH_TEXT",
    "NUMBER",
    "RADIO_BUTTON",
    "DROP_DOWN",
    "CHECK_BOX",
    "MULTI_SELECT",
    "DATE",
    "TIME",
    "DATETIME",
    "LINK",
    "USER_SELECT",
    "ORGANIZATION_SELECT",
    "GROUP_SELECT",
    "FILE"
  ]);
  var SELECT = /* @__PURE__ */ new Set(["RADIO_BUTTON", "DROP_DOWN", "CHECK_BOX", "MULTI_SELECT"]);
  var TABLE_TYPES = new Set([...TYPES].filter((t) => t !== "RICH_TEXT"));
  var SAFE_CODE = /^[\p{L}_][\p{L}\p{N}_]{0,127}$/u;
  var bad3 = (message) => {
    throw new Error(message);
  };
  var plain = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
  var str = (x) => typeof x === "string" ? x : "";
  var copy = (o, keys, into) => {
    for (const key of keys) if (Object.hasOwn(o, key)) into[key] = structuredClone(o[key]);
  };
  function definition(code2, raw, inTable, skipped) {
    if (!plain(raw) || !SAFE_CODE.test(code2) || ["__proto__", "prototype", "constructor"].includes(code2)) {
      skipped.push(code2 + ": \u672A\u5BFE\u5FDC\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u30B3\u30FC\u30C9");
      return null;
    }
    if (raw.type === "SUBTABLE") {
      if (inTable) {
        skipped.push(code2 + ": \u30C6\u30FC\u30D6\u30EB\u306E\u5165\u308C\u5B50\u306F\u672A\u5BFE\u5FDC");
        return null;
      }
      const fields = {};
      for (const [child, def2] of Object.entries(raw.fields || {})) {
        const built = definition(child, def2, true, skipped);
        if (built) Object.defineProperty(fields, child, { value: built, enumerable: true, writable: true, configurable: true });
      }
      if (!Object.keys(fields).length) {
        skipped.push(code2 + ": \u30C6\u30FC\u30D6\u30EB\u5185\u306E\u79FB\u884C\u53EF\u80FD\u30D5\u30A3\u30FC\u30EB\u30C9\u304C\u3042\u308A\u307E\u305B\u3093");
        return null;
      }
      return { type: "SUBTABLE", code: code2, label: str(raw.label) || code2, fields };
    }
    if (!TYPES.has(raw.type) || raw.lookup || raw.referenceTable || inTable && !TABLE_TYPES.has(raw.type)) {
      skipped.push(code2 + ": \u5BFE\u5FDC\u3067\u304D\u306A\u3044\u30D5\u30A3\u30FC\u30EB\u30C9\u7A2E\u5225\u307E\u305F\u306F\u53C2\u7167\u8A2D\u5B9A (" + (raw.type || "unknown") + ")");
      return null;
    }
    const def = { type: raw.type, code: code2, label: str(raw.label) || code2, required: false, unique: false };
    if (SELECT.has(raw.type)) {
      if (!plain(raw.options) || Object.keys(raw.options).length === 0) {
        skipped.push(code2 + ": \u9078\u629E\u80A2\u304C\u306A\u304F\u518D\u4F5C\u6210\u3067\u304D\u307E\u305B\u3093");
        return null;
      }
      const options = {};
      for (const [label, opt] of Object.entries(raw.options)) {
        if (!plain(opt) || !label || !Number.isFinite(Number(opt.index))) {
          skipped.push(code2 + ": \u9078\u629E\u80A2\u8A2D\u5B9A\u304C\u4E0D\u6B63\u3067\u3059");
          return null;
        }
        Object.defineProperty(options, label, { value: { label, index: String(opt.index) }, enumerable: true, writable: true, configurable: true });
      }
      def.options = options;
      if (raw.type === "RADIO_BUTTON" || raw.type === "CHECK_BOX" || raw.type === "MULTI_SELECT") {
        if (["VERTICAL", "HORIZONTAL"].includes(raw.align)) def.align = raw.align;
      }
    }
    if (raw.type === "LINK") def.protocol = ["WEB", "CALL", "MAIL"].includes(raw.protocol) ? raw.protocol : "WEB";
    if (raw.type === "NUMBER") copy(raw, ["digit", "displayScale", "unit", "unitPosition"], def);
    if (raw.type === "FILE" && ["50", "150", "250", "500"].includes(String(raw.thumbnailSize))) def.thumbnailSize = String(raw.thumbnailSize);
    return def;
  }
  function planNewApp(archive, name) {
    if (!archive || !archive.manifest || !plain(archive.sourceFields?.properties))
      bad3("\u3053\u306E\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u306B\u306F\u30A2\u30D7\u30EA\u69CB\u9020\u518D\u73FE\u7528\u306E\u30D5\u30A3\u30FC\u30EB\u30C9\u8A2D\u5B9A\u304C\u3042\u308A\u307E\u305B\u3093\u3002v2\u5F62\u5F0F\u3067\u518D\u53D6\u5F97\u3057\u3066\u304F\u3060\u3055\u3044");
    if (![2, 3].includes(archive.manifest.version)) bad3("\u81EA\u52D5\u30D5\u30A9\u30FC\u30E0\u518D\u73FE\u306Fv2/v3\u5F62\u5F0F\u306B\u5BFE\u5FDC\u3057\u307E\u3059");
    if (typeof name !== "string" || !name.trim() || name.length > 64) bad3("\u30A2\u30D7\u30EA\u540D\u306F1\uFF5E64\u6587\u5B57\u306B\u3057\u3066\u304F\u3060\u3055\u3044");
    const props = {};
    const skipped = [];
    for (const [code2, def] of Object.entries(archive.sourceFields.properties)) {
      const compiled = definition(code2, def, false, skipped);
      if (compiled) Object.defineProperty(props, code2, { value: compiled, enumerable: true, writable: true, configurable: true });
    }
    if (!Object.keys(props).length) bad3("\u79FB\u884C\u3067\u304D\u308B\u30D5\u30A3\u30FC\u30EB\u30C9\u304C\u3042\u308A\u307E\u305B\u3093");
    Object.defineProperty(props, "ResoArcRestoreKey", { value: {
      type: "SINGLE_LINE_TEXT",
      code: "ResoArcRestoreKey",
      label: "ResoArc\u5FA9\u5143\u8B58\u5225\u5B50",
      required: false,
      unique: true
    }, writable: true, enumerable: true, configurable: true });
    const sourceCodes = Object.keys(archive.schema);
    const missing = sourceCodes.filter((code2) => !Object.hasOwn(props, code2));
    for (const code2 of missing) if (!skipped.some((s2) => s2.startsWith(code2 + ":"))) skipped.push(code2 + ": \u79FB\u884C\u5BFE\u8C61\u304B\u3089\u9664\u5916");
    return {
      name: name.trim(),
      properties: props,
      skipped,
      fieldCount: Object.keys(props).length,
      sourceAppId: archive.manifest.sourceAppId,
      recordCount: archive.records.length,
      warnings: ["\u65E2\u5B58\u306E\u30A2\u30D7\u30EA\u306B\u306F\u9069\u7528\u3057\u307E\u305B\u3093", "\u5143\u306E\u8868\u793A\u914D\u7F6E\u30FB\u6A29\u9650\u30FB\u4E00\u89A7\u30FB\u30D7\u30ED\u30BB\u30B9\u30FB\u30EB\u30C3\u30AF\u30A2\u30C3\u30D7\u53C2\u7167\u306F\u518D\u73FE\u3057\u307E\u305B\u3093", "\u5FC5\u9808\u30FB\u4E00\u610F\u5236\u7D04\u306F\u79FB\u884C\u512A\u5148\u306E\u305F\u3081\u7121\u52B9\u306B\u3057\u307E\u3059", "\u30C7\u30FC\u30BF\u5FA9\u5143\u306F\u5225\u9014\u30D7\u30EC\u30D3\u30E5\u30FC\u3068\u660E\u793A\u627F\u8A8D\u304C\u5FC5\u8981\u3067\u3059"]
    };
  }
  async function createDraftApp(plan, api2, onStep = () => {
  }) {
    if (typeof api2 !== "function") bad3("kintone API\u95A2\u6570\u304C\u3042\u308A\u307E\u305B\u3093");
    if (!plan?.name || !plain(plan.properties) || !Object.keys(plan.properties).length) bad3("\u4F5C\u6210\u8A08\u753B\u304C\u4E0D\u6B63\u3067\u3059");
    onStep("\u52D5\u4F5C\u30C6\u30B9\u30C8\u74B0\u5883\u306B\u65B0\u898F\u30A2\u30D7\u30EA\u3092\u4F5C\u6210\u3057\u3066\u3044\u307E\u3059");
    const created = await api2("/k/v1/preview/app.json", "POST", { name: plan.name });
    const id = Number(created?.app);
    if (!Number.isSafeInteger(id) || id <= 0) bad3("\u65B0\u898F\u30A2\u30D7\u30EAID\u3092\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F");
    try {
      onStep("\u65B0\u898F\u30A2\u30D7\u30EA #" + id + " \u306B\u30D5\u30A3\u30FC\u30EB\u30C9\u3092\u8A2D\u5B9A\u3057\u3066\u3044\u307E\u3059");
      await api2("/k/v1/preview/app/form/fields.json", "POST", { app: id, properties: plan.properties });
      onStep("\u65B0\u898F\u30A2\u30D7\u30EA #" + id + " \u306E\u4E0B\u66F8\u304D\u304C\u3067\u304D\u307E\u3057\u305F\u3002\u30A2\u30D7\u30EA\u306E\u8A2D\u5B9A\u753B\u9762\u3067\u5185\u5BB9\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
    } catch (e) {
      throw new Error("\u30A2\u30D7\u30EA #" + id + " \u306F\u4F5C\u6210\u3055\u308C\u307E\u3057\u305F\u304C\u3001\u30D5\u30A3\u30FC\u30EB\u30C9\u8FFD\u52A0\u304C\u5931\u6557\u3057\u307E\u3057\u305F\u3002\u8A2D\u5B9A\u753B\u9762\u3067\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u539F\u56E0: " + e.message);
    }
    return { appId: id, deployed: false, recordsCopied: 0, requiresManualDeploy: true };
  }

  // src/local-app.js
  var K = window.kintone;
  var api = (path, method, body) => K.api(K.api.url(path, true), method, body);
  var getFields = (id) => api("/k/v1/app/form/fields.json", "GET", { app: id });
  var getLayout = (id) => api("/k/v1/app/form/layout.json", "GET", { app: id });
  var requiredApp = () => {
    const id = Number(K.app.getId());
    if (!Number.isSafeInteger(id) || id < 1) throw Error("\u30A2\u30D7\u30EA\u306E\u30EC\u30B3\u30FC\u30C9\u4E00\u89A7\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044");
    return id;
  };
  var sections = {
    app: "/k/v1/app.json",
    views: "/k/v1/app/views.json",
    reports: "/k/v1/app/reports.json",
    process: "/k/v1/app/status.json",
    actions: "/k/v1/app/actions.json",
    appAcl: "/k/v1/app/acl.json",
    recordAcl: "/k/v1/record/acl.json",
    fieldAcl: "/k/v1/field/acl.json",
    notificationGeneral: "/k/v1/app/notifications/general.json",
    notificationPerRecord: "/k/v1/app/notifications/perRecord.json",
    notificationReminder: "/k/v1/app/notifications/reminder.json",
    customize: "/k/v1/app/customize.json"
  };
  var metaFields = ["$id", "$revision", "\u4F5C\u6210\u8005", "\u66F4\u65B0\u8005", "\u4F5C\u6210\u65E5\u6642", "\u66F4\u65B0\u65E5\u6642", "\u30B9\u30C6\u30FC\u30BF\u30B9", "\u4F5C\u696D\u8005", "\u30AB\u30C6\u30B4\u30EA\u30FC"];
  var errorText = (e) => String(e?.message || e).slice(0, 350);
  async function collectSettings(id, onProgress) {
    const settings = {}, coverage = { sections: {}, limitations: [
      "API\u6A29\u9650\u306E\u7BC4\u56F2\u306E\u307F\u53D6\u5F97",
      "\u30B3\u30E1\u30F3\u30C8\u30FB\u5909\u66F4\u5C65\u6B74\u30FB\u30B9\u30DA\u30FC\u30B9\u30FB\u76E3\u67FB\u5C65\u6B74\u306F\u5BFE\u8C61\u5916",
      "\u30AB\u30B9\u30BF\u30DE\u30A4\u30BAJS/CSS\u306E\u53C2\u7167\u60C5\u5831\u306F\u4FDD\u6301\u3057\u3066\u3082\u5B9F\u884C\u30FB\u5B8C\u5168\u518D\u73FE\u3057\u306A\u3044",
      "\u53D6\u5F97\u4E2D\u306E\u540C\u6642\u66F4\u65B0\u306B\u3064\u3044\u3066\u540C\u4E00\u6642\u70B9\u30B9\u30CA\u30C3\u30D7\u30B7\u30E7\u30C3\u30C8\u3092\u4FDD\u8A3C\u3057\u306A\u3044"
    ] };
    for (const [name, path] of Object.entries(sections)) {
      onProgress("\u8A2D\u5B9A\u53D6\u5F97: " + name);
      try {
        const response = await api(path, "GET", name === "app" ? { id } : { app: id });
        settings[name] = response;
        coverage.sections[name] = { status: "captured" };
      } catch (e) {
        coverage.sections[name] = { status: "unavailable", reason: errorText(e) };
      }
    }
    return { settings, coverage };
  }
  async function downloadAttachment(fileKey) {
    const response = await fetch("/k/v1/file.json?fileKey=" + encodeURIComponent(fileKey), {
      method: "GET",
      credentials: "same-origin",
      headers: { "X-Requested-With": "XMLHttpRequest" }
    });
    if (!response.ok) throw Error("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u53D6\u5F97\u5931\u6557 HTTP " + response.status);
    const blob = await response.blob();
    if (blob.size > MAX_BYTES) throw Error("\u5358\u4E00\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u304C25MiB\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
    return new Uint8Array(await blob.arrayBuffer());
  }
  async function uploadAttachment(bytes, name, contentType) {
    if (bytes.length > MAX_BYTES) throw Error("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u5BB9\u91CF\u4E0A\u9650\u8D85\u904E");
    const body = new FormData();
    body.append("__REQUEST_TOKEN__", K.getRequestToken());
    body.append("file", new Blob([bytes], { type: contentType || "application/octet-stream" }), name || "attachment.bin");
    const response = await fetch("/k/v1/file.json", {
      method: "POST",
      credentials: "same-origin",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      body
    });
    if (!response.ok) throw Error("\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u306E\u767B\u9332\u306B\u5931\u6557 HTTP " + response.status);
    const data = await response.json();
    if (!data.fileKey) throw Error("\u79FB\u884C\u5148\u306E\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u30AD\u30FC\u304C\u3042\u308A\u307E\u305B\u3093");
    return data.fileKey;
  }
  function saveBytes(bytes, name) {
    const url = URL.createObjectURL(new Blob([bytes], { type: "application/octet-stream" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 6e4);
  }
  function chooseFile() {
    return new Promise((resolve) => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = ".ra-kintone,.enc,.zip,.json,application/zip,application/octet-stream";
      input.multiple = true;
      input.onchange = () => resolve([...input.files || []]);
      input.oncancel = () => resolve(null);
      input.click();
    });
  }
  async function loadFile() {
    const files = await chooseFile();
    if (!files?.length) return null;
    const collection = files.find((f) => f.name === "resoarc-collection.ra-collection.json");
    if (collection) {
      const indexBytes = new Uint8Array(await collection.arrayBuffer());
      let index;
      try {
        index = JSON.parse(new TextDecoder().decode(indexBytes));
      } catch {
        throw Error("\u7D22\u5F15JSON\u3092\u8AAD\u307F\u53D6\u308C\u307E\u305B\u3093");
      }
      const passphrase = index.encrypted ? window.prompt("\u5206\u5272\u30A2\u30FC\u30AB\u30A4\u30D6\u306E\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044", "") : "";
      if (passphrase === null) return null;
      const map = /* @__PURE__ */ new Map();
      for (const f of files) {
        if (map.has(f.name)) throw Error("\u91CD\u8907\u3057\u305F\u30D5\u30A1\u30A4\u30EB\u540D\u304C\u3042\u308A\u307E\u3059: " + f.name);
        map.set(f.name, f);
      }
      return openCollection(indexBytes, async (name) => {
        const f = map.get(name);
        if (!f) throw Error("\u7D22\u5F15\u306B\u8A18\u8F09\u3055\u308C\u305F\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u304C\u3042\u308A\u307E\u305B\u3093: " + name);
        if (f.size > MAX_BYTES + 56) throw Error("\u5206\u5272\u30D5\u30A1\u30A4\u30EB\u306E\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
        return new Uint8Array(await f.arrayBuffer());
      }, { passphrase });
    }
    if (files.length !== 1) throw Error("\u5206\u5272\u30A2\u30FC\u30AB\u30A4\u30D6\u306F\u7D22\u5F15JSON\u3068\u5168\u30D1\u30FC\u30C8\u3092\u307E\u3068\u3081\u3066\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044");
    const file = files[0];
    if (file.size > MAX_BYTES + 56) throw Error("\u30D5\u30A1\u30A4\u30EB\u306E\u5BB9\u91CF\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059");
    const raw = new Uint8Array(await file.arrayBuffer());
    if (isPotentialEncryptedArchive(raw) && !isEncryptedArchive(raw)) throw Error("\u7834\u640D\u307E\u305F\u306F\u975E\u5BFE\u5FDC\u306E\u6697\u53F7\u5316\u30D8\u30C3\u30C0\u30FC\u3067\u3059");
    if (isEncryptedArchive(raw)) {
      const passphrase = window.prompt("\u3053\u306E\u30D5\u30A1\u30A4\u30EB\u306E\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u753B\u9762\u3084\u30B5\u30FC\u30D0\u30FC\u306B\u306F\u4FDD\u5B58\u3057\u307E\u305B\u3093\u3002", "");
      if (passphrase === null) return null;
      const plaintext = await decryptLocalArchive(raw, passphrase);
      try {
        return await inspectArchive(plaintext);
      } finally {
        plaintext.fill(0);
      }
    }
    return inspectArchive(raw);
  }
  function text(tag, content) {
    const node = document.createElement(tag);
    node.textContent = content;
    return node;
  }
  function button(host, label, callback) {
    const b = text("button", label);
    b.type = "button";
    b.className = "ra-button";
    b.onclick = callback;
    host.append(b);
    return b;
  }
  function boot() {
    const holder = K.app.getHeaderSpaceElement?.() || K.app.getHeaderMenuSpaceElement?.();
    if (!holder || holder.querySelector("[data-ra-archive]")) return;
    const panel = document.createElement("section");
    panel.dataset.raArchive = "1";
    panel.style.cssText = "margin:10px 0;padding:14px;border-radius:10px;background:#f4f9fc;color:#163449;border:1px solid #aecbd9;max-width:1060px;font:14px sans-serif";
    const heading = text("strong", "ResoArc kintone Archive | v1.0.0");
    const info = text("div", "\u3053\u306EPC\u306B\u4FDD\u5B58\u3057\u307E\u3059\u3002ResoArc\u306E\u30B5\u30FC\u30D0\u30FC\u306B\u3082\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u7BA1\u7406\u30A2\u30D7\u30EA\u306B\u3082\u9001\u4FE1\u3057\u307E\u305B\u3093\u3002\u5FA9\u5143\u306F\u8FFD\u8A18\u306E\u307F\u3002");
    info.style.margin = "9px 0";
    const actions = document.createElement("div");
    const status = text("pre", "\u6E96\u5099\u5B8C\u4E86");
    status.style.cssText = "white-space:pre-wrap;font:12px/1.7 sans-serif;margin-top:12px";
    panel.append(heading, info, actions, status);
    holder.append(panel);
    const css = document.createElement("style");
    css.textContent = ".ra-button{margin:3px;padding:9px 12px;border:1px solid #93b0c3;border-radius:6px;background:white;color:#123c54;cursor:pointer}.ra-button:disabled{opacity:.5;cursor:wait}";
    panel.append(css);
    let loaded = null, prepared = null;
    async function run(task) {
      const buttons = [...actions.querySelectorAll("button")];
      buttons.forEach((b) => b.disabled = true);
      try {
        await task();
      } catch (e) {
        status.textContent = "\u30A8\u30E9\u30FC: " + errorText(e);
        console.error(e);
      } finally {
        buttons.forEach((b) => b.disabled = false);
      }
    }
    button(actions, "\u3053\u306E\u30A2\u30D7\u30EA\u3092\u30ED\u30FC\u30AB\u30EB\u4FDD\u5B58", () => run(async () => {
      const id = requiredApp();
      if (!window.confirm("\u30A2\u30D7\u30EA #" + id + " \u3092\u30ED\u30FC\u30AB\u30EB\u4FDD\u5B58\u3057\u307E\u3059\u3002\u73FE\u5728\u306E\u4E0A\u9650\u306F25MiB\u3067\u3059\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F")) return;
      const passphrase = window.prompt("\u63A8\u5968\uFF1A\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA12\u6587\u5B57\u4EE5\u4E0A\u3067\u6697\u53F7\u5316\u3057\u307E\u3059\u3002\u7A7A\u6B04\u306A\u3089\u6697\u53F7\u5316\u305B\u305A\u4FDD\u5B58\u3057\u307E\u3059\uFF08\u6A5F\u5BC6\u60C5\u5831\u306E\u6F0F\u6D29\u306B\u6CE8\u610F\uFF09\u3002", "");
      if (passphrase === null) return;
      if (passphrase && passphrase !== window.prompt("\u78BA\u8A8D\u306E\u305F\u3081\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u3092\u518D\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002", "")) throw Error("\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (passphrase && passphrase.length < 12) throw Error("\u6697\u53F7\u5316\u306B\u306F12\u6587\u5B57\u4EE5\u4E0A\u306E\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u304C\u5FC5\u8981\u3067\u3059");
      if (!passphrase && !window.confirm("\u6697\u53F7\u5316\u306A\u3057\u306E\u5E73\u6587\u30A2\u30FC\u30AB\u30A4\u30D6\u3067\u3059\u3002\u4FDD\u5B58\u5148\u306E\u4FDD\u8B77\u3092\u78BA\u8A8D\u3057\u307E\u3057\u305F\u304B\uFF1F")) return;
      status.textContent = "\u30D5\u30A3\u30FC\u30EB\u30C9\u30FB\u30EC\u30B3\u30FC\u30C9\u3092\u53D6\u5F97\u4E2D\uFF08\u30C7\u30FC\u30BF\u3092\u5225\u30B5\u30FC\u30D0\u30FC\u306B\u9001\u4FE1\u3057\u307E\u305B\u3093\uFF09";
      const fields = await getFields(id);
      const layout = await getLayout(id);
      const records = await fetchAllRecords(id, api);
      const { settings, coverage } = await collectSettings(id, (info2) => {
        status.textContent = info2;
      });
      coverage.sections.fields = { status: "captured" };
      coverage.sections.layout = { status: "captured" };
      coverage.sections.records = { status: "captured", count: records.length };
      const sourceMeta = records.map((record) => {
        const values = {};
        for (const code2 of metaFields) if (record[code2] && Object.hasOwn(record[code2], "value")) values[code2] = record[code2].value;
        return values;
      });
      status.textContent = "\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u3068ZIP\u306E\u691C\u8A3C\u60C5\u5831\u3092\u751F\u6210\u3057\u3066\u3044\u307E\u3059";
      const result = await makeArchive({ appId: id, fields, layout, records, download: downloadAttachment, settings, coverage, sourceMeta });
      const valid = await inspectArchive(result.zip, { expectedHash: result.hash });
      const failed = Object.entries(coverage.sections).filter(([, x]) => x.status !== "captured").map(([name]) => name);
      const protectedArchive = passphrase ? await encryptLocalArchive(result.zip, passphrase) : result.zip;
      saveBytes(protectedArchive, "resoarc-app-" + id + "-" + (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) + (passphrase ? ".ra-kintone.enc" : ".ra-kintone"));
      status.textContent = "PC\u306B" + (passphrase ? "\u6697\u53F7\u5316\u3057\u3066" : "\u6697\u53F7\u5316\u305B\u305A") + "\u4FDD\u5B58\u3057\u307E\u3057\u305F\uFF1A" + valid.manifest.recordCount + "\u4EF6 / " + protectedArchive.byteLength + " bytes\nZIP SHA-256: " + result.hash + "\n\u53D6\u5F97\u3067\u304D\u306A\u304B\u3063\u305F\u8A2D\u5B9A: " + (failed.join(", ") || "\u306A\u3057") + "\n\u203B\u904E\u53BB\u5C65\u6B74\u30FB\u5B9F\u884C\u6642\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA\u306F\u518D\u73FE\u3057\u307E\u305B\u3093\u3002";
    }));
    button(actions, "\u30ED\u30FC\u30AB\u30EB\u30D5\u30A1\u30A4\u30EB\u3092\u8AAD\u307F\u8FBC\u307F\u30FB\u5FA9\u5143\u30D7\u30EC\u30D3\u30E5\u30FC", () => run(async () => {
      prepared = null;
      loaded = await loadFile();
      if (!loaded) return;
      const app = requiredApp();
      const fields = await getFields(app);
      const mappingInput = window.prompt("\u30D5\u30A3\u30FC\u30EB\u30C9\u5BFE\u5FDC\u8868\uFF08JSON\u3002\u30B3\u30FC\u30C9\u304C\u540C\u4E00\u306A\u3089\u7A7A\u6B04\uFF09", "");
      if (mappingInput === null) return;
      let mapping = {};
      if (mappingInput.trim()) mapping = JSON.parse(mappingInput);
      const plan = createMappedRestorePlan(loaded, fields, app, 0, mapping);
      const progress = await previewRestoreProgress({ archive: loaded, plan, api });
      prepared = {
        plan,
        archive: loaded,
        otherArchiveKeyCount: progress.otherArchiveKeyCount,
        unmarkedRecordCount: progress.unmarkedRecordCount
      };
      status.textContent = "\u691C\u8A3C\u6E08\u307F\u306E\u30A2\u30FC\u30AB\u30A4\u30D6\u3067\u3059\n\u5143\u30A2\u30D7\u30EA: " + plan.sourceAppId + "\u3000\u5FA9\u5143\u5148: " + app + "\n\u5168" + plan.recordCount + "\u4EF6 / \u65E2\u5B58" + progress.already + "\u4EF6 / \u8FFD\u52A0\u4E88\u5B9A" + progress.remaining + "\u4EF6\n\u9664\u5916\u9805\u76EE: " + (plan.skipped.join(", ") || "\u306A\u3057") + "\n\u5FA9\u5143\u5148\u306B\u91CD\u8907\u4E0D\u53EF\u306E\u6587\u5B57\u5217\u30D5\u30A3\u30FC\u30EB\u30C9 " + MARKER_CODE + " \u304C\u5FC5\u8981\u3067\u3059\u3002\u5143ID\u30FB\u5C65\u6B74\u30FB\u6A29\u9650\u8A2D\u5B9A\u306F\u518D\u73FE\u3057\u307E\u305B\u3093\u3002" + ((progress.otherArchiveKeyCount > 0 || progress.unmarkedRecordCount > 0) && progress.remaining > 0 ? "\n\u8B66\u544A: \u5225\u30A2\u30FC\u30AB\u30A4\u30D6\u7531\u6765 " + progress.otherArchiveKeyCount + " \u4EF6\u3001\u5FA9\u5143\u8B58\u5225\u5B50\u304C\u306A\u3044\u65E2\u5B58\u30EC\u30B3\u30FC\u30C9 " + progress.unmarkedRecordCount + " \u4EF6\u304C\u3042\u308A\u307E\u3059\u3002\u91CD\u8907\u8FFD\u52A0\u306E\u5371\u967A\u304C\u3042\u308B\u305F\u3081\u5B9F\u884C\u6642\u306B\u5225\u9014\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002" : "");
    }));
    button(actions, "\u30D7\u30EC\u30D3\u30E5\u30FC\u5F8C\u306B\u8FFD\u8A18\u5FA9\u5143", () => run(async () => {
      if (!prepared) throw Error("\u5148\u306B\u30ED\u30FC\u30AB\u30EB\u30D5\u30A1\u30A4\u30EB\u3092\u9078\u3073\u3001\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044");
      const { plan, archive, otherArchiveKeyCount, unmarkedRecordCount } = prepared;
      let allowCrossArchiveAppend = false;
      if (otherArchiveKeyCount > 0 || unmarkedRecordCount > 0) {
        const crossText = "ALLOW CROSS ARCHIVE " + plan.targetAppId + " " + plan.recordCount;
        const entered = window.prompt("\u8B66\u544A: \u5FA9\u5143\u5148\u306B\u5225\u30A2\u30FC\u30AB\u30A4\u30D6\u7531\u6765\u306E\u5C65\u6B74\u304C " + otherArchiveKeyCount + " \u4EF6\u3001\u5FA9\u5143\u8B58\u5225\u5B50\u304C\u306A\u3044\u65E2\u5B58\u30EC\u30B3\u30FC\u30C9\u304C " + unmarkedRecordCount + " \u4EF6\u3042\u308A\u307E\u3059\u3002\u901A\u5E38\u306F\u65B0\u898F\u306E\u7A7A\u30A2\u30D7\u30EA\u306B\u5FA9\u5143\u3057\u3066\u304F\u3060\u3055\u3044\u3002\n\u8FFD\u52A0\u3092\u660E\u793A\u7684\u306B\u8A31\u53EF\u3059\u308B\u5834\u5408\u3060\u3051\u3001\u4EE5\u4E0B\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044:\n" + crossText, "");
        if (entered !== crossText) return;
        allowCrossArchiveAppend = true;
      }
      const phrase = "RESTORE " + plan.targetAppId + " " + plan.recordCount;
      const typed = window.prompt("\u5FA9\u5143\u5148\u3078\u8FFD\u8A18\u3057\u307E\u3059\u3002\u65E2\u5B58\u30EC\u30B3\u30FC\u30C9\u306F\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002\n\u78BA\u8A8D\u6587\u5B57\u5217: " + phrase, "");
      if (typed !== phrase) return;
      if (!window.confirm("\u6700\u7D42\u78BA\u8A8D\uFF1A\u8FFD\u52A0\u6E08\u307F\u306E\u30EC\u30B3\u30FC\u30C9\u306F\u81EA\u52D5\u524A\u9664\u3055\u308C\u307E\u305B\u3093\u3002\u5B9F\u884C\u3057\u307E\u3059\u304B\uFF1F")) return;
      const latest = await getFields(plan.targetAppId);
      const checked = createMappedRestorePlan(archive, latest, plan.targetAppId, 0, plan.mapping);
      if (JSON.stringify(checked.mapped) !== JSON.stringify(plan.mapped)) throw Error("\u30D7\u30EC\u30D3\u30E5\u30FC\u6642\u304B\u3089\u30D5\u30A9\u30FC\u30E0\u304C\u5909\u66F4\u3055\u308C\u3066\u3044\u307E\u3059\u3002\u518D\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044");
      const done = await runResumableRestore({
        archive,
        plan,
        api,
        upload: uploadAttachment,
        allowCrossArchiveAppend,
        onProgress: (p) => {
          status.textContent = "\u8FFD\u52A0\u6E08\u307F " + p.added + " / \u6B8B " + p.remaining;
        }
      });
      status.textContent = "\u8FFD\u8A18\u5FA9\u5143\u5B8C\u4E86\uFF1A" + done.added + "\u4EF6\u8FFD\u52A0 / " + done.already + "\u4EF6\u306F\u91CD\u8907\u9632\u6B62\u3067\u30B9\u30AD\u30C3\u30D7\n\u518D\u8AAD\u8FBC\u691C\u8A3C\uFF1A" + done.verifiedRows + "\u4EF6\u306E\u5FA9\u5143\u8B58\u5225\u5B50\u3092\u78BA\u8A8D";
      prepared = null;
    }));
    button(actions, "\u5FA9\u5143\u6E08\u307F\u30C7\u30FC\u30BF\u306E\u6574\u5408\u6027\u76E3\u67FB\uFF08\u8AAD\u53D6\u306E\u307F\uFF09", () => run(async () => {
      if (!prepared) throw Error("\u5148\u306B\u30ED\u30FC\u30AB\u30EB\u30D5\u30A1\u30A4\u30EB\u3092\u9078\u3073\u3001\u5FA9\u5143\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044");
      const { archive, plan } = prepared;
      status.textContent = "\u5FA9\u5143\u6E08\u307F\u306E\u5024\u30FB\u30B5\u30D6\u30C6\u30FC\u30D6\u30EB\u30FB\u6DFB\u4ED8\u30D5\u30A1\u30A4\u30EB\u3092\u7167\u5408\u4E2D";
      const result = await auditRestoredContent({
        archive,
        plan,
        api,
        download: downloadAttachment,
        onProgress: (p) => {
          status.textContent = "\u76E3\u67FB " + p.scanned + "\u4EF6\u8D70\u67FB / " + p.matched + "\u4EF6\u4E00\u81F4";
        }
      });
      status.textContent = "\u5FA9\u5143\u5F8C\u306E\u8AAD\u307F\u53D6\u308A\u5C02\u7528\u76E3\u67FB: " + (result.passed ? "\u5408\u683C" : "\u4E0D\u4E00\u81F4") + "\n\u4E00\u81F4 " + result.matched + " / " + result.expected + " \u4EF6\u3001\u6B20\u843D " + result.missing + " \u4EF6\u3001\u6DFB\u4ED8SHA-256\u691C\u8A3C " + result.attachmentsVerified + " \u4EF6" + (result.mismatchedPaths.length ? "\n\u5DEE\u7570\u9805\u76EE: " + result.mismatchedPaths.join(", ") : "") + "\n\u203B\u5FA9\u5143\u5148\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002";
    }));
    button(actions, "\u30ED\u30FC\u30AB\u30EB\u30D5\u30A1\u30A4\u30EB\u304B\u3089\u65B0\u898F\u30A2\u30D7\u30EA\u306E\u4E0B\u66F8\u304D", () => run(async () => {
      const archive = loaded || await loadFile();
      if (!archive) return;
      const proposed = window.prompt("\u65B0\u898F\u30A2\u30D7\u30EA\u540D\u3092\u5165\u529B", "ResoArc Archive " + archive.manifest.sourceAppId);
      if (!proposed) return;
      const plan = planNewApp(archive, proposed);
      status.textContent = "\u4E0B\u66F8\u304D\u4E88\u5B9A: " + plan.name + " / " + plan.fieldCount + "\u9805\u76EE\n\u9664\u5916: " + plan.skipped.join(", ") + "\n\u30D5\u30A9\u30FC\u30E0\u306E\u5B9A\u7FA9\u306E\u307F\u3002\u30D7\u30ED\u30BB\u30B9\u30FB\u6A29\u9650\u30FB\u30C7\u30FC\u30BF\u306F\u81EA\u52D5\u79FB\u884C\u3057\u307E\u305B\u3093\u3002";
      const phrase = "CREATE " + plan.name;
      if (window.prompt("\u65B0\u898F\u30A2\u30D7\u30EA\u306E\u4E0B\u66F8\u304D\u3092\u4F5C\u6210\u3057\u307E\u3059\u3002\u78BA\u8A8D\u6587\u5B57\u5217: " + phrase, "") !== phrase) return;
      if (!window.confirm("\u65E2\u5B58\u30A2\u30D7\u30EA\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002\u65B0\u898F\u30A2\u30D7\u30EA\u306E\u4E0B\u66F8\u304D\u3092\u4F5C\u6210\u3057\u307E\u3059\u304B\uFF1F")) return;
      const created = await createDraftApp(plan, api, (s2) => {
        status.textContent = s2;
      });
      status.textContent = "\u65B0\u898F\u30A2\u30D7\u30EA #" + created.appId + " \u306E\u4E0B\u66F8\u304D\u3092\u4F5C\u6210\u3057\u307E\u3057\u305F\u3002\u624B\u52D5\u3067\u30D5\u30A9\u30FC\u30E0\u3092\u78BA\u8A8D\u3057\u3066\u300C\u30A2\u30D7\u30EA\u3092\u66F4\u65B0\u300D\u3057\u3066\u304F\u3060\u3055\u3044\u3002";
    }));
    button(actions, "\u5927\u5BB9\u91CF: \u30D5\u30A9\u30EB\u30C0\u30FC\u306B\u5206\u5272\u4FDD\u5B58", () => run(async () => {
      if (typeof window.showDirectoryPicker !== "function")
        throw Error("\u5206\u5272\u4FDD\u5B58\u306B\u306FEdge/Chrome\u306E\u30D5\u30A9\u30EB\u30C0\u30FC\u66F8\u304D\u8FBC\u307F\u5BFE\u5FDC\u304C\u5FC5\u8981\u3067\u3059\u3002HTTPS\u306Ekintone\u304B\u3089\u5B9F\u884C\u3057\u3066\u304F\u3060\u3055\u3044");
      const parent = await window.showDirectoryPicker({ mode: "readwrite" });
      const id = requiredApp();
      const password = window.prompt("\u63A8\u5968: \u5206\u5272\u30D5\u30A1\u30A4\u30EB\u3092\u6697\u53F7\u5316\u3059\u308B\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\uFF0812\u6587\u5B57\u4EE5\u4E0A\uFF09\u3002\u7A7A\u6B04\u306A\u3089\u5E73\u6587\u3067\u3059\u3002", "");
      if (password === null) return;
      if (password && password !== window.prompt("\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u3092\u3082\u3046\u4E00\u5EA6\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044", "")) throw Error("\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u304C\u4E00\u81F4\u3057\u307E\u305B\u3093");
      if (password && password.length < 12) throw Error("\u30D1\u30B9\u30D5\u30EC\u30FC\u30BA\u306F12\u6587\u5B57\u4EE5\u4E0A\u306B\u3057\u3066\u304F\u3060\u3055\u3044");
      if (!password && !window.confirm("\u6697\u53F7\u5316\u3057\u306A\u3044\u5206\u5272\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002\u4FDD\u5B58\u5148\u306F\u4FDD\u8B77\u3055\u308C\u3066\u3044\u307E\u3059\u304B\uFF1F")) return;
      const dirname = "resoarc-app-" + id + "-" + (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-") + "-" + crypto.randomUUID().slice(0, 8);
      const target = await parent.getDirectoryHandle(dirname, { create: true });
      if (!window.confirm("\u30A2\u30D7\u30EA #" + id + " \u306E\u5206\u5272\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3092\u9078\u629E\u30D5\u30A9\u30EB\u30C0\u30FC\u5185\u306E " + dirname + " \u306B\u4F5C\u6210\u3057\u307E\u3059\u3002\u9014\u4E2D\u5931\u6557\u6642\u306B\u306F\u7D22\u5F15\u30D5\u30A1\u30A4\u30EB\u306F\u4F5C\u6210\u3055\u308C\u307E\u305B\u3093\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F")) return;
      status.textContent = "\u30A2\u30D7\u30EA\u69CB\u9020\u3092\u53D6\u5F97\u3057\u3066\u3044\u307E\u3059";
      const [fields, layout] = await Promise.all([getFields(id), getLayout(id)]);
      const { settings, coverage } = await collectSettings(id, (message) => {
        status.textContent = message;
      });
      coverage.sections.fields = { status: "captured" };
      coverage.sections.layout = { status: "captured" };
      coverage.sections.records = { status: "captured", mode: "cursor-stream", count: "\u7D22\u5F15\u4F5C\u6210\u5F8C\u306B\u78BA\u5B9A" };
      const metadataOf = (record) => {
        const values = {};
        for (const code2 of metaFields) if (record[code2] && Object.hasOwn(record[code2], "value")) values[code2] = record[code2].value;
        return values;
      };
      async function writeLocal(name, bytes2) {
        const fileHandle = await target.getFileHandle(name, { create: true });
        const writer = await fileHandle.createWritable();
        try {
          await writer.write(bytes2);
          await writer.close();
        } catch (e) {
          try {
            await writer.abort();
          } catch {
          }
          throw e;
        }
      }
      const { index, bytes, filename } = await buildCollectionStream({
        appId: id,
        fields,
        layout,
        pages: streamRecordPages(id, api, { maxRecords: MAX_COLLECTION_RECORDS }),
        metadataOf,
        settings,
        coverage,
        download: downloadAttachment,
        passphrase: password,
        onProgress: (p) => {
          status.textContent = "\u53D6\u5F97 " + p.read + "\u4EF6 / \u4FDD\u5B58 " + p.written + "\u4EF6 / \u5206\u5272 " + p.parts + "\u30D5\u30A1\u30A4\u30EB";
        },
        onPart: async (name, bytes2, entry) => {
          status.textContent = "\u5206\u5272ZIP " + name + " / " + entry.count + "\u4EF6 / " + entry.bytes + " bytes \u3092\u4FDD\u5B58\u4E2D";
          await writeLocal(name, bytes2);
        }
      });
      await writeLocal(filename, bytes);
      status.textContent = "\u5206\u5272\u4FDD\u5B58\u5B8C\u4E86: " + index.parts.length + "\u30D5\u30A1\u30A4\u30EB / " + index.recordCount + "\u4EF6 / " + index.totalBytes + " bytes\n\u4FDD\u5B58\u5148: " + dirname + "\n\u6697\u53F7\u5316: " + (index.encrypted ? "AES-256-GCM" : "\u306A\u3057") + "\n\u5FA9\u5143/\u95B2\u89A7\u306B\u306F\u7D22\u5F15JSON\u3068\u5168\u30D1\u30FC\u30C8\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002";
    }));
  }
  if (K?.events) K.events.on("app.record.index.show", (event) => {
    try {
      boot();
    } catch (e) {
      console.error(e);
    }
    return event;
  });
})();
