﻿import {chromium,firefox} from 'playwright-core';
import ExcelJS from 'exceljs';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {mkdir,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const out=join(process.cwd(),'tests','qa-artifacts','offline-singlefile-20261110');
await mkdir(out,{recursive:true});
const file=pathToFileURL('C:/Users/zin/Documents/ResoArc/release-audit-20261109/sheet/single-file-qa/ResoArc-Sheet-v0.7.0-offline.html').href;
const input=join(out,'test.xlsx');
const w=new ExcelJS.Workbook();const s=w.addWorksheet('試験用');s.getCell('A1').value='商品';s.getCell('A2').value='0007';s.getCell('B2').value=24;s.getCell('C2').value={formula:'B2*3',result:72};w.addWorksheet('保全').getCell('A1').value='残す';await w.xlsx.writeFile(input);
const configs=[
{name:'Edge',engine:chromium,exe:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'},
{name:'Chrome',engine:chromium,exe:'C:/Program Files/Google/Chrome/Application/chrome.exe'},
{name:'Firefox',engine:firefox}
];
const results=[];
for(const c of configs.filter(x=>x.name==='Firefox')){
 let browser,page;
 const row={browser:c.name,status:'FAIL',pageErrors:[],consoleErrors:[],externalUrls:[]};
 try{
  browser=await c.engine.launch({headless:true,...(c.exe?{executablePath:c.exe}:{})});
  page=await browser.newPage({viewport:{width:1366,height:900},acceptDownloads:true});
  page.setDefaultTimeout(14000);
  page.on('pageerror',e=>row.pageErrors.push(e.stack||String(e)));
  page.on('console',e=>{if(e.type()==='error')row.consoleErrors.push(e.text())});
  page.on('request',r=>{if(/^https?:/.test(r.url()))row.externalUrls.push(r.url())});
  await page.goto(file,{waitUntil:'networkidle',timeout:30000});
  row.title=await page.title();
  row.statusbars=await page.locator('.statusbar').count();
  if(!row.statusbars)throw new Error('Sheet UI statusbar missing on file://');
  await page.locator('input[accept=".xlsx,.csv"]').setInputFiles(input);
  await page.waitForTimeout(1500);
  row.statusText=(await page.locator('.statusbar').innerText()).slice(0,200);
  await page.getByRole('tab',{name:'ファイル'}).click();
  const promise=page.waitForEvent('download',{timeout:30000});
  await page.getByRole('button',{name:'保存',exact:true}).click();
  const dl=await promise;
  const f=join(out,c.name+'-export.xlsx');await dl.saveAs(f);
  const again=new ExcelJS.Workbook();await again.xlsx.readFile(f);
  assert.deepEqual(again.worksheets.map(x=>x.name),['試験用','保全']);
  assert.equal(again.worksheets[0].getCell('A2').value,'0007');
  assert.equal(again.worksheets[0].getCell('B2').value,24);
  assert.equal(again.worksheets[0].getCell('C2').value.formula,'B2*3');
  assert.equal(again.worksheets[1].getCell('A1').value,'残す');
  assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.externalUrls,[]);
  const mobile=await browser.newPage({viewport:{width:390,height:844}});
  await mobile.goto(file,{waitUntil:'domcontentloaded',timeout:30000});await mobile.waitForTimeout(700);
  row.mobileScrollWidth=await mobile.evaluate(()=>document.documentElement.scrollWidth);
  row.mobilePass=row.mobileScrollWidth<=390;
  assert.equal(row.mobilePass,true);
  row.status='PASS';
 }catch(e){row.error=String(e.stack||e).slice(0,1800)}
 finally{results.push(row);console.log(c.name+' '+row.status+(row.error?' '+row.error.slice(0,160):''));if(browser)await browser.close().catch(()=>{});await writeFile(join(out,'results.json'),JSON.stringify(results,null,2))}
}
if(results.some(x=>x.status!=='PASS'))process.exitCode=1;

