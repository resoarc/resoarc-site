import {chromium, firefox} from 'playwright-core';
import ExcelJS from 'exceljs';
import assert from 'node:assert/strict';
import {mkdir, writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
const results=[];
const out=resolve(process.cwd(),'tests','qa-artifacts','press-multibrowser-20261109');
await mkdir(out,{recursive:true});
const input=join(out,'sample.xlsx');
const w=new ExcelJS.Workbook();
const ws=w.addWorksheet('表計算テスト');
ws.getCell('A1').value='商品';ws.getCell('B1').value='数量';ws.getCell('C1').value='単価';ws.getCell('D1').value='金額';
ws.getCell('A2').value='ペン';ws.getCell('B2').value=4;ws.getCell('C2').value=99;
ws.getCell('D2').value={formula:'B2*C2',result:396};
ws.getCell('A3').value='0007';
const second=w.addWorksheet('備考');second.getCell('A1').value='互換性検証';
await w.xlsx.writeFile(input);
const browsers=[
  {name:'Edge',type:chromium,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'},
  {name:'Chrome',type:chromium,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'},
  {name:'Firefox',type:firefox,executablePath:undefined}
];
for (const cfg of browsers) {
  const row={browser:cfg.name,status:'NOT_RUN',errors:[],external:[],started:new Date().toISOString()};
  let browser;
  try {
    browser=await cfg.type.launch({headless:true,...(cfg.executablePath?{executablePath:cfg.executablePath}:{})});
    const page=await browser.newPage({viewport:{width:1366,height:900},acceptDownloads:true});
    page.on('pageerror',e=>row.errors.push('pageerror: '+e.message));
    page.on('console',m=>{if(m.type()==='error')row.errors.push('console: '+m.text());});
    page.on('request',req=>{let u=req.url();if(/^https?:\/\//.test(u)&&!u.startsWith('http://127.0.0.1:5174/'))row.external.push(u);});
    await page.goto('http://127.0.0.1:5174/',{waitUntil:'networkidle',timeout:25000});
    row.title=await page.title();
    await page.locator('input[accept=".xlsx,.csv"]').setInputFiles(input);
    await page.waitForTimeout(1700);
    row.imported=(await page.locator('.statusbar').innerText()).slice(0,220);
    await page.getByRole('tab',{name:'ファイル'}).click();
    const d=page.waitForEvent('download',{timeout:35000});
    await page.getByRole('button',{name:'保存',exact:true}).click();
    const dl=await d;
    const dest=join(out,cfg.name+'-export.xlsx');await dl.saveAs(dest);
    const data=new ExcelJS.Workbook(); await data.xlsx.readFile(dest);
    assert.deepEqual(data.worksheets.map(s=>s.name),['表計算テスト','備考']);
    assert.equal(data.worksheets[0].getCell('A3').value,'0007');
    assert.equal(data.worksheets[0].getCell('B2').value,4);
    assert.equal(data.worksheets[0].getCell('D2').value.formula,'B2*C2');
    assert.equal(data.worksheets[1].getCell('A1').value,'互換性検証');
    assert.deepEqual(row.errors,[]);
    assert.deepEqual(row.external,[]);
    row.status='PASS';
    await page.screenshot({path:join(out,cfg.name+'-desktop.png')});
    const mobile=await browser.newPage({viewport:{width:390,height:844}});
    mobile.on('pageerror',e=>row.errors.push('mobile pageerror: '+e.message));
    await mobile.goto('http://127.0.0.1:5174/',{waitUntil:'networkidle',timeout:25000});
    row.mobileDocumentWidth=await mobile.evaluate(()=>document.documentElement.scrollWidth);
    row.mobileViewportWidth=390;
    row.mobileStatus=row.mobileDocumentWidth<=390?'PASS':'OVERFLOW';
    await mobile.screenshot({path:join(out,cfg.name+'-mobile.png')});
  } catch(e) {row.status='FAIL';row.failure=String(e.stack||e);}
  finally {if(browser)await browser.close().catch(()=>{});row.finished=new Date().toISOString();results.push(row);console.log(cfg.name+': '+row.status+' mobile '+(row.mobileStatus||'?'));await writeFile(join(out,'results.json'),JSON.stringify(results,null,2));}
}
if(results.some(r=>r.status!=='PASS'))process.exitCode=1;