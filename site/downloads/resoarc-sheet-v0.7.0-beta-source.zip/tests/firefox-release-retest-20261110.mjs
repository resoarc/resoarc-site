import { firefox } from 'playwright-core';
import { join } from 'node:path';
import {mkdir,writeFile} from 'node:fs/promises';
const d=join(process.cwd(),'tests','qa-artifacts','firefox-release-retest');
await mkdir(d,{recursive:true});
const result={ts:new Date().toISOString(),console:[],pageErrors:[],requests:[],failedRequests:[],exceptions:[]};
let browser, page;
try{
 browser=await firefox.launch({headless:true});
 page=await browser.newPage({viewport:{width:1366,height:900},acceptDownloads:true});
 page.on('pageerror',e=>result.pageErrors.push(e.stack||e.message));
 page.on('console',m=>{if(['error','warning'].includes(m.type()))result.console.push(m.type()+': '+m.text())});
 page.on('requestfailed',r=>result.failedRequests.push(r.url()+' '+r.failure()));
 page.on('response',r=>{if(r.status()>=400)result.requests.push(r.status()+' '+r.url())});
 const response=await page.goto('http://127.0.0.1:5174/',{waitUntil:'networkidle',timeout:30000});
 result.status=response.status();result.title=await page.title();
 result.initialStatus=await page.locator('.statusbar').count();
 result.initialBody=(await page.locator('body').innerText()).slice(0,2000);
 await page.screenshot({path:join(d,'before-import.png')});
 console.log('INITIAL',JSON.stringify({status:result.status,title:result.title,statusbar:result.initialStatus,bodyLength:result.initialBody.length}));
 const input=join(process.cwd(),'tests','qa-artifacts','press-multibrowser-20261109','sample.xlsx');
 await page.locator('input[accept=".xlsx,.csv"]').setInputFiles(input);
 await page.waitForTimeout(3000);
 result.afterStatusCount=await page.locator('.statusbar').count();
 result.afterBody=(await page.locator('body').innerText()).slice(0,3000);
 result.importStatus=await page.locator('.statusbar').allInnerTexts();
 result.errorsAfterImport=result.pageErrors.slice();
 await page.screenshot({path:join(d,'after-import.png')});
 console.log('AFTER',JSON.stringify({count:result.afterStatusCount,errorCount:result.pageErrors.length,body:result.afterBody.slice(0,300)}));
}catch(e){result.exceptions.push(e.stack||String(e));console.log('EXCEPTION',e.stack||String(e))}
finally{
 await writeFile(join(d,'results.json'),JSON.stringify(result,null,2));
 if(browser)await browser.close().catch(()=>{});
 console.log('RESULT',JSON.stringify({status:result.status,initialStatus:result.initialStatus,afterStatusCount:result.afterStatusCount,pageErrors:result.pageErrors,console:result.console,failedRequests:result.failedRequests,exceptions:result.exceptions}).slice(0,5000));
}