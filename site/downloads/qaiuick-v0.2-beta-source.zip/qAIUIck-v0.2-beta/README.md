# qAIUIck (クイック)

**Small, readable, beautiful web apps. Built for humans and AI.**

A zero-build micro UI toolkit with optional localStorage or SQLite persistence. Free, portable, no npm dependencies required for the app. Experimental **v0.2**.

## 30-second example

Copy [`examples/hello/index.html`](examples/hello/index.html), a complete app in **one HTML file** (plus reusable qAIUIck CSS/JS):

```html
<body class="q-app">
  <main id="app" class="q-page">
    <section class="q-panel">
      <h1>こんにちは、<span q-text="name"></span>さん</h1>
      <label>名前 <input q-model="name"></label>
      <button type="button" q-action="reset">戻す</button>
    </section>
  </main>
  <script type="module">
    import { createApp } from './src/qaiuick.js';
    createApp({
      root: '#app', state: { name: '世界' },
      actions: { reset: (s) => { s.name = '世界'; } }
    });
  </script>
</body>
```

Link `src/qaiuick.css` in `<head>`, and adapt the import path to where the HTML file is saved. This snippet assumes the HTML is in the repository root. Inputs and buttons are styled automatically inside `.q-app`.

### Why qAIUIck?

- **Readable HTML**: just `q-model`, `q-text`, `q-submit`, `q-action`, `q-show`, and `q-each` (with optional `q-arg` and `q-as`). No templating expressions, no bundler.
- **Good-looking by default**: responsive cards, forms, table, list, empty state, dark mode. Themes `violet` / `teal` / `rose` by changing `<html data-q-theme="teal">`.
- **Less repeated state**: `computed: { count: s => s.items.length }` for derived values.
- **Understand AI changes**: a human-readable [`DESIGN.md`](examples/todo/DESIGN.md) for each example, [`AGENTS.md`](AGENTS.md) for AI edit rules, and `tools/explain.py` for actual HTML bindings and Git changes.
- **Portable storage**: one CRUD interface for memory, localStorage, or a same-origin HTTP API; real SQLite demo uses only Python's standard library.
- **Safety first**: no executable expressions in HTML, no untrusted `innerHTML`, a static directive checker, and local-only SQLite example.

## Run

```sh
python3 -m http.server 8000
# http://127.0.0.1:8000/examples/hello/
# http://127.0.0.1:8000/examples/todo/
# http://127.0.0.1:8000/examples/inventory/
```

For the **real SQLite file** demo:

```sh
python3 server/app.py
# http://127.0.0.1:8765/examples/inventory/?db=sqlite
```

The file lives at `server/data/inventory.sqlite` (Git-ignored). For a consistent backup stop the server first, or use SQLite's online backup API while running. The Python API binds to `127.0.0.1` and has **no login or public-server security controls**. Never expose it to the internet or LAN as-is. Browser localStorage also has no independent backup.

## Read the design and change history

```sh
python3 tools/explain.py examples/inventory
python3 tools/explain.py examples/inventory --since HEAD~1
```

The tool prints the authored design memo, an independently extracted map of HTML bindings, and optionally actual Git change statistics. Notes explain intent; Git history proves which files changed. It does **not** detect authorship or certify security.

## Tests

```sh
npm run check
# Optional: install Playwright and run the real-browser smoke suite
python3 tests/browser_smoke.py
```

No npm install is needed for the standard checks. Python >=3.9 and Node >=20 are sufficient for development; the browser runtime is just modern standard HTML/CSS/JS.

## What is not implemented yet

Browser SQLite WASM/OPFS, schema migrations, PostgreSQL/MySQL/Cloudflare D1 adapters, multi-user auth, sync, full code generation studio, comprehensive accessibility/security reviews. Do not treat this experimental version as production-ready.

## License

MIT. Copyright (c) 2026 ResoArc.
