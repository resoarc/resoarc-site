/* SPDX-FileCopyrightText: 2026 ResoArc Open Technology Project */
/* SPDX-License-Identifier: MIT */
/* v1.0.0: metadata-validated legacy-compatible configuration UI. */
(function(pluginId){
  'use strict';
  const spec={"fields": [{"key": "postalField", "label": "郵便番号フィールド", "allowed": ["SINGLE_LINE_TEXT"], "default": "Zip"}, {"key": "addressField", "label": "住所出力先フィールド", "allowed": ["SINGLE_LINE_TEXT", "MULTI_LINE_TEXT"], "default": "Address"}]};
  const fieldsHost=document.getElementById('ra-fields');
  const status=document.getElementById('ra-status');
  const error=document.getElementById('ra-error');
  const save=document.getElementById('ra-save');
  const retry=document.getElementById('ra-retry');
  const stored=kintone.plugin.app.getConfig(pluginId)||{};
  let config={};
  let metadata=null;
  try{
    const decoded=JSON.parse(stored.ra_settings||'{}');
    if(decoded&&typeof decoded==='object'&&!Array.isArray(decoded))config=decoded;
    else error.textContent='保存済み設定を読み取れません。設定値を確認してください。';
  }catch(_){error.textContent='保存済み設定のJSONが不正です。設定値を確認してください。';}
  const controls={};
  const hint=document.getElementById('ra-hint');
  for(const field of spec.fields){
    const label=document.createElement('label');
    label.htmlFor='ra-field-'+field.key;
    label.textContent=field.label;
    const input=document.createElement('input');
    input.type='text'; input.id=label.htmlFor; input.maxLength=128;
    input.autocomplete='off';
    input.value=typeof config[field.key]==='string'?config[field.key]:field.default;
    input.placeholder='フィールドコードを選択または入力';
    const datalist=document.createElement('datalist');
    datalist.id='ra-options-'+field.key;
    input.setAttribute('list',datalist.id);
    input.addEventListener('input',()=>{
      error.textContent='';
      status.textContent='';
    });
    fieldsHost.appendChild(label);
    fieldsHost.appendChild(input);
    fieldsHost.appendChild(datalist);
    controls[field.key]={input,datalist,field};
  }
  async function fetchFormFields(){
    if(kintone.app&&typeof kintone.app.getFormFields==='function'){
      return kintone.app.getFormFields();
    }
    if(kintone.app&&typeof kintone.app.getId==='function'&&typeof kintone.api==='function'){
      const appId=kintone.app.getId();
      if(appId){
        const response=await kintone.api(
          kintone.api.url('/k/v1/app/form/fields.json',true),
          'GET',{app:appId});
        return response&&response.properties;
      }
    }
    throw Error('この画面ではフィールド一覧を取得できません。');
  }
  async function loadFields(){
    save.disabled=true;
    retry.disabled=true;
    hint.textContent='フィールド一覧を確認中…';
    try{
      const properties=await fetchFormFields();
      if(!properties||typeof properties!=='object'||Array.isArray(properties)||
        Object.keys(properties).length===0)throw Error('フィールド一覧が空です。');
      metadata=properties;
      for(const {datalist,field} of Object.values(controls)){
        datalist.replaceChildren();
        const filtered=Object.entries(properties)
          .filter(([code,item])=>code&&item&&field.allowed.includes(item.type))
          .sort(([a],[b])=>a.localeCompare(b,'ja'));
        for(const [code,item] of filtered){
          const option=document.createElement('option');
          option.value=code;
          option.label=String(item.label||code)+' ('+item.type+')';
          datalist.appendChild(option);
        }
      }
      save.disabled=false;
      hint.textContent='対応するフィールドコードを候補から選んでください。入力値は保存時に型まで検証します。';
      status.textContent='利用可能なフィールド情報を確認しました。';
    }catch(_){
      metadata=null;
      error.textContent='フィールド情報を取得できません。アクセス権または接続を確認し、再試行してください。';
      hint.textContent='未取得：誤設定防止のため保存を停止しています。';
    }finally{retry.disabled=false;}
  }
  retry.addEventListener('click',()=>{error.textContent='';void loadFields();});
  save.addEventListener('click',()=>{
    error.textContent='';status.textContent='';
    if(!metadata){error.textContent='フィールド情報が未取得です。再試行してください。';return;}
    const next={};
    for(const {input,field} of Object.values(controls)){
      const code=input.value.trim();
      const info=Object.prototype.hasOwnProperty.call(metadata,code)?metadata[code]:undefined;
      if(!code||code.length>128||!info||!field.allowed.includes(info.type)){
        error.textContent='「'+field.label+'」には、存在する対応型フィールドを指定してください。';
        input.focus();return;
      }
      next[field.key]=code;
    }
    if(spec.fields.length>1&&new Set(Object.values(next)).size!==spec.fields.length){
      error.textContent='郵便番号と住所のフィールドには別のフィールドを指定してください。';
      return;
    }
    try{
      // Keep the existing JSON settings key and property names, so the
      // old runtime and prior user settings remain compatible.
      kintone.plugin.app.setConfig({ra_settings:JSON.stringify(next)},()=>{
        status.textContent='設定を保存しました。アプリ設定を更新して反映してください。';
      });
    }catch(_){
      error.textContent='設定の保存に失敗しました。権限・接続状況を確認してください。';
    }
  });
  document.getElementById('ra-back').addEventListener('click',()=>history.back());
  void loadFields();
})(kintone.$PLUGIN_ID);
