(function(){'use strict';
const stored=kintone.plugin.app.getConfig(kintone.$PLUGIN_ID)||{};
let cfg={};try{cfg=JSON.parse(stored.ra_settings||'{}')}catch(_){}
cfg=Object.assign({},{"postalField": "Zip", "addressField": "Address"},cfg);
const on=(events,cb)=>kintone.events.on(events,cb);
const parse=s=>String(s||'').split(',').map(x=>x.trim()).filter(Boolean);
const el=(tag,content)=>{const x=document.createElement(tag);if(content!==undefined)x.textContent=String(content);return x;};
const btn=(label,fn)=>{const x=el('button',label);x.type='button';x.className='ra-mini-button';x.style.cssText='background:#176c68;color:white;border:none;border-radius:5px;padding:7px 11px;margin:3px;cursor:pointer';x.addEventListener('click',fn);return x;};
const panel=()=>{let space=null;try{space=kintone.app.record.getHeaderMenuSpaceElement?.()||kintone.app.getHeaderMenuSpaceElement?.()||kintone.app.getHeaderSpaceElement?.();}catch(_){}if(!space)return null;let x=document.getElementById('ra-mini-'+"postal-address");if(x){x.replaceChildren();return x;}x=el('div');x.id='ra-mini-'+"postal-address";x.style.cssText='display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin:8px 0;padding:7px;border:1px solid #bbd8d2;border-radius:6px;background:#f6fbfa;color:#1e4240';space.appendChild(x);return x;};
const cur=()=>{try{return kintone.app.record.get()?.record||null;}catch(_){return null;}};
const val=(r,k)=>r?.[k]?.value;
const scalar=x=>x==null?'':Array.isArray(x)?x.map(v=>v.name||v.code||String(v)).join(', '):String(x);
const template=(t,r,encode=false)=>String(t??'').replace(/\{\{([A-Za-z0-9_]+)\}\}/g,(_,k)=>encode?encodeURIComponent(scalar(val(r,k))):scalar(val(r,k)));
const set=(r,k,value)=>{const item=r?.[k];if(!item||['CALC','RECORD_NUMBER','CREATED_TIME','UPDATED_TIME','CREATOR','MODIFIER','STATUS','STATUS_ASSIGNEE','FILE','SUBTABLE','REFERENCE_TABLE','CATEGORY'].includes(item.type))return false;
const arrays=['CHECK_BOX','MULTI_SELECT','USER_SELECT','ORGANIZATION_SELECT','GROUP_SELECT'];
if(arrays.includes(item.type)){if(!Array.isArray(value))return false;}
else if(value!==null&&typeof value==='object')return false;
item.value=value;return true;};
const apply=r=>{try{kintone.app.record.set({record:r});return true;}catch(err){console.warn('[ResoArc Mini]',err);return false;}};
on(['app.record.create.show','app.record.edit.show'],e=>{
 const root=panel();if(!root)return e;
 const input=el('input');input.inputMode='numeric';input.maxLength=8;input.placeholder='郵便番号7桁';input.setAttribute('aria-label','郵便番号');input.style.cssText='width:115px;padding:6px';
 input.value=scalar(val(e.record,cfg.postalField));const message=el('span','日本郵便の収録データで検索します（外部通信なし）');
 const choices=el('div');
 choices.style.cssText='display:flex;align-items:center;gap:6px;flex-wrap:wrap';
 let lookupNumber=0;
 input.addEventListener('input',()=>{
   lookupNumber++;
   choices.replaceChildren();
   message.textContent='郵便番号が変わりました。検索し直してください';
 });
 const reflect=(candidate,zip)=>{
   if(!candidate||candidate.requiresConfirmation)throw Error('町域を確定できません。住所を手入力してください');
   const address=candidate.prefecture+candidate.city+candidate.town;
   if(!address.trim()||address.length>300||/[\u0000-\u001f\u007f]/.test(address))
     throw Error('住所データが不正です');
   const r=cur();if(!r)throw Error('編集画面を取得できません');
   if(!cfg.postalField||!cfg.addressField||cfg.postalField===cfg.addressField)
     throw Error('郵便番号・住所のフィールド設定を確認してください');
   const postal=r[cfg.postalField],locationField=r[cfg.addressField];
   if(!postal||postal.type!=='SINGLE_LINE_TEXT'||postal.disabled===true)
     throw Error('郵便番号は編集可能な文字列（1行）フィールドにしてください');
   if(!locationField||!['SINGLE_LINE_TEXT','MULTI_LINE_TEXT'].includes(locationField.type)||locationField.disabled===true)
     throw Error('住所は編集可能な文字列フィールドにしてください');
   const previousZip=postal.value,previousAddress=locationField.value;
   postal.value=zip;locationField.value=address;
   if(!apply(r)){
     postal.value=previousZip;locationField.value=previousAddress;
     throw Error('フォームへの反映に失敗しました');
   }
   const reflected=cur();
   if(reflected?.[cfg.postalField]?.value!==zip||reflected?.[cfg.addressField]?.value!==address)
     throw Error('反映結果を確認できませんでした');
   message.textContent='住所を反映しました（保存はまだです）';
 };
 const search=btn('住所を検索',()=>{
   choices.replaceChildren();
   const zip=input.value.normalize('NFKC').replace(/[^0-9]/g,'');
   if(!/^\d{7}$/.test(zip)){message.textContent='郵便番号は7桁で入力してください';return;}
   let matches=[];
   try{
     if(!globalThis.ResoArcPostalLookup||typeof globalThis.ResoArcPostalLookup.lookup!=='function')
       throw Error('住所データを読み込めませんでした');
     matches=globalThis.ResoArcPostalLookup.lookup(zip);
   }catch(err){message.textContent='検索失敗: '+err.message;return;}
   if(!Array.isArray(matches)||matches.length===0){
     message.textContent='住所が見つかりません。郵便番号を確認してください';return;
   }
   const ticket=++lookupNumber;
   const select=el('select');select.setAttribute('aria-label','該当する住所を選択');
   select.style.cssText='max-width:100%;padding:5px';
   for(let i=0;i<matches.length;i++){
     const candidate=matches[i];
     const option=el('option',candidate.prefecture+candidate.city+candidate.town);
     option.value=String(i);select.appendChild(option);
   }
   const confirm=btn('選択した住所を反映',()=>{
     try{
       if(ticket!==lookupNumber||!input.isConnected||input.value.normalize('NFKC').replace(/[^0-9]/g,'')!==zip)
         throw Error('郵便番号が変更されました。再検索してください');
       const candidate=matches[Number(select.value)];
       reflect(candidate,zip);
     }catch(err){message.textContent='反映できません: '+err.message;}
   });
   choices.append(select,confirm);
   const requires=matches.some(x=>x.requiresConfirmation);
   message.textContent=matches.length>1
     ?'住所候補が'+matches.length+'件あります。確認して選択してください'
     :'住所を確認して「選択した住所を反映」を押してください';
   if(requires)message.textContent+='。「以下に掲載がない場合」等は町域を手入力してください';
 });
 root.append(input,search,message,choices);return e;

});

})();
