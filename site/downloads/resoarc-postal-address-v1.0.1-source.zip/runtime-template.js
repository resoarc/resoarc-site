/* SPDX-FileCopyrightText: 2026 ResoArc Open Technology Project
 * SPDX-License-Identifier: MIT
 * Offline postcode search. Derived from Japan Post UTF-8 data (2026-10-30).
 * Source: https://www.post.japanpost.jp/service/search/zipcode/download/
 * No network calls, browser storage or external dependencies.
 */
(function(root) {
"use strict";
const UPDATED="2026-10-30";
const PREFECTURES=__PREFS__;
const CITIES=__CITIES__;
const BLOCKS=__BLOCKS__;
const CACHE=new Map();
function normalize(value) {
  if (value === null || value === undefined) return null;
  const s=String(value).normalize("NFKC").replace(/[\s\u002d\u2010\u2011\u2212\u30fc]/g,"");
  return /^\d{7}$/.test(s) ? s : null;
}
function parsePrefix(prefix) {
  if (CACHE.has(prefix)) return CACHE.get(prefix);
  const text=BLOCKS[prefix], out=new Map();
  if (text) {
    for (const line of text.split("\n")) {
      const a=line.indexOf("\t"),b=line.indexOf("\t",a+1),c=line.indexOf("\t",b+1);
      if (a<0 || b<0 || c<0) throw Error("Corrupt postcode block");
      const code=prefix+line.slice(0,a);
      const prefecture=PREFECTURES[Number(line.slice(a+1,b))];
      const city=CITIES[Number(line.slice(b+1,c))];
      const town=line.slice(c+1);
      if (!prefecture || !city) throw Error("Invalid postcode dictionary");
      const candidate=Object.freeze({
        zip:code,prefecture,city,town,
        requiresConfirmation:town==="以下に掲載がない場合" ||
          town.includes("の次に番地がくる場合") || town.endsWith("一円")
      });
      if(!out.has(code))out.set(code,[]);
      out.get(code).push(candidate);
    }
  }
  CACHE.set(prefix,out);
  return out;
}
root.ResoArcPostalLookup=Object.freeze({
  source:"Japan Post official downloadable postcode data",
  updateDate:UPDATED,
  lookup(input) {
    const code=normalize(input);
    if (!code)return [];
    return (parsePrefix(code.slice(0,3)).get(code)||[]).slice();
  },
  stats() {
    return Object.freeze({
      prefixCount:Object.keys(BLOCKS).length,
      loadedPrefixCount:CACHE.size
    });
  }
});
})(globalThis);