// SPDX-FileCopyrightText: 2026 ResoArc Open Technology Project
// SPDX-License-Identifier: MIT
// Generates a deterministic, network-free browser lookup from Japan Post data.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import zlib from "node:zlib";
import {fileURLToPath} from "node:url";
const root=path.dirname(fileURLToPath(import.meta.url));
const csv=path.join(root,"source","utf_ken_all.csv");
const sourceZip=path.join(root,"utf_ken_all-20261030-source.zip");
const output=path.join(root,"postal-index-offline.js");
const fixturePath=path.join(root,"test-fixtures.json");
const metadataPath=path.join(root,"PROVENANCE.json");
const template=fs.readFileSync(path.join(root,"runtime-template.js"),"utf8");
function csvLine(line) {
  let cols=[],part="",quoted=false;
  for (let i=0;i<line.length;i++) {
    const ch=line[i];
    if(ch==='"') {
      if(quoted&&line[i+1]==='"'){part+='"';i++;}
      else quoted=!quoted;
    } else if(ch===','&&!quoted){cols.push(part);part="";}
    else part+=ch;
  }
  if(quoted)throw Error("Unclosed CSV quote");
  cols.push(part);
  return cols;
}
const src=fs.readFileSync(csv,"utf8").replace(/^\uFEFF/,"");
let total=0,duplicate=0,sentinel=0;
const rows=[],seen=new Set(),prefSet=new Set(),citySet=new Set();
for(const line of src.split(/\r?\n/)) {
  if(!line)continue;
  const v=csvLine(line);total++;
  if(v.length!==15)throw Error("CSV columns "+v.length+" at "+total);
  const code=v[2],pref=v[6],city=v[7],town=v[8];
  if(!/^\d{7}$/.test(code)||!pref||!city)throw Error("Invalid row "+total);
  if([pref,city,town].some(x=>/[\t\r\n]/.test(x)))throw Error("Invalid delimiter");
  const signature=[code,pref,city,town].join("\t");
  if(seen.has(signature)){duplicate++;continue;}
  seen.add(signature);
  rows.push([code,pref,city,town]);
  prefSet.add(pref);citySet.add(city);
  if(town==="以下に掲載がない場合")sentinel++;
}
const prefs=[...prefSet].sort(),cities=[...citySet].sort();
const prefIds=new Map(prefs.map((x,i)=>[x,i]));
const cityIds=new Map(cities.map((x,i)=>[x,i]));
const groups=Object.create(null),codes=new Map();
for(const [code,pref,city,town] of rows){
  const p=code.slice(0,3),tail=code.slice(3);
  const line=[tail,prefIds.get(pref),cityIds.get(city),town].join("\t");
  (groups[p]??=[]).push(line);
  if(!codes.has(code))codes.set(code,[]);
  codes.get(code).push({zip:code,prefecture:pref,city,town});
}
// Keep source CSV order for multiple address candidates.
const blocks=Object.fromEntries(Object.entries(groups).sort(([a],[b])=>a.localeCompare(b))
  .map(([p,arr])=>[p,arr.join("\n")]));
if(!template.includes("__PREFS__")||!template.includes("__CITIES__")||!template.includes("__BLOCKS__"))throw Error("Template invalid");
const compiled=template.replace("__PREFS__",JSON.stringify(prefs))
  .replace("__CITIES__",JSON.stringify(cities))
  .replace("__BLOCKS__",JSON.stringify(blocks));
fs.writeFileSync(output,compiled,"utf8");
const allCodes=[...codes.keys()].sort();
const sample=["0600000","1000001","7300001","0790177","0000000",
 ...Array.from({length:80},(_,i)=>allCodes[Math.floor(i*(allCodes.length-1)/79)])];
const fixtures=[...new Set(sample)].map(zip=>({zip,expected:codes.get(zip)||[]}));
fs.writeFileSync(fixturePath,JSON.stringify(fixtures,null,2)+"\n","utf8");
const digest=file=>crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
const jsBytes=fs.statSync(output).size;
if(jsBytes>20*1024*1024)throw Error("Exceeds Kintone JS file limit");
const result={
  source:"Japan Post official downloadable postcode data",
  sourceDate:"2026-10-30",
  downloadedForPrototype:"2026-11-09",
  sourceUrl:"https://www.post.japanpost.jp/service/search/zipcode/download/utf/zip/utf_ken_all.zip",
  redistributionTerms:"https://www.post.japanpost.jp/service/search/zipcode/download/utf-readme.html",
  sourceZipSHA256:digest(sourceZip),sourceCsvSHA256:digest(csv),indexJsSHA256:digest(output),
  csvRows:total,duplicateAddressRows:duplicate,uniqueAddressRows:rows.length,
  distinctPostcodes:codes.size,prefixBlocks:Object.keys(blocks).length,
  prefectures:prefs.length,cities:cities.length,unspecifiedTownRows:sentinel,
  indexJsBytes:jsBytes,gzipEstimateBytes:zlib.gzipSync(Buffer.from(compiled),{level:9}).length,
  fixtures:fixtures.length,externalNetworkRequestsAtRuntime:0,
  signedPluginBuilt:false,realKintoneTested:false
};
fs.writeFileSync(metadataPath,JSON.stringify(result,null,2)+"\n");
console.log(JSON.stringify(result,null,2));