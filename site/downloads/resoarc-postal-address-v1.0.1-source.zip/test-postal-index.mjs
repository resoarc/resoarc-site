// SPDX-FileCopyrightText: 2026 ResoArc Open Technology Project
// SPDX-License-Identifier: MIT
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import assert from "node:assert/strict";
import {fileURLToPath} from "node:url";
const root=path.dirname(fileURLToPath(import.meta.url));
const source=fs.readFileSync(path.join(root,"postal-index-offline.js"),"utf8");
const fixture=JSON.parse(fs.readFileSync(path.join(root,"test-fixtures.json"),"utf8"));
const provenance=JSON.parse(fs.readFileSync(path.join(root,"PROVENANCE.json"),"utf8"));
assert.ok(source.length>1000000);
for(const forbidden of ["fetch(", "XMLHttpRequest", "WebSocket(", "localStorage.", "sessionStorage.", "sendBeacon("]){
  assert.ok(!source.includes(forbidden),"Unexpected network/storage API "+forbidden);
}
const scope=vm.createContext({console});
const started=performance.now();
vm.runInContext(source,scope,{timeout:15000,filename:"postal-index-offline.js"});
const parseMs=performance.now()-started;
const lookup=scope.ResoArcPostalLookup;
assert.equal(typeof lookup.lookup,"function");
assert.equal(lookup.updateDate,provenance.sourceDate);
assert.equal(lookup.stats().loadedPrefixCount,0,"not lazy");
assert.equal(lookup.stats().prefixCount,provenance.prefixBlocks);
let passed=0;
for(const {zip,expected} of fixture){
  const actual=lookup.lookup(zip);
  const simple=JSON.parse(JSON.stringify(actual.map(a=>({
    zip:a.zip,prefecture:a.prefecture,city:a.city,town:a.town
  }))));
  assert.deepEqual(simple,expected,"lookup differs for "+zip);
  assert.ok(actual.every(a=>typeof a.requiresConfirmation==="boolean"));
  passed++;
}
const src=lookup.lookup("0600000");
assert.ok(src.length>0 && src.some(x=>x.prefecture==="北海道"));
assert.deepEqual(lookup.lookup("060-0000").length,src.length);
assert.deepEqual(lookup.lookup("０６０－００００").length,src.length);
assert.ok(lookup.lookup("1000001").some(a=>a.prefecture==="東京都"));
assert.ok(lookup.lookup("0295523").length>1,"many-to-one must be preserved");
assert.ok(lookup.lookup("0600000").some(a=>a.requiresConfirmation===true));
for(const invalid of [null,undefined,NaN,"foo","123456","12345678","1234567x","<script>","012 345 678"]){
  assert.equal(lookup.lookup(invalid).length,0,"bad postcode accepted");
}
const first=lookup.lookup("1000001");
const firstLength=first.length;
first.pop();
assert.equal(lookup.lookup("1000001").length,firstLength,"cache mutated by caller");
assert.ok(lookup.stats().loadedPrefixCount<100,"should lazily parse only used prefixes");
const elapsed=performance.now()-started;
console.log(JSON.stringify({
  result:"PASS",fixtureChecks:passed,normalizationChecks:2,multipleAddressChecks:1,
  invalidInputChecks:9,immutableResultChecks:1,noNetworkChecks:6,
  lazyPrefixes:lookup.stats().loadedPrefixCount,
  startupMs:Math.round(parseMs),totalMs:Math.round(elapsed),
  sourceRows:provenance.csvRows,distinctPostcodes:provenance.distinctPostcodes
},null,2));