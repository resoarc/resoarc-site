# ResoArc Sheet v1.0.0-rc.2 第三者ソース10項目の条件付き例外案

日付：2026-11-18 JST

**判定：条件付きの例外承認候補（承認は未実施）。**

## 確認済みの根拠

- npm配布元のExcelJS 4.4.0をSHA-512照合済み。配布されたソースマップとインストール済みの6ファイルはバイト単位で一致。
- 10件の元ソースは、検証済みExcelJSソースマップに掲載されている。
- 対象は3ライブラリ：@fast-csv/parse 5件、@fast-csv/format 4件、xmlchars 1件。
- MIT候補ライセンス文面は実配布ZIPのlicenses/に同梱されている。
- 第三者通知には変換済みソースの厳密な版が未証明である旨が明記されている。
- ただし、個々の元版と全10ファイルの意味的同一性は未証明。バイト不一致から直ちにライセンス違反を認定しない。

## 対象10ファイル

| パッケージ | ソースマップ内のファイル | ソースSHA-256冒頭 | 通知に使われた候補版（確定版ではない） |
|---|---|---|---|
| @fast-csv/format | build/src/FormatterOptions.js | 7ac0c7355ec0811d | 4.3.5 |
| @fast-csv/format | build/src/formatter/FieldFormatter.js | fa351a853bd24bd8 | 4.3.5 |
| @fast-csv/format | build/src/formatter/RowFormatter.js | 2a76c862c5aa969a | 4.3.5 |
| @fast-csv/format | build/src/index.js | 01ce74fe08483c4f | 4.3.5 |
| @fast-csv/parse | build/src/CsvParserStream.js | 65af74d673ace6b1 | 4.3.6 |
| @fast-csv/parse | build/src/ParserOptions.js | 171414fea2015364 | 4.3.6 |
| @fast-csv/parse | build/src/index.js | 5b3ad5686f6fa5c5 | 4.3.6 |
| @fast-csv/parse | build/src/transforms/HeaderTransformer.js | 8af80a5223de41cc | 4.3.6 |
| @fast-csv/parse | build/src/transforms/RowTransformerValidator.js | 8e71c51a7e482b81 | 4.3.6 |
| xmlchars | xmlns/1.0/ed3.js | f26e032a6eebabd1 | 2.2.0 |

完全SHA-256、ソースマップ出典、通知ファイルパス・ハッシュは compliance/VENDOR_10_EXCEPTION_REGISTER.json に保存。

## 提案するリリース時の扱い

1. **バージョン未特定をそのまま開示**：候補版を確定版として表示しない。ライブラリ一覧は候補版と未証明ステータスを併記。
2. **条件付き例外（P2追跡）**：個々の版番号の未特定だけを理由に、内部RCの利用を停止しない。
3. **公開前ゲート（P0）**：元のExcelJS tarball整合、10件のソースハッシュ、MIT通知と著作権表示の同梱、他のライセンスと矛盾しないことを確認。
4. **変更時の再監査（P0）**：ExcelJSの配布元、ソースマップ、10件のソースハッシュまたは通知文面が変更されたら例外を再審査。
5. **停止条件**：ライセンス文面の欠落、相反する著作権・ライセンス情報、親パッケージの整合性不一致、未審査ソース増加があれば公開を保留。
6. **責任者の承認が必要**：条件付き例外はまだ提案段階。法的な完全保証ではなく、v1.0.0の公開には別途承認と配布物の確認が必要。
7. **通知の旧見出しを修正**：RC2のTHIRD_PARTY_NOTICES.md表題と候補版の説明は修正済み。RC1の配布ZIPとタグは変更していない。

## ユーザー向けの短い表記案

本製品はExcelJS 4.4.0等のオープンソースコードを利用します。一部の変換済み依存ソースは個別の厳密な元バージョンが未特定です。配布物には確認できた著作権・ライセンス通知を同梱し、候補版と未確定の状態を区別して記載しています。

## 現時点の判定

- ExcelJS 4.4.0からの来歴：確認済み。
- ライセンス通知の実在：確認済み。
- 元ソースファイルの厳密な版：一部未証明。
- この10件のみで技術的なRC承認を撤回する必要：現時点でなし。
- この調査だけで正式版公開を無条件許可：不可。
- Excel GUIの修復警告なし目視などは別の正式版ゲート。

参照：RC1_EXCELJS_NPM_PROVENANCE_20261118.json、RC1_LICENSE_VARIANT_SOURCE_MATCH_20261118.json、RC1_CYCLONEDX_SBOM_20261118.json。


## RC2 review status

- Documentation and technical evidence completed.
- The proposed conditional exception is **not signed off**.
- Source map hashes and notice presence are automatically checked by the RC2 release gate.
- Official v1.0.0 deployment remains blocked pending final release review and Excel GUI acceptance.
