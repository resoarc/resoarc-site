# ResoArc Sheet v1.0.0-rc.2: 受入基準

**RCは正式版と同一ではありません。受入に不合格の項目を隠して一般公開しないこと。**

## 必須受入条件 (P0)
1. GitでRCコードを独立して固定し、clean `npm ci`、`npm test`、`npm run build` がすべて成功する
2. 配布ZIP内の `ResoArc-Sheet.html` をファイルとして直接開き、Edge・Chrome・FirefoxでXLSXを読込できる
3. 4形式（機能保持XLSX、簡易版XLSX、CSV、JSON）を3ブラウザでダウンロード・解析できる
4. 機能保持XLSXは既存セル値・式を反映し、グラフ・画像・OOXML部品を欠落させない
5. 元ファイルの高度な機能が消失する簡易版XLSXは利用者の明示同意と欠落項目の確認後のみ保存される
6. Excelデスクトップ 16.0で機能保持・簡易版・新規作成のXLSXを通常Openし、文字列・数式・再計算・グラフ・画像を確認する
7. 配布ZIP、ソースZIP、HTMLに各SHA-256を発行し、全アーカイブを展開・ハッシュ照合する
8. 原本を上書きしないこと、既存公式サイトと旧リリースを変更しないこと

## 追加検証と未解決事項 (P1)
- Excel GUI上で警告・修復ダイアログが一切出ないか目視受入。COMの正常OpenはGUIの証明ではない
- 双方向のExcel/ブラウザ間貼り付け、1万・5万行の性能と複雑なブックの全数式計算
- 第三者ベンダー68件のうち9件はライセンス本文まで照合したが、変換済みソースの版完全特定は未了
- GitHub ActionsのWindows/Ubuntu実行結果（ローカル成功と分離して記録）
- 高度機能の編集やマクロには未対応。簡易版保存で失われるものはユーザーに確認させる

## 正式版の判定
P0すべてPASS、実際に存在する配布物とハッシュの一致が成立すれば候補を受理可能。P1に未確認がある場合は本番公開前に影響と判断を記録する。既存タグを上書きせず正式版は新しいタグで発行する。

## RC2 additional attribution gate

1. \`THIRD_PARTY_NOTICES.md\` must say v1.0.0-rc.2, not inherit the v0.7.0 beta heading.
2. Both candidate MIT notices for @fast-csv/parse and @fast-csv/format and the xmlchars MIT notice must remain bundled with all copyright and license texts.
3. All ten source-map entries and their SHA-256 hashes must match the ExcelJS 4.4.0 registry-verified source map used to produce the build.
4. \`compliance/VENDOR_10_EXCEPTION_DECISION.md\` explicitly marks the disposition as proposed, not independently legally certified or approved.
5. Stable v1.0.0 distribution still requires an explicit owner release decision, and Excel GUI visual acceptance; do not change the v1.0.0-rc.1 tag.
