import {chromium,firefox} from 'playwright-core';
import {readFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import assert from 'node:assert/strict';

const configs=[
 {name:'Edge',engine:chromium,exe:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'},
 {name:'Chrome',engine:chromium,exe:'C:/Program Files/Google/Chrome/Application/chrome.exe'},
 {name:'Firefox',engine:firefox},
];
const out=join(process.cwd(),'tests','qa-artifacts','sheet-guard-regression-offline');
await mkdir(out,{recursive:true});
let failures=0;
for(const browserConfig of configs){
 let browser;const findings={browser:browserConfig.name,checks:[],pageErrors:[]};
 try{
  browser=await browserConfig.engine.launch({headless:true,...browserConfig.exe?{executablePath:browserConfig.exe}:{}});
  const page=await browser.newPage({viewport:{width:1360,height:850},acceptDownloads:true});
  page.on('pageerror',e=>findings.pageErrors.push(e.message));
  page.on('dialog',d=>d.accept());
  const status=page.locator('.statusbar [role=status]');
  const goto=async addr=>{
   const box=page.getByRole('textbox',{name:'名前ボックス'});
   await box.fill(addr);await box.press('Enter');
  };
  const backup=async label=>{
   await page.getByRole('tab',{name:'ファイル'}).click();
   const download=page.waitForEvent('download',{timeout:15000});
   await page.getByRole('button',{name:'バックアップ',exact:true}).click();
   const f=await download;const dest=join(out,browserConfig.name+'-'+label+'.json');
   await f.saveAs(dest);return JSON.parse(await readFile(dest,'utf8'));
  };
  await page.goto(process.env.RESOARC_OFFLINE_URL,{waitUntil:'networkidle'});
  await page.locator('input[accept=".xlsx,.csv"]').setInputFiles({name:'guard.csv',mimeType:'text/csv',buffer:Buffer.from('name,qty\nBlue,3\nBeta,1\nBravo,2\n')});
  await status.getByText('読み込みました。',{exact:false}).waitFor({timeout:18000});
  await goto('A2');
  await page.getByRole('button',{name:'絞り込み',exact:true}).click();
  const filter=page.getByRole('dialog',{name:'列の簡易フィルター'});
  await filter.getByLabel('含む文字').fill('Blue');
  await filter.getByRole('button',{name:'絞り込む'}).click();
  assert.match(await filter.locator('[role=status]').innerText(),/行を表示/);
  await filter.getByRole('button',{name:'閉じる'}).last().click();
  const before=await backup('before-insert');
  await page.getByRole('tab',{name:'挿入'}).click();
  await page.getByRole('button',{name:'上に行を挿入'}).click();
  assert.match(await status.innerText(),/簡易フィルター中は行・列の挿入ができません/);
  const after=await backup('after-insert');
  assert.equal(after.sheets[0].row,before.sheets[0].row);
  assert.deepEqual(after.sheets[0].data,before.sheets[0].data);
  findings.checks.push('filter blocks ribbon row insertion');
  const nativeBlocked=await page.locator('.grid-wrap').evaluate(el=>!el.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true,cancelable:true})));
  assert.equal(nativeBlocked,true);
  findings.checks.push('filter blocks native context menu');
  await page.getByRole('button',{name:'絞り込み解除'}).click();
  assert.match(await status.innerText(),/簡易フィルターを解除/);
  findings.checks.push('filter clear after rejected insertion');
  const target=await backup('before-protected');
  target.sheets[0].config={...target.sheets[0].config,protect:true};
  await page.locator('input[accept=".json"]').setInputFiles({
   name:'protected.resoarc.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(target)),
  });
  await status.getByText('読み込みました。',{exact:false}).waitFor({timeout:15000});
  const loaded=await backup('protected-loaded');
  assert.equal(loaded.sheets[0].config.protect,true,'Protection flag lost during JSON restore');
  await goto('A2');
  const formula=page.getByRole('textbox',{name:'数式バー'});
  await formula.fill('HACKED');await formula.press('Enter');
  assert.match(await status.innerText(),/保護されたシートでは編集できません/);
  findings.checks.push('protected formula bar cannot edit');
  await page.getByRole('button',{name:'昇順',exact:true}).click();
  assert.match(await status.innerText(),/保護されたシートでは編集できません/);
  findings.checks.push('protected sort rejected');
  await page.getByRole('tab',{name:'挿入'}).click();
  await page.getByRole('button',{name:'上に行を挿入'}).click();
  assert.match(await status.innerText(),/保護されたシートでは編集できません/);
  findings.checks.push('protected row insertion rejected');
  const protectedAfter=await backup('protected-after');
  assert.deepEqual(protectedAfter.sheets[0].data,loaded.sheets[0].data,'Protected sheet contents changed');
  assert.equal(protectedAfter.sheets[0].row,loaded.sheets[0].row);
  const protectedMenu=await page.locator('.grid-wrap').evaluate(el=>!el.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true,cancelable:true})));
  assert.equal(protectedMenu,true);
  findings.checks.push('protected context menu blocked');
  assert.deepEqual(findings.pageErrors,[]);
  findings.status='PASS';
 }catch(e){findings.status='FAIL';findings.error=String(e.stack||e).slice(0,1700);failures++;}
 finally{console.log(JSON.stringify(findings));if(browser)await browser.close().catch(()=>{});}
}
if(failures)process.exitCode=1;
