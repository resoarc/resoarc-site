import {chromium,firefox} from 'playwright-core';
import {readFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import ExcelJS from 'exceljs';

const root=process.cwd(),source=join(root,'tests/qa-artifacts/complex-acceptance-20261116.xlsx');
const destDir=join(root,'tests/qa-artifacts/complex-acceptance-results');
await mkdir(destDir,{recursive:true});
const variants=[
 {name:'Edge', engine:chromium,exe:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'},
 {name:'Chrome',engine:chromium,exe:'C:/Program Files/Google/Chrome/Application/chrome.exe'},
 {name:'Firefox',engine:firefox},
];
const original=await JSZip.loadAsync(await readFile(source));
let errors=0;
for(const v of variants){
 let browser;const result={browser:v.name,checks:[],errors:[],dialogs:[]};
 try{
  browser=await v.engine.launch({headless:true,...v.exe?{executablePath:v.exe}:{}});
  const page=await browser.newPage({viewport:{width:1380,height:900},acceptDownloads:true});
  page.on('pageerror',e=>result.errors.push(e.message));
  page.on('dialog',async d=>{result.dialogs.push(d.message().slice(0,250));await d.accept();});
  await page.goto(process.env.RESOARC_BASE_URL||'http://127.0.0.1:5174/',{waitUntil:'networkidle'});
  await page.locator('input[accept=".xlsx,.csv"]').setInputFiles(source);
  await page.getByText('読み込みました。',{exact:false}).first().waitFor({timeout:30000});
  result.warnings=await page.locator('.notice-line').allTextContents();
  await page.getByRole('tab',{name:'ファイル'}).click();
  const safe=page.getByRole('button',{name:'安全保存'});
  await safe.waitFor({timeout:30000});
  await page.waitForFunction(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.textContent.includes('安全保存'));return !!b && !b.disabled;},{timeout:30000});
  result.checks.push('complex workbook imported and safe save enabled');
  const box=page.getByRole('textbox',{name:'名前ボックス'});
  await box.fill('B4');await box.press('Enter');
  const formula=page.getByRole('textbox',{name:'数式バー'});
  result.before=await formula.inputValue();
  assert.equal(result.before.trim(),'3','Original B4 expected 3');
  await formula.fill('7');await formula.press('Enter');
  const d=page.waitForEvent('download',{timeout:35000});
  await safe.click();
  const download=await d;
  const path=join(destDir,v.name+'-preserved.xlsx');await download.saveAs(path);
  const after=await JSZip.loadAsync(await readFile(path));
  const required=Object.keys(original.files).filter(n=>!original.files[n].dir&&/^(xl\/charts\/|xl\/media\/|xl\/drawings\/|xl\/styles\.xml|xl\/theme\/)/.test(n));
  for(const name of required){
   assert.ok(after.file(name),'missing '+name);
   const a=await original.file(name).async('uint8array'),b=await after.file(name).async('uint8array');
   assert.deepEqual(a,b,'complex original asset changed: '+name);
  }
  result.checks.push('kept chart,image,drawings,styles exactly '+required.length+' OOXML parts');
  const wb=new ExcelJS.Workbook();await wb.xlsx.readFile(path);
  assert.equal(wb.getWorksheet('売上とグラフ').getCell('B4').value,7);
  assert.equal(wb.getWorksheet('備考').getCell('A2').value,'残すべき値');
  assert.equal(wb.getWorksheet('売上とグラフ').getCell('A1').isMerged,true);
  assert.equal(wb.getWorksheet('売上とグラフ').getImages().length,1);
  assert.ok(wb.getWorksheet('売上とグラフ').conditionalFormattings.length>0);
  result.checks.push('edited value, merged cell, image, conditional formatting, second sheet survived');
  assert.deepEqual(result.errors,[]);
  result.status='PASS';
 }catch(e){errors++;result.status='FAIL';result.error=String(e.stack||e).slice(0,1800);}
 finally{console.log(JSON.stringify(result));if(browser)await browser.close().catch(()=>{});}
}
if(errors)process.exitCode=1;
