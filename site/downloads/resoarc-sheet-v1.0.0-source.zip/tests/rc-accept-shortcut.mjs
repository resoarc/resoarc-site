if(!process.env.RC_QA_DIR||!process.env.RC_HTML_URL)throw Error('Required: RC_QA_DIR, RC_HTML_URL');
import {chromium} from 'playwright-core';
import {readFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import ExcelJS from 'exceljs';
import assert from 'node:assert/strict';
const root=join(process.env.RC_QA_DIR,'shortcut');
await mkdir(root,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
const result={result:'FAIL',checks:[],dialogs:[]};
try {
 const page=await browser.newPage({viewport:{width:1280,height:880},acceptDownloads:true});
 page.on('dialog',async d=>{result.dialogs.push(d.message());await d.accept()});
 await page.goto(process.env.RC_HTML_URL,{waitUntil:'networkidle'});
 // Ensure the React workbook and its global keydown handler are mounted.
 await page.getByRole('textbox',{name:'ワークブック名'}).waitFor({timeout:20000});
 await page.waitForTimeout(350);
 await page.keyboard.press('Control+s');
 const d=page.getByRole('dialog',{name:'形式を選んで保存'});
 await d.waitFor({timeout:10000});
 assert.equal(await d.getByRole('radio',{name:/Excel機能を保持して保存/}).isDisabled(),true);
 assert.equal(await d.getByRole('radio',{name:/標準XLSXで保存/}).isChecked(),true);
 assert.equal(await d.getByRole('checkbox').count(),0);
 result.checks.push('Ctrl+S opens format chooser; new workbook defaults to standard XLSX');
 const promise=page.waitForEvent('download',{timeout:30000});
 await d.getByRole('button',{name:'この形式で保存'}).click();
 const download=await promise;
 assert.ok(download.suggestedFilename().endsWith('.xlsx'));
 const output=join(root,'newbook.xlsx');await download.saveAs(output);
 const wb=new ExcelJS.Workbook();await wb.xlsx.readFile(output);
 assert.equal(wb.worksheets.length,1);
 result.checks.push('new workbook saved a valid ExcelJS-readable XLSX');
 result.result='PASS';
}catch(e){result.error=String(e.stack||e).slice(0,1300)}
finally{await browser.close().catch(()=>{})}
console.log(JSON.stringify(result));
if(result.result!=='PASS')process.exitCode=1;
