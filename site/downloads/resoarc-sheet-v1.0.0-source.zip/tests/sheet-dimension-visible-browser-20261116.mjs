import {chromium} from 'playwright-core';
import assert from 'node:assert/strict';
import {join} from 'node:path';
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',args:['--no-first-run']});
try{
 const page=await browser.newPage({viewport:{width:1400,height:850}});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
 await page.goto('http://127.0.0.1:5174/',{waitUntil:'networkidle'});
 await page.locator('input[accept=".xlsx,.csv"]').setInputFiles(join(process.cwd(),'tests','qa-artifacts','input-two-sheets.xlsx'));
 await page.locator('.statusbar').getByText('読み込みました。',{exact:false}).waitFor({timeout:20000});
 await page.waitForTimeout(11000);
 const note=await page.locator('.notice-line').innerText();
 const status=await page.locator('.statusbar').innerText();
 assert.ok(!note.includes('一部を反映できませんでした'), 'Unexpected dimension failure warning: '+note);
 assert.ok(!status.includes('列幅・行高の一部を取り込めませんでした'), 'Unexpected dimension retry exhaustion');
 assert.deepEqual(errors,[]);
 console.log('PASS delayed dimensions on XLSX import',JSON.stringify({note,status}));
}catch(e){console.error('FAIL delayed dimensions on XLSX import',e.stack);process.exitCode=1;}
finally{await browser.close();}
