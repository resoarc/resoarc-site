import {chromium} from 'playwright-core';
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',args:['--no-first-run']});
const errors=[];
try{
 const p=await browser.newPage({viewport:{width:1400,height:900}});
 p.on('dialog',d=>d.accept());p.on('pageerror',e=>errors.push(e.stack||e.message));
 await p.goto('http://127.0.0.1:5174/',{waitUntil:'domcontentloaded'});
 await p.locator('input[accept=".xlsx,.csv"]').setInputFiles({name:'smoke.csv',mimeType:'text/csv',buffer:Buffer.from('name,value\nC,3\nA,1\nB,2')});
 await p.waitForTimeout(2500);
 console.log('LOAD=',await p.locator('.statusbar').innerText());
 await p.getByRole('button',{name:'検索・置換'}).click();
 const d=p.getByRole('dialog',{name:'検索・置換'});
 await d.getByLabel('検索する文字').fill('B');
 await d.getByRole('button',{name:'次を検索'}).click();
 console.log('NOTE=',await d.locator('.sheet-tool-note').allInnerTexts());
 console.log('ERRORS=',JSON.stringify(errors));
 await p.screenshot({path:'tests/qa-artifacts/sheet-search-smoke.png'});
}catch(e){console.log('SMOKE_FAILED',e.stack,JSON.stringify(errors));process.exitCode=1;}
finally{await browser.close();}
