import {chromium} from 'playwright-core';
import assert from 'node:assert/strict';
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',args:['--no-first-run']});
try{
 const page=await browser.newPage({viewport:{width:1400,height:850}});const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:5174/',{waitUntil:'networkidle'});
 await page.locator('input[accept=".xlsx,.csv"]').setInputFiles({name:'cycle.csv',mimeType:'text/csv',buffer:Buffer.from('name\nBeta\nBlue\nBravo\n')});
 await page.locator('.statusbar').getByText('読み込みました。',{exact:false}).waitFor({timeout:15000});
 await page.getByRole('button',{name:'検索・置換'}).click();
 const d=page.getByRole('dialog',{name:'検索・置換'});
 await d.getByLabel('検索する文字').fill('B');
 const names=[],formulas=[],hints=[];
 for(let i=0;i<4;i++){
  await d.getByRole('button',{name:'次を検索'}).click();
  names.push(await page.getByRole('textbox',{name:'名前ボックス'}).inputValue());
  formulas.push(await page.getByRole('textbox',{name:'数式バー'}).inputValue());
  hints.push(await page.locator('.notice-line').innerText());
 }
 console.log('CYCLE_DEBUG',JSON.stringify({names,formulas,hints}));
 assert.deepEqual(names,['A2','A3','A4','A2']);
 assert.deepEqual(formulas,['Beta','Blue','Bravo','Beta']);
 assert.ok(hints.every(v=>v.includes('操作対象: A')));
 assert.deepEqual(errors,[]);
 console.log('PASS repeated search',JSON.stringify({names,formulas}));
}catch(e){console.error('FAIL repeated search',e.stack);process.exitCode=1;}
finally{await browser.close();}
