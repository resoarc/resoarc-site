import {chromium,firefox} from 'playwright-core';
import assert from 'node:assert/strict';
const configs=[
 {name:'Edge',engine:chromium,exe:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'},
 {name:'Chrome',engine:chromium,exe:'C:/Program Files/Google/Chrome/Application/chrome.exe'},
 {name:'Firefox',engine:firefox},
];
const outcomes=[];
for(const config of configs){
 let browser;
 const outcome={browser:config.name,status:'FAIL',errors:[],checks:[]};
 try{
  browser=await config.engine.launch({headless:true,...(config.exe?{executablePath:config.exe}:{})});
  const context=await browser.newContext({viewport:{width:1360,height:900},...(config.name==='Firefox'?{}:{permissions:['clipboard-read','clipboard-write']})});
  const page=await context.newPage();
  page.on('pageerror',err=>outcome.errors.push(String(err)));
  page.on('dialog',d=>d.accept());
  await page.goto('http://127.0.0.1:5174/',{waitUntil:'networkidle'});
  await page.locator('input[accept=".xlsx,.csv"]').setInputFiles({
   name:'features.csv',mimeType:'text/csv',buffer:Buffer.from('name,value\nBlue,3\nBeta,1\nBravo,2\n')
  });
  await page.locator('.statusbar').getByText('読み込みました。',{exact:false}).waitFor({timeout:25000});
  const address=async cell=>{
    const el=page.getByRole('textbox',{name:'名前ボックス'});
    await el.fill(cell);await el.press('Enter');
  };
  await address('A2');
  if(config.name!=='Firefox'){
  await page.getByRole('button',{name:'値をコピー'}).click();
  const copied=await page.evaluate(()=>navigator.clipboard.readText());
  assert.equal(copied,'Blue');outcome.checks.push('clipboard copy');
  await address('C2');
  await page.evaluate(()=>navigator.clipboard.writeText('0007'));
  await page.getByRole('button',{name:'値を貼り付け'}).click();
  await page.locator('.statusbar [role=status]').getByText('C2 から 1セルに値を貼り付けました',{exact:false}).waitFor({timeout:10000});
  outcome.checks.push('clipboard paste with leading zeros');
  }
  await page.getByRole('button',{name:'検索・置換'}).click();
  const dialog=page.getByRole('dialog',{name:'検索・置換'});
  await dialog.getByLabel('検索する文字').fill('B');
  const found=[];
  for(let j=0;j<4;j++){
   await dialog.getByRole('button',{name:'次を検索'}).click();
   found.push(await page.getByRole('textbox',{name:'名前ボックス'}).inputValue());
  }
  assert.deepEqual(found,['A3','A4','A2','A3']);outcome.checks.push('repeated search');
  await dialog.getByRole('button',{name:'閉じる'}).last().click();
  await address('B2');
  await page.getByRole('button',{name:'昇順',exact:true}).click();
  await page.waitForTimeout(1100);
  const sortStatus=await page.locator('.statusbar [role=status]').innerText();
  assert.ok(sortStatus.includes('行全体を並べ替えました'),'Sort status: '+sortStatus);
  outcome.checks.push('row sort');
  await address('A2');
  await page.getByRole('button',{name:'絞り込み',exact:true}).click();
  const filter=page.getByRole('dialog',{name:'列の簡易フィルター'});
  await filter.getByLabel('含む文字').fill('Blue');
  await filter.getByRole('button',{name:'絞り込む'}).click();
  await filter.getByText('1行を表示',{exact:false}).waitFor({timeout:12000});
  await filter.getByRole('button',{name:'閉じる'}).last().click();
  await page.getByRole('button',{name:'絞り込み解除'}).click();
  outcome.checks.push('filter and clear');
  assert.deepEqual(outcome.errors,[]);
  outcome.status='PASS';
 }catch(e){outcome.error=String(e.stack||e).slice(0,800)}
 finally{outcomes.push(outcome);console.log(JSON.stringify(outcome));if(browser)await browser.close().catch(()=>{});}
}
if(outcomes.some(o=>o.status!=='PASS'))process.exitCode=1;
