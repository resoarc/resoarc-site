if(!process.env.RC_QA_DIR||!process.env.RC_HTML_URL)throw Error('Required: RC_QA_DIR, RC_HTML_URL');
import {chromium} from 'playwright-core';
import {mkdir,readFile} from 'node:fs/promises';
import {join} from 'node:path';
import ExcelJS from 'exceljs';
import assert from 'node:assert/strict';

const destination=join(process.env.RC_QA_DIR,'app-created');
await mkdir(destination,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
const errors=[],notes=[];
try{
 const page=await browser.newPage({viewport:{width:1460,height:920},acceptDownloads:true});
 page.on('pageerror',e=>errors.push(e.message));
 page.on('dialog',d=>d.accept());
 await page.goto(process.env.RC_HTML_URL,{waitUntil:'networkidle',timeout:30000});
 await page.getByRole('textbox',{name:'ワークブック名'}).fill('RSからExcelへ_多機能互換性確認');
 const addr=page.getByRole('textbox',{name:'名前ボックス'});
 const form=page.getByRole('textbox',{name:'数式バー'});
 const select=async a=>{await addr.fill(a);await addr.press('Enter')};
 const put=async(a,v)=>{await select(a);await form.fill(String(v));await form.press('Enter')};
 const products=[
  ['ノート','文具',5,270,'',0.10,'','日本語'],
  ['USBケーブル','電子',3,980,'',0.10,'','0000123'],
  ['付箋','文具',12,180,'',0.08,'','軽減8%'],
  ['マグカップ','雑貨',2,1200,'',0.10,'','色を確認'],
  ['充電器','電子',4,1980,'',0.10,'','長い商品名のテスト'],
  ['クリアファイル','文具',8,120,'',0.08,'',''],
  ['デスクライト','電子',2,4200,'',0.10,'','売上高'],
  ['封筒','文具',20,65,'',0.08,'','半角ABC'],
  ['ブックエンド','雑貨',3,1680,'',0.10,'','漢字・カタカナ'],
  ['キーボード','電子',1,4900,'',0.10,'','@exampleは文字列'],
  ['ペンセット','文具',6,650,'',0.08,'','絵文字🌠✨'],
  ['マウス','電子',2,2300,'',0.10,'','負数-23・引用符"']
 ];
 await put('A1','ResoArc Sheet で作った互換性テスト');
 await put('A2','このXLSXをMicrosoft Excelで開き、数式・色・文字・数値・複数シートを確認してください');
 await select('A4');
 await page.getByRole('tab',{name:'ホーム'}).click();
 await page.getByRole('button',{name:'値のみ貼り付け'}).click();
 const table=[['品名','分類','数量','単価','小計','税率','税込売上','備考'],...products];
 const rows=table.map(r=>r.map(v=>String(v??'')).join('\t')).join('\n');
 const dialog=page.getByRole('dialog',{name:/形式を選択して貼り付け/});
 await dialog.getByRole('textbox',{name:'貼り付ける値'}).fill(rows);
 await dialog.getByRole('button',{name:'値を貼り付け'}).click();
 notes.push('paste='+await page.locator('.statusbar').innerText());
 for(let i=5;i<=16;i++){
  await put('E'+i,'=C'+i+'*D'+i);
  await put('G'+i,'=E'+i+'*(1+F'+i+')');
 }
 await put('D18','合計');
 await put('E18','=SUM(E5:E16)');
 await put('G18','=SUM(G5:G16)');
 await put('A20','特殊値');await put('A21','先頭ゼロ');
 await select('B21');await page.getByRole('button',{name:'値のみ貼り付け'}).click();
 const zeroDialog=page.getByRole('dialog',{name:/形式を選択して貼り付け/});
 await zeroDialog.getByRole('textbox',{name:'貼り付ける値'}).fill('00001234');
 await zeroDialog.getByRole('button',{name:'値を貼り付け'}).click();
 await put('A22','負数');await put('B22','-1250.75');
 await put('A23','日本語');await put('B23','東京都足立区 梅島');
 await put('A24','Unicode');await put('B24','星🌠・編み物🧶・矢印→');
 await put('A25','日付文字列');await put('B25','2026/11/16');
 await put('A26','検査式');await put('B26','=SUM(C5:C16)');
 // Build style through actual RS ribbon, no XLSX direct modifications.
 const style=async(a,opts={})=>{
  await select(a);
  if(opts.bold)await page.getByRole('button',{name:'太字'}).click();
  if(opts.fill)await page.getByRole('textbox',{name:'塗りつぶし'}).fill(opts.fill);
  if(opts.font)await page.getByRole('textbox',{name:'文字色'}).fill(opts.font);
  if(opts.center)await page.getByRole('button',{name:'中央揃え'}).click();
 };
 for(let i=0;i<8;i++){
  const a=String.fromCharCode(65+i)+'4';
  await style(a,{bold:true,fill:'#173A69',font:'#ffffff',center:true});
 }
 await style('A1',{bold:true,fill:'#173A69',font:'#ffffff'});
 await style('A20',{bold:true,fill:'#126B6B',font:'#ffffff'});
 await style('D18',{bold:true,fill:'#173A69',font:'#ffffff'});
 await style('E18',{bold:true,fill:'#173A69',font:'#ffffff'});
 await style('G18',{bold:true,fill:'#173A69',font:'#ffffff'});
 await style('B21',{fill:'#FFF1CF'});
 await style('B22',{fill:'#FBE0E6'});
 await style('B24',{fill:'#E6E3FF'});
 // Format a few numeric and percentage cells
 await select('F5');await page.getByRole('button',{name:'パーセント'}).click();
 await select('F6');await page.getByRole('button',{name:'パーセント'}).click();
 await select('E18');await page.getByRole('button',{name:'小数点'}).click();
 // Create a second sheet using RS itself
 await page.getByRole('tab',{name:'挿入'}).click();
 await page.getByRole('button',{name:'新しいシート'}).click();
 await page.waitForTimeout(450);
 notes.push('tabs='+await page.locator('.luckysheet-sheet-area').innerText().catch(()=>'-'));
 const tabs=await page.locator('[class*="sheet-tab"]').allTextContents().catch(()=>[]);
 notes.push('sheet-tabs='+JSON.stringify(tabs.slice(0,12)));
 const current=await page.getByRole('textbox',{name:'名前ボックス'}).inputValue();
 notes.push('address-after-sheet='+current);
 await put('A1','ResoArc Sheet 作成：確認ポイント');
 await put('A3','No.');await put('B3','検証事項');await put('C3','期待値');
 await put('A4','1');await put('B4','売上数値');await put('C4','1枚目のE5=1350');
 await put('A5','2');await put('B5','先頭ゼロ');await put('C5','00001234（文字列）');
 await put('A6','3');await put('B6','日本語');await put('C6','東京都足立区 梅島');
 await put('A7','4');await put('B7','数式');await put('C7','合計、税率、小数点');
 await put('A8','5');await put('B8','色');await put('C8','見出しの紺色・特殊値の色');
 await put('A9','6');await put('B9','シート');await put('C9','2シートあること');
 await page.getByRole('tab',{name:'ホーム'}).click();
 await style('A1',{bold:true,fill:'#173A69',font:'#ffffff'});
 for(const a of ['A3','B3','C3'])await style(a,{bold:true,fill:'#126B6B',font:'#ffffff'});
 // Save through ResoArc Sheet XLSX export
 const downloadPromise=page.waitForEvent('download',{timeout:35000});
 await page.getByRole('tab',{name:'ファイル'}).click();
 await page.getByRole('button',{name:'形式を選んで保存'}).last().click();
 await page.getByRole('dialog',{name:'形式を選んで保存'}).getByRole('button',{name:'この形式で保存'}).click();
 const download=await downloadPromise;
 const out=join(destination,'01_RS作成_RC1_Excelで開く.xlsx');
 await download.saveAs(out);
 const w=new ExcelJS.Workbook();await w.xlsx.readFile(out);
 notes.push('worksheets='+w.worksheets.map(s=>s.name).join('|'));
 const first=w.worksheets[0],second=w.worksheets[1];
 assert.equal(w.worksheets.length,2);
 assert.equal(first.getCell('A5').value,'ノート');
 assert.equal(first.getCell('C5').value,5);
 assert.equal(first.getCell('D5').value,270);
 assert.equal(first.getCell('E5').value.formula,'C5*D5');
 assert.ok(first.getCell('G5').value.formula?.includes('E5*(1+F5)'));
 assert.equal(first.getCell('B21').value,'00001234');
 assert.equal(second.getCell('B7').value,'数式');
 assert.equal(first.getCell('A4').font.bold,true);
 assert.ok(first.getCell('A4').fill?.fgColor);
 assert.deepEqual(errors,[]);
 const report={created_by:'ResoArc Sheet browser UI, not generated by ExcelJS',path:out,bytes:(await readFile(out)).byteLength,sheets:w.worksheets.map(s=>s.name),formula_E5:first.getCell('E5').value,fill_A4:first.getCell('A4').fill,zero_B21:first.getCell('B21').value,notes,errors};
 console.log('RS_EXPORT_PASS',JSON.stringify(report));
}catch(e){console.error('RS_EXPORT_FAIL',e.stack,JSON.stringify({errors,notes}));process.exitCode=1;}
finally{await browser.close()};
