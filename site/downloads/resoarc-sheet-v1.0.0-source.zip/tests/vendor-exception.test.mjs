import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const root=new URL('../',import.meta.url);
const sha256=(b)=>createHash('sha256').update(b).digest('hex');
const read=(p)=>readFile(new URL(p,root));
const parse=async p=>JSON.parse((await read(p)).toString('utf8'));
test('v1.0.0 package version and third-party notices agree, and legacy beta title is not reused',async()=>{
 const pkg=await parse('package.json');
 const notice=(await read('THIRD_PARTY_NOTICES.md')).toString('utf8');
 assert.equal(pkg.version,'1.0.0');
 assert.match(notice,/^# ResoArc Sheet v1\.0\.0:/);
 assert.doesNotMatch(notice.split('\n')[0],/v0\.7\.0/);
 for(const name of ['@fast-csv/parse','@fast-csv/format','xmlchars']){
  assert.ok(notice.includes(name),name);
 }
 assert.match(notice,/candidate\/reference versions only/i);
 assert.match(notice,/conditional approval on 2026-11-20/i);
});
test('all ten exceptions retain their original source-map SHA256 and parent ExcelJS provenance',async()=>{
 const exception=await parse('compliance/VENDOR_10_EXCEPTION_REGISTER.json');
 const prov=await parse('compliance/EXCELJS_NPM_PROVENANCE.json');
 const pkg=await parse('package-lock.json');
 assert.equal(exception.review_status,'DOCUMENTED_EXCEPTION_PROPOSAL_UNAPPROVED');
 assert.equal(exception.affected_files,10);
 assert.equal(exception.items.length,10);
 assert.equal(prov.npm_version,'4.4.0');
 assert.equal(prov.npm_package_integrity_sha512_verified,true);
 assert.equal(prov.installed_distribution_files_byte_identical_to_registry_tarball,true);
 assert.equal(pkg.packages['node_modules/exceljs'].version,'4.4.0');
 const sourceMapPath=require.resolve('exceljs/dist/exceljs.js.map');
 const sourceMapRaw=await readFile(sourceMapPath);
 assert.equal(sha256(sourceMapRaw),exception.parent_sourcemap_sha256);
 const map=JSON.parse(sourceMapRaw.toString('utf8'));
 const sources=new Map(map.sources.map((key,i)=>[key,map.sourcesContent[i]]));
 const names=new Map();
 for(const row of exception.items){
  const source=sources.get(row.source_map_path);
  assert.equal(typeof source,'string',row.source_map_path);
  assert.equal(sha256(Buffer.from(source,'utf8')),row.source_map_content_sha256,row.source_map_path);
  assert.equal(row.candidate_version_is_exact_proof,false);
  assert.equal(row.candidate_license,'MIT');
  assert.match(row.candidate_notice_path,/^licenses\/exceljs-vendors\//);
  names.set(row.name,(names.get(row.name)||0)+1);
 }
 assert.deepEqual([...names].sort((a,b)=>a[0].localeCompare(b[0])),[
  ['@fast-csv/format',4],
  ['@fast-csv/parse',5],
  ['xmlchars',1]
 ]);
});
test('exception disposition is explicitly proposed, not released or legally approved',async()=>{
 const doc=(await read('compliance/VENDOR_10_EXCEPTION_DECISION.md')).toString('utf8');
 assert.match(doc,/未実施|未承認|not signed off/i);
 assert.match(doc,/正式|stable v1\.0\.0/i);
});

test('owner approval is scoped and conditional; stable release remains on hold',async()=>{
 const decision=(await read('compliance/VENDOR_10_OWNER_APPROVAL_20261120.md')).toString('utf8');
 const history=(await read('compliance/VENDOR_10_EXCEPTION_DECISION.md')).toString('utf8');
 const register=await parse('compliance/VENDOR_10_EXCEPTION_REGISTER.json');
 assert.equal(register.affected_files,10);
 assert.match(history,/未実施|未承認/); // historical proposal remains unmodified
 assert.match(decision,/条件付き例外として承認/);
 assert.match(decision,/2026-11-20/);
 for(const term of ['@fast-csv/parse','@fast-csv/format','xmlchars','MIT','再審査','著作権','公開を保留','一般公開：**保留']){
  assert.ok(decision.includes(term),term);
 }
 assert.doesNotMatch(decision,/法的な完全保証として扱う。/);
});
