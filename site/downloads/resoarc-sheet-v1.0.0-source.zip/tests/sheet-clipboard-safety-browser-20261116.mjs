import {chromium} from 'playwright-core';
import assert from 'node:assert/strict';

const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',args:['--no-first-run']});
const errors=[],records=[];
try{
 const context=await browser.newContext({permissions:['clipboard-read','clipboard-write'],viewport:{width:1360,height:820}});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:5174/',{waitUntil:'networkidle'});
 await page.locator('input[accept=".xlsx,.csv"]').setInputFiles({name:'unsafe-text.csv',mimeType:'text/csv',buffer:Buffer.from('name\n@external-command\n+some-text\n-plain-text\n')});
 await page.locator('.statusbar').getByText('読み込みました。',{exact:false}).waitFor({timeout:15000});
 await page.waitForTimeout(400);
 for(const [address,expected] of [['A2',"'@external-command"],['A3',"' +some-text".replace(' ', '')],['A4',"'-plain-text"]]){
  const box=page.getByRole('textbox',{name:'名前ボックス'});
  await box.fill(address);await box.press('Enter');
  await page.getByRole('button',{name:'値をコピー'}).click();
  const actual=await page.evaluate(()=>navigator.clipboard.readText());
  records.push({address,actual});
  assert.equal(actual,expected,address+' was not protected');
 }
 assert.deepEqual(errors,[]);
 console.log('PASS spreadsheet clipboard safety',JSON.stringify(records));
}catch(e){console.error('FAIL spreadsheet clipboard safety',e.stack,JSON.stringify(records),JSON.stringify(errors));process.exitCode=1;}
finally{await browser.close();}
