if(!process.env.RC_QA_DIR||!process.env.RC_HTML_URL||!process.env.RC_FIXTURE)throw Error('Required: RC_QA_DIR, RC_HTML_URL, RC_FIXTURE');
import {chromium,firefox} from 'playwright-core';
import {readFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import JSZip from 'jszip';
import ExcelJS from 'exceljs';
import assert from 'node:assert/strict';

const root=process.env.RC_QA_DIR;
const out=join(root,'rc1-save-formats-results');
await mkdir(out,{recursive:true});
const fixture=process.env.RC_FIXTURE;
const target=process.env.RC_HTML_URL;
const profiles={
 Edge:()=>chromium.launch({headless:true,executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'}),
 Chrome:()=>chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'}),
 Firefox:()=>firefox.launch({headless:true})
};
const names=(process.env.QA_BROWSERS||'Edge,Chrome,Firefox').split(',').map(x=>x.trim());
const overall=[];
for(const name of names){
 const result={browser:name,checks:[],dialog:[],downloads:[],errors:[],status:'FAIL'};
 const browser=await profiles[name]();
 try{
 const page=await browser.newPage({viewport:{width:1400,height:900},acceptDownloads:true});
 page.on('pageerror',e=>result.errors.push(e.message));
 page.on('dialog',async d=>{result.dialog.push(d.message());await d.accept();});
 await page.goto(target,{waitUntil:'networkidle',timeout:60000});
 await page.locator('input[accept=".xlsx,.csv"]').setInputFiles(fixture);
 await page.getByText('読み込みました。',{exact:false}).first().waitFor({timeout:60000});
 await page.waitForFunction(()=>!document.querySelector('#formula-field')?.disabled,undefined,{timeout:30000});
 // Text edit in original workbook.
 await page.getByText('売上データ',{exact:true}).last().click();
 const address=page.getByRole('textbox',{name:'名前ボックス'});
 const formula=page.getByRole('textbox',{name:'数式バー'});
 await address.fill('B6');await address.press('Enter');
 assert.equal(await formula.inputValue(),'ノート');
 await formula.fill('ノート・形式選択テスト');await formula.press('Enter');
 await page.getByRole('tab',{name:'ファイル'}).click();
 await page.getByRole('button',{name:'形式を選んで保存'}).last().click();
 const modal=page.getByRole('dialog',{name:'形式を選んで保存'});
 await modal.waitFor();
 assert.equal(await modal.getByRole('radio',{name:/Excel機能を保持して保存/}).isChecked(),true);
 assert.equal(await modal.getByRole('radio').count(),4);
 result.checks.push('four formats shown and preserve selected by default');
 // First, loss-preserving XLSX
 const preservedEvent=page.waitForEvent('download',{timeout:35000});
 await modal.getByRole('button',{name:'この形式で保存'}).click();
 const preservedDownload=await preservedEvent;
 assert.ok(preservedDownload.suggestedFilename().endsWith('.preserved.xlsx'));
 const preservedFile=join(out,name+'-preserved.xlsx');await preservedDownload.saveAs(preservedFile);
 result.downloads.push(preservedDownload.suggestedFilename());
 const original=await JSZip.loadAsync(await readFile(fixture)),saved=await JSZip.loadAsync(await readFile(preservedFile));
 const origParts=Object.keys(original.files).filter(x=>!original.files[x].dir);
 assert.deepEqual(origParts.filter(x=>!saved.files[x]),[]);
 assert.ok((await saved.file('xl/worksheets/sheet2.xml').async('string')).includes('ノート・形式選択テスト'));
 for(const key of ['xl/drawings/charts/chart1.xml','xl/media/image.png']){
  assert.deepEqual(await saved.file(key).async('uint8array'),await original.file(key).async('uint8array'));
 }
 result.checks.push('preserve mode retains all OOXML parts and updated string');
 // Save the simplified format via checkbox and precise confirmation
 await page.getByRole('tab',{name:'ファイル'}).click();
 await page.getByRole('button',{name:'形式を選んで保存'}).last().click();
 const m=page.getByRole('dialog',{name:'形式を選んで保存'});
 await m.getByRole('radio',{name:/標準XLSXで保存/}).check();
 assert.equal(await m.getByRole('button',{name:'この形式で保存'}).isDisabled(),true);
 await m.getByRole('checkbox',{name:'高度なExcel機能が失われても標準XLSXを作成する'}).check();
 assert.equal(await m.getByRole('button',{name:'この形式で保存'}).isEnabled(),true);
 const simpleEvent=page.waitForEvent('download',{timeout:40000});
 await m.getByRole('button',{name:'この形式で保存'}).click();
 const simplified=await simpleEvent;
 assert.ok(simplified.suggestedFilename().endsWith('.simplified.xlsx'));
 const simpleFile=join(out,name+'-simplified.xlsx');await simplified.saveAs(simpleFile);
 result.downloads.push(simplified.suggestedFilename());
 assert.ok(result.dialog.some(x=>x.includes('【簡易版XLSXへの保存】')&&x.includes('グラフ')));
 const simpleExcel=new ExcelJS.Workbook();await simpleExcel.xlsx.readFile(simpleFile);
 assert.equal(simpleExcel.getWorksheet('売上データ').getCell('B6').value,'ノート・形式選択テスト');
 const simpleZip=await JSZip.loadAsync(await readFile(simpleFile));
 assert.equal(simpleZip.file('xl/drawings/charts/chart1.xml'),null);
 result.checks.push('lossy mode only possible with acknowledgement, exact losses confirmed, simplified filename');
 // CSV through the same Save As chooser
 await page.getByRole('tab',{name:'ファイル'}).click();
 await page.getByRole('button',{name:'形式を選んで保存'}).last().click();
 const cm=page.getByRole('dialog',{name:'形式を選んで保存'});
 await cm.getByRole('radio',{name:/CSVで保存/}).check();
 const csvEvent=page.waitForEvent('download',{timeout:30000});
 await cm.getByRole('button',{name:'この形式で保存'}).click();
 const cd=await csvEvent;assert.ok(cd.suggestedFilename().endsWith('.csv'));
 const csvFile=join(out,name+'.csv');await cd.saveAs(csvFile);
 result.checks.push('CSV selectable and downloaded');
 result.downloads.push(cd.suggestedFilename());
 // JSON through Save As chooser
 await page.getByRole('tab',{name:'ファイル'}).click();
 await page.getByRole('button',{name:'形式を選んで保存'}).last().click();
 const jm=page.getByRole('dialog',{name:'形式を選んで保存'});
 await jm.getByRole('radio',{name:/ResoArc編集バックアップ/}).check();
 const jsonEvent=page.waitForEvent('download',{timeout:30000});
 await jm.getByRole('button',{name:'この形式で保存'}).click();
 const jd=await jsonEvent;assert.ok(jd.suggestedFilename().endsWith('.resoarc.json'));
 const jsonFile=join(out,name+'.resoarc.json');await jd.saveAs(jsonFile);
 const data=JSON.parse(await readFile(jsonFile,'utf8'));assert.equal(data.format,'resoarc-fortune-1');
 result.downloads.push(jd.suggestedFilename());
 result.checks.push('ResoArc backup selectable and valid JSON');
 assert.deepEqual(result.errors,[]);
 result.status='PASS';
 }catch(e){result.error=String(e.stack||e).slice(0,1700)}
 finally{await browser.close().catch(()=>{})}
 overall.push(result);console.log(JSON.stringify(result));
}
if(overall.some(x=>x.status!=='PASS'))process.exitCode=1;
