# Known limitations: ResoArc Sheet v1.0.0

1. Windows版Microsoft Excel 16.0で新規作成・通常保存・安全保存XLSXの開封試験を実施しました。旧通常保存にはExcelが拒否するファイルがありましたが、ExcelJS再シリアライズ後に再試験合格。すべてのExcel機能や環境での完全互換性は保証しません。
2. 高度なグラフ、ピボット、画像、名前定義、入力規則、条件付き書式などは画面上の完全再現を保証しません。 通常保存でこれらの要素の減少が検出された場合は、保存形式選択画面の「標準XLSX」で明示的に機能消失を了承したときのみ、実際の消失項目を列挙して再確認のうえ「.simplified.xlsx」として別ファイル出力します。了承がなければ保存を中止します。
3. 「安全保存」は既存セルの値・数式の編集のみ対応します。構造・書式変更には利用できません。数式のキャッシュはExcelで再計算されるまで古い場合があります。
4. XLSM、XLSB、旧XLS、マクロは非対応です。
5. 並べ替えは最大5,000行までの式・結合・高度なフィルター等のない表を想定し、1行目を見出し扱いします。
6. 簡易フィルター中は行・列の挿入を拒否します。Excelのオートフィルターの完全互換ではありません。
7. クリップボードAPIの読み取り権限はブラウザにより異なり、数式に見える文字列のExcel貼り付け解釈は未検証です。
8. 名前ボックスで移動する対象と、FortuneSheetのグリッド選択枠は完全同期していません。
9. 大規模データ、あらゆるExcel関数やバージョンでの動作を保証するものではありません。原本は保持してください。

10. XLSXを開いた直後の数百ミリ秒～数秒は差分記録準備のため編集を制限します。保存対象セルの漏れを防ぐためです。

11. XLSXの安全検査では1つの内部XMLが16MB、展開合計150MBを超えると取り込みを拒否します。大容量ブックは大量数式・書式の組合せで性能が低下することがあります。

12. ExcelJS 4.4.0 includes 10 transformed source-map modules (5 \`@fast-csv/parse\`, 4 \`@fast-csv/format\`, 1 \`xmlchars\`) whose exact individual npm editions remain unproven. Source map SHA-256 fingerprints and candidate MIT license notices are provided. The limited conditional exception was approved by the owner on 2026-11-20 but is not a legal guarantee or blanket public-release authorization; see \`compliance/VENDOR_10_EXCEPTION_DECISION.md\`.
