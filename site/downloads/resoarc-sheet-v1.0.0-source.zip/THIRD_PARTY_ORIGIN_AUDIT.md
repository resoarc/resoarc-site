# Third-party origin audit, 2026-11-16

68 embedded ExcelJS-related vendors: 59 exact source versions matched in the previous audit; nine transformed/bundled source editions remain unproven.

For those nine, the candidate npm tarball was independently fetched and its MIT/ISC license text was compared with the bundled license copy. All nine matched after whitespace normalization. This confirms permission and notice attribution for the named candidates, **not** the exact source version of the browserified code.

| Candidate package | Version | License | Evidence |
|---|---|---|---|
| @fast-csv/format | 4.3.5 | MIT | npm license text matched |
| @fast-csv/parse | 4.3.6 | MIT | npm license text matched |
| bn.js | 5.2.1 | MIT | npm license text matched |
| buffer | 6.0.3 | MIT | npm license text matched |
| events | 3.3.0 | MIT | npm license text matched |
| inherits | 2.0.4 | ISC | npm license text matched |
| readable-stream | 3.6.2 | MIT | npm license text matched |
| safe-buffer | 5.2.1 | MIT | npm license text matched |
| xmlchars | 2.2.0 | MIT | npm license text matched |

**Version caveat:** the active dependency lockfile records buffer 5.7.1, whereas the prior embedded vendor candidate was 6.0.3. Do not state that the browserified code is conclusively from 6.0.3.

The evidence manifest VENDOR_FINAL_CHECK.json is included in the release archive, alongside VENDOR_ORIGIN_REVIEW.json and licenses/.
