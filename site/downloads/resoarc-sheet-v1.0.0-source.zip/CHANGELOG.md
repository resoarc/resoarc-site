# Changelog

## v1.0.0 (2026-11-20, prepared; not yet published)
- Promote the accepted RC2 capabilities into a separately staged stable-version candidate without overwriting prior tags or archives.
- Detect Excel feature loss even when worksheet OOXML parts have nonstandard filenames; cover the fix with regression tests.
- Preserve explicit consent and precise loss warnings for simplified XLSX exports.
- Record the owner-approved conditional exception for ten transformed ExcelJS source-map modules, without implying exact origin editions or independent legal certification.
- Confirm Excel desktop open-time no-repair acceptance for four RC2 workbooks; offline Edge/Chrome/Firefox x four save formats; Windows/Ubuntu private CI on the preparation baseline.
- Require package-specific final acceptance and explicit release authorization before any public deployment.

## v1.0.0-rc.2 (2026-11-18, unreleased release candidate)
- Correct third-party notice heading from the inherited v0.7.0 beta version to the correct RC2 version.
- Identify the 10 transformed ExcelJS source-map modules explicitly as unproven individual source editions, rather than asserting the candidate versions are exact.
- Bundle the npm-parent and per-file SHA-256 provenance record and the proposed, **not yet approved**, conditional release exception.
- Add regression tests that verify source-map module SHA-256 and disclosure/notice integrity.
- No functional spreadsheet code change beyond displaying the correct RC2 version.


## v1.0.0-rc.1 (2026-11-17)
- 正式版候補として機能範囲を固定。保存時にExcel機能保持XLSX、標準XLSX（明示的な簡易化）、CSV、ResoArc JSONバックアップを選択可能。
- 旧版のExcel通常保存破損、XML読込互換、BOM、安全保存前の編集競合、機能消失の無断保存を修正済み。
- Microsoft Excel 16.0、Edge/Chrome/Firefox、50,000行の基本表のQAに基づく受入試験を再実施するRC。
- 未対応のExcel高度機能と第三者ライセンス来歴の留保を明記。


## v0.7.1-beta.0（2026-11-16、2026-11-17 QA追補）
- FortuneExcelからの通常XLSX出力をExcelJSで再シリアライズし、Excel 16.0が拒否するファイルを修正。Excel 16.0で新規作成と通常保存の実ファイルを確認。
- 複雑なXLSXの通常保存で画像・グラフ・書式などの消失を検出した場合、確認ダイアログで強行可能だった挙動を改め、データ損失を防ぐため通常保存を中止する仕様に変更。
- 2026-11-17保存形式選択画面を追加。Excel機能保持XLSX／標準XLSX（高度機能の明示了承、消失項目再確認、simplified別名保存）／CSV／ResoArc JSONバックアップを選択可能。選択なしの危険な通常保存禁止は維持。
- XLSX取込直後の差分記録競合を修正。元の状態を記録できるまでセル編集・書式変更を制限し、安全保存の変更セル数が0と誤認される状況を防止。
- ExcelのXML名前空間表記とBOMを受け入れ、文字列変更後に#ERROR!となる問題を修正。
- XLSX内部XMLの検査上限を5MBから16MBに調整（展開合計150MB上限は維持）。50000行の性能試験用。
- 単体試験48/48合格。
- 検索・文字列置換、行全体並べ替え、簡易フィルター、オートフィル、値コピー/貼り付けとXLSX保存前比較。
- CSVの空の入力規則設定が並べ替えを妨げる問題を修正。
- 保護シートの編集拒否を共通化し、フィルター中の構造変更を禁止。
- XLSX行高・列幅取込中の構造変更競合を防止。
- Edge・Chrome・Firefoxの各ブラウザでXLSX、複雑なブックの安全保存試験を追加。

## v0.7.0-beta（2026-11-10）
- 最初のオフラインXLSX・CSVエディターβ公開。
- 原本のOOXML構造を維持する値・数式のみの安全保存。
