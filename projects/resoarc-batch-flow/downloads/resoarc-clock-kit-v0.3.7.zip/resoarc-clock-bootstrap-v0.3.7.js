/* ResoArc Clock v0.3.7 one-time install script
 * Run ONLY on your own logged-in kintone test tenant in the browser console.
 * Creates a NEW app. No API tokens or passwords are used or requested.
 * No writes occur until you confirm the prompt.
 * Upload the signed ResoArc Batch Center plugin separately after deploy.
 */
(async () => {
  'use strict';
  const properties={"BatchName":{"type":"SINGLE_LINE_TEXT","code":"BatchName","label":"バッチ名","required":true},"BatchEnabled":{"type":"DROP_DOWN","code":"BatchEnabled","label":"自動実行","options":{"停止":{"label":"停止","index":"0"},"有効":{"label":"有効","index":"1"}},"defaultValue":"停止"},"DailyTime":{"type":"TIME","code":"DailyTime","label":"実行時刻（日本時間）","defaultValue":"03:00"},"ScheduleType":{"type":"DROP_DOWN","code":"ScheduleType","label":"実行方法","options":{"毎日":{"label":"毎日","index":"0"},"間隔":{"label":"間隔","index":"1"},"一回":{"label":"一回","index":"2"}},"defaultValue":"毎日"},"OneTimeAt":{"type":"DATETIME","code":"OneTimeAt","label":"一回実行日時"},"IntervalMinutes":{"type":"NUMBER","code":"IntervalMinutes","label":"実行間隔（分・1～10080）","defaultValue":"60"},"NextRunAt":{"type":"DATETIME","code":"NextRunAt","label":"次回実行予定"},"RunState":{"type":"DROP_DOWN","code":"RunState","label":"実行状態","options":{"待機":{"label":"待機","index":"0"},"実行中":{"label":"実行中","index":"1"},"正常終了":{"label":"正常終了","index":"2"},"要確認":{"label":"要確認","index":"3"}},"defaultValue":"待機"},"LastStartedAt":{"type":"DATETIME","code":"LastStartedAt","label":"最終開始時刻"},"LastFinishedAt":{"type":"DATETIME","code":"LastFinishedAt","label":"最終終了時刻"},"LastResult":{"type":"MULTI_LINE_TEXT","code":"LastResult","label":"直近の実行結果"},"RunHistory":{"type":"MULTI_LINE_TEXT","code":"RunHistory","label":"実行履歴（直近分）"},"RunToken":{"type":"SINGLE_LINE_TEXT","code":"RunToken","label":"実行ロックID"},"Steps":{"type":"SUBTABLE","code":"Steps","label":"処理タスク","fields":{"TaskType":{"type":"DROP_DOWN","code":"TaskType","label":"処理種別","options":{"取得":{"label":"取得","index":"0"},"更新":{"label":"更新","index":"1"},"転記":{"label":"転記","index":"2"},"登録":{"label":"登録","index":"3"}},"defaultValue":"取得"},"TargetApp":{"type":"NUMBER","code":"TargetApp","label":"対象アプリID"},"Query":{"type":"MULTI_LINE_TEXT","code":"Query","label":"取得条件"},"FieldsJSON":{"type":"MULTI_LINE_TEXT","code":"FieldsJSON","label":"項目マッピングJSON"}}}};
  const buildClockLayout=function buildClockLayout(properties) {
  if (!properties || typeof properties !== 'object' || !properties.Steps) throw Error('Clock schema is missing Steps');
  const name = code => {
    const config = properties[code];
    if(!config || config.type === 'SUBTABLE') throw Error('Invalid layout field '+code);
    return {type:config.type,code};
  };
  const rows=[
    ['BatchName','BatchEnabled','RunState'],
    ['ScheduleType','DailyTime','OneTimeAt','IntervalMinutes'],
    ['NextRunAt','LastStartedAt','LastFinishedAt'],
    ['LastResult'],
    ['RunHistory'],
    ['RunToken']
  ].map(fields=>({type:'ROW',fields:fields.map(name)}));
  const table=properties.Steps;
  rows.push({type:'SUBTABLE',code:'Steps',fields:Object.keys(table.fields).map(code=>({
    type:table.fields[code].type,code
  }))});
  return rows;
};
  const provisionClockApp=async function provisionClockApp(request,properties,appName='ResoArc Clock 検証用') {
  if(typeof request!=='function') throw Error('kintone API adapter required');
  if(typeof appName!=='string'||appName.length>64||!appName.trim())throw Error('Invalid app name');
  if(!properties||Object.keys(properties).length<10)throw Error('Clock fields are missing');
  // Plan before any network write, so local definition errors cannot leave an empty app.
  const layout=buildClockLayout(properties);
  let app;
  try {
    const result=await request('/k/v1/preview/app.json','POST',{name:appName});
    app=Number(result?.app);
    if(!Number.isSafeInteger(app)||app<1)throw Error('kintone did not return a valid new app ID');
    const fields=await request('/k/v1/preview/app/form/fields.json','POST',{app,properties});
    if(!fields?.revision)throw Error('Field addition returned no revision');
    const structure=await request('/k/v1/preview/app/form/layout.json','PUT',{app,revision:fields.revision,layout});
    if(!structure?.revision)throw Error('Layout update returned no revision');
    await request('/k/v1/preview/app/deploy.json','POST',{apps:[{app,revision:structure.revision}]});
    return {app,status:'deploy_requested',name:appName};
  } catch (error) {
    // The new app might remain in preview and need manual inspection.
    error.clockAppId=app||null;
    throw error;
  }
};
  if(!/^([a-zA-Z0-9-]+\.)+(cybozu\.com|kintone\.com)$/.test(location.hostname))
    throw Error('Open your own kintone test tenant');
  if(typeof kintone==='undefined'||typeof kintone.api!=='function')
    throw Error('Open a signed-in kintone app page');
  if(!confirm('ResoArc Clock専用の新しい検証用アプリを1つ作成します。既存アプリは変更しません。よろしいですか？'))
    return {cancelled:true};
  let createdAppId=null;
  try{
    const response=await provisionClockApp((path,method,params)=>
      kintone.api(kintone.api.url(path,true),method,params),properties);
    createdAppId=response.app;
    console.info('ResoArc Clock app created; deployment requested. ID:',createdAppId);
    console.info('Next: install signed Batch Center plugin and create read-only API token');
    return response;
  }catch(error){
    console.error('ResoArc Clock setup stopped:',error.message);
    if(error.clockAppId)console.info('New app remains for review. App ID:',error.clockAppId);
    throw error;
  }
})()
